import { VisualMotion, cameraFocus } from "./motion-visual.js";
import * as THREE from "./vendor/three.module.min.js";
const {
  Group,
  Mesh,
  BoxGeometry,
  CylinderGeometry,
  SphereGeometry,
  PlaneGeometry,
  MeshStandardMaterial,
  MeshBasicMaterial,
  Vector3,
  Color,
} = THREE;
const materials = new Map(),
  geometries = new Map();
function mat(color, roughness = 0.8) {
  let k = color + ":" + roughness;
  if (!materials.has(k))
    materials.set(k, new MeshStandardMaterial({ color, roughness }));
  return materials.get(k);
}
function geo(key, fn) {
  if (!geometries.has(key)) geometries.set(key, fn());
  return geometries.get(key);
}
function box(w, h, d, color, x = 0, y = 0, z = 0) {
  const m = new Mesh(
    geo(`b${w},${h},${d}`, () => new BoxGeometry(w, h, d)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}
function sphere(r, color, x = 0, y = 0, z = 0) {
  const m = new Mesh(
    geo("s" + r, () => new SphereGeometry(r, 12, 8)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}
function cylinder(rt, rb, h, color, x = 0, y = 0, z = 0) {
  let m = new Mesh(
    geo(`c${rt},${rb},${h}`, () => new CylinderGeometry(rt, rb, h, 10)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}
function seeded(seed) {
  return () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}
function line(points, color = "#e5f2dd", opacity = 1) {
  let g = new THREE.BufferGeometry().setFromPoints(
    points.map((p) => new Vector3(...p)),
  );
  let m = new THREE.Line(
    g,
    new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity }),
  );
  return m;
}
function circle(x, z, r, color, y = 0.035) {
  const ps = [];
  for (let i = 0; i <= 80; i++) {
    let a = (i / 80) * Math.PI * 2;
    ps.push([x + Math.cos(a) * r, y, z + Math.sin(a) * r]);
  }
  return line(ps, color);
}
function pitchTexture() {
  const c = document.createElement("canvas");
  c.width = 2048;
  c.height = 1326;
  const ctx = c.getContext("2d"),
    rand = seeded(171);
  ctx.fillStyle = "#44752e";
  ctx.fillRect(0, 0, c.width, c.height);
  for (let x = 0; x < 14; x++) {
    ctx.fillStyle = x % 2 ? "rgba(191,209,118,.09)" : "rgba(0,34,9,.075)";
    ctx.fillRect((x * c.width) / 14, 0, c.width / 14, c.height);
  }
  for (let i = 0; i < 180000; i++) {
    let x = rand() * c.width,
      y = rand() * c.height,
      v = rand();
    ctx.fillStyle = v > 0.5 ? "rgba(185,205,110,.11)" : "rgba(10,40,12,.13)";
    ctx.fillRect(x, y, 0.5 + rand(), 2 + rand() * 3);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
function shirtTexture(number, color) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext("2d");
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = "rgba(255,255,255,.9)";
  ctx.font = "bold 16px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("FLOW", 64, 26);
  ctx.font = "bold 70px sans-serif";
  ctx.fillText(String(number).padStart(2, "0"), 64, 100);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function athlete(index, color, keeper = false) {
  const root = new Group(),
    body = new Group();
  root.add(body);
  const skin = ["#cb926d", "#ac7654", "#ebbb99", "#784c35", "#ddad87"][
      index % 5
    ],
    shirt = keeper ? (index < 11 ? "#d2db68" : "#bb8ae8") : color,
    shorts = keeper ? "#253c32" : index < 11 ? "#e6edf3" : "#462e32",
    sock = keeper ? shirt : index < 11 ? "#e8eff3" : shirt;
  const torso = cylinder(0.24, 0.19, 0.46, shirt, 0, 1.2, 0);
  torso.scale.z = 0.62;
  body.add(torso);
  body.add(cylinder(.116,.13,.045,"#eaf4ed",0,1.445,0));
  body.add(box(.045,.32,.018,"#ffffff",-.18,1.2,.13));
  body.add(sphere(0.115, skin, 0, 1.49, 0));
  const head = sphere(0.155, skin, 0, 1.7, 0);
  head.scale.set(0.87, 1.1, 0.95);
  body.add(head);
  const hair = sphere(
    0.156,
    index % 3 === 0 ? "#292018" : "#352b25",
    0,
    1.77,
    -0.02,
  );
  hair.scale.set(0.9, 0.65, 0.95);
  body.add(hair);
  body.add(box(0.38, 0.2, 0.23, shorts, 0, 0.92, 0));
  const number = new Mesh(
    new PlaneGeometry(0.29, 0.31),
    new MeshBasicMaterial({ map: shirtTexture((index % 11) + 1, shirt) }),
  );
  number.position.set(0, 1.24, -0.153);
  number.rotation.y = Math.PI;
  body.add(number);
  const crest = box(0.06, 0.07, 0.01, "#eff7e8", -0.1, 1.34, 0.152);
  body.add(crest);
  const legs = [],
    arms = [];
  for (let sign of [-1, 1]) {
    let hip = new Group();
    hip.position.set(sign * 0.115, 0.9, 0);
    body.add(hip);
    hip.add(cylinder(0.105, 0.085, 0.27, shorts, 0, -0.1, 0));
    hip.add(cylinder(0.085, 0.068, 0.27, skin, 0, -0.26, 0));
    let knee = new Group();
    knee.position.y = -0.39;
    hip.add(knee);
    knee.add(cylinder(0.07, 0.052, 0.31, sock, 0, -0.17, 0));
    knee.add(
      box(
        0.13,
        0.08,
        0.27,
        index % 4 === 0 ? "#e7e545" : "#253036",
        0,
        -0.36,
        0.065,
      ),
    );
    legs.push({ hip, knee });
    let shoulder = new Group();
    shoulder.position.set(sign * 0.25, 1.38, 0);
    body.add(shoulder);
    let sleeve = cylinder(0.083, 0.07, 0.22, shirt, 0, -0.1, 0);
    shoulder.add(sleeve);
    shoulder.add(cylinder(0.064, 0.05, 0.23, skin, 0, -0.24, 0));
    let elbow = new Group();
    elbow.position.y = -0.33;
    shoulder.add(elbow);
    elbow.add(cylinder(0.05, 0.037, 0.25, skin, 0, -0.12, 0));
    elbow.add(
      sphere(keeper ? 0.065 : 0.047, keeper ? "#f0f2d6" : skin, 0, -0.25, 0),
    );
    shoulder.rotation.z = sign * 0.13;
    arms.push({ shoulder, elbow });
  }
  let shadow = new Mesh(
    new THREE.CircleGeometry(0.5, 20),
    new MeshBasicMaterial({
      color: "#14291c",
      transparent: true,
      opacity: 0.23,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.012;
  root.add(shadow);
  root.scale.setScalar(1.08);
  return { root, body, legs, arms, color, head, phase: index * 1.37 };
}
export class PitchRenderer {
  constructor(container, onSelect) {
    this.container = container;
    this.onSelect = onSelect;
    this.state = null;
    this.selected = 7;
    this.cameraMode = "broadcast";
    this.zoom = 1;
    this.focus = "overview";
    this.quality = "balanced";
    this.motion = new VisualMotion();
    this.look = new Vector3();
    this.flags = {
      prediction: false,
      command: false,
      history: false,
      centroids: false,
      tactical: false,
      communication: false,
      observation: false,
      targets: false,
    };
    this.scope = "selected";
    this.agentView = false;
    this.fps = 0;
    this.frames = 0;
    this.start = performance.now();
    this.athletes = [];
    this.lastTime = performance.now();
    this.scene = new THREE.Scene();
    this.scene.background = new Color("#152c33");
    this.scene.fog = new THREE.Fog("#152c33", 170, 310);
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 500);
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    this.renderer.setSize(900, 550);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.setAttribute(
      "aria-label",
      "Interactive 3D football field",
    );
    this.renderer.domElement.setAttribute("role", "img");
    this.scene.add(new THREE.HemisphereLight("#e1f5ff", "#41604b", 1.9));
    const sun = new THREE.DirectionalLight("#fff5dc", 3.4);
    sun.position.set(-32, 70, 30);
    this.sun = sun;
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, {
      left: -65,
      right: 65,
      top: 48,
      bottom: -48,
      near: 5,
      far: 160,
    });
    sun.shadow.bias = -0.0007;
    sun.shadow.normalBias = 0.035;
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight("#b6d9e9", 0.6);
    fill.position.set(60, 40, -50);
    this.scene.add(fill);
    this.buildStadium();
    for (let i = 0; i < 22; i++) {
      let p = athlete(i, i < 11 ? "#338cea" : "#f27860", i % 11 === 0);
      this.scene.add(p.root);
      this.athletes.push(p);
    }
    this.ball = new Mesh(
      new SphereGeometry(0.19, 16, 12),
      new MeshStandardMaterial({ map: this.ballTexture(), roughness: 0.55 }),
    );
    this.ball.castShadow = true;
    this.scene.add(this.ball);
    this.ballShadow = new Mesh(
      new THREE.CircleGeometry(0.27, 16),
      new MeshBasicMaterial({
        color: "#14271a",
        transparent: true,
        opacity: 0.35,
      }),
    );
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.scene.add(this.ballShadow);
    this.selection = new Mesh(
      new THREE.RingGeometry(0.7, 0.84, 48),
      new MeshBasicMaterial({
        color: "#88edce",
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      }),
    );
    this.selection.rotation.x = -Math.PI / 2;
    this.selection.position.y = 0.04;
    this.scene.add(this.selection);
    this.overlay = new Group();
    this.scene.add(this.overlay);
    this.label = document.createElement("div");
    this.label.className = "pitch-player-label";
    container.appendChild(this.label);
    this.renderer.domElement.addEventListener("pointerup", (e) => {
      const r = this.renderer.domElement.getBoundingClientRect();
      let best = null,
        min = 20;
      this.state?.players.forEach((p) => {
        if (
          this.agentView &&
          p.id !== this.selected &&
          !this.state.players[this.selected].visible.some((q) => q.id === p.id)
        )
          return;
        let v = new Vector3(p.x, 1, p.y).project(this.camera),
          px = (v.x + 1) * 0.5 * r.width,
          py = (1 - v.y) * 0.5 * r.height,
          d = Math.hypot(px - (e.clientX - r.left), py - (e.clientY - r.top));
        if (d < min) {
          min = d;
          best = p.id;
        }
      });
      if (best !== null) {
        this.selected = best;
        this.onSelect(best);
      }
    });
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(container);
    this.resize();
    this.renderer.setAnimationLoop((t) => this.frame(t));
  }
  ballTexture() {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 128;
    const x = c.getContext("2d");
    x.fillStyle = "#f7f5dc";
    x.fillRect(0, 0, 256, 128);
    x.fillStyle = "#243842";
    for (let i = 0; i < 12; i++) {
      let px = (i % 6) * 43,
        py = Math.floor(i / 6) * 64 + 20;
      x.beginPath();
      for (let j = 0; j < 5; j++) {
        const a = (j * Math.PI * 2) / 5;
        x.lineTo(px + Math.cos(a) * 12, py + Math.sin(a) * 12);
      }
      x.closePath();
      x.fill();
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  buildStadium() {
    this.scene.add(box(145, 0.5, 108, "#203b30", 0, -0.32, 0));
    const turf = new Mesh(
      new PlaneGeometry(105, 68),
      new MeshStandardMaterial({ map: pitchTexture(), roughness: 0.98 }),
    );
    turf.rotation.x = -Math.PI / 2;
    turf.receiveShadow = true;
    turf.position.y = 0.002;
    this.scene.add(turf);
    const markings = new Group();
    this.scene.add(markings);
    const add = (ps) =>
      markings.add(
        line(
          ps.map((p) => [p[0], 0.026, p[1]]),
          "#dbe7cc",
        ),
      );
    add([
      [-52.5, -34],
      [52.5, -34],
      [52.5, 34],
      [-52.5, 34],
      [-52.5, -34],
    ]);
    add([
      [0, -34],
      [0, 34],
    ]);
    markings.add(circle(0, 0, 9.15, "#dbe7cc"));
    markings.add(sphere(0.13, "#e2e9d3", 0, 0.05, 0));
    for (let s of [-1, 1]) {
      add([
        [s * 52.5, -20.16],
        [s * 36, -20.16],
        [s * 36, 20.16],
        [s * 52.5, 20.16],
      ]);
      add([
        [s * 52.5, -9.16],
        [s * 47, -9.16],
        [s * 47, 9.16],
        [s * 52.5, 9.16],
      ]);
      markings.add(sphere(0.11, "#e2e9d3", s * 41.5, 0.06, 0));
      const arc = [];
      for (let j = 0; j <= 40; j++) {
        let a = -0.92 + (j / 40) * 1.84;
        arc.push([s * (41.5 - 9.15 * Math.cos(a)), 9.15 * Math.sin(a)]);
      }
      add(arc);
      this.goal(s);
      for (let y of [-33.8, 33.8]) {
        this.scene.add(
          cylinder(0.032, 0.032, 1.55, "#e5e6dc", s * 52.3, 0.77, y),
        );
        this.scene.add(
          box(
            0.45,
            0.28,
            0.015,
            s < 0 ? "#87d7e2" : "#f4ca75",
            s * 52.3 + 0.2,
            1.38,
            y,
          ),
        );
      }
    }
    // Advertising bands, seating, floodlights and a simple crowd are all real geometry.
    for (let side of [-1, 1]) {
      this.scene.add(box(128, 0.9, 0.22, "#152c3f", 0, 0.5, side * 38));
      const banner = this.bannerTexture();
      let b = new Mesh(
        new PlaneGeometry(120, 0.85),
        new MeshBasicMaterial({ map: banner, side: THREE.DoubleSide }),
      );
      b.position.set(0, 0.5, side * 37.86);
      if (side === 1) b.rotation.y = Math.PI;
      this.scene.add(b);
      for (let row = 0; row < 8; row++) {
        this.scene.add(
          box(
            132,
            0.8,
            1.75,
            row % 2 ? "#273c49" : "#304652",
            0,
            0.5 + row * 0.8,
            side * (42 + row * 1.8),
          ),
        );
      }
      this.scene.add(box(135, 0.35, 3.2, "#293f4a", 0, 8, side * 56));
    }
    for (let s of [-1, 1])
      for (let row = 0; row < 6; row++)
        this.scene.add(
          box(1.9, 0.8, 80, "#304653", s * (60 + row * 2), 0.6 + row * 0.8, 0),
        );
    const crowdGeo = new SphereGeometry(0.23, 5, 4),
      crowdMat = new MeshStandardMaterial({ roughness: 1 }),
      crowd = new THREE.InstancedMesh(crowdGeo, crowdMat, 1800),
      dummy = new THREE.Object3D(),
      random = seeded(32),
      colors = [
        "#d5a376",
        "#3b83a5",
        "#8f8175",
        "#c1bfb0",
        "#7e4b47",
        "#194560",
        "#254754",
      ];
    for (let i = 0; i < 1800; i++) {
      let side = i % 2 ? 1 : -1,
        row = Math.floor(random() * 8),
        x = (random() - 0.5) * 128,
        z = side * (42 + row * 1.8);
      dummy.position.set(x, 1.2 + row * 0.8, z);
      dummy.scale.set(0.9, 1.5, 1);
      dummy.updateMatrix();
      crowd.setMatrixAt(i, dummy.matrix);
      crowd.setColorAt(
        i,
        new Color(colors[Math.floor(random() * colors.length)]),
      );
    }
    crowd.instanceMatrix.needsUpdate = true;
    this.scene.add(crowd);
    for (let x of [-65, 65])
      for (let z of [-45, 45]) {
        this.scene.add(cylinder(0.2, 0.3, 19, "#5b727b", x, 9.5, z));
        const light = box(6, 2, 0.3, "#e7eee7", x, 19, z);
        light.material = new MeshBasicMaterial({ color: "#e6f4e6" });
        this.scene.add(light);
      }
  }
  bannerTexture() {
    const c = document.createElement("canvas");
    c.width = 2048;
    c.height = 64;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#102b3b";
    ctx.fillRect(0, 0, 2048, 64);
    ctx.font = "600 27px sans-serif";
    ctx.fillStyle = "#aed6e7";
    ctx.textBaseline = "middle";
    for (let i = 0; i < 4; i++) {
      ctx.fillText(
        i % 2 ? "INTELLIGENCE IN MOTION" : "OWN / FLOW",
        40 + i * 512,
        34,
      );
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  goal(side) {
    const gx = side * 52.5,
      back = side * 55;
    for (let y of [-3.66, 3.66]) {
      this.scene.add(cylinder(0.06, 0.06, 2.44, "#e9eee8", gx, 1.22, y));
      this.scene.add(
        line(
          [
            [gx, 2.44, y],
            [back, 1.8, y],
            [back, 0.05, y],
            [gx, 0.05, y],
          ],
          "#b9d0c7",
        ),
      );
    }
    const bar = cylinder(0.06, 0.06, 7.32, "#e9eee8", gx, 2.44, 0);
    bar.rotation.x = Math.PI / 2;
    this.scene.add(bar);
    const pts = [];
    for (let y = -3.66; y <= 3.67; y += 0.22) {
      pts.push([gx, 2.44, y], [back, 1.8, y]);
      pts.push([back, 1.8, y], [back, 0.05, y]);
    }
    for (let h = 0; h <= 1.82; h += 0.2)
      pts.push([back, h, -3.66], [back, h, 3.66]);
    for (let x = 0; x <= 2.5; x += 0.22) {
      let h = 2.44 - (x / 2.5) * 0.64;
      pts.push([gx + side * x, h, -3.66], [gx + side * x, h, 3.66]);
      for (let y of [-3.66, 3.66])
        pts.push([gx + side * x, 0.05, y], [gx + side * x, h, y]);
    }
    const g = new THREE.BufferGeometry().setFromPoints(
      pts.map((p) => new Vector3(...p)),
    );
    this.scene.add(
      new THREE.LineSegments(
        g,
        new THREE.LineBasicMaterial({
          color: "#d4e1d6",
          transparent: true,
          opacity: 0.38,
        }),
      ),
    );
  }
  resize() {
    let w = this.container.clientWidth,
      h = this.container.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  setState(s) {
    this.state = s;
    this.received = performance.now();
    this.motion.receive(s, this.received);
    this.refreshOverlay();
  }
  configure(opts) {
    const oldQuality=this.quality;
    Object.assign(this, opts);
    if(oldQuality!==this.quality){
      this.renderer.setPixelRatio(Math.min(devicePixelRatio,this.quality==='detail'?2:this.quality==='performance'?1:1.5));
      this.renderer.shadowMap.enabled=this.quality!=='performance';
      const resolution=this.quality==='detail'?2048:1024;
      this.sun.shadow.mapSize.set(resolution,resolution);
      this.sun.shadow.map?.dispose();this.sun.shadow.map=null;
      this.resize();
    }
    this.refreshOverlay();
  }
  refreshOverlay() {
    if (!this.state) return;
    for (let child of [...this.overlay.children]) {
      this.overlay.remove(child);
      child.geometry?.dispose();
      child.material?.dispose();
    }
    const s = this.state,
      p = s.players[this.selected] || s.players[0],
      team = p.team,
      cfg = s.tactics[team];
    const use = s.players.filter(
      (q) =>
        this.scope === "all" ||
        (this.scope === "team" && q.team === team) ||
        (this.scope === "unit" &&
          cfg.groups.some(
            (g) =>
              g.members.includes(p.index) &&
              g.members.includes(q.index) &&
              q.team === team,
          )) ||
        q.id === p.id,
    );
    const addLine = (points, color, opacity = 0.8) =>
      this.overlay.add(line(points, color, opacity));
    const arrow = (a, b, color) => {
      addLine(
        [
          [a.x, 0.12, a.y],
          [b.x, 0.12, b.y],
        ],
        color,
      );
      let dx = b.x - a.x,
        dy = b.y - a.y,
        n = Math.hypot(dx, dy) || 1,
        ux = dx / n,
        uy = dy / n;
      addLine(
        [
          [b.x - ux * 0.8 - uy * 0.35, 0.12, b.y - uy * 0.8 + ux * 0.35],
          [b.x, 0.12, b.y],
          [b.x - ux * 0.8 + uy * 0.35, 0.12, b.y - uy * 0.8 - ux * 0.35],
        ],
        color,
      );
    };
    for (let q of use) {
      if (this.flags.prediction && q.prediction?.length)
        addLine(
          [[q.x, 0.15, q.y], ...q.prediction.map((v) => [v.x, 0.15, v.y])],
          "#8cf4cc",
        );
      if (this.flags.command && q.command)
        arrow(
          q,
          { x: q.x + q.command.x * 0.8, y: q.y + q.command.y * 0.8 },
          "#f6ce74",
        );
      if (this.flags.history && q.trail?.length)
        addLine(
          q.trail.map((v) => [v.x, 0.07, v.y]),
          "#b6d0de",
          0.5,
        );
      if (this.flags.targets) {
        this.overlay.add(circle(q.target.x, q.target.y, 0.7, "#ffe294", 0.08));
        addLine(
          [
            [q.x, 0.07, q.y],
            [q.target.x, 0.07, q.target.y],
          ],
          "#ffe294",
          0.25,
        );
      }
      if (this.flags.centroids && q.estimate)
        this.overlay.add(
          circle(q.estimate.x, q.estimate.y, 0.4, "#99b1ff", 0.1),
        );
    }
    if (this.flags.centroids) {
      const m = s.metrics[team];
      if (m) {
        this.overlay.add(
          circle(m.centroid.x, m.centroid.y, 1.15, "#faf3c0", 0.12),
        );
        this.overlay.add(
          circle(m.reference.x, m.reference.y, 1.5, "#8cefc9", 0.12),
        );
      }
    }
    if (this.flags.tactical)
      for (let [a, b] of cfg.tacticalEdges) {
        let a1 = s.players[team * 11 + a],
          b1 = s.players[team * 11 + b];
        addLine(
          [
            [a1.x, 0.18, a1.y],
            [b1.x, 0.18, b1.y],
          ],
          "#e8c579",
          0.55,
        );
      }
    if (this.flags.communication)
      for (let [a, b] of cfg.commEdges) {
        let a1 = s.players[team * 11 + a],
          b1 = s.players[team * 11 + b];
        addLine(
          [
            [a1.x, 0.35, a1.y],
            [b1.x, 0.35, b1.y],
          ],
          "#6cd3e9",
          0.6,
        );
      }
    if (this.flags.observation || this.agentView) {
      const radius = p.vision || cfg.vision,
        angle = (cfg.fov * Math.PI) / 180,
        points = [[p.x, 0.08, p.y]];
      for (let i = 0; i <= 48; i++) {
        let a = p.heading - angle / 2 + (angle * i) / 48;
        points.push([
          p.x + Math.cos(a) * radius,
          0.08,
          p.y + Math.sin(a) * radius,
        ]);
      }
      points.push([p.x, 0.08, p.y]);
      addLine(points, "#93efca", 0.7);
    }
  }
  frame(now) {
    let elapsed = Math.min(0.08, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.frames++;
    if (now - this.start > 1000) {
      this.fps = Math.round((this.frames * 1000) / (now - this.start));
      this.frames = 0;
      this.start = now;
    }
    if (!this.container.isConnected || this.container.clientWidth === 0) return;
    const s = this.state;
    if (!s) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    const visual = this.motion.sample(now);
    const selected = visual.players[this.selected] || visual.players[0],
      known = new Set(selected.visible?.map((p) => p.id) || []);
    known.add(selected.id);
    for (let i = 0; i < 22; i++) {
      const p = visual.players[i],
        m = this.athletes[i];
      if (!p) continue;
      m.root.visible = !this.agentView || known.has(p.id);
      m.root.position.set(p.x, 0, p.y);
      m.root.rotation.y = Math.PI / 2 - p.heading;
      const {phase,amp,kick,save,lean,bob,tackle} = p.visual;
      m.body.position.y = bob;
      m.body.rotation.x = lean + tackle*.16;
      m.body.rotation.z = save*.5;
      m.legs.forEach((leg, j) => {
        const a = phase + j * Math.PI;
        leg.hip.rotation.x = Math.sin(a) * .68 * amp - (j === 1 ? kick*1.3+tackle*.7 : 0);
        leg.knee.rotation.x =
          Math.max(0,-Math.sin(a))*.85*amp*(1-kick) + kick*.15;
      });
      m.arms.forEach((a, j) => {
        a.shoulder.rotation.x = -save*1.5 - Math.sin(phase+j*Math.PI)*.5*amp*(1-save);
        a.elbow.rotation.x = -0.3 - amp * 0.45;
        a.shoulder.rotation.z = (j ? 1 : -1)*(.13-save*1.03);
      });
    }
    const ballVisible =
      !this.agentView ||
      (selected.knownBall?.via === "vision" &&
        s.time - selected.knownBall.time < 0.2);
    this.ball.visible = this.ballShadow.visible = ballVisible;
    const ball=visual.ball;
    this.ball.position.set(ball.x,Math.max(.19,ball.z),ball.y);
    this.ball.rotation.x=ball.spin;this.ball.rotation.z=ball.spin*.4;
    this.ballShadow.position.set(ball.x,.02,ball.y);
    this.ballShadow.material.opacity=Math.max(.07,.35-ball.z*.08);
    this.ballShadow.scale.setScalar(1+Math.max(0,ball.z)*.12);
    this.selection.position.set(selected.x,.04,selected.y);
    const focus=cameraFocus(s,this.selected,this.focus,this.agentView),target=new Vector3(focus.x,0,focus.y);
    this.look.lerp(target,Math.min(1,elapsed*4));
    const fit=Math.max(1,1.5/this.camera.aspect),zoom=this.zoom;
    const desired=this.cameraMode==='tactical'
      ?new Vector3(this.look.x,114*fit/zoom,this.look.z+27*fit/zoom)
      :new Vector3(this.look.x+5,70*fit/zoom,this.look.z+91*fit/zoom);
    if(!this.cameraReady){this.camera.position.copy(desired);this.cameraReady=true;}
    else this.camera.position.lerp(desired,Math.min(1,elapsed*5));
    this.camera.lookAt(this.look);
    const pixelScale=this.container.clientHeight/(2*Math.tan(42*Math.PI/360)*this.camera.position.distanceTo(this.ball.position));
    this.ball.scale.setScalar(Math.min(2.2,Math.max(1,2.2/(.19*pixelScale))));
    const lp = new Vector3(selected.x, 2.9, selected.y).project(this.camera),
      w = this.container.clientWidth,
      h = this.container.clientHeight;
    this.label.style.left = (lp.x + 1) * 0.5 * w + "px";
    this.label.style.top = (1 - lp.y) * 0.5 * h + "px";
    this.label.textContent =
      String(selected.index + 1).padStart(2, "0") + " " + selected.name;
    this.label.style.display = lp.z < 1 ? "block" : "none";
    this.renderer.render(this.scene, this.camera);
  }
  mount(container) {
    this.observer.disconnect();
    this.container = container;
    container.append(this.renderer.domElement, this.label);
    this.observer.observe(container);
    this.resize();
  }
  dispose() {
    this.renderer.setAnimationLoop(null);
    this.observer.disconnect();
    this.renderer.dispose();
  }
}
