// Analyst-only diagnostics. These functions never feed the agents or alter a run.
export const mean = a => a.length ? a.reduce((s, v) => s + v, 0) / a.length : null;
export const rms = a => a.length ? Math.sqrt(mean(a.map(v => v * v))) : null;
export function spectrum(edges, n = 11) {
  const a = Array.from({length:n}, () => Array(n).fill(0)), degrees = Array(n).fill(0);
  for (const [i,j] of edges) { a[i][i]++; a[j][j]++; a[i][j]--; a[j][i]--; degrees[i]++; degrees[j]++; }
  // Jacobi diagonalization of the real symmetric, unweighted Laplacian.
  for (let iter=0; iter<100*n*n; iter++) {
    let p=0,q=1,m=0;
    for(let i=0;i<n;i++) for(let j=i+1;j<n;j++) if(Math.abs(a[i][j])>m){m=Math.abs(a[i][j]);p=i;q=j;}
    if(m<1e-11) break;
    const theta=.5*Math.atan2(2*a[p][q],a[q][q]-a[p][p]), c=Math.cos(theta),s=Math.sin(theta),ap=a[p][p],aq=a[q][q],v=a[p][q];
    for(let k=0;k<n;k++) if(k!==p&&k!==q){const x=a[k][p],y=a[k][q];a[k][p]=a[p][k]=c*x-s*y;a[k][q]=a[q][k]=s*x+c*y;}
    a[p][p]=c*c*ap-2*c*s*v+s*s*aq; a[q][q]=s*s*ap+2*c*s*v+c*c*aq;a[p][q]=a[q][p]=0;
  }
  const eigenvalues=a.map((r,i)=>Math.max(0,r[i])).sort((a,b)=>a-b);
  return {eigenvalues,lambda2:eigenvalues[1]||0,lambdaMax:eigenvalues[n-1]||0,degrees,components:eigenvalues.filter(x=>x<1e-8).length,density:2*edges.length/(n*(n-1))};
}
export function teamAnalysis(state, team) {
  const ps=state.players.filter(p=>p.team===team), c=state.tactics[team];
  if(!ps.length) return null;
  const center={x:mean(ps.map(p=>p.x)),y:mean(ps.map(p=>p.y))}, est={x:mean(ps.map(p=>p.estimate.x)),y:mean(ps.map(p=>p.estimate.y))};
  const bias=Math.hypot(est.x-center.x,est.y-center.y), disagreement=rms(ps.map(p=>Math.hypot(p.estimate.x-est.x,p.estimate.y-est.y)));
  const agents=ps.map(p=>({id:p.id,index:p.index,name:p.name,tracking:Math.hypot(p.target.x-p.x,p.target.y-p.y),estimation:Math.hypot(p.estimate.x-center.x,p.estimate.y-center.y),gap:Math.hypot(p.command.x-p.vx,p.command.y-p.vy),degree:c.commEdges.filter(e=>e.includes(p.index)).length,saturated:p.saturated}));
  const edgeErrors=c.tacticalEdges.map(([i,j])=>{const p=ps[i],q=ps[j];return Math.hypot((q.x-p.x)-(q.target.x-p.target.x),(q.y-p.y)-(q.target.y-p.target.y));});
  return {center,meanEstimate:est,bias,disagreement,rmse:rms(agents.map(a=>a.estimation)),relational:rms(edgeErrors),agents,width:Math.max(...ps.map(p=>p.y))-Math.min(...ps.map(p=>p.y)),depth:Math.max(...ps.map(p=>p.x))-Math.min(...ps.map(p=>p.x)),gap:rms(agents.map(a=>a.gap)),saturation:mean(ps.map(p=>+p.saturated))};
}
export function pairedMetric(results,key) {
  const a=results.map(r=>r.a[key]), b=results.map(r=>r.b[key]),delta=b.map((x,i)=>x-a[i]),av=mean(a),bv=mean(b),d=mean(delta);
  const sd=delta.length>1?Math.sqrt(delta.reduce((s,v)=>s+(v-d)**2,0)/(delta.length-1)):null;
  // The UI executes exactly three paired seeds: Student-t(2), two-sided 95%.
  const half=delta.length===3?4.3026527299*sd/Math.sqrt(3):null;
  return {a:av,b:bv,delta:d,percent:Math.abs(av)>1e-10?100*d/av:null,low:half===null?null:d-half,high:half===null?null:d+half,deltaSamples:delta};
}
export function responseSummary(series, key='shape', threshold=1) {
  const values=series.map(r=>r.teams[0][key]);
  if(!values.length) return null;
  let first=values.findIndex((v,i)=>v<=threshold && values.slice(i).every(x=>x<=threshold));
  return {initial:values[0],final:values.at(-1),peak:Math.max(...values),mean:mean(values),settling:first<0?null:series[first].time-series[0].time,threshold};
}
