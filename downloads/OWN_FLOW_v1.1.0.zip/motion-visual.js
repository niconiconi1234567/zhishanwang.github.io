// Presentation only: never extrapolate or change the simulation's physical state.
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function blendPose(previous, current, alpha, moving = true) {
  if (!previous || !moving || Math.hypot(current.x - previous.x, current.y - previous.y) > 8) return {...current};
  const t = clamp(alpha, 0, 1), out = {...current};
  for (const k of ['x', 'y', 'z', 'vx', 'vy', 'spin'])
    if (Number.isFinite(previous[k]) && Number.isFinite(current[k])) out[k] = previous[k] + (current[k] - previous[k]) * t;
  if (Number.isFinite(current.heading)) out.heading = previous.heading + Math.atan2(Math.sin(current.heading - previous.heading), Math.cos(current.heading - previous.heading)) * t;
  return out;
}
export function actionPose(player, time, distance = 0) {
  const amp = clamp(Math.hypot(player.vx, player.vy) / 6, 0, 1), phase = distance * 2.8 + player.id * 1.37;
  const remaining = clamp((player.actionUntil ?? time) - time, 0, .55);
  const pulse = Math.sin(Math.PI * (1 - remaining / .55));
  return {amp, phase, bob: Math.abs(Math.sin(phase)) * .045 * amp,
    lean: amp * .09, kick: ['pass', 'shoot'].includes(player.action) ? pulse : 0,
    save: player.action === 'save' ? pulse : 0, tackle: player.action === 'tackle' ? pulse : 0};
}
export function cameraFocus(state, selected = 7, mode = 'overview', agentView = false) {
  const p = state?.players[selected];
  if (!p || mode === 'overview' && !agentView) return {x:0, y:0};
  // An agent view must not reveal a hidden ball through camera motion.
  if (agentView || mode === 'player') return {x:p.x, y:p.y};
  return {x:clamp(state.ball.x, -44, 44), y:clamp(state.ball.y, -27, 27)};
}
export class VisualMotion {
  constructor() { this.previous = null; this.current = null; this.phases = new Map(); }
  receive(state, now) {
    this.previous = this.current;
    this.duration = clamp(now - (this.received ?? now - 100), 30, 180);
    this.received = now;
    this.current = state;
    if (!this.previous || state.time < this.previous.time || state.time - this.previous.time > 2) {
      this.previous = null; this.phases.clear();
    }
  }
  sample(now) {
    const s = this.current, old = this.previous, a = clamp((now - this.received) / this.duration, 0, 1);
    const moving = !!s.running && !!old;
    const time = moving ? old.time + (s.time - old.time) * a : s.time;
    const players = s.players.map(p => {
      const pose = blendPose(old?.players[p.id], p, a, moving), previous = this.phases.get(p.id);
      let distance = previous?.distance ?? 0;
      if (previous && moving) {
        const step = Math.hypot(pose.x - previous.x, pose.y - previous.y);
        if (step < 4) distance += step;
      }
      this.phases.set(p.id, {...pose, distance});
      return {...pose, visual:actionPose(pose,time,distance)};
    });
    return {players, ball:blendPose(old?.ball,s.ball,a,moving), time};
  }
}
