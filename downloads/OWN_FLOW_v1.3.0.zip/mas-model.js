import {symmetricEigenvalues} from './graph-matrix.js';

// This module consumes sampled positions, velocities and supplied role targets.
// Communication memories, commands and controller gains are never fit inputs.
export const SAMPLE_PERIOD = .2;
const mean = a => a.reduce((s, v) => s + v, 0) / Math.max(1, a.length);
const rms = a => Math.sqrt(mean(a.map(v => v * v)));
const finite = Number.isFinite;

export function motionFrame(state, epoch = 0) {
  return {time:state.time, tick:state.tick, half:state.half, phase:state.phase,
    epoch, seed:state.seed, players:state.players.map(p => ({
      id:p.id, team:p.team, index:p.index, x:p.x, y:p.y, vx:p.vx, vy:p.vy,
      target:{...p.target}, estimate:{...p.estimate}, saturated:!!p.saturated
    }))};
}

export class MotionBuffer {
  constructor(){ this.frames=[]; this.epoch=null; }
  append(frames) {
    for (const frame of frames) {
      const last=this.frames.at(-1);
      if (frame.epoch!==this.epoch || (last && frame.time<last.time) ||
          (last && frame.half!==last.half)) this.frames=[];
      this.epoch=frame.epoch;
      if (this.frames.at(-1)?.tick===frame.tick) continue;
      this.frames.push(frame);
      while (this.frames.length>301) this.frames.shift();
    }
  }
  window(seconds=30) {
    const last=this.frames.at(-1);
    return last?this.frames.filter(f=>f.time>=last.time-seconds-1e-8):[];
  }
}

export function groupMetrics(frame, team) {
  const p=frame.players.filter(p=>p.team===team);
  const z=p.map(p=>({x:p.x-p.target.x,y:p.y-p.target.y}));
  const center={x:mean(p.map(p=>p.x)),y:mean(p.map(p=>p.y))};
  const offset={x:mean(z.map(z=>z.x)),y:mean(z.map(z=>z.y))};
  const estimate={x:mean(p.map(p=>p.estimate.x)),y:mean(p.map(p=>p.estimate.y))};
  return {
    tracking:rms(z.map(z=>Math.hypot(z.x,z.y))),
    shape:rms(z.map(z=>Math.hypot(z.x-offset.x,z.y-offset.y))),
    translation:Math.hypot(offset.x,offset.y),
    disagreement:rms(p.map(p=>Math.hypot(p.estimate.x-estimate.x,p.estimate.y-estimate.y))),
    bias:Math.hypot(estimate.x-center.x,estimate.y-center.y),
    saturation:mean(p.map(p=>Number(p.saturated))),center,offset,estimate
  };
}

function solvePositive(matrix, rhs) {
  const n=rhs.length, L=Array.from({length:n},()=>Array(n).fill(0));
  for(let i=0;i<n;i++) for(let j=0;j<=i;j++) {
    let v=matrix[i][j];
    for(let k=0;k<j;k++)v-=L[i][k]*L[j][k];
    if(i===j){ if(v<=0 || !finite(v))throw Error('ill_conditioned'); L[i][j]=Math.sqrt(v); }
    else L[i][j]=v/L[j][j];
  }
  const y=Array(n).fill(0),x=Array(n).fill(0);
  for(let i=0;i<n;i++){
    let v=rhs[i]; for(let j=0;j<i;j++)v-=L[i][j]*y[j]; y[i]=v/L[i][i];
  }
  for(let i=n-1;i>=0;i--){
    let v=y[i];for(let j=i+1;j<n;j++)v-=L[j][i]*x[j];x[i]=v/L[i][i];
  }
  return x;
}

export function ridgeFit(rows, penalty=.01) {
  const n=rows[0].x.length;
  const scales=Array.from({length:n},(_,j)=>Math.sqrt(mean(rows.map(r=>r.x[j]**2)))||1);
  const gram=Array.from({length:n},()=>Array(n).fill(0)),rhs=Array(n).fill(0);
  for(const row of rows){
    const x=row.x.map((v,j)=>v/scales[j]);
    for(let j=0;j<n;j++){
      rhs[j]+=x[j]*row.y/rows.length;
      for(let k=0;k<n;k++)gram[j][k]+=x[j]*x[k]/rows.length;
    }
  }
  const eigen=symmetricEigenvalues(gram),maximum=eigen.at(-1);
  const rank=eigen.filter(v=>v>Math.max(1e-9,maximum*1e-7)).length;
  const condition=rank===n?Math.sqrt(maximum/Math.max(eigen[0],1e-15)):null;
  const regularized=gram.map((r,i)=>r.map((v,j)=>v+(i===j?penalty:0)));
  const beta=solvePositive(regularized,rhs).map((v,j)=>v/scales[j]);
  return {beta,rank,columns:n,condition,scales};
}

function featureRows(frame,next,index,team,network) {
  const players=frame.players.filter(p=>p.team===team).sort((a,b)=>a.index-b.index);
  const after=next.players.filter(p=>p.team===team).sort((a,b)=>a.index-b.index);
  const p=players[index],q=after[index],dt=next.time-frame.time;
  return ['x','y'].map((axis,axisIndex)=>{
    const error=p.target[axis]-p[axis];
    const x=[error,p['v'+axis],axisIndex===0?1:0,axisIndex===1?1:0];
    if(network)for(const neighbor of players){
      if(neighbor.index===index)continue;
      x.push((neighbor[axis]-neighbor.target[axis])-(p[axis]-p.target[axis]));
    }
    return {x,y:(q[axis]-p[axis])/dt,time:next.time,axis};
  });
}
const predict=(model,row)=>model.beta.reduce((sum,b,j)=>sum+b*row.x[j],0);
function score(model,rows) {
  const predictions=rows.map(row=>({time:row.time,axis:row.axis,actual:row.y,fit:predict(model,row)}));
  const error=rows.map((row,i)=>predictions[i].fit-row.y);
  return {rmse:rms(error),predictions};
}

export function usableIntervals(frames,team) {
  const intervals=[];
  for(let k=0;k<frames.length-1;k++) {
    const a=frames[k],b=frames[k+1],dt=b.time-a.time;
    if(a.epoch!==b.epoch || a.half!==b.half || a.phase!=='live' || b.phase!=='live' ||
        Math.abs(dt-SAMPLE_PERIOD)>1e-6)continue;
    const pa=a.players.filter(p=>p.team===team).sort((a,b)=>a.index-b.index);
    const pb=b.players.filter(p=>p.team===team).sort((a,b)=>a.index-b.index);
    if(pa.length!==11||pb.length!==11)continue;
    const valid=pa.every((p,i)=>p.index===i&&pb[i].index===i&&p.id===pb[i].id&&
      [p.x,p.y,p.vx,p.vy,p.target?.x,p.target?.y,pb[i].x,pb[i].y].every(finite)&&
      Math.hypot(p.x-pb[i].x,p.y-pb[i].y)<3.5);
    if(valid)intervals.push([a,b]);
  }
  return intervals;
}

export function identifyInteractions(frames,{team=0,penalty=.01}={}) {
  if(![0,1].includes(team)||!finite(penalty)||penalty<1e-6||penalty>1)throw Error('fit_options');
  // Use only the most recent configuration/half, even for imported test data.
  const end=frames.at(-1);
  const sample=frames.filter(f=>f.epoch===end?.epoch&&f.half===end?.half);
  const intervals=usableIntervals(sample,team);
  const split=Math.floor(intervals.length*.7);
  const meta={team,penalty,epoch:end?.epoch,seed:end?.seed,intervals:intervals.length,
    excluded:Math.max(0,sample.length-1-intervals.length),
    start:intervals[0]?.[0].time,end:intervals.at(-1)?.[1].time,
    trainEnd:intervals[split-1]?.[1].time,splitTime:intervals[split+1]?.[0].time,samplePeriod:SAMPLE_PERIOD};
  if(intervals.length<40)return {...meta,available:false,reason:'samples'};
  const agents=[];
  for(let i=0;i<11;i++) {
    const train=intervals.slice(0,split).flatMap(([a,b])=>featureRows(a,b,i,team,true));
    const test=intervals.slice(split+1).flatMap(([a,b])=>featureRows(a,b,i,team,true));
    const baselineRows=rows=>rows.map(r=>({...r,x:r.x.slice(0,4)}));
    const full=ridgeFit(train,penalty),base=ridgeFit(baselineRows(train),penalty);
    const holdout=score(full,test),baseline=score(base,baselineRows(test));
    const gain=baseline.rmse>1e-8?1-holdout.rmse/baseline.rmse:null;
    const identifiable=full.rank===full.columns && full.condition<10000;
    const informative=identifiable && gain!==null && gain>.05;
    let j=4;
    const weights=Array.from({length:11},(_,from)=>from).filter(from=>from!==i)
      .map(from=>({from,to:i,weight:full.beta[j++]}));
    const trainScore=score(full,train);
    const constantVelocity=rms(test.map(r=>r.x[1]-r.y));
    agents.push({index:i,...full,weights,gain,identifiable,informative,
      trainRmse:trainScore.rmse,rmse:holdout.rmse,baselineRmse:baseline.rmse,
      constantVelocityRmse:constantVelocity,predictions:holdout.predictions.map((p,k)=>({...p,baseline:baseline.predictions[k].fit}))});
  }
  return {...meta,available:true,agents,
    rmse:rms(agents.map(a=>a.rmse)),baselineRmse:rms(agents.map(a=>a.baselineRmse)),
    informative:agents.filter(a=>a.informative).length};
}

// Controlled synthetic check with a known directed graph. All samples are generated
// separately from the football match. Target steps provide independent excitation.
export function calibrationFrames({seed=361,excited=true,seconds=40}={}) {
  let rng=seed>>>0;
  const random=()=>{rng=(Math.imul(1664525,rng)+1013904223)>>>0;return rng/4294967296;};
  const players=Array.from({length:11},(_,i)=>({id:i,team:0,index:i,
    x:excited?8*(random()-.5):3,y:excited?8*(random()-.5):2,vx:0,vy:0,
    target:{x:0,y:0},estimate:{x:0,y:0},saturated:false}));
  const weights=players.map((p,i)=>[
    {from:(i+1)%11,to:i,weight:.18},{from:(i+3)%11,to:i,weight:.1}
  ]).flat();
  const frames=[];
  for(let k=0;k<=seconds/SAMPLE_PERIOD;k++){
    if(excited&&k%10===0)for(const p of players)p.target={x:6*(random()-.5),y:6*(random()-.5)};
    frames.push(motionFrame({players,time:k*SAMPLE_PERIOD,tick:k*6,half:1,phase:'live',seed},1));
    const next=players.map((p,i)=>{
      const v={};
      for(const axis of ['x','y']){
        v[axis]=.55*(p.target[axis]-p[axis])+.35*p['v'+axis];
        for(const edge of weights.filter(w=>w.to===i)){
          const q=players[edge.from];
          v[axis]+=edge.weight*((q[axis]-q.target[axis])-(p[axis]-p.target[axis]));
        }
      }
      return v;
    });
    players.forEach((p,i)=>{p.vx=next[i].x;p.vy=next[i].y;p.x+=p.vx*SAMPLE_PERIOD;p.y+=p.vy*SAMPLE_PERIOD;});
  }
  return {frames,weights};
}

export function runCalibration(excited=true) {
  const {frames,weights}=calibrationFrames({excited});
  const report=identifyInteractions(frames,{penalty:.001});
  const coefficients=report.agents.flatMap(a=>a.weights.map(w=>{
    const truth=weights.find(t=>t.from===w.from&&t.to===w.to)?.weight||0;
    return {...w,truth};
  }));
  const recovered=coefficients.filter(w=>Math.abs(w.weight)>.04);
  const hits=recovered.filter(w=>w.truth!==0).length;
  return {excited,report,weights,mae:mean(coefficients.map(w=>Math.abs(w.weight-w.truth))),
    precision:recovered.length?hits/recovered.length:null,recall:hits/weights.length,
    goalError:mean(report.agents.map(a=>Math.abs(a.beta[0]-.55))),
    inertiaError:mean(report.agents.map(a=>Math.abs(a.beta[1]-.35)))};
}
