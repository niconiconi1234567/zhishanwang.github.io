# Network Studio methods · v1.3.0

## Purpose and data boundary

Network Studio is an analyst view of the same live football simulation. It shows a selected team's eleven players. Both teams remain active on the pitch. The analyst can inspect all team positions and targets. Individual controllers retain their existing local information restrictions.

The three coordinate views use physical positions p, formation offsets z = p − r, and centroid-estimator errors ĉ − c. Every player has an individual role target r. Agreement of z means common formation displacement. Reaching z = 0 means reaching individual role targets. The observer view separates spread among estimates from their common bias relative to the physical centroid.

The selected player and team are shared with Match, Control Laboratory and Diagnostics. The node centres use the same sampled physical coordinates as the pitch. Gold command and mint velocity arrows project one second. Command has units m/s. Physics limits changes in velocity according to each player's acceleration capability.

## Actual controller evidence

Each controller call records a diagnostic controlTrace with its own timestamp, pre-update position, velocity, displacement, observer values and packet contributions. Tactical relationship inputs record the selected source, observed position, desired relative offset and error vector. Source selection follows the engine's existing choice of visible teammate first, then a recent cached message. Direction is sender to receiving agent.

State-message edges in the new scene represent inputs actually used at the latest control call. Existing Effective Network panels continue to describe messages currently available in receiver memory. These are related measurements with different sampling semantics. Every new trace is labelled with its control sample time.

The seven final command components reconstruct p.raw. The saved command is the result of the existing speed limit. Football possession, pressing and goalkeeper branches can change the formation component before that sum. For this reason the panel displays the final executed component rather than presenting every relationship as an independent unsuppressed command. The historical telemetry and controlTrace are read-only diagnostics and do not feed back into the controller.

## Motion model

At h = 0.2 physical seconds, for each receiving agent i, fit

    vbar_i(k+1) = beta_i [r_i(k) − p_i(k)] + alpha_i v_i(k)
                 + sum(j != i) w_ij [z_j(k) − z_i(k)] + b_i + residual
    z_i = p_i − r_i
    vbar_i(k+1) = [p_i(k+1) − p_i(k)] / h

The scalar beta, alpha and ten directed w coefficients are shared across x and y, with separate x and y intercepts. This gives fourteen parameters per agent. beta and w have units s^-1, alpha is dimensionless, and b has units m/s. This is an empirical discrete response model. In particular alpha is a persistence coefficient and the w values are predictive associations.

Targets come from the simulator. The fit reads sampled positions, velocities and those targets. It does not read actual controller gains, commands, command decomposition, visibility, packet memories or the configured graph. All ten teammates are candidates, independent of the communication graph.

Worker telemetry is collected every six physics ticks, independent of browser paint speed. At 1x, 4x and 8x it retains a 0.2 s physical sample interval. The bounded buffer holds at most 301 frames, approximately 60 s. Users can fit 10, 30 or 60 s. Forty valid intervals are required. New matches, restored checkpoints and tactic changes advance an epoch. A half change also starts a fresh buffer. Fit intervals must have the same epoch and half, live phase at both ends, expected time interval, all eleven finite players, and less than 3.5 m displacement for each player. Restarts and larger jumps are excluded. Sampling does not interpolate across missing data.

## Estimation and validation

The first floor(0.7 N) valid intervals train the model. One interval is omitted as a temporal gap and the later intervals test it. Both coordinate rows of an interval stay in the same partition. Feature scales use only training RMS, with zero columns assigned scale one. Ridge minimizes average squared error plus lambda times the squared scaled coefficients. Default lambda is 0.01, with 0.001 and 0.1 also selectable. No parameter is selected using the held-out error.

The comparison model uses the same target, own velocity and intercept columns, without neighbor terms. It has four parameters and uses the same split and penalty. Constant-velocity prediction is also reported. RMSE is calculated over coordinate components in m/s. Charts show one-step predictions at actual measured states, only on the validation interval. They are not free-running multi-step simulations.

The unregularized normalized Gram matrix supplies a rank diagnostic. Eigenvalues must exceed max(1e-9, maximum eigenvalue times 1e-7). The reported condition estimate is the square root of the maximum/minimum Gram eigenvalue and is null for deficient rank. A receiver's fit edges are shown only if rank is fourteen, the condition estimate is below 1e4, and validation RMSE improves over the target-plus-velocity baseline by more than 5%. Display up to four strongest incoming coefficients with magnitude at least 0.025 s^-1. The coefficient table retains all ten candidates and diagnostic status.

Changing the coefficient magnitude threshold would change the displayed graph. It is a visualization threshold, not a significance test. Good prediction and full sampled rank do not prove causal topology, recover actual message delivery, or establish stability of the football match. Moving targets, contacts, task switches, nonlinear actuator limits and omitted evidence can confound the fitted associations. A failure to improve prediction remains a valid result and is explicitly shown.

## Independent validation

A separate eleven-agent linear generator has alpha = 0.35, beta = 0.55, and two incoming edges per receiver. The edge from i+1 has weight 0.18 and that from i+3 weight 0.10, with indices modulo eleven. Euler position updates use h = 0.2 s and the newly calculated velocity. This generator is separate from football dynamics.

Independent target changes every two seconds produce excitation. A second case uses identical states and targets for all agents, making relative feature columns zero. Both use seed 361 and forty seconds. Recovery uses lambda 0.001. The known-network comparison uses a fixed 0.04 s^-1 threshold for precision and recall. In the synchronous case the UI withholds edge recall and precision because the network is ambiguous, even though prediction error is small. The exported numerical result retains the raw comparison and ranks for inspection.

## Reproduction

Run `npm test` for the complete suite, or `node --test maintenance/network-studio.test.mjs` for the new module. Run `node maintenance/reproduce-network.mjs` for the deterministic calibration and match summaries. To verify a browser export, run `node maintenance/reproduce-network.mjs path/to/OWN_FLOW_Interaction_Evidence.json`. It reconstructs the fit and compares the entire saved report, including scales, coefficients and prediction arrays, with 1e-9 absolute/relative numerical tolerance across JavaScript runtimes.

## References

These papers motivate the interpretation boundary. The implemented ridge model and display gates are project design choices.

- Weerts, Van den Hof and Dankers, Identifiability of linear dynamic networks, Automatica 89, 247–258, 2018. https://arxiv.org/abs/1609.00864
- Angulo et al., Fundamental limitations of network reconstruction from temporal data, Journal of the Royal Society Interface 14, 20160966, 2017. https://pmc.ncbi.nlm.nih.gov/articles/PMC5332581/
