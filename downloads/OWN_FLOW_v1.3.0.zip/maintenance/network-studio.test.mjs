import test from 'node:test';
import assert from 'node:assert/strict';
import {MatchEngine,defaultTactic} from '../engine.js';
import {MotionBuffer,motionFrame,groupMetrics,identifyInteractions,calibrationFrames,runCalibration,usableIntervals} from '../mas-model.js';
import {nodeScene,tracePanel,fitSummary} from '../mas-view.js';
const clone=x=>structuredClone(x);
const near=(a,b,tolerance=1e-8)=>assert.ok(Math.abs(a-b)<tolerance,`${a} vs ${b}`);

test('independently excited directed network recovers weights on later unseen samples',()=>{
  const c=runCalibration(true);
  assert.equal(c.report.agents.length,11);
  assert.ok(c.report.agents.every(a=>a.rank===14&&a.informative));
  assert.ok(c.mae<.002);
  assert.ok(c.report.rmse<c.report.baselineRmse*.03);
  assert.equal(c.precision,1);assert.equal(c.recall,1);
  for(const a of c.report.agents){
    near(a.weights.find(w=>w.from===(a.index+1)%11).weight,.18,.003);
    near(a.weights.find(w=>w.from===(a.index+3)%11).weight,.10,.003);
  }
});

test('synchronized trajectories are flagged ambiguous despite tiny prediction error',()=>{
  const c=runCalibration(false);
  assert.ok(c.report.rmse<.001);
  assert.ok(c.report.agents.every(a=>a.rank<14&&!a.identifiable&&!a.informative));
  assert.match(fitSummary(c.report,0,'en'),/Ambiguous coefficients/);
});

test('held-out positions do not alter fitted coefficients or training scales',()=>{
  const {frames}=calibrationFrames();
  const original=identifyInteractions(frames);
  const changed=clone(frames);
  for(const frame of changed)if(frame.time>=original.splitTime){
    for(const p of frame.players){p.x+=.11*Math.sin(frame.time);p.y+=.09*Math.cos(frame.time);}
  }
  const second=identifyInteractions(changed);
  assert.equal(second.intervals,original.intervals);
  for(let i=0;i<11;i++){
    assert.deepEqual(second.agents[i].beta,original.agents[i].beta);
    assert.deepEqual(second.agents[i].scales,original.agents[i].scales);
  }
  assert.ok(original.splitTime>original.trainEnd);
  assert.notEqual(second.rmse,original.rmse);
});

test('motion fit does not read communication, commands or controller gains',()=>{
  const {frames}=calibrationFrames();
  const original=identifyInteractions(frames),changed=clone(frames);
  for(const frame of changed){
    frame.tactics=[{kFormation:999,commEdges:[]}];
    for(const p of frame.players){p.command={x:999,y:999};p.parts={};p.neighbors={};p.estimate={x:-999,y:999};}
  }
  assert.deepEqual(identifyInteractions(changed),original);
});

test('common formation translation is agreement with a nonzero target error',()=>{
  const frame=calibrationFrames({seconds:1}).frames[0];
  for(const p of frame.players){p.x=p.target.x+3;p.y=p.target.y+4;p.estimate={x:2,y:2};}
  const m=groupMetrics(frame,0);
  near(m.shape,0);near(m.tracking,5);near(m.translation,5);near(m.disagreement,0);
  assert.ok(m.bias>0);
});

test('sampling excludes restarts, epoch changes, halftime, gaps and teleports',()=>{
  const {frames}=calibrationFrames({seconds:2});
  assert.equal(usableIntervals(frames,0).length,10);
  for(const edit of [f=>{f.phase='restart';},f=>{f.epoch=9;},f=>{f.half=2;},f=>{f.time+=.07;},f=>{f.players[2].x+=20;}]){
    const changed=clone(frames);edit(changed[5]);
    assert.equal(usableIntervals(changed,0).length,8);
  }
});

test('buffer is bounded and resets on epoch, half and backwards time',()=>{
  const buffer=new MotionBuffer(),{frames}=calibrationFrames({seconds:80});
  buffer.append(frames);assert.equal(buffer.frames.length,301);
  assert.equal(buffer.window(10).length,51);
  buffer.append([{...frames.at(-1),tick:frames.at(-1).tick+6,half:2}]);
  assert.equal(buffer.frames.length,1);
  buffer.append([{...frames[0],epoch:2}]);assert.equal(buffer.frames.length,1);
  buffer.append([{...frames[2],epoch:2},{...frames[1],epoch:2}]);assert.equal(buffer.frames.length,1);
});

test('all-zero and short windows return valid diagnostics instead of fake evidence',()=>{
  assert.equal(identifyInteractions([]).available,false);
  const {frames}=calibrationFrames({excited:false,seconds:3});
  assert.equal(identifyInteractions(frames).reason,'samples');
  assert.throws(()=>identifyInteractions(frames,{penalty:0}),/fit_options/);
});

test('post-training model change reports a negative validation gain',()=>{
  const {frames}=calibrationFrames();
  const split=identifyInteractions(frames).splitTime;
  // Validation trajectories follow only their own velocity. Existing training is intact.
  for(let k=0;k<frames.length-1;k++)if(frames[k].time>=split){
    for(let i=0;i<11;i++){
      const p=frames[k].players[i],q=frames[k+1].players[i];
      q.x=p.x+.2*p.vx;q.y=p.y+.2*p.vy;q.vx=p.vx;q.vy=p.vy;
    }
  }
  const report=identifyInteractions(frames);
  assert.ok(report.agents.some(a=>a.gain<0));
  assert.ok(report.agents.every(a=>a.constantVelocityRmse<1e-10));
});

test('controller trace reconstructs the actual sampled command in all compensator modes',()=>{
  for(const compensator of ['none','damping','pi','lowpass']){
    const tactics=[defaultTactic(0),defaultTactic(1)];tactics[0].compensator=compensator;
    const engine=new MatchEngine({tactics,mode:'formation'});
    for(let k=0;k<90;k++)engine.step();
    for(const p of engine.players){
      const t=p.controlTrace;
      assert.ok(t&&t.time<=engine.time);
      const sum=Object.values(t.parts).reduce((a,b)=>({x:a.x+b.x,y:a.y+b.y}),{x:0,y:0});
      near(sum.x,t.raw.x);near(sum.y,t.raw.y);
      assert.deepEqual(t.command,p.command);
      assert.ok(t.relations.every(e=>e.from!==p.id&&Math.floor(e.from/11)===p.team));
      for(const e of t.relations){near(e.error.x,e.observed.x-t.position.x-e.offset.x);near(e.error.y,e.observed.y-t.position.y-e.offset.y);}
      const correction=t.observerInputs.reduce((a,e)=>({x:a.x+e.correction.x,y:a.y+e.correction.y}),{x:0,y:0});
      near(t.estimateAfter.x,Math.max(-100,Math.min(100,t.estimateBefore.x+t.displacement.x+correction.x)));
      near(t.estimateAfter.y,Math.max(-80,Math.min(80,t.estimateBefore.y+t.displacement.y+correction.y)));
    }
  }
});

test('muted state communication emits no observer arrows while relationship evidence remains independent',()=>{
  const tactics=[defaultTactic(0),defaultTactic(1)];tactics[0].information='ball';
  const engine=new MatchEngine({tactics,mode:'formation'});
  for(let k=0;k<90;k++)engine.step();
  assert.ok(engine.players.slice(0,11).every(p=>p.controlTrace.observerInputs.length===0));
  assert.ok(engine.players.slice(0,11).some(p=>p.controlTrace.relations.length>0));
});

test('trace rendering escapes imported player names and graph preserves sender direction',()=>{
  const engine=new MatchEngine({mode:'formation'});for(let k=0;k<90;k++)engine.step();
  const state=engine.snapshot();state.players[7].name='<script>bad()</script>';
  const trace=tracePanel(state,0,7,'en');assert.ok(!trace.includes('<script>'));
  assert.ok(trace.includes('&lt;script&gt;'));
  const scene=nodeScene(state,{team:0,selected:7,layer:'messages'});
  for(const edge of state.players[7].controlTrace.observerInputs)assert.ok(scene.includes(`#${edge.from%11+1} → #8`));
});

test('both match teams produce separate finite fits without engine mutation',()=>{
  const engine=new MatchEngine(),frames=[];
  for(let k=0;k<1200;k++){engine.step();if(engine.tick%6===0)frames.push(motionFrame(engine.snapshot()));}
  const before=JSON.stringify(engine.checkpoint());
  for(const team of [0,1]){
    const report=identifyInteractions(frames,{team});
    assert.ok(report.available);assert.equal(report.team,team);assert.ok(Number.isFinite(report.rmse));
  }
  assert.equal(JSON.stringify(engine.checkpoint()),before);
});

test('worker samples physical time at 5 Hz across speed changes and resets epochs',async()=>{
  const saved={self:globalThis.self,postMessage:globalThis.postMessage,setInterval:globalThis.setInterval,performance:globalThis.performance};
  let timer,now=0;const messages=[];
  try{
    globalThis.self={};globalThis.postMessage=m=>messages.push(structuredClone(m));
    globalThis.setInterval=fn=>{timer=fn;return 0;};globalThis.performance={now:()=>now};
    await import('../sim-worker.js');
    for(const speed of [1,4,8]){
      self.onmessage({data:{type:'speed',value:speed}});
      for(let i=0;i<20;i++){now+=100;timer();}
    }
    const frames=messages.flatMap(m=>m.observations||[]);
    assert.ok(frames.length>100);
    for(let i=1;i<frames.length;i++)near(frames[i].time-frames[i-1].time,.2);
    const previousEpoch=messages.at(-1).epoch;
    self.onmessage({data:{type:'tactic',team:0,value:defaultTactic(0)}});
    now+=100;timer();assert.ok(messages.at(-1).epoch>previousEpoch);
    self.onmessage({data:{type:'new',options:{seed:123}}});
    now+=100;timer();assert.equal(messages.at(-1).state.seed,123);
    assert.ok(messages.at(-1).observations.every(f=>f.seed===123));
  }finally{Object.assign(globalThis,saved);}
});
