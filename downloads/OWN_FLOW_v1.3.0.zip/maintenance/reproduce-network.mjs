import fs from 'node:fs';
import assert from 'node:assert/strict';
import {MatchEngine} from '../engine.js';
import {runCalibration,identifyInteractions,motionFrame} from '../mas-model.js';

function compareReports(actual,expected,path='report'){
  if(typeof actual==='number'&&typeof expected==='number'){
    assert.ok(Number.isFinite(actual)&&Number.isFinite(expected));
    assert.ok(Math.abs(actual-expected)<=1e-9*Math.max(1,Math.abs(expected)),`Numerical mismatch at ${path}`);
    return;
  }
  if(actual&&expected&&typeof actual==='object'&&typeof expected==='object'){
    assert.deepEqual(Object.keys(actual),Object.keys(expected),`Structure mismatch at ${path}`);
    for(const key of Object.keys(actual))compareReports(actual[key],expected[key],`${path}.${key}`);
    return;
  }
  assert.equal(actual,expected,`Value mismatch at ${path}`);
}

// npm is optional. Run with Node 20+ from the extracted package directory.
// An exported browser evidence file can be passed as the first argument.
if(process.argv[2]){
  const file=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
  assert.equal(file.kind,'FlowInteractionEvidence');
  assert.equal(file.schema,1);
  const result=identifyInteractions(file.frames,{team:file.report.team,penalty:file.report.penalty});
  // Different JS engines may round transcendental functions in the Gram
  // eigensolver differently. Preserve structure and compare all numerics.
  compareReports(result,file.report);
  console.log('Export reproduced within 1e-9 relative/absolute tolerance, including coefficients, scaling and held-out predictions.');
}else{
  const summary={application:'OWN / FLOW 1.3.0',seed:361};
  for(const excited of [true,false]){
    const result=runCalibration(excited);
    summary[excited?'excited':'synchronized']={
      fullRank:result.report.agents.filter(a=>a.identifiable).length,
      ranks:result.report.agents.map(a=>a.rank),
      testRmse:result.report.rmse,baselineRmse:result.report.baselineRmse,
      weightMAE:result.mae,precision:result.precision,recall:result.recall
    };
  }
  const engine=new MatchEngine(),frames=[];
  for(let k=0;k<1200;k++){
    engine.step();
    if(engine.tick%6===0)frames.push(motionFrame(engine.snapshot()));
  }
  const sample=frames.filter(f=>f.time>=10),report=identifyInteractions(sample,{team:0,penalty:.01});
  summary.match={start:report.start,end:report.end,intervals:report.intervals,excluded:report.excluded,
    testRmse:report.rmse,baselineRmse:report.baselineRmse,informativeAgents:report.informative};
  console.log(JSON.stringify(summary,null,2));
}
