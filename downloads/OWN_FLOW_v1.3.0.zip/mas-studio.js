import {MotionBuffer,groupMetrics} from './mas-model.js';
import {nodeScene,tracePanel,neighborPanel,fitSummary,calibrationGraph,tr,fmt,panel,stat} from './mas-view.js';
import {plotChart} from './charts.js';
import {download} from './storage.js';
import {typesetMath} from './math-display.js';

const options=(rows,value)=>rows.map(([v,label])=>`<option value="${v}" ${String(v)===String(value)?'selected':''}>${label}</option>`).join('');
export class NetworkStudio {
  constructor(hooks){
    this.hooks=hooks;this.buffer=new MotionBuffer();this.tab='motion';this.mode='world';
    this.layer='relations';this.all=false;this.seconds=30;this.penalty=.01;
    this.report=null;this.calibration=null;this.worker=null;this.busy=null;
  }
  get L(){return tr(this.hooks.lang());}
  get root(){return document.getElementById('network-studio');}
  get team(){return this.hooks.team();}
  get selected(){return this.hooks.selected()%11;}
  get currentReport(){return this.report?.team===this.team?this.report:null;}
  ingest(frames,epoch){
    const old=this.buffer.epoch;
    const priorHalf=this.buffer.frames.at(-1)?.half;
    const nextHalf=frames?.at(-1)?.half;
    if((old!==null&&old!==epoch)||(priorHalf!==undefined&&nextHalf!==undefined&&priorHalf!==nextHalf)){
      const redrawFit=!!this.report||this.busy==='fit';
      this.buffer.frames=[];this.buffer.epoch=epoch;this.report=null;this.fitFrames=null;
      if(this.busy==='fit'){this.worker?.terminate();this.worker=null;this.busy=null;}
      // Preserve the slider DOM while input events are still arriving.
      if(this.root&&this.tab==='identify'&&redrawFit)this.hooks.render();
    }
    this.buffer.append(frames||[]);
  }
  select(name,label,rows,value){return `<label class="mas-select">${label}<select data-n-key="${name}" aria-label="${label}">${options(rows,value)}</select></label>`;}
  webpage(){
    const L=this.L;
    const tab=(id,en,zh)=>`<button role="tab" aria-selected="${this.tab===id}" class="tab ${this.tab===id?'active':''}" data-n-action="tab" data-value="${id}">${L(en,zh)}</button>`;
    let content='';
    if(this.tab==='motion')content=this.motionPage();
    if(this.tab==='identify')content=this.identifyPage();
    if(this.tab==='diagnose')content=this.diagnosePage();
    const transport=this.tab==='motion'?'':`<button id="play-button" data-action="toggle-run">${this.hooks.state()?.running?L('Pause','暂停'):L('Continue','继续')}</button>`;
    return `<div id="network-studio"><div class="page-head"><div class="page-title"><div class="eyebrow">OWN / FLOW · NETWORKED DYNAMICS</div><h1>${L('Network Studio','多智能体工作台')}</h1><p>${L('Follow the same eleven players from the pitch to signals, interactions and evidence.','从球场到节点、信号与交互，追踪同一组智能体。')}</p></div><div class="head-actions">${this.hooks.pickers()}${transport}</div></div>
      <div class="tabs" role="tablist">${tab('motion','Motion & signals','运动与信号')}${tab('identify','Identify interactions','交互辨识')}${tab('diagnose','Validate & diagnose','验证与诊断')}</div>
      ${content}</div>`;
  }
  graphControls(fit=false){
    const L=this.L;
    return `<div class="mas-graph-controls">${this.select('mode',L('Coordinates','坐标'),[['world',L('Physical positions','真实位置')],['error',L('Formation errors','队形误差')],['observer',L('Centroid estimates','中心估计')]],this.mode)}
      ${fit?'':this.select('layer',L('Connections','连线'),[['relations',L('Used relationships','实际关系输入')],['messages',L('Used state messages','实际状态消息')],['fit',L('Fitted associations','拟合关联')]],this.layer)}
      <label class="mas-check"><input type="checkbox" data-n-key="all" ${this.all?'checked':''}>${L('All receivers','全部接收方')}</label></div>`;
  }
  motionPage(){
    const L=this.L;
    return `<div class="mas-stats" id="mas-live-metrics"></div>
      <div class="mas-dual"><div class="mas-football">${this.hooks.pitch()}</div>
      ${panel(L('The same world, as a network','同一物理世界的网络视图'),`${this.graphControls()}<div id="mas-scene"></div><div class="mas-legend"><span class="blue">${L('Reference / error','参考／误差')}</span><span class="mint">${L('Actual velocity','实际速度')}</span><span class="gold">${L('Command','控制指令')}</span></div><p class="hint" id="mas-scene-note"></p>`,`<span class="chip">11 NODES</span>`)}</div>
      <div class="mas-explanation"><span>01 · ${L('Select a node','选一个节点')}</span><span>02 · ${L('Read its error and inputs','检查误差与输入')}</span><span>03 · ${L('Change a design and compare','修改设计并对照')}</span></div>
      <div class="mas-lower">${panel(L('Inside the selected controller','选中智能体的控制过程'),'<div id="mas-trace"></div>')}${panel(L('Formation agreement over time','队形一致性的时间变化'),`<div class="chart-wrap"><canvas id="mas-error-chart"></canvas></div><div class="mas-legend"><span class="blue">${L('Target RMS','目标误差 RMS')}</span><span class="mint">${L('Offset disagreement','相对偏移分歧')}</span></div><div class="mas-equation">zᵢ = pᵢ − rᵢ<br>D = √mean ‖zᵢ − z̄‖²</div><p class="hint">${L('D → 0 means matching formation offsets. A shared offset can still leave every player away from its target.','D → 0 表示队形偏移趋于一致。即使偏移一致，全队仍可能同时偏离目标。')}</p><button data-action="nav" data-page="ground">${L('Test a consensus controller','测试共识控制器')}</button>`)}</div>
      ${panel(L('Which evidence changed this agent?','哪些证据影响了这个智能体？'),'<div id="mas-neighbors"></div>')}
      <div class="mas-next">${panel(L('Adjust the live team controller','调整实时球队控制器'),`${this.hooks.tuning()}<p class="hint">${L('Changes apply to this team and start a fresh observation window. Per-player overrides still take precedence. Pause the match to inspect a single sample.','修改会应用到当前球队，并重新积累观测窗口。个人覆盖参数仍优先生效，可暂停比赛检查单次采样。')}</p>`)}</div>`;
  }
  identifyPage(){
    const L=this.L;
    return `<div class="mas-identify-toolbar">${this.select('seconds',L('Observation window','观测窗口'),[[10,'10 s'],[30,'30 s'],[60,'60 s']],this.seconds)}${this.select('penalty',L('Regularization λ','正则化 λ'),[[.001,'0.001'],[.01,'0.01'],[.1,'0.1']],this.penalty)}
      <button class="primary" data-n-action="fit" ${this.busy?'disabled':''}>${this.busy==='fit'?L('Fitting…','拟合中…'):L('Fit current window','拟合当前窗口')}</button><button data-n-action="export" ${this.currentReport?.available?'':'disabled'}>${L('Export evidence','导出证据')}</button>
      <span class="hint" id="mas-buffer-count"></span></div>
      <div class="mas-fit-body">${panel(L('Does interaction improve the prediction?','交互项是否改善预测？'),fitSummary(this.currentReport,this.selected,this.hooks.lang()))}
      ${panel(L('Inferred incoming associations','估计的入向关联'),`${this.graphControls(true)}<div id="mas-scene"></div><p class="hint">${L('Mint is positive and coral is negative. Show up to four incoming coefficients per receiver, |w| ≥ 0.025 s⁻¹, only with full rank and >5% held-out gain. These edges describe motion, not packet delivery.','薄荷绿为正系数，珊瑚红为负系数。每个接收方最多显示四条 |w| ≥ 0.025 s⁻¹ 的边，要求满秩且留出段改善超过 5%。这些边描述运动关联。实际消息请查看“运动与信号”。')}</p>`)}</div>
      ${panel(L('Predict the next observed motion','预测下一段实测运动'),`<div class="mas-fit-plots"><div class="chart-wrap"><canvas id="mas-fit-x"></canvas></div><div class="chart-wrap"><canvas id="mas-fit-y"></canvas></div></div><div class="mas-legend"><span class="coral">${L('Observed','实测')}</span><span class="mint">${L('Network model','网络模型')}</span><span class="blue">${L('No-neighbor baseline','无邻居基线')}</span></div><p class="hint">${L('One-step predictions use the actual measured state at each time. The chart shows only the later validation interval.','每一步预测均使用该时刻真实测得的状态。图中仅显示后段验证区间。')}</p>`)}
      ${this.agentComparison()}
      <details class="mas-method"><summary>${L('Model, evidence and interpretation','模型、证据与解释')}</summary><p>${L('Each agent has 14 coefficients, jointly fitted across x and y. Features are scaled with training-only RMS. Ridge minimizes mean squared residual plus λ times the squared scaled coefficients. All ten teammates are candidates. Targets are supplied by the simulator; positions and velocities are sampled at 5 Hz. Controller gains, actual command terms and communication data are excluded from the regression.','每个智能体有 14 个系数，由 x、y 两轴联合拟合。特征按训练段 RMS 缩放，岭回归最小化平均残差平方加 λ 乘缩放系数的平方和。其余 10 名队友全部作为候选。目标由模拟器提供，位置与速度按 5 Hz 采样。回归输入包含运动与目标，不使用控制器增益、指令分项或通信记录。')}</p><p>${L('The first 70% of valid intervals train the model, one interval is omitted, and the later intervals validate it. Restart, halftime, configuration changes, time gaps and large position jumps are excluded. Rank uses the unregularized scaled design with relative Gram eigenvalue cutoff 10⁻⁷. The condition cutoff is 10⁴. A low prediction error cannot establish causal edges or closed-loop stability.','前 70% 有效间隔用于训练，跳过一个间隔，后段用于验证。排除重启、半场、配置变化、时间缺口和大幅位置跳变。秩检查基于未正则化的缩放设计矩阵，Gram 特征值相对阈值 10⁻⁷，条件数阈值 10⁴。较小预测误差本身不能证明因果连接或闭环稳定性。')}</p>
      <p><a href="https://arxiv.org/abs/1609.00864" target="_blank" rel="noopener">Weerts et al. · Network identifiability</a> · <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC5332581/" target="_blank" rel="noopener">Angulo et al. · Reconstruction limits</a></p></details>`;
  }
  agentComparison(){
    const L=this.L,r=this.currentReport;if(!r?.available)return '';
    return `<div class="mas-next">${panel(L('Eleven agents, eleven model checks','逐智能体验证'),`<div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Agent','智能体')}</th><th>${L('Network RMSE','网络 RMSE')}</th><th>${L('Baseline RMSE','基线 RMSE')}</th><th>${L('Gain','改善')}</th><th>${L('Rank','秩')}</th><th>${L('Evidence','证据')}</th></tr></thead><tbody>${r.agents.map(a=>`<tr><td><button class="small quiet" data-n-action="select" data-index="${a.index}">#${a.index+1}</button></td><td>${fmt(a.rmse,3)}</td><td>${fmt(a.baselineRmse,3)}</td><td>${fmt(a.gain===null?null:a.gain*100,1)}%</td><td>${a.rank}/14</td><td>${!a.identifiable?L('Ambiguous','有歧义'):a.informative?L('Improved','有改善'):L('Insufficient gain','改善不足')}</td></tr>`).join('')}</tbody></table></div><p class="hint">${L('RMSE in m/s, per coordinate. All models share the same chronological split. Select a receiver to inspect its coefficients.','RMSE 单位为 m/s，按坐标分量计算。所有模型使用同一时间划分，选择接收方可查看其系数。')}</p>`)}</div>`;
  }
  diagnosePage(){
    const L=this.L;
    return `<div id="mas-diagnosis"></div>
      ${panel(L('Validate the identification method','验证辨识方法'),`<p class="hint">${L('An independent 11-agent linear test has known directed weights. Compare varied target steps with synchronized motion to see when a network can be distinguished. These generated trials are separate from match evidence.','独立的 11 智能体线性测试具有已知有向权重。比较变化目标与完全同步运动，观察哪些情况下可以区分网络。这些生成试验独立于比赛证据。')}</p><div class="mas-equation">vᵢ,k+1 = 0.55(rᵢ − pᵢ) + 0.35vᵢ + Σⱼ wᵢⱼ(zⱼ − zᵢ)<br>wᵢ,i+1 = 0.18 · wᵢ,i+3 = 0.10 · Δt = 0.2 s</div>
      <div class="actions"><button data-n-action="calibrate" data-excited="true" ${this.busy?'disabled':''}>${L('Run varied targets','运行变化目标')}</button><button data-n-action="calibrate" data-excited="false" ${this.busy?'disabled':''}>${L('Run synchronized motion','运行完全同步运动')}</button>${this.calibration?`<button data-n-action="export-calibration">${L('Export validation','导出验证结果')}</button>`:''}</div><div id="mas-calibration">${this.calibrationMarkup()}</div>`)}
      <div class="mas-next">${panel(L('Design → observe → test','设计 → 观察 → 验证'),`<p>${L('Build a controller, apply it to this team, inspect the live signals here, then fork the exact match state to compare an intervention.','搭建控制器并应用到球队，在此检查实时信号，再从完整比赛状态分叉，比较干预效果。')}</p><div class="actions"><button data-action="nav" data-page="ground">${L('Design a controller','设计控制器')}</button><button data-action="fork">${L('Start paired comparison','开始配对比较')}</button><button data-action="nav" data-page="diagnostics">${L('Open player diagnostics','打开球员诊断')}</button></div>`)}</div>`;
  }
  calibrationMarkup(){
    const L=this.L,c=this.calibration;
    if(!c)return `<p class="hint">${this.busy==='calibration'?L('Running the independent test…','正在运行独立测试…'):L('Choose a test to inspect numerical recovery and excitation.','选择一个测试，检查数值恢复和激励情况。')}</p>`;
    const r=c.report,full=r.agents.filter(a=>a.identifiable).length;
    return `<div class="mas-calibration-result"><h3>${c.excited?L('Varied targets · known network','变化目标 · 已知网络'):L('Synchronized motion · ambiguous network','完全同步运动 · 网络有歧义')}</h3><div class="mas-stats">
      ${stat(L('FULL-RANK AGENTS','满秩智能体'),`${full}/11`,'',L('14 coefficients per agent','每个智能体 14 个系数'))}
      ${stat(L('HELD-OUT RMSE','留出段 RMSE'),fmt(r.rmse,5),'m/s',L('Measured against generated truth','与生成真值比较'))}
      ${stat(L('WEIGHT MAE','权重平均绝对误差'),fmt(c.mae,5),'s⁻¹',L('All 110 directed candidates','全部 110 个有向候选'))}
      ${stat(L('EDGE RECALL','边召回率'),full===11?fmt(c.recall*100,0):'—','%',L('Known graph · threshold 0.04 s⁻¹','已知网络 · 阈值 0.04 s⁻¹'))}
      </div><div class="mas-calibration-pair"><div>${calibrationGraph(c,this.hooks.lang())}</div><div><p>${c.excited?L('Independent target changes separate the candidate effects.','各智能体的目标独立变化，使候选作用可以区分。'):L('All relative errors coincide. Many different networks produce the same motion. A small prediction error still leaves the edge weights ambiguous.','所有相对误差相同，多种网络都能产生相同运动。即使预测误差很小，边权仍无法区分。')} ${L('Seed','种子')} 361 · 40 s · λ = 0.001.</p><p>${L('True directed edges','真实有向边')} 22 · ${L('Candidate edges','候选边')} 110 · ${L('Precision','精确率')} ${full===11?fmt(c.precision*100,0)+'%':L('undetermined','未确定')}.</p></div></div></div>`;
  }
  mount(){
    const root=this.root;if(!root)return;
    root.addEventListener('click',e=>{
      const el=e.target.closest('[data-n-action]');if(!el||el.disabled)return;
      const a=el.dataset.nAction;
      if(a==='tab'){this.tab=el.dataset.value;this.hooks.render();}
      if(a==='select')this.hooks.select(this.team*11+Number(el.dataset.index));
      if(a==='fit')this.fit();
      if(a==='calibrate')this.runWorker({type:'calibration',excited:el.dataset.excited==='true'});
      if(a==='export'&&this.currentReport?.available)download('OWN_FLOW_Interaction_Evidence.json',{
        kind:'FlowInteractionEvidence',schema:1,model:'offset-velocity-ridge-v1',
        report:this.currentReport,frames:this.fitFrames,
        interpretation:'Predictive motion associations. Targets supplied by simulator. No causal or stability certificate.'});
      if(a==='export-calibration'&&this.calibration)download('OWN_FLOW_Network_Validation.json',this.calibration);
    });
    root.addEventListener('keydown',e=>{
      if((e.key==='Enter'||e.key===' ')&&e.target.matches('.mas-node')){e.preventDefault();e.stopPropagation();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));}
    });
    root.addEventListener('change',e=>{
      const key=e.target.dataset.nKey;if(!key)return;
      this[key]=key==='all'?e.target.checked:['seconds','penalty'].includes(key)?Number(e.target.value):e.target.value;
      this.paint();
    });
    this.paint();
  }
  fit(){
    this.fitFrames=structuredClone(this.buffer.window(this.seconds));
    this.runWorker({type:'fit',frames:this.fitFrames,options:{team:this.team,penalty:this.penalty}});
  }
  runWorker(message){
    if(this.worker)return;
    this.busy=message.type;this.worker=new Worker('./mas-worker.js',{type:'module'});
    const fail=()=>{this.worker?.terminate();this.worker=null;this.busy=null;this.hooks.toast(this.L('Analysis failed. Please try again.','分析失败，请重试。'));this.hooks.render();};
    this.worker.onmessage=({data})=>{
      if(!data.ok){fail();return;}
      if(message.type==='fit')this.report=data.result;else this.calibration=data.result;
      this.worker.terminate();this.worker=null;this.busy=null;this.hooks.render();
    };
    this.worker.onerror=fail;
    this.worker.postMessage(message);this.hooks.render();
  }
  paint(){
    const root=this.root,s=this.hooks.state();if(!root||!s)return;
    const signature=[s.tick,this.buffer.epoch,this.team,this.selected,this.mode,this.layer,this.all,this.seconds,this.tab].join('|');
    if(root===this.lastRoot&&signature===this.lastPaint)return;
    this.lastRoot=root;this.lastPaint=signature;
    const L=this.L,lang=this.hooks.lang(),frames=this.buffer.window(this.seconds);
    const assign=(id,html)=>{
      const el=root.querySelector('#'+id);if(!el)return;
      const focused=el.contains(document.activeElement)?document.activeElement:null;
      const index=focused?.dataset.index,action=focused?.dataset.action;
      el.innerHTML=html;
      const replacement=index!==undefined?el.querySelector(`[data-index="${index}"]`):
        action?el.querySelector(`[data-action="${action}"]`):null;
      replacement?.focus({preventScroll:true});
    };
    const m=groupMetrics(s,this.team);
    assign('mas-live-metrics',stat(L('ROLE TARGET RMS','角色目标 RMS'),fmt(m.tracking),'m',L('Distance to current targets','到当前角色目标的距离'))+
      stat(L('OFFSET DISAGREEMENT','相对偏移分歧'),fmt(m.shape),'m',L('Spread after subtracting role targets','扣除角色目标后的离散程度'))+
      stat(L('OBSERVER DISAGREEMENT','中心估计分歧'),fmt(m.disagreement),'m',L('Agreement among local estimates','各局部估计之间的一致程度'))+
      stat(L('CENTROID BIAS','中心估计偏差'),fmt(m.bias),'m',L('Mean estimate vs actual centroid','平均估计与真实中心之差')));
    assign('mas-scene',nodeScene(s,{team:this.team,selected:this.selected,mode:this.mode,
      layer:this.tab==='identify'?'fit':this.layer,all:this.all,fit:this.currentReport,lang}));
    const note=this.mode==='world'?L('Node centres use the same physical coordinates as the pitch. Velocity and command arrows project one second.','节点与球场使用同一物理坐标。速度和指令箭头按一秒位移绘制。'):
      this.mode==='error'?L('Each node shows p − r. Consensus here means matching offsets. The origin means reaching each individual role target.','每个节点显示 p − r。此处共识表示偏移一致，原点表示各自到达角色目标。'):
      L('Each node shows its centroid estimate minus the actual team centre. Cluster width measures disagreement; distance from the origin measures bias.','每个节点显示自身中心估计减去真实球队中心。簇的宽度体现分歧，偏离原点体现偏差。');
    assign('mas-scene-note',note+' '+(this.layer==='fit'?L('Fitted associations require a completed fit on the Identify tab.','拟合关联需要先在交互辨识页完成分析。'):L('Arrows point toward the receiver. Evidence is from its latest controller sample.','箭头指向接收方，证据取自最近一次控制采样。')));
    assign('mas-trace',tracePanel(s,this.team,this.selected,lang));
    assign('mas-neighbors',neighborPanel(s,this.team,this.selected,lang));
    assign('mas-buffer-count',`${frames.length} ${L('frames','帧')} · ${fmt(frames.length?frames.at(-1).time-frames[0].time:0,1)} s · 5 Hz`);
    const chart=root.querySelector('#mas-error-chart');
    if(chart){const values=frames.map(f=>({time:f.time,...groupMetrics(f,this.team)}));
      plotChart(chart,[{name:L('Target RMS','目标 RMS'),color:'#72b6f7',points:values.map(v=>({x:v.time,y:v.tracking}))},
        {name:L('Offset disagreement','偏移分歧'),color:'#9be5c6',points:values.map(v=>({x:v.time,y:v.shape}))}],{lang,unit:'m',title:L('Formation errors','队形误差')});}
    const model=this.currentReport?.agents?.[this.selected];
    for(const axis of ['x','y']){
      const canvas=root.querySelector('#mas-fit-'+axis);if(!canvas)continue;
      const rows=(model?.predictions||[]).filter(p=>p.axis===axis);
      plotChart(canvas,[['actual','#f58672',L('Observed','实测')],['fit','#9be5c6',L('Network model','网络模型')],['baseline','#72b6f7',L('Baseline','基线')]].map(([key,color,name])=>({name,color,points:rows.map(p=>({x:p.time,y:p[key]}))})),{lang,unit:`${axis} · m/s`,title:L('Held-out motion','留出段运动')});
    }
    assign('mas-diagnosis',this.diagnosis(s,frames,m));
    typesetMath(root);
  }
  diagnosis(state,frames,m){
    const L=this.L,values=frames.map(f=>groupMetrics(f,this.team));
    const saturation=values.length?values.reduce((s,v)=>s+v.saturation,0)/values.length:0;
    const agents=state.players.filter(p=>p.team===this.team),links=agents.flatMap(p=>p.controlTrace?.observerInputs||[]);
    const age=links.length?links.reduce((s,e)=>s+e.age,0)/links.length:null;
    const maxClosure=Math.max(0,...agents.map(p=>{const t=p.controlTrace;if(!t)return 0;const v=Object.values(t.parts).reduce((s,v)=>({x:s.x+v.x,y:s.y+v.y}),{x:0,y:0});return Math.hypot(v.x-t.raw.x,v.y-t.raw.y);}));
    const cards=[
      [L('Formation agreement','队形一致性'),`${fmt(m.shape)} m`,L('Offset disagreement','相对偏移分歧'),L(`Shared offset is ${fmt(m.translation)} m. Review role targets alongside football tasks.`,`全队共同偏移为 ${fmt(m.translation)} m。结合足球任务检查角色目标。`)],
      [L('Execution limits','执行约束'),`${fmt(saturation*100,1)}%`,L('Window saturation','窗口内限幅比例'),saturation>.25?L('Frequent limits can prevent a larger gain from improving tracking. Compare a smaller gain on matched runs.','频繁限幅可能使增益增大无法改善跟踪，可在配对实验中比较更小增益。'):L('Inspect actual velocity against the requested command to see acceleration-limited response.','比较实际速度与期望指令，观察加速度受限时的响应。')],
      [L('Information freshness','信息时效'),`${fmt(age)} s`,L('Mean age of used messages','使用消息的平均年龄'),L(`${links.length} state inputs used in the latest control samples. Observer disagreement is ${fmt(m.disagreement)} m and centroid bias is ${fmt(m.bias)} m.`,`最近控制采样使用 ${links.length} 个状态输入。估计分歧 ${fmt(m.disagreement)} m，中心偏差 ${fmt(m.bias)} m。`)]
    ];
    return `<div class="mas-diagnostic-cards">${cards.map(([title,value,label,text])=>`<section><span class="eyebrow">${title}</span><strong>${value}</strong><small>${label}</small><p>${text}</p></section>`).join('')}</div>
      <div class="mas-audit-line">${L('Signal accounting','信号核算')} · ${L('Maximum sum-to-command residual','分项求和最大残差')} ${maxClosure.toExponential(2)} m/s · ${L('Sampled physical time','采样物理时间')} ${fmt(state.time)} s</div>`;
  }
}
