import {identifyInteractions,runCalibration} from './mas-model.js';
self.onmessage=({data})=>{
  try{
    const result=data.type==='calibration'?runCalibration(data.excited):identifyInteractions(data.frames,data.options);
    postMessage({ok:true,result});
  }catch(error){postMessage({ok:false,error:error.message});}
};
