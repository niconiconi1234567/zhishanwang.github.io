// Perspective software renderer: the same physical world, for devices without WebGL.
const add = (a, b) => a.map((v, i) => v + b[i]),
  sub = (a, b) => a.map((v, i) => v - b[i]),
  dot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0),
  unit = (a) => {
    let n = Math.hypot(...a);
    return a.map((v) => v / n);
  },
  cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
const seed = (s) => () => {
  s = (s * 1664525 + 1013904223) >>> 0;
  return s / 4294967296;
};
export class CanvasPitchRenderer {
  constructor(container, onSelect) {
    this.container = container;
    this.onSelect = onSelect;
    this.canvas = document.createElement("canvas");
    this.ctx = this.canvas.getContext("2d");
    this.canvas.setAttribute("role", "img");
    this.canvas.setAttribute(
      "aria-label",
      "Interactive perspective football field · compatibility renderer",
    );
    container.append(this.canvas);
    this.state = null;
    this.cameraMode = "broadcast";
    this.zoom = 1;
    this.flags = {};
    this.scope = "selected";
    this.selected = 7;
    this.agentView = false;
    this.fps = 0;
    this.start = performance.now();
    this.frames = 0;
    this.positions = [];
    this.dead = false;
    this.label = document.createElement("div");
    this.label.className = "pitch-player-label";
    container.append(this.label);
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(container);
    this.canvas.addEventListener("pointerup", (e) => {
      const r = this.canvas.getBoundingClientRect();
      let chosen = null,
        best = 17;
      this.state?.players.forEach((p) => {
        if (
          this.agentView &&
          p.id !== this.selected &&
          !this.state.players[this.selected].visible.some((q) => q.id === p.id)
        )
          return;
        let v = this.project([p.x, 1, p.y]),
          d = Math.hypot(v.x - e.clientX + r.left, v.y - e.clientY + r.top);
        if (d < best) {
          chosen = p.id;
          best = d;
        }
      });
      if (chosen !== null) this.onSelect(chosen);
    });
    this.resize();
    this.frame();
  }
  resize() {
    this.w = this.container.clientWidth;
    this.h = this.container.clientHeight;
    if (!this.w || !this.h) return;
    let pr = Math.min(devicePixelRatio, 1.5);
    this.ratio = pr;
    this.canvas.width = Math.round(this.w * pr);
    this.canvas.height = Math.round(this.h * pr);
    this.canvas.style.width = this.w + "px";
    this.canvas.style.height = this.h + "px";
    this.setupCamera();
    this.background = null;
  }
  setupCamera() {
    const fit = this.w / this.h < 1.25 ? 1.4 : 1,
      z = this.zoom || 1;
    this.eye =
      this.cameraMode === "tactical"
        ? [0, (114 * fit) / z, (27 * fit) / z]
        : [5, (76 * fit) / z, (95 * fit) / z];
    this.forward = unit(sub([0, 0, 0], this.eye));
    this.right = unit(cross(this.forward, [0, 1, 0]));
    this.up = cross(this.right, this.forward);
    this.focal = this.h / (2 * Math.tan((42 * Math.PI) / 360));
  }
  project(point) {
    let d = sub(point, this.eye),
      depth = dot(d, this.forward);
    return {
      x: this.w / 2 + (dot(d, this.right) * this.focal) / depth,
      y: this.h / 2 - (dot(d, this.up) * this.focal) / depth,
      scale: this.focal / depth,
      depth,
    };
  }
  configure(opts) {
    let old = this.cameraMode + ":" + this.zoom;
    Object.assign(this, opts);
    if (old !== this.cameraMode + ":" + this.zoom) {
      this.setupCamera();
      this.background = null;
    }
  }
  setState(s) {
    this.previous = this.state;
    this.received = performance.now();
    this.state = s;
  }
  path(points, color, width = 1, fill = null, alpha = 1) {
    let ctx = this.ctx;
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    points.forEach((v, i) => {
      let p = this.project(v);
      if (i === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    });
    if (fill) {
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
    }
    if (color) {
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  rect(x, z, w, d, y, color) {
    this.path(
      [
        [x, y, z],
        [x + w, y, z],
        [x + w, y, z + d],
        [x, y, z + d],
      ],
      null,
      0,
      color,
    );
  }
  ring(x, z, r, color, y = 0.03, width = 1, alpha = 1) {
    let pts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * 2 * Math.PI;
      pts.push([x + Math.cos(a) * r, y, z + Math.sin(a) * r]);
    }
    this.path(pts, color, width, null, alpha);
  }
  sphere(point, r, color) {
    const c = this.ctx,
      p = this.project(point);
    c.beginPath();
    c.ellipse(p.x, p.y, r * p.scale, r * p.scale, 0, 0, Math.PI * 2);
    c.fillStyle = color;
    c.fill();
  }
  staticScene() {
    const c = this.ctx;
    const sky = c.createLinearGradient(0, 0, 0, this.h);
    sky.addColorStop(0, "#23373c");
    sky.addColorStop(1, "#263c33");
    c.fillStyle = sky;
    c.fillRect(0, 0, this.w, this.h);
    this.rect(-75, -55, 150, 110, -0.1, "#284331");
    for (let side of [-1, 1])
      for (let row = 8; row >= 0; row--) {
        let z = side * (42 + row * 1.7);
        this.rect(
          -68,
          z,
          136,
          side * 1.7,
          0.5 + row * 0.7,
          row % 2 ? "#31424d" : "#293943",
        );
      }
    for (let side of [-1, 1])
      for (let row = 5; row >= 0; row--) {
        let x = side * (60 + row * 2);
        this.rect(x, -40, side * 2, 80, 0.5 + row * 0.65, "#30434c");
      }
    let rng = seed(32);
    for (let i = 0; i < 2000; i++) {
      let side = i % 2 ? 1 : -1,
        row = Math.floor(rng() * 9),
        x = (rng() - 0.5) * 134,
        z = side * (42 + row * 1.7);
      this.sphere(
        [x, 1.1 + row * 0.7, z],
        0.22,
        ["#83949b", "#c0a692", "#557887", "#889db0", "#335569", "#8e6e60"][
          Math.floor(rng() * 6)
        ],
      );
    }
    for (let z of [-38, 38]) {
      this.path(
        [
          [-61, 0, z],
          [61, 0, z],
          [61, 0.9, z],
          [-61, 0.9, z],
        ],
        null,
        0,
        "#112e3d",
      );
      for (let x = -51; x < 55; x += 19) {
        let a = this.project([x, 0.45, z]),
          b = this.project([x + 16, 0.45, z]);
        c.save();
        c.translate(a.x, a.y);
        c.rotate(Math.atan2(b.y - a.y, b.x - a.x));
        c.fillStyle = "#a5c6d2";
        c.font = `600 ${Math.max(4, 1.7 * a.scale)}px sans-serif`;
        c.fillText(x % 2 ? "OWN / FLOW" : "INTELLIGENCE", 0, 0);
        c.restore();
      }
    }
    for (let i = 0; i < 14; i++)
      this.rect(
        -52.5 + i * 7.5,
        -34,
        7.5,
        68,
        0,
        i % 2 ? "#4d7d3b" : "#447333",
      );
    rng = seed(171);
    for (let i = 0; i < 10000; i++) {
      let x = (rng() - 0.5) * 105,
        z = (rng() - 0.5) * 68,
        p = this.project([x, 0.003, z]);
      c.fillStyle =
        rng() > 0.5 ? "rgba(191,204,126,.11)" : "rgba(15,45,19,.11)";
      c.fillRect(p.x, p.y, 0.12 * p.scale, 0.3 * p.scale);
    }
    const ground = (points) =>
      this.path(
        points.map((p) => [p[0], 0.03, p[1]]),
        "#e4ebd3",
        0.85,
      );
    ground([
      [-52.5, -34],
      [52.5, -34],
      [52.5, 34],
      [-52.5, 34],
      [-52.5, -34],
    ]);
    ground([
      [0, -34],
      [0, 34],
    ]);
    this.ring(0, 0, 9.15, "#e3ead4", 0.03, 0.8);
    this.sphere([0, 0.05, 0], 0.12, "#edf1dc");
    for (let s of [-1, 1]) {
      ground([
        [s * 52.5, -20.16],
        [s * 36, -20.16],
        [s * 36, 20.16],
        [s * 52.5, 20.16],
      ]);
      ground([
        [s * 52.5, -9.16],
        [s * 47, -9.16],
        [s * 47, 9.16],
        [s * 52.5, 9.16],
      ]);
      this.sphere([s * 41.5, 0.05, 0], 0.11, "#edf1dc");
      let arc = [];
      for (let j = 0; j <= 40; j++) {
        let a = -0.92 + (j / 40) * 1.84;
        arc.push([s * (41.5 - 9.15 * Math.cos(a)), 9.15 * Math.sin(a)]);
      }
      ground(arc);
      this.drawGoal(s);
      for (let y of [-33.8, 33.8]) {
        this.path(
          [
            [s * 52.3, 0, y],
            [s * 52.3, 1.6, y],
          ],
          "#ebedd5",
          1,
        );
        this.path(
          [
            [s * 52.3, 1.6, y],
            [s * 52.3 + 0.4, 1.6, y],
            [s * 52.3 + 0.4, 1.3, y],
            [s * 52.3, 1.3, y],
          ],
          null,
          0,
          "#e9c867",
        );
      }
    }
    this.background = document.createElement("canvas");
    this.background.width = this.canvas.width;
    this.background.height = this.canvas.height;
    this.background.getContext("2d").drawImage(this.canvas, 0, 0);
  }
  drawGoal(side) {
    const x = side * 52.5,
      back = side * 55;
    for (let y of [-3.66, 3.66])
      this.path(
        [
          [x, 0, y],
          [x, 2.44, y],
          [back, 1.8, y],
          [back, 0, y],
        ],
        "#d9e1d8",
        1.15,
      );
    this.path(
      [
        [x, 2.44, -3.66],
        [x, 2.44, 3.66],
      ],
      "#f4f5e8",
      1.5,
    );
    this.path(
      [
        [back, 0, -3.66],
        [back, 1.8, -3.66],
        [back, 1.8, 3.66],
        [back, 0, 3.66],
      ],
      "#c6d6cd",
      0.6,
    );
    for (let y = -3.66; y < 3.67; y += 0.32) {
      this.path(
        [
          [x, 2.44, y],
          [back, 1.8, y],
          [back, 0, y],
        ],
        "#d7e5d2",
        0.45,
        null,
        0.4,
      );
    }
    for (let h = 0.2; h < 1.9; h += 0.25)
      this.path(
        [
          [back, h, -3.66],
          [back, h, 3.66],
        ],
        "#d7e5d2",
        0.45,
        null,
        0.4,
      );
  }
  limb(a, b, width, color) {
    const A = this.project(a),
      B = this.project(b),
      c = this.ctx;
    c.beginPath();
    c.moveTo(A.x, A.y);
    c.lineTo(B.x, B.y);
    c.lineWidth = Math.max(0.6, (width * (A.scale + B.scale)) / 2);
    c.strokeStyle = color;
    c.lineCap = "round";
    c.stroke();
  }
  drawPlayer(p) {
    const old = this.previous?.players[p.id],
      a = Math.min(1, (performance.now() - this.received) / 90);
    if (this.state.running && old && Math.hypot(old.x - p.x, old.y - p.y) < 4)
      p = {
        ...p,
        x: old.x + (p.x - old.x) * a,
        y: old.y + (p.y - old.y) * a,
        heading:
          old.heading +
          Math.atan2(
            Math.sin(p.heading - old.heading),
            Math.cos(p.heading - old.heading),
          ) *
            a,
      };
    const t = this.state.time,
      sp = Math.hypot(p.vx, p.vy),
      amp = Math.min(1, sp / 5),
      phase = t * (sp > 5 ? 12 : 9) + p.id * 1.37,
      kick = ["pass", "shoot"].includes(p.action),
      save = p.action === "save",
      skin = ["#cb926d", "#ac7654", "#ebbb99", "#784c35", "#ddad87"][p.id % 5],
      color =
        p.index === 0
          ? p.team
            ? "#ba91d6"
            : "#d6dd83"
          : this.state.tactics[p.team].color,
      shorts = p.team ? "#4c3438" : "#e1e8e5",
      sock = p.team ? color : "#d9e5e4";
    const scale = 1.16,
      bob = Math.abs(Math.sin(phase)) * 0.05 * amp,
      cos = Math.cos(p.heading),
      sin = Math.sin(p.heading),
      joint = (lat, h, fwd) => [
        p.x + (cos * fwd - sin * lat) * scale,
        (h + bob) * scale,
        p.y + (sin * fwd + cos * lat) * scale,
      ];
    const shadow = this.project([p.x + 0.3, 0.01, p.y + 0.15]),
      c = this.ctx;
    c.beginPath();
    c.ellipse(
      shadow.x,
      shadow.y,
      0.62 * shadow.scale,
      0.22 * shadow.scale,
      0.1,
      0,
      Math.PI * 2,
    );
    c.fillStyle = "#172e2563";
    c.fill();
    for (let side of [-1, 1]) {
      let swing = Math.sin(phase + (side > 0 ? Math.PI : 0)) * 0.48 * amp;
      if (kick && side === 1) swing = 0.75;
      const hip = joint(side * 0.12, 0.9, 0),
        knee = joint(side * 0.12, 0.51, Math.sin(swing) * 0.4),
        foot = joint(
          side * 0.12,
          0.08 + Math.max(0, -Math.sin(swing)) * 0.2,
          Math.sin(swing) * 0.72,
        );
      this.limb(hip, knee, 0.17, shorts);
      this.limb(knee, foot, 0.115, sock);
      this.limb(
        foot,
        add(foot, [cos * 0.15, 0, sin * 0.15]),
        0.12,
        p.id % 3 ? "#223435" : "#e6d86e",
      );
    }
    const hips = joint(0, 0.95, 0),
      shoulder = joint(0, 1.36, 0.035);
    this.limb(hips, shoulder, 0.43, color);
    this.limb(joint(-0.19, 1.36, 0), joint(0.19, 1.36, 0), 0.18, color);
    for (let side of [-1, 1]) {
      let swing = -Math.sin(phase + (side > 0 ? Math.PI : 0)) * 0.35 * amp;
      let sh = joint(side * 0.25, 1.34, 0),
        el = joint(side * 0.31, save ? 1.57 : 1.1, swing),
        hand = joint(
          side * (save ? 0.65 : 0.29),
          save ? 1.7 : 0.93,
          swing + 0.12,
        );
      this.limb(sh, el, 0.14, color);
      this.limb(el, hand, 0.09, skin);
      if (p.index === 0) this.sphere(hand, 0.055, "#edf1d5");
    }
    this.sphere(joint(0, 1.65, 0.03), 0.155, skin);
    this.sphere(joint(0, 1.76, 0.0), 0.12, p.id % 3 ? "#332c24" : "#232423");
    const chest = this.project(joint(0, 1.2, 0.13));
    if (chest.scale > 6) {
      c.font = `700 ${0.26 * chest.scale}px sans-serif`;
      c.fillStyle = "#f8f8ec";
      c.textAlign = "center";
      c.fillText(String(p.index + 1), chest.x, chest.y);
    }
  }
  drawOverlay() {
    const s = this.state,
      p = s.players[this.selected],
      cfg = s.tactics[p.team];
    const use = s.players.filter(
      (q) =>
        this.scope === "all" ||
        (this.scope === "team" && q.team === p.team) ||
        (this.scope === "unit" &&
          q.team === p.team &&
          cfg.groups.some(
            (g) => g.members.includes(p.index) && g.members.includes(q.index),
          )) ||
        q.id === p.id,
    );
    for (let q of use) {
      if (this.flags.prediction && q.prediction?.length)
        this.path(
          [[q.x, 0.1, q.y], ...q.prediction.map((v) => [v.x, 0.1, v.y])],
          "#a5f3cf",
          1.25,
        );
      if (this.flags.history && q.trail?.length)
        this.path(
          q.trail.map((v) => [v.x, 0.08, v.y]),
          "#b5d4e0",
          1,
          null,
          0.6,
        );
      if (this.flags.command) {
        let end = [q.x + q.command.x * 0.8, 0.1, q.y + q.command.y * 0.8];
        this.path([[q.x, 0.1, q.y], end], "#f7d27c", 1.3);
        const a = this.project([q.x, 0.1, q.y]),
          b = this.project(end),
          d = Math.atan2(b.y - a.y, b.x - a.x),
          ctx = this.ctx;
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - Math.cos(d - 0.5) * 5, b.y - Math.sin(d - 0.5) * 5);
        ctx.lineTo(b.x - Math.cos(d + 0.5) * 5, b.y - Math.sin(d + 0.5) * 5);
        ctx.fillStyle = "#f7d27c";
        ctx.fill();
      }
      if (this.flags.targets) this.ring(q.target.x, q.target.y, 0.7, "#f8d78a");
      if (this.flags.centroids)
        this.ring(q.estimate.x, q.estimate.y, 0.45, "#98b9ef", 0.08, 1);
    }
    if (this.flags.centroids) {
      let m = s.metrics[p.team];
      if (m) {
        this.ring(m.centroid.x, m.centroid.y, 1.15, "#fff0bc", 0.08, 1.5);
        this.ring(m.reference.x, m.reference.y, 1.5, "#a5f3cf", 0.08, 1.4);
      }
    }
    for (let [key, color, edges] of [
      ["tactical", "#f0cf82", cfg.tacticalEdges],
      ["communication", "#79d4e7", cfg.commEdges],
    ])
      if (this.flags[key])
        for (let [a, b] of edges) {
          let A = s.players[p.team * 11 + a],
            B = s.players[p.team * 11 + b];
          this.path(
            [
              [A.x, 0.12, A.y],
              [B.x, 0.12, B.y],
            ],
            color,
            0.8,
            null,
            0.65,
          );
        }
    if (this.flags.observation || this.agentView) {
      let angle = (cfg.fov * Math.PI) / 180,
        points = [[p.x, 0.05, p.y]];
      for (let j = 0; j <= 48; j++) {
        let a = p.heading - angle / 2 + (angle * j) / 48;
        points.push([
          p.x + Math.cos(a) * p.vision,
          0.05,
          p.y + Math.sin(a) * p.vision,
        ]);
      }
      points.push([p.x, 0.05, p.y]);
      this.path(points, "#9fe7c9", 1, "#8ef3cb", 0.14);
      this.path(points, "#a7ebd2", 1, null, 0.6);
    }
  }
  frame() {
    if (this.dead) return;
    requestAnimationFrame(() => this.frame());
    let now = performance.now();
    this.frames++;
    if (now - this.start > 1000) {
      this.fps = Math.round((this.frames * 1000) / (now - this.start));
      this.frames = 0;
      this.start = now;
    }
    if (!this.container.isConnected || !this.state || !this.w || !this.h)
      return;
    const c = this.ctx;
    c.setTransform(this.ratio, 0, 0, this.ratio, 0, 0);
    if (!this.background) this.staticScene();
    else c.drawImage(this.background, 0, 0, this.w, this.h);
    let s = this.state,
      p = s.players[this.selected],
      known = new Set([p.id, ...p.visible.map((q) => q.id)]);
    this.drawOverlay();
    this.ring(p.x, p.y, 0.8, "#b0f6d4", 0.05, 1.4);
    let draw = s.players
      .filter((q) => !this.agentView || known.has(q.id))
      .map((q) => ({ depth: this.project([q.x, 0, q.y]).depth, p: q }));
    draw.push({
      depth: this.project([s.ball.x, 0, s.ball.y]).depth,
      ball: true,
    });
    draw.sort((a, b) => b.depth - a.depth);
    for (let item of draw) {
      if (item.ball) {
        if (
          this.agentView &&
          (p.knownBall?.via !== "vision" || s.time - p.knownBall.time >= 0.12)
        )
          continue;
        let b = s.ball,
          a = this.project([b.x, 0, b.y]);
        c.beginPath();
        c.ellipse(a.x, a.y, 0.22 * a.scale, 0.1 * a.scale, 0, 0, Math.PI * 2);
        c.fillStyle = "#1229207a";
        c.fill();
        this.sphere([b.x, Math.max(0.17, b.z), b.y], 0.2, "#f5f2dc");
        let v = this.project([b.x, Math.max(0.17, b.z) + 0.03, b.y]);
        c.fillStyle = "#3a4845";
        c.fillRect(v.x - 0.4, v.y - 0.4, 0.9, 0.9);
      } else this.drawPlayer(item.p);
    }
    let v = this.project([p.x, 2.6, p.y]);
    this.label.textContent =
      String(p.index + 1).padStart(2, "0") + " " + p.name;
    this.label.style.left = v.x + "px";
    this.label.style.top = v.y + "px";
  }
  mount(container) {
    this.observer.disconnect();
    this.container = container;
    container.append(this.canvas, this.label);
    this.observer.observe(container);
    this.resize();
  }
  dispose() {
    this.dead = true;
    this.observer.disconnect();
  }
}
