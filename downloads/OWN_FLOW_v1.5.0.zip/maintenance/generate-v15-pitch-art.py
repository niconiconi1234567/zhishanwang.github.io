"""Generate the original v1.5 pitch and terrace colour textures from scratch.

Requires Python 3, NumPy and Pillow. Run this file from any working directory.
No photographs, club marks, source images or external assets are read. Both
renderers can use these same colour maps; pitch markings remain runtime geometry.

UV contract: turf covers 105 m horizontally and 68 m vertically. Terrace is the
existing 2048 x 192 horizontal bank, with the top row at the top of the image.
The fine detail is deliberately restrained so tactical-camera downsampling does
not turn the pitch or crowd into sparkling noise.

Use --check to regenerate in memory and verify the bundled files without edits.
"""
from __future__ import annotations

import argparse
import hashlib
import io
from pathlib import Path
import random

import numpy as np
from PIL import Image, ImageDraw


ASSETS = Path(__file__).resolve().parents[1] / "assets"
PITCH_SIZE = (2048, 1328)
TERRACE_SIZE = (2048, 192)


def smooth_noise(rng, width, height, cols, rows):
    """A smooth zero-centred field with a fixed amplitude, without seams."""
    values = rng.normal(128, 27, (rows, cols)).clip(0, 255).astype("uint8")
    field = Image.fromarray(values).resize((width, height), Image.Resampling.BICUBIC)
    return (np.asarray(field, dtype="float32") - 128) / 27


def make_turf():
    rng = np.random.default_rng(15052026)
    width, height = PITCH_SIZE
    x = np.linspace(-52.5, 52.5, width, dtype="float32")[None, :]
    y = np.linspace(-34, 34, height, dtype="float32")[:, None]
    broad = smooth_noise(rng, width, height, 17, 11)
    growth = smooth_noise(rng, width, height, 97, 63)
    tufts = smooth_noise(rng, width, height, 420, 270)

    # Sixteen neat cut bands. Their small edge feather is intentional, while the
    # nominal band position stays straight and legible from a high camera.
    lane = np.tanh(np.sin(np.pi * (x + 52.5) / 6.5625) * 9.0)

    # Directional blade grain: short, closely related samples, not independent
    # coloured pixels. Alternating cut direction slightly changes the blade lean.
    seed = rng.normal(0, 1, (height, width)).astype("float32")
    forward = sum(weight * np.roll(seed, (step, step // 3), (0, 1))
                  for step, weight in enumerate((.34, .25, .19, .13, .09)))
    backward = sum(weight * np.roll(seed, (step, -(step // 3)), (0, 1))
                   for step, weight in enumerate((.34, .25, .19, .13, .09)))
    fibre = np.where(lane > 0, forward, backward)
    short_blades = smooth_noise(rng, width, height, 1024, 340)

    # Almost even albedo lets each renderer provide scene lighting. The natural
    # broad variation is considerably weaker than the mowing contrast.
    luminance = (5.1 * lane + 1.35 * broad + .95 * growth + .60 * tufts
                 + 1.65 * fibre + .70 * short_blades)

    # Light goalkeeper footfall, with a healthy strip at the goal line. There
    # are no baked white lines, centre spots, circles, shadows or advertisements.
    goal_mouth = np.exp(-((np.abs(x) - 49.6) / 3.25) ** 2 - (y / 5.3) ** 2)
    keeper_step = np.exp(-((np.abs(x) - 47.0) / 2.4) ** 2 - ((y + .25) / 2.7) ** 2)
    wear = np.clip((.29 * goal_mouth + .12 * keeper_step)
                   * (1 + .22 * growth + .12 * tufts), 0, .52)
    # Flattened yellow-green fibres, rather than large brown patches.
    rgb = np.stack((59.5 + .82 * luminance + 24 * wear,
                    101.0 + luminance + 3 * wear,
                    60.0 + .66 * luminance - 11 * wear), axis=2)

    # Sparse small divots are restricted to the same lightly worn zone. Their
    # low contrast survives closer views without making a distant field dirty.
    speckle = np.maximum(0, rng.normal(0, 1, (height, width)) - 2.15) * wear
    rgb += speckle[:, :, None] * np.array((2.6, -3.4, -2.5), dtype="float32")
    return Image.fromarray(rgb.clip(0, 255).astype("uint8"))


def shade(rgb, amount):
    return tuple(max(0, min(255, round(channel + amount))) for channel in rgb)


def make_terrace():
    rng = random.Random(15052719)
    width, height = TERRACE_SIZE
    image = Image.new("RGB", (width, height), (37, 49, 53))
    draw = ImageDraw.Draw(image)

    # Contiguous sections give the crowd an architectural rhythm. A restrained
    # palette has coherent groups, empty seats and small warm skin accents.
    coat_palettes = (
        ((57, 84, 89), (70, 94, 96), (91, 109, 109), (65, 77, 83), (123, 128, 119)),
        ((74, 82, 91), (86, 96, 106), (112, 116, 119), (58, 75, 84), (127, 121, 111)),
        ((64, 86, 88), (77, 101, 101), (104, 119, 113), (56, 72, 80), (118, 124, 116)),
        ((80, 83, 87), (100, 103, 106), (117, 111, 104), (64, 78, 86), (105, 124, 123)),
    )
    skin = ((164, 129, 107), (143, 109, 88), (185, 149, 121),
            (117, 89, 75), (174, 139, 116))
    hair = ((52, 48, 43), (67, 59, 49), (84, 77, 63), (45, 44, 42))
    seat_colour = (52, 75, 82)
    section_width, aisle_width = 256, 23

    # Nine rows retain the old texture's scale on every existing seating mesh.
    for row in range(9):
        y = 8 + row * 20
        row_light = .9 * row
        draw.rectangle((0, y, width, y + 19), fill=shade((42, 54, 58), row_light))
        draw.rectangle((0, y + 16, width, y + 19), fill=(29, 43, 49))
        draw.line((0, y + 19, width, y + 19), fill=shade((94, 107, 108), row_light * .5))

        for section in range(8):
            x0 = section * section_width
            palette = coat_palettes[section % len(coat_palettes)]
            # Clear, uninterrupted stairs down each section boundary.
            draw.rectangle((x0, y, x0 + aisle_width - 1, y + 16), fill=(71, 82, 83))
            draw.line((x0 + 2, y + 16, x0 + aisle_width - 3, y + 16), fill=(113, 121, 118))
            draw.line((x0, y, x0, y + 19), fill=(36, 50, 55))
            # Handrails run down an aisle, small and lower contrast than the
            # shoulders of nearby spectators, avoiding bright vertical stripes.
            draw.line((x0 + 10, y, x0 + 10, y + 19), fill=(99, 111, 109), width=1)

            for col in range(20):
                x = x0 + aisle_width + 5 + col * 11
                seat = shade(seat_colour, rng.choice((-3, 0, 2)))
                draw.rounded_rectangle((x, y + 3, x + 8, y + 14), radius=2, fill=seat)
                draw.line((x + 1, y + 14, x + 8, y + 14), fill=(27, 43, 49), width=2)
                # Repeated small vacancies read as seats; do not scatter large
                # saturated pixels between every head.
                if rng.random() < (.075 + .025 * ((section + row) % 3)):
                    continue
                px = x + 4 + rng.choice((-1, 0, 0, 0, 1))
                py = y + 12 + rng.choice((-1, 0, 0, 1))
                coat = shade(rng.choice(palette), rng.choice((-5, -2, 0, 2, 4)))
                draw.ellipse((px - 4, py, px + 5, py + 4), fill=(25, 38, 44))
                draw.polygon(((px - 2, py - 7), (px + 2, py - 7),
                              (px + 4, py - 4), (px + 4, py + 1),
                              (px - 4, py + 1), (px - 4, py - 3)), fill=coat)
                draw.line((px - 2, py - 5, px - 3, py - 1), fill=shade(coat, 8))
                draw.ellipse((px - 2, py - 12, px + 2, py - 7), fill=rng.choice(skin))
                draw.arc((px - 2, py - 12, px + 2, py - 8), 170, 355,
                         fill=rng.choice(hair), width=2)

        # Narrow cross-bank safety rails give depth without hiding every row.
        if row in (3, 7):
            draw.line((0, y + 17, width, y + 17), fill=(101, 119, 118))
            draw.line((0, y + 18, width, y + 18), fill=(39, 58, 64))

    # Simple unbranded top parapet and near lip. A faint vertical light falloff
    # adds depth as a bank while preserving the palette's restrained character.
    draw.rectangle((0, 0, width, 3), fill=(28, 43, 50))
    draw.line((0, 4, width, 4), fill=(75, 91, 94))
    draw.rectangle((0, 189, width, 191), fill=(31, 46, 52))
    pixels = np.asarray(image, dtype="float32")
    depth = np.linspace(.91, 1.0, height, dtype="float32")[:, None, None]
    return Image.fromarray((pixels * depth).clip(0, 255).astype("uint8"))


def encode_jpeg(image, quality):
    output = io.BytesIO()
    image.save(output, format="JPEG", quality=quality, subsampling=0,
               optimize=True, progressive=True)
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true",
                        help="compare deterministic output with existing assets; do not write")
    args = parser.parse_args()
    outputs = (("turf-v15.jpg", make_turf(), 92),
               ("terrace-v15.jpg", make_terrace(), 93))
    if not args.check:
        ASSETS.mkdir(parents=True, exist_ok=True)
    for name, image, quality in outputs:
        data = encode_jpeg(image, quality)
        destination = ASSETS / name
        if args.check:
            if not destination.is_file() or destination.read_bytes() != data:
                raise SystemExit(f"FAIL: {name} differs from its deterministic generator")
        else:
            destination.write_bytes(data)
        print(f"{'PASS' if args.check else 'WROTE'} {name}: {image.width} x {image.height}, "
              f"{len(data):,} bytes, sha256 {hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
