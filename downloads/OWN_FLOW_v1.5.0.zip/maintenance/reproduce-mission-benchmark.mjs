import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {MatchEngine} from '../engine.js';
import {taskWindowSummary} from '../task-monitor.js';
const path=process.argv[2]??new URL('./mission-benchmark.json.gz',import.meta.url);
let bytes=fs.readFileSync(path);if(bytes[0]===31&&bytes[1]===139)bytes=gunzipSync(bytes);
const r=JSON.parse(bytes);assert.equal(r.kind,'BenchmarkReport');let maxError=0,branches=0;
for(const pair of r.results)for(const side of ['a','b']){
 const e=MatchEngine.restore(pair.initialCheckpoint),start=structuredClone(e.journal);
 if(side==='b')e.setTactic(r.team,pair.branchBTactic);
 for(let k=0;k<r.duration*30;k++)e.step();
 for(const [key,value] of Object.entries(taskWindowSummary(start,e.journal,r.team))){
  const expected=pair[side][key];if(value===null){assert.equal(expected,null);continue;}
  const error=Math.abs(value-expected);maxError=Math.max(maxError,error);assert.ok(error<=1e-9*Math.max(1,Math.abs(expected)),`${side}.${key}: ${error}`);
 }
 assert.deepEqual(e.score,pair[side].score);branches++;
}
console.log(JSON.stringify({valid:true,branches,taskMetricsPerBranch:10,maxAbsoluteError:maxError,tolerance:1e-9},null,2));
