import test from 'node:test';
import assert from 'node:assert/strict';
import {missionPreset,validateMission,localMission,validMissionMemory} from '../mission-core.js';
import {addTransition,stateCycle,graphWarnings,MissionGraph,GRAPH_POSITIONS} from '../mission-graph.js';
import {missionOverlay} from '../mission-visual.js';
import {phaseReadiness} from '../phase-workflow.js';
import {calibrationFrames,usableIntervals} from '../mas-model.js';
import {MatchEngine} from '../engine.js';
const p=()=>({id:1,index:1,team:0,x:0,y:0,neighbors:{},visible:[],knownBall:{x:6,y:0,vx:0,vy:0,owner:12,time:1,via:'vision'}});
const edge=(from,state,guard='always',id='r1')=>({id,from,state,guard,enabled:true});
const policy=rules=>({...missionPreset('balanced'),minDwell:0,guardDwell:0,rules});
const step=(a,c,t=1,phase='live')=>{a.knownBall.time=t;return localMission(a,c,{x:0,y:0},t,1,phase);};
test('DES edges require their source state and commit stable transition IDs',()=>{
 const a=p(),c=policy([edge('recover','press')]);let r=step(a,c);assert.equal(r.mission.state,'hold');assert.equal(r.transition,null);
 c.rules[0].from='hold';r=step(a,c);assert.equal(r.mission.state,'press');assert.equal(r.transition.edgeId,'r1');assert.deepEqual(r.mission.lastTransition,{from:'hold',to:'press',edgeId:'r1',rule:'always',time:1,revision:0});
 a.mission=r.mission;assert.equal(step(a,c,1.1).mission.state,'press');assert.equal(step(a,c,1.1).mission.candidateRule,'no_transition');
});
test('global and state-specific rules share explicit first-eligible priority',()=>{
 const a=p(),c=policy([edge('*','hold'),edge('hold','press','always','r2')]);assert.equal(step(a,c).mission.state,'hold');c.rules.reverse();assert.equal(step(a,c).mission.state,'press');
 assert.ok(graphWarnings(policy([edge('*','hold'),edge('hold','press','always','r2')])).some(w=>w.kind==='shadowed'&&w.id==='r2'));
});
test('candidate edge is separate from actual transition while dwell is pending',()=>{
 const a=p(),c={...policy([edge('hold','press')]),guardDwell:.2,minDwell:.6};a.mission=step(a,c).mission;
 a.mission=step(a,c,1.3).mission;assert.equal(a.mission.state,'hold');assert.equal(a.mission.pending,'press');assert.equal(a.mission.pendingEdge,'r1');assert.equal(a.mission.lastTransition,undefined);assert.equal(a.mission.confirmationRemaining,0);
 a.mission=step(a,c,1.6).mission;assert.equal(a.mission.state,'press');assert.equal(a.mission.lastTransition.time,1.6);
});
test('semantic policy edits reset confirmation without resetting residence',()=>{
 const a=p(),c={...policy([edge('hold','press')]),guardDwell:.2};a.mission=step(a,c).mission;const entered=a.mission.enteredAt;c.revision++;
 a.mission=step(a,c,1.15).mission;assert.equal(a.mission.pendingSince,1.15);assert.equal(a.mission.enteredAt,entered);assert.equal(step(a,c,1.3).mission.state,'hold');assert.equal(step(a,c,1.35).mission.state,'press');
});
test('self-loops retain residence and do not create transition journal entries',()=>{
 const a=p(),c=policy([edge('*','hold')]);a.mission=step(a,c).mission;const r=step(a,c,8);assert.equal(r.transition,null);assert.equal(r.mission.enteredAt,1);assert.equal(r.mission.transitions,0);
});
test('mandatory system exits survive deletion of outgoing and global edges',()=>{
 const a=p(),c=policy([edge('*','press')]);a.mission=step(a,c).mission;c.rules=[edge('hold','press')];
 a.knownBall.time=0;let r=localMission(a,c,{x:0,y:0},2,1,'live');assert.equal(r.mission.state,'recover');assert.equal(r.transition.edgeId,null);
 r=step(a,c,2,'restart');assert.equal(r.mission.state,'hold');assert.equal(r.transition.rule,'stoppage');
 c.rules=[edge('*','cover')];a.mission=step(p(),c).mission;r=step(a,c,2,'restart');assert.equal(r.mission.state,'hold');assert.equal(r.mission.evidence.handoffPending,false);
});
test('cover releases only after an actual fresh arrived ACK, even with a drawn edge',()=>{
 const a=p(),c=policy([edge('*','cover')]);a.mission=step(a,c).mission;c.rules=[edge('cover','press')];assert.equal(step(a,c,1.1).mission.state,'cover');a.neighbors={2:{x:-2,y:0,time:1.2,mission:{state:'cover'}}};const r=step(a,c,1.2);assert.equal(r.mission.state,'press');assert.equal(r.transition.edgeId,'r1');
});
test('legacy policies gain wildcard sources; malformed IDs and duplicates are rejected',()=>{
 const c=policy([{guard:'always',state:'hold',enabled:true}]),v=validateMission(c);assert.deepEqual(v.rules,[edge('*','hold')]);
 for(const rules of [[{...edge('*','hold'),from:'bogus'}],[{...edge('*','hold'),id:'<script>'}],[edge('*','hold'),edge('hold','press')]])assert.throws(()=>validateMission(policy(rules)));
 const added=addTransition(v,'hold','recover');assert.equal(added.rule.id,'r2');assert.equal(added.rule.from,'hold');assert.equal(v.rules.length,1);
});
test('layout history never changes or applies the mission policy',()=>{
 let calls=0;const c=policy([edge('*','hold')]),g=new MissionGraph({team:()=>0,policy:()=>c,apply:()=>calls++});g.layouts[0]=structuredClone(GRAPH_POSITIONS);const old=structuredClone(g.positions);g.positions.hold.x+=25;g.saveLayout=()=>{};g.historyButtons=()=>{};g.renderGraph=()=>{};g.layoutCommit(old);g.travel(g.history,g.future);assert.deepEqual(g.positions,old);assert.equal(calls,0);assert.equal(c.revision,0);
});
test('new mission metadata round trips; invalid metadata is rejected while legacy is accepted',()=>{
 const a=p(),c=policy([edge('*','press')]),m=step(a,c).mission;assert.equal(validMissionMemory(m,1),true);const legacy=structuredClone(m);delete legacy.lastTransition;delete legacy.pendingEdge;delete legacy.candidateEdge;delete legacy.confirmationRemaining;delete legacy.residenceRemaining;assert.equal(validMissionMemory(legacy,1),true);
 for(const patch of [{lastTransition:{...m.lastTransition,to:'<script>'}},{pendingEdge:'bad"'},{confirmationRemaining:NaN},{lastTransition:{...m.lastTransition,time:2}}])assert.equal(validMissionMemory({...m,...patch},1),false);
});
test('mission overlay uses interpolated positions without mutation and never leaks in local perspective',()=>{
 const e=new MatchEngine();e.tactics[0].mission=missionPreset('balanced');const s=e.snapshot(),copy=structuredClone(s),players=structuredClone(s.players);players[7].x+=.2;
 const options={selected:7,missions:true,tracking:true,scope:'team',players};const o=missionOverlay(s,options);assert.equal(o.tags.length,11);assert.equal(o.tags.find(q=>q.id===7).x,players[7].x);assert.ok(o.segments.some(v=>v.color==='#74c9ff'));assert.ok(o.segments.every(v=>[...v.a,...v.b].every(Number.isFinite)));assert.deepEqual(s,copy);
 assert.deepEqual(missionOverlay(s,{...options,agentView:true}),{segments:[],tags:[]});assert.deepEqual(missionOverlay({...s,training:true},options),{segments:[],tags:[]});
});
test('phase readiness uses the exact fitter interval rules and retains episode gaps',()=>{
 const {frames}=calibrationFrames();for(const f of frames){f.segment=f.time<20?1:2;f.stages=f.time<20?['attack','defend']:['loss','gain'];}
 const all=phaseReadiness(frames,0);assert.equal(all.valid,usableIntervals(frames,0).length);assert.equal(all.valid,199);assert.equal(all.segments.length,2);
 assert.equal(phaseReadiness(frames,0,'attack').valid,99);assert.equal(phaseReadiness(frames.slice(0,40),0).ready,false);assert.equal(phaseReadiness(frames.slice(0,41),0).ready,true);
 const gap=frames.filter(f=>f.time<2||f.time>4);assert.equal(phaseReadiness(gap,0).segments.length,3);
});
test('public stop commits actual transition metadata once and retains hold residence',()=>{
 const e=new MatchEngine();e.tactics[0].mission=missionPreset('balanced');e.phase='live';e.control();const a=e.players[1];a.mission={...a.mission,state:'press',rule:'always',enteredAt:0};e.time=1;e.tick=30;e.suspendMissions();assert.equal(a.mission.lastTransition.to,'hold');assert.equal(a.mission.lastTransition.rule,'public_stop');assert.equal(a.mission.pendingEdge,null);const count=e.journal.totalEvents,entered=a.mission.enteredAt;e.time=2;e.suspendMissions();assert.equal(e.journal.totalEvents,count);assert.equal(a.mission.enteredAt,entered);
});

test('state-cycle example is a bounded executable policy with source-specific edges and a recovery path',()=>{const c=stateCycle(missionPreset('balanced'));assert.deepEqual(validateMission(c),c);assert.equal(c.rules.length,14);assert.equal(c.structure,'custom');assert.ok(c.rules.some(r=>r.from==='press'&&r.state==='recover'));assert.ok(c.rules.some(r=>r.from==='recover'&&r.state==='hold'));assert.equal(graphWarnings(c).length,0);});
test('contact priority changes only ball-task formation weight, preserving imported legacy policies',async()=>{
 const {missionShapeWeight}=await import('../mission-core.js');const c=missionPreset('balanced');
 for(const state of ['press','collect','carry'])assert.ok(Math.abs(missionShapeWeight(c,state)-.0675)<1e-12);
 for(const state of ['hold','cover','screen','recover','support'])assert.equal(missionShapeWeight(c,state),c.shapeWeight);
 const legacy=structuredClone(c);delete legacy.contactPriority;assert.equal(validateMission(legacy).contactPriority,0);assert.equal(missionShapeWeight(validateMission(legacy),'collect'),legacy.shapeWeight);
 assert.throws(()=>validateMission({...c,contactPriority:1.1}));
});
