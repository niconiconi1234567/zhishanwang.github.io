import fs from 'node:fs';
import assert from 'node:assert/strict';
import {summarizeJournal,validateJournal} from '../task-monitor.js';
const path=process.argv[2]??'maintenance/mission-browser-evidence.json';
const r=JSON.parse(fs.readFileSync(path,'utf8'));assert.equal(r.kind,'FlowMissionReport');assert.equal(r.schema,1);
const tick=Math.round(r.physicalTime*30);validateJournal(r.journal,r.physicalTime,tick);
for(const e of r.journal.events){assert.ok(Math.abs(e.time-e.tick/30)<1e-8);assert.equal(e.frame.players.length,22);}
assert.deepEqual(r.summaries,[0,1].map(t=>summarizeJournal(r.journal,t)));
console.log(JSON.stringify({valid:true,engine:r.engine,physicalTime:r.physicalTime,events:r.journal.events.length,omitted:r.journal.droppedEvents,summaryReproduced:true},null,2));
