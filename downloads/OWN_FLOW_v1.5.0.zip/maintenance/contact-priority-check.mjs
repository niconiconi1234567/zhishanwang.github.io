import fs from 'node:fs';
import assert from 'node:assert/strict';
import {MatchEngine,ENGINE_VERSION} from '../engine.js';
import {missionPreset} from '../mission-core.js';
const results=[];
for(const priority of [0,.85]){
 const e=new MatchEngine({seed:361});for(let t=0;t<2;t++)e.setTactic(t,{...e.tactics[t],mission:{...missionPreset('balanced'),contactPriority:priority}});
 let run=0,max=0;
 for(let k=0;k<1800;k++){e.step();if(e.phase==='live'&&e.ball.owner<0&&Math.hypot(e.ball.vx,e.ball.vy)<.1){run++;max=Math.max(max,run);}else run=0;assert.ok(e.players.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)));}
 results.push({engine:ENGINE_VERSION,seed:361,physicalSeconds:60,contactPriority:priority,score:e.score,passes:e.stats.map(x=>x.passes),shots:e.stats.map(x=>x.shots),longestUnownedBallBelowPointOneMetresPerSecond:max/30});
}
assert.ok(results[0].longestUnownedBallBelowPointOneMetresPerSecond>30);
assert.ok(results[1].longestUnownedBallBelowPointOneMetresPerSecond<1);
const evidence={scope:'Single deterministic regression of a reproduced collection deadlock, not general tactical superiority.',results};
fs.writeFileSync(process.argv[2]??new URL('./contact-priority-evidence.json',import.meta.url),JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence,null,2));
