import fs from 'node:fs';
import assert from 'node:assert/strict';
import {MatchEngine} from '../engine.js';
import {missionPreset} from '../mission-core.js';
import {summarizeJournal} from '../task-monitor.js';
const results=[];
for(const [seed,structure] of [[361,'balanced'],[458,'hunt'],[572,'lanes']]){
 const e=new MatchEngine({seed,minutes:90,clockRate:30});for(let t=0;t<2;t++)e.setTactic(t,{...e.tactics[t],mission:missionPreset(t?'shield':structure)});
 let steps=0;while(e.phase!=='finished'&&steps++<5500){e.step();for(const p of e.players){assert.ok(Number.isFinite(p.x)&&Number.isFinite(p.y));assert.ok(Math.abs(p.x)<=52.6&&Math.abs(p.y)<=34.1);}}
 assert.equal(e.phase,'finished');assert.equal(e.half,2);assert.equal(e.time,180);assert.equal(e.journal.totalEvents,e.journal.events.length+e.journal.droppedEvents);
 const restored=MatchEngine.restore(JSON.parse(JSON.stringify(e.checkpoint())));assert.deepEqual(restored.journal,e.journal);
 results.push({seed,structure,physicalSeconds:e.time,clockRate:30,score:e.score,eventCount:e.journal.totalEvents,retained:e.journal.events.length,dropped:e.journal.droppedEvents,summary:[0,1].map(t=>summarizeJournal(e.journal,t))});
}
fs.writeFileSync(new URL('./mission-full-matches.json',import.meta.url),JSON.stringify(results,null,2));console.log(results.map(r=>({seed:r.seed,score:r.score,eventCount:r.eventCount,retained:r.retained,dropped:r.dropped})));
