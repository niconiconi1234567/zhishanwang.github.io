import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {Group} from '../vendor/three.module.min.js';
import {ARENA_TEXTURES,appearanceFor,athleteVisible,selectedAthlete,trainingStrokes} from '../arena-visual.js';
import {actionPose,VisualMotion,cameraFocus} from '../motion-visual.js';
import {PitchRenderer} from '../renderer.js';
import {paintSurface} from '../perspective-texture.js';

function trainingState(){
  const players=[0,1,11].map(id=>({id,index:id%11,team:Math.floor(id/11),name:`P${id}`,x:id+2,y:3,vx:0,vy:0,heading:0}));
  const paths=players.map(p=>({
    id:p.id,origin:{x:-2,y:1},target:{x:6,y:3},actualPoint:p,
    reference:[{x:-2,y:1},{x:6,y:3}],actual:[{x:-2,y:1},p],
  }));
  return {players,training:{team:0,paths},time:0,running:false,tactics:[{players:[{},{}]},{players:[{}]}]};
}

test('a training pitch shows only the training team; clipped paths never alter the data',()=>{
  const s=trainingState();
  s.training.paths[1].actual.push({x:1000,y:3});
  s.training.paths[1].actualPoint={x:1000,y:3};
  const before=JSON.stringify(s);
  const lines=trainingStrokes(s,1);
  assert.equal(selectedAthlete(s,11).id,0);
  assert.equal(athleteVisible(s,s.players[0]),true);
  assert.equal(athleteVisible(s,{...s.players[0],x:52.6}),false);
  assert.equal(athleteVisible(s,s.players[2]),false);
  assert.deepEqual([...new Set(lines.map(p=>p.id))],[0,1]);
  for(const segment of lines.flatMap(line=>line.segments)){
    for(const p of segment){assert.ok(Number.isFinite(p.x)&&Number.isFinite(p.y));assert.ok(Math.abs(p.x)<=52.5000001&&Math.abs(p.y)<=34.0000001);}
  }
  assert.ok(lines.some(line=>line.kind==='actual'&&line.segments.some(seg=>seg.some(p=>Math.abs(p.x-52.5)<1e-8))));
  assert.ok(lines.find(x=>x.id===1).alpha>lines.find(x=>x.id===0).alpha);
  assert.equal(JSON.stringify(s),before);
});
test('the WebGL scene builds finite blue and orange ribbon meshes without a ball',()=>{
  const r=Object.create(PitchRenderer.prototype);Object.assign(r,{motion:new VisualMotion(),athletes:[],overlay:new Group(),selected:1});
  const s=trainingState();r.setState(s);
  const colors=new Set(r.overlay.children.map(mesh=>mesh.material.color.getHexString()));
  assert.ok(colors.has('74c9ff')&&colors.has('ff9273'));
  for(const mesh of r.overlay.children){
    const position=mesh.geometry.attributes.position;
    assert.ok(position.count>0&&position.count%3===0&&[...position.array].every(Number.isFinite));
  }
  const previous=r.overlay.children.map(c=>c.geometry);let disposed=0;
  previous.forEach(g=>g.addEventListener('dispose',()=>disposed++));r.setState(s);
  assert.equal(disposed,previous.length);
});
test('appearance data changes body scale and kit while old tactics have deterministic defaults',()=>{
  const s=trainingState(),p=s.players[1],fallback=appearanceFor(s.tactics,p);
  assert.deepEqual(fallback,appearanceFor(s.tactics,p));
  s.tactics[0].color='#597b93';s.tactics[0].players[1].appearance={heightCm:198,build:1.11,skinTone:4};
  const taller=appearanceFor(s.tactics,p);
  assert.ok(taller.heightScale>fallback.heightScale);assert.equal(taller.shirt,'#597b93');assert.equal(taller.build,1.11);
  s.tactics[0].players[1].appearance={heightCm:Infinity,build:20,skinTone:99};
  const bounded=appearanceFor(s.tactics,p);assert.equal(bounded.heightCm,fallback.heightCm);assert.equal(bounded.build,1.2);assert.equal(bounded.skin,taller.skin);
});
test('a stance foot remains on the grass as the virtual hip advances',()=>{
  const p={id:0,vx:3,vy:0,action:'run'};
  const stride=.8+.43*3,advance=.025,firstPhase=2*Math.PI*.2;
  const first=actionPose(p,1,firstPhase/2.8).legs[0];
  const next=actionPose(p,1+advance/3,(firstPhase+2*Math.PI*advance/stride)/2.8).legs[0];
  assert.ok(first.ground&&next.ground);assert.ok(Math.abs(first.footHeight-.056)<1e-8);
  assert.ok(Math.abs(first.footForward-next.footForward-advance)<1e-8);
  for(const speed of [0,2,5.5,8])for(let step=0;step<48;step++){
    const pose=actionPose({...p,vx:speed},1,step/48*2*Math.PI/2.8);
    for(const leg of pose.legs){
      assert.ok(leg.footHeight>.0559);
      if(leg.ground)assert.ok(leg.footHeight<.0681);
    }
  }
});
test('sparse red training snapshots interpolate by ID and local focus stays on the training team',()=>{
  const a=trainingState();a.training.team=1;a.players=a.players.filter(p=>p.team===1);a.running=true;
  const b=structuredClone(a);b.time=.1;b.players[0].x+=3;
  const m=new VisualMotion();m.receive(a,0);m.receive(b,100);
  assert.equal(m.sample(150).players[0].x,a.players[0].x+1.5);
  assert.equal(m.sample(150).ball,null);assert.equal(cameraFocus(b,0,'ball').x,b.players[0].x);
});
test('perspective texture clips a plane crossing the eye and emits finite transforms',()=>{
  let draws=0;
  const ctx={save(){},restore(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},clip(){},transform(...coeff){assert.ok(coeff.every(Number.isFinite));},drawImage(_image,...rects){assert.ok(rects.every(Number.isFinite));assert.ok(rects[2]>0&&rects[3]>0);draws++;}};
  const view={ctx,w:400,h:300,project:([x,y,z])=>({depth:z,x:200+150*x/z,y:150-150*y/z})};
  const image={complete:true,naturalWidth:2048,naturalHeight:1328};
  assert.equal(paintSurface(view,image,[-1,.2,-1],[2,0,0],[0,0,3.8],4,3),true);assert.ok(draws>0);
});
test('all arena textures are packaged with valid JPEG or WebP container headers',()=>{
  for(const url of Object.values(ARENA_TEXTURES)){
    const bytes=fs.readFileSync(new URL(url));if(url.endsWith('.jpg')){assert.equal(bytes.readUInt16BE(0),0xffd8);assert.equal(bytes.readUInt16BE(bytes.length-2),0xffd9);assert.ok(bytes.length>10000);continue;}assert.equal(bytes.toString('ascii',0,4),'RIFF');assert.equal(bytes.toString('ascii',8,12),'WEBP');assert.equal(bytes.length,bytes.readUInt32LE(4)+8);
  }
});
