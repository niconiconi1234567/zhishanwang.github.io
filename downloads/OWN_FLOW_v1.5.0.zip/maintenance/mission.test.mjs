import test from 'node:test';
import assert from 'node:assert/strict';
import {MatchEngine,defaultTactic,validateTactic} from '../engine.js';
import {defaultMission,missionPreset,validateMission,localMission,phaseState} from '../mission-core.js';
import {newJournal,monitorTick,taskSnapshot,summarizeJournal,taskWindowSummary,reportEvidence,journalEvent} from '../task-monitor.js';
import {missionReportHTML} from '../mission-view.js';
import {calibrationFrames,usableIntervals,identifyInteractions} from '../mas-model.js';
const copy=x=>structuredClone(x),near=(a,b,eps=1e-9)=>assert.ok(Math.abs(a-b)<eps,`${a} != ${b}`);
const policy=()=>({...missionPreset('balanced'),minDwell:0,guardDwell:0});
const player=()=>({id:1,index:1,team:0,x:0,y:0,neighbors:{},visible:[],knownBall:{x:6,y:0,vx:0,vy:0,owner:12,time:1,via:'vision'}});
const decide=(p,c=policy(),time=1)=>localMission(p,c,{x:0,y:0},time,1,'live');
const run=(e,n)=>{for(let i=0;i<n;i++)e.step();return e;};
function monitored(){const e=new MatchEngine();e.phase='live';e.ball={...e.ball,x:0,y:0,owner:12};for(const p of e.players){p.x=p.team?30:-40;p.y=20;p.target={x:p.x,y:p.y};p.formationTarget={...p.target};}e.journal=newJournal();return e;}
function tick(e){e.tick++;e.time=e.tick/30;monitorTick(e);}

test('mission policies validate every preset, priority table and bounded knob',()=>{
 for(const name of ['balanced','shield','hunt','lanes'])assert.deepEqual(validateMission(missionPreset(name)),missionPreset(name));
 for(const patch of [{taskGain:NaN},{roles:['press']},{rules:[]},{rules:[{guard:'remote_truth',state:'press',enabled:true}]},{minDwell:-1},{enabled:'yes'}])assert.throws(()=>validateMission({...policy(),...patch}));
 const old=defaultTactic();delete old.mission;assert.equal(validateTactic(old).mission.enabled,false);
});

test('ordered local guards change actual mission references without using hidden world fields',()=>{
 const p=player(),c=policy(),a=decide(p,c);assert.equal(a.mission.state,'press');assert.deepEqual(a.mission.target,{x:6,y:0});
 const b=decide({...p,hiddenBall:{x:-40,y:30},globalPlayers:Array(22).fill({x:100})},c);assert.deepEqual(a,b);
 c.rules.unshift({guard:'always',state:'hold',enabled:true});assert.equal(decide(p,c).mission.state,'hold');
});

test('free-ball collection restores an explicit retrieval duty and exits on possession',()=>{
 const p=player();p.knownBall.owner=-1;p.mission=decide(p).mission;assert.equal(p.mission.state,'collect');
 p.knownBall.owner=p.id;p.knownBall.time=1.1;const next=decide(p,policy(),1.1);assert.equal(next.mission.state,'carry');assert.equal(next.transition.from,'collect');
});

test('guard dwell prevents switching on one short pulse; stale evidence bypasses residence safely',()=>{
 const p=player(),c={...policy(),guardDwell:.2,minDwell:.6};p.mission=decide(p,c).mission;
 for(const t of [1.1,1.2,1.5]){p.knownBall.time=t;p.mission=decide(p,c,t).mission;assert.equal(p.mission.state,'hold');}
 p.knownBall.time=1.6;p.mission=decide(p,c,1.6).mission;assert.equal(p.mission.state,'press');
 p.knownBall.time=0;assert.equal(decide(p,c,1.7).mission.state,'recover');
});

test('recovery hysteresis retains recovery below entry threshold until the exit threshold',()=>{
 const p=player(),c=policy();p.knownBall.owner=-1;c.rules=[{guard:'displaced',state:'recover',enabled:true},{guard:'always',state:'hold',enabled:true}];
 p.x=16;p.mission=decide(p,c).mission;assert.equal(p.mission.state,'recover');p.x=12;p.mission=decide(p,c,1.1).mission;assert.equal(p.mission.state,'recover');p.x=9;assert.equal(decide(p,c,1.2).mission.state,'hold');
});

test('screening needs a visible outlet and loses that state when lane evidence disappears',()=>{
 const p=player(),c=policy();c.rules=[{guard:'always',state:'screen',enabled:true}];assert.equal(decide(p,c).mission.state,'recover');
 p.visible=[{id:13,team:1,x:-10,y:5,time:1}];p.mission=decide(p,c).mission;assert.equal(p.mission.state,'screen');
 p.visible=[];c.minDwell=3;assert.equal(decide(p,c,1.1).mission.state,'recover');
});

test('cover handoff retains responsibility without a fresh arrived state ACK',()=>{
 const p=player(),c=policy();c.rules=[{guard:'always',state:'cover',enabled:true}];p.mission=decide(p,c).mission;assert.equal(p.mission.state,'cover');
 c.rules=[{guard:'always',state:'press',enabled:true}];let n=decide(p,c,1.1);assert.equal(n.mission.state,'cover');assert.equal(n.mission.evidence.handoffPending,true);
 p.visible=[{id:2,team:0,x:-2,y:0,time:1.1,mission:{state:'cover'}}];assert.equal(decide(p,c,1.1).mission.state,'cover');
 p.neighbors={2:{x:-2,y:0,time:0,mission:{state:'cover'}}};assert.equal(decide(p,c,2).mission.state,'cover');
 p.knownBall.time=2;p.neighbors[2].time=2;n=decide(p,c,2);assert.equal(n.mission.state,'press');assert.equal(n.transition.evidence.handoffAccepted,2);
});

test('mission references enter velocity control and all signed terms reconstruct the pre-limit command',()=>{
 const e=new MatchEngine();e.phase='live';e.tactics[0].mission=policy();e.tactics[0].mission.rules=[{guard:'always',state:'hold',enabled:true}];e.control();
 const p=e.players[3];assert.equal(p.mission.state,'hold');near(p.parts.mission.x,e.tactics[0].mission.taskGain*(p.target.x-p.x));
 const sum=Object.values(p.parts).reduce((a,v)=>({x:a.x+v.x,y:a.y+v.y}),{x:0,y:0});near(sum.x,p.raw.x);near(sum.y,p.raw.y);assert.deepEqual(p.parts.support,{x:0,y:0});
});

test('ball-only links and removed communication edges cannot provide a cached handoff ACK',()=>{
 for(const ballOnly of [true,false]){const e=new MatchEngine();e.phase='live';e.time=1;e.tick=30;const c=e.tactics[0];c.vision=0;c.information=ballOnly?'ball':'full';c.commEdges=[];c.mission=policy();
 const p=e.players[1];p.vision=0;p.knownBall={x:6,y:0,vx:0,vy:0,owner:12,time:1,source:1,via:'message'};
 c.mission.rules=[{guard:'always',state:'cover',enabled:true}];e.control();p.neighbors={2:{x:-2,y:0,ex:0,ey:0,time:1,mission:{state:'cover'}}};c.mission.rules=[{guard:'always',state:'press',enabled:true}];e.control();assert.equal(p.mission.state,'cover');assert.equal(p.mission.evidence.handoffPending,true);}
});

test('phase labels distinguish gain, settled possession, loss, loose ball and stoppage',()=>{
 let p=phaseState(null,1,'live',0);assert.deepEqual(p.labels,['gain','loss']);p=phaseState(p,3,'live',3.1);assert.deepEqual(p.labels,['attack','defend']);near(p.changedAt,0);
 p=phaseState(p,15,'live',4);assert.deepEqual(p.labels,['loss','gain']);assert.deepEqual(phaseState(p,-1,'live',4.2).labels,['loose','loose']);assert.deepEqual(phaseState(p,15,'restart',4.2).labels,['stopped','stopped']);
});

test('stage-filtered identification never connects intervals across phase boundaries',()=>{
 const {frames}=calibrationFrames();for(const f of frames){f.segment=f.time<20?1:2;f.stages=f.time<20?['attack','defend']:['loss','gain'];}
 const all=usableIntervals(frames,0),attack=usableIntervals(frames,0,'attack');assert.equal(all.length,199);assert.equal(attack.length,99);assert.ok(all.every(([a,b])=>a.segment===b.segment));
 const r=identifyInteractions(frames,{stage:'attack'});assert.equal(r.available,true);assert.equal(r.stage,'attack');assert.equal(r.episodes,1);assert.throws(()=>identifyInteractions(frames,{stage:'made_up'}));
 assert.equal(identifyInteractions(frames.slice(0,10),{stage:'attack'}).reason,'samples');
});

test('task and formation errors separate intentional duty motion from nominal shape',()=>{
 const e=monitored(),p=e.players[1];p.x=5;p.y=0;p.target={x:5,y:0};p.formationTarget={x:0,y:0};const s=taskSnapshot(e,0);near(s.tracking,0);near(s.formation,Math.sqrt(25/10));assert.ok(s.consensus>0);
});

test('joint duty coverage requires distinct agents and uses defensive-time denominators',()=>{
 const e=monitored();e.tactics[0].mission={...policy(),coverDepth:3,coverRadius:5,pressRadius:3};e.players[1].x=-1;e.players[1].y=0;tick(e);let r=summarizeJournal(e.journal,0)[0];near(r.pressure,1);near(r.cover,1);near(r.joint,0);
 e.players[2].x=-2;e.players[2].y=0;tick(e);r=summarizeJournal(e.journal,0)[0];near(r.joint,.5);
 e.ball.owner=1;tick(e);const attack=summarizeJournal(e.journal,0).find(r=>r.phase==='gain');assert.equal(attack.pressure,null);assert.equal(attack.cover,null);
});

test('pressure confirmation demands sustained sampled contact; policy edits do not reset deadlines',()=>{
 const e=monitored();e.tactics[0].mission={...policy(),deadline:.3};tick(e);const start=e.journal.episode.start;
 for(let i=0;i<4;i++){e.players[1].x=0;e.players[1].y=0;tick(e);}e.players[1].x=-40;e.players[1].y=20;tick(e);
 assert.equal(e.journal.episode.pressureMet,false);e.setTactic(0,{...e.tactics[0],mission:{...policy(),deadline:6}});near(e.journal.episode.deadline,.3);near(e.journal.episode.start,start);
 for(let i=0;i<7;i++)tick(e);assert.equal(e.journal.episode.expired,true);assert.equal(e.journal.events.filter(x=>x.kind==='deadline_miss').length,1);
 e.players[1].x=0;e.players[1].y=0;for(let i=0;i<6;i++)tick(e);assert.equal(e.journal.episode.pressureMet,true);assert.equal(e.journal.episode.expired,true);
});

test('event snapshots are immutable, physical-tick stamped and bounded without discarding aggregates',()=>{
 const e=monitored();tick(e);const old=copy(e.journal.events[0]);e.players[1].x=17;assert.deepEqual(e.journal.events[0],old);
 assert.ok(e.journal.events.every(x=>Math.abs(x.time-x.tick/30)<1e-9));const row=copy(e.journal.teams);
 for(let i=0;i<2405;i++)journalEvent(e,'policy_edit',0,-1,{});assert.equal(e.journal.events.length,2400);assert.equal(e.journal.totalEvents,e.journal.events.length+e.journal.droppedEvents);assert.deepEqual(e.journal.teams,row);
});

test('window metrics subtract checkpoint history and reports escape user-supplied names',()=>{
 const e=monitored();e.players[1].x=0;e.players[1].y=0;tick(e);const before=copy(e.journal);e.players[1].x=-40;e.players[1].y=20;tick(e);near(taskWindowSummary(before,e.journal,0).pressureRate,0);
 e.tactics[0].teamName='<script>alert(1)</script>';const report=reportEvidence(e),html=missionReportHTML(report,'zh');assert.ok(!html.includes('<script>'));assert.ok(html.includes('&lt;script&gt;'));assert.equal(report.protocol.monitorHz,30);
});

test('mission memories, events and aggregate measurements continue identically after JSON restore',()=>{
 const e=new MatchEngine();for(const t of [0,1])e.setTactic(t,{...e.tactics[t],mission:missionPreset(t?'shield':'hunt')});run(e,700);const r=MatchEngine.restore(JSON.parse(JSON.stringify(e.checkpoint())));run(e,150);run(r,150);assert.deepEqual(e.checkpoint(),r.checkpoint());
 const kinds=new Set(e.journal.events.filter(x=>x.kind==='mission').map(x=>x.to));assert.ok(kinds.has('collect'));assert.ok(kinds.has('press'));assert.ok(kinds.has('cover'));
});

test('malformed mission journal or memory is rejected and old checkpoints start a fresh monitor',()=>{
 const e=run(new MatchEngine(),90),cp=e.checkpoint();const bad=copy(cp);bad.journal.events[0].seq=99;assert.throws(()=>MatchEngine.restore(bad),/checkpoint_journal/);
 const old=copy(cp);delete old.journal;old.engine='1.2.0';for(const t of old.tactics)delete t.mission;const r=MatchEngine.restore(old);assert.equal(r.journal.totalEvents,0);near(r.journal.lastTime,r.time);r.step();assert.ok(Object.values(r.journal.teams[0]).every(v=>v.seconds<=1/30+1e-9));
});

test('public stoppages suspend active duties once and leave an explicit mission event',()=>{
 const e=new MatchEngine();e.phase='live';e.tactics[0].mission=policy();e.control();const p=e.players[1];p.mission.state='press';e.phase='restart';e.phaseUntil=10;e.step();assert.equal(p.mission.state,'hold');assert.equal(p.mission.rule,'public_stop');const n=e.journal.events.filter(v=>v.kind==='mission'&&v.rule==='public_stop').length;e.step();assert.equal(e.journal.events.filter(v=>v.kind==='mission'&&v.rule==='public_stop').length,n);
});

test('a future-dated or opposing-team state cannot acknowledge cover handoff',()=>{
 const p=player(),c=policy();c.rules=[{guard:'always',state:'cover',enabled:true}];p.mission=decide(p,c).mission;c.rules=[{guard:'always',state:'press',enabled:true}];
 for(const neighbors of [{2:{x:-2,y:0,time:10,mission:{state:'cover'}}},{13:{x:-2,y:0,time:1,mission:{state:'cover'}}}]){p.neighbors=neighbors;assert.equal(decide(p,c,1).mission.state,'cover');}
});
