import {phaseState,defaultMission,pointSegmentDistance} from './mission-core.js';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const mean=a=>a.reduce((s,v)=>s+v,0)/Math.max(1,a.length);
export function newJournal(){return {schema:1,events:[],totalEvents:0,droppedEvents:0,phase:null,
  episode:null,episodeSerial:0,teams:[{},{}],latest:[null,null],lastTime:0,lastTick:-1};}
export function validateJournal(j,time,tick){
  const keys=['seconds','tracking2','formation2','consensus2','saturation','effort','defendingSeconds','pressureSeconds','coverSeconds','jointSeconds','laneSeconds','laneEligibleSeconds','attackSeconds','supportSeconds'];
  const finite=v=>Number.isFinite(v)&&v>=0,stages=['gain','attack','loss','defend','loose','stopped'];
  const kinds=['mission','phase','episode_start','episode_end','pressure_confirmed','deadline_miss','cover_ready','cover_gap','football','policy_edit'];
  if(!j||j.schema!==1||!Array.isArray(j.events)||j.events.length>2400||!Number.isInteger(j.totalEvents)||!Number.isInteger(j.droppedEvents)||
    j.droppedEvents<0||j.totalEvents!==j.events.length+j.droppedEvents||!Number.isInteger(j.lastTick)||j.lastTick>tick||j.lastTick< -1||
    !finite(j.lastTime)||j.lastTime>time+1e-6||!Number.isInteger(j.episodeSerial)||j.episodeSerial<0||
    !Array.isArray(j.teams)||j.teams.length!==2||!Array.isArray(j.latest)||j.latest.length!==2)throw Error('checkpoint_journal');
  for(const team of j.teams)for(const [stage,row] of Object.entries(team))if(!stages.includes(stage)||!keys.every(k=>finite(row[k])))throw Error('checkpoint_journal');
  if(j.phase&&(!Array.isArray(j.phase.labels)||j.phase.labels.length!==2||!j.phase.labels.every(s=>stages.includes(s))||!Number.isInteger(j.phase.serial)||!finite(j.phase.changedAt)||![-1,0,1].includes(j.phase.lastTeam)))throw Error('checkpoint_journal');
  if(j.episode&&(!Number.isInteger(j.episode.id)||!Number.isInteger(j.episode.owner)||j.episode.owner<0||j.episode.owner>21||![0,1].includes(j.episode.defending)||!finite(j.episode.start)||j.episode.start>time+1e-6||!finite(j.episode.deadline)||!finite(j.episode.pressureDwell)||!['pressureMet','coverMet','expired'].every(k=>typeof j.episode[k]==='boolean')))throw Error('checkpoint_journal');
  for(const [i,e] of j.events.entries())if(e.seq!==j.droppedEvents+i+1||!kinds.includes(e.kind)||!finite(e.time)||e.time>time+1e-6||!Number.isInteger(e.tick)||e.tick<0||e.tick>tick||![-1,0,1].includes(e.team)||!Number.isInteger(e.player)||e.player< -1||e.player>21||!Array.isArray(e.frame?.players)||e.frame.players.length!==22||!Number.isFinite(e.frame.ball?.x)||!Number.isFinite(e.frame.ball?.y)||e.frame.players.some((p,k)=>p.id!==k||!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('checkpoint_journal');
  return j;
}
export function sceneFrame(e){return {time:e.time,half:e.half,ball:{x:e.ball.x||0,y:e.ball.y||0,owner:e.ball.owner},
  players:e.players.map(p=>({id:p.id,x:p.x||0,y:p.y||0,state:p.mission?.state??'legacy'}))};}
export function journalEvent(e,kind,team=-1,player=-1,detail={}){
  const j=e.journal;if(!j)return;
  j.events.push({seq:++j.totalEvents,tick:e.tick,time:e.time,clock:e.time*e.clockRate,kind,team,player,
    episode:j.episode?.id??null,revision:team>=0?e.tactics[team].mission?.revision??0:null,
    ...JSON.parse(JSON.stringify(detail)),frame:sceneFrame(e)});
  while(j.events.length>2400){j.events.shift();j.droppedEvents++;}
}
export function taskSnapshot(e,team){
  const policy=e.tactics[team].mission??defaultMission(),d=e.dir(team),ps=e.players.filter(p=>p.team===team),out=ps.filter(p=>p.index!==0);
  const ball=e.ball,ownerTeam=ball.owner>=0?Math.floor(ball.owner/11):-1;
  const defending=e.phase==='live'&&ownerTeam>=0&&ownerTeam!==team;
  const attacking=e.phase==='live'&&ownerTeam===team;
  const cover={x:Math.max(-49,Math.min(49,ball.x-d*policy.coverDepth)),y:ball.y*(1-.35*policy.compactness)};
  const pressure=defending?out.filter(p=>distance(p,ball)<=policy.pressRadius):[];
  const covering=defending?out.filter(p=>distance(p,cover)<=policy.coverRadius&&(ball.x-p.x)*d>0):[];
  const outlets=defending?e.players.filter(p=>p.team===ownerTeam&&p.id!==ball.owner&&distance(p,ball)>4)
    .sort((a,b)=>((a.x-ball.x)*d-(b.x-ball.x)*d)||a.id-b.id).slice(0,2):[];
  const lanes=outlets.map(q=>({receiver:q.id,from:{x:ball.x,y:ball.y},to:{x:q.x,y:q.y},
    ready:out.filter(p=>pointSegmentDistance(p,ball,q)<=policy.laneRadius).map(p=>p.id)}));
  const rms=(target)=>Math.sqrt(mean(out.map(p=>distance(p,target(p))**2)));
  const offset=out.map(p=>({x:p.x-(p.formationTarget??p.target).x,y:p.y-(p.formationTarget??p.target).y}));
  const z={x:mean(offset.map(q=>q.x)),y:mean(offset.map(q=>q.y))};
  const tracking=rms(p=>p.target),formation=rms(p=>p.formationTarget??p.target);
  const consensus=Math.sqrt(mean(offset.map(q=>(q.x-z.x)**2+(q.y-z.y)**2)));
  const optimistic=Math.min(...out.map(p=>Math.max(0,distance(p,ball)-policy.pressRadius)/Math.max(.1,p.speed)));
  return {defending,attacking,pressure:pressure.map(p=>p.id),covering:covering.map(p=>p.id),cover,lanes,
    tracking,formation,consensus,saturation:mean(out.map(p=>+p.saturated)),
    controlEffort:mean(out.map(p=>p.command.x**2+p.command.y**2)),optimisticFrozenArrival:optimistic,
    deadline:policy.deadline,pressRadius:policy.pressRadius,coverRadius:policy.coverRadius,laneRadius:policy.laneRadius,
    support:attacking?out.filter(p=>p.id!==ball.owner&&distance(p,ball)>=5&&distance(p,ball)<=22).map(p=>p.id):[],
    width:Math.max(...out.map(p=>p.y))-Math.min(...out.map(p=>p.y)),
    depth:Math.max(...out.map(p=>p.x))-Math.min(...out.map(p=>p.x)),
    states:Object.fromEntries(['hold','collect','press','screen','cover','recover','support','carry','legacy'].map(s=>[s,out.filter(p=>(p.mission?.state??'legacy')===s).length]))};
}
export function monitorTick(e){
  const j=e.journal;if(!j||j.lastTick===e.tick)return;
  const dt=Math.max(0,Math.min(1/30,e.time-j.lastTime));j.lastTime=e.time;j.lastTick=e.tick;
  const next=phaseState(j.phase,e.ball.owner,e.phase,e.time),prev=j.phase;j.phase=next;
  if(!prev||next.serial!==prev.serial)for(let t=0;t<2;t++)if(next.labels[t]!==prev?.labels[t])
    journalEvent(e,'phase',t,-1,{from:prev?.labels[t]??'stopped',to:next.labels[t]});
  const owner=e.phase==='live'?e.ball.owner:-1;
  if(owner!==j.episode?.owner){
    if(j.episode){journalEvent(e,'episode_end',j.episode.defending,-1,{duration:e.time-j.episode.start,
      pressureMet:j.episode.pressureMet,coverMet:j.episode.coverMet,deadlineMiss:j.episode.expired,
      reason:owner<0?'release_or_stop':'owner_change'});}
    j.episode=owner>=0?{id:++j.episodeSerial,owner,defending:1-Math.floor(owner/11),start:e.time,
      deadline:e.tactics[1-Math.floor(owner/11)].mission?.deadline??2,pressRadius:e.tactics[1-Math.floor(owner/11)].mission?.pressRadius??3,
      pressureDwell:0,pressureMet:false,coverMet:false,expired:false}:null;
    if(j.episode)journalEvent(e,'episode_start',j.episode.defending,-1,{deadline:j.episode.deadline,pressRadius:j.episode.pressRadius,owner});
  }
  for(let t=0;t<2;t++){
    const v=taskSnapshot(e,t),label=next.labels[t],prevTask=j.latest[t];
    const row=j.teams[t][label]??={seconds:0,tracking2:0,formation2:0,consensus2:0,saturation:0,effort:0,
      defendingSeconds:0,pressureSeconds:0,coverSeconds:0,jointSeconds:0,laneSeconds:0,laneEligibleSeconds:0,attackSeconds:0,supportSeconds:0};
    row.seconds+=dt;row.tracking2+=v.tracking**2*dt;row.formation2+=v.formation**2*dt;row.consensus2+=v.consensus**2*dt;
    row.saturation+=v.saturation*dt;row.effort+=v.controlEffort*dt;
    if(v.defending){
      row.defendingSeconds+=dt;if(v.pressure.length)row.pressureSeconds+=dt;if(v.covering.length)row.coverSeconds+=dt;
      if(v.pressure.length&&v.pressure.some(id=>v.covering.some(other=>other!==id)))row.jointSeconds+=dt;
      row.laneEligibleSeconds+=v.lanes.length*dt;row.laneSeconds+=v.lanes.filter(l=>l.ready.length).length*dt;
      if(j.episode?.defending===t){
        const episode=j.episode,windowPressure=e.players.filter(p=>p.team===t&&p.index!==0&&distance(p,e.ball)<=(episode.pressRadius??3));
        episode.pressureDwell=windowPressure.length?episode.pressureDwell+dt:0;
        if(!episode.pressureMet&&episode.pressureDwell>=.2-1e-8){episode.pressureMet=true;journalEvent(e,'pressure_confirmed',t,windowPressure[0].id,{dwell:episode.pressureDwell,pressRadius:episode.pressRadius});}
        if(v.covering.length)episode.coverMet=true;
        if(!episode.expired&&e.time-episode.start>=episode.deadline&&!episode.pressureMet){episode.expired=true;journalEvent(e,'deadline_miss',t,-1,{elapsed:e.time-episode.start,deadline:episode.deadline});}
      }
      if(!prevTask?.defending||Boolean(v.covering.length)!==Boolean(prevTask.covering.length))journalEvent(e,v.covering.length?'cover_ready':'cover_gap',t,v.covering[0]??-1,{target:v.cover,occupants:v.covering});
    }
    if(v.attacking){row.attackSeconds+=dt;if(v.support.length>=2)row.supportSeconds+=dt;}
    j.latest[t]=v;
  }
}
export function summarizeJournal(j,team){
  const ratio=(a,b)=>b>0?a/b:null;
  return Object.entries(j?.teams?.[team]??{}).map(([phase,r])=>({phase,seconds:r.seconds,
    tracking:Math.sqrt(r.tracking2/(r.seconds||1)),formation:Math.sqrt(r.formation2/(r.seconds||1)),
    consensus:Math.sqrt(r.consensus2/(r.seconds||1)),saturation:ratio(r.saturation,r.seconds),effort:ratio(r.effort,r.seconds),
    pressure:ratio(r.pressureSeconds,r.defendingSeconds),cover:ratio(r.coverSeconds,r.defendingSeconds),
    joint:ratio(r.jointSeconds,r.defendingSeconds),lanes:ratio(r.laneSeconds,r.laneEligibleSeconds),support:ratio(r.supportSeconds,r.attackSeconds)}));
}
export function taskWindowSummary(before,after,team){
  const total={};
  for(const [phase,row] of Object.entries(after.teams[team]))for(const [key,value] of Object.entries(row))total[key]=(total[key]??0)+value-(before?.teams?.[team]?.[phase]?.[key]??0);
  const ratio=(a,b)=>total[b]>1e-8?Math.max(0,total[a])/total[b]:null;
  return {taskTracking:Math.sqrt(ratio('tracking2','seconds')??0),nominalFormation:Math.sqrt(ratio('formation2','seconds')??0),
    offsetDisagreement:Math.sqrt(ratio('consensus2','seconds')??0),pressureRate:ratio('pressureSeconds','defendingSeconds'),coverRate:ratio('coverSeconds','defendingSeconds'),
    jointRate:ratio('jointSeconds','defendingSeconds'),laneRate:ratio('laneSeconds','laneEligibleSeconds'),supportRate:ratio('supportSeconds','attackSeconds'),
    defenseSeconds:total.defendingSeconds??0,attackSeconds:total.attackSeconds??0};
}
export function reportEvidence(e){return {kind:'FlowMissionReport',schema:1,engine:e.snapshot().engine,seed:e.seed,
  physicalTime:e.time,clock:e.time*e.clockRate,score:[...e.score],tactics:structuredClone(e.tactics),
  journal:structuredClone(e.journal),summaries:[summarizeJournal(e.journal,0),summarizeJournal(e.journal,1)],
  protocol:{monitorHz:30,controlHz:10,fitHz:5,pressureDwell:.2,
    scope:'Sampled geometry at physical ticks. Pressure proximity, lane readiness and cover occupancy are declared proxy tasks, not interception or victory guarantees. No joint infeasibility certificate.',
    eventCapacity:2400,coverage:'Aggregates cover all monitored ticks; the event journal is a bounded recent history.'}};}
