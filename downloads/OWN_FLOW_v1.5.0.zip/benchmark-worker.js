import { MatchEngine, ENGINE_VERSION } from "./engine.js";
import {missionPreset} from './mission-core.js';
import {taskWindowSummary} from './task-monitor.js';
self.onmessage = ({ data: m }) => {
  try {
    const team=Number(m.team)===1?1:0;
    const results = [],
      seeds = m.seeds || [361, 727, 2026],
      duration = Math.min(120, m.duration || 45);
    for (let k = 0; k < seeds.length; k++) {
      const initial = m.checkpoint
        ? MatchEngine.restore(m.checkpoint)
        : new MatchEngine({
            seed: seeds[k],
            tactics: m.tactics,
            mode: m.mode || "formation",
          });
      if (m.checkpoint && k > 0) initial.rng.s = seeds[k];
      if (initial.phase === "finished") throw Error("benchmark_finished");
      const cp = initial.checkpoint(),
        a = MatchEngine.restore(cp),
        b = MatchEngine.restore(cp);
      let changed = structuredClone(b.tactics[team]);
      if (m.intervention === "loss") changed.loss = 0.35;
      else if (m.intervention === "compensator") {
        changed.compensator = "none";
        changed.compGain = 0;
      } else if (m.intervention === "tracker") {
        if(!changed.tracker)throw Error("benchmark_tracker_missing");
        changed.tracker=null;
      } else if (m.intervention === "algorithm") {
        changed.algorithm = null;
      } else if(m.intervention==='mission_off'){
        if(initial.mode!=='match')throw Error('benchmark_mission_match');
        if(!changed.mission.enabled)throw Error('benchmark_mission_missing');
        changed.mission.enabled=false;changed.mission.revision++;
      } else if(['mission_shield','mission_hunt','mission_lanes'].includes(m.intervention)){
        if(initial.mode!=='match')throw Error('benchmark_mission_match');
        changed.mission={...missionPreset(m.intervention.slice(8)),revision:changed.mission.revision+1};
      } else changed.kFormation = Math.min(2, changed.kFormation * 1.5 + 0.1);
      b.setTactic(team, changed);
      const steps = Math.round(duration * 30);
      for (let i = 0; i < steps; i++) {
        a.step();
        b.step();
        if (i % 600 === 0)
          postMessage({
            type: "progress",
            value: (k + i / steps) / seeds.length,
          });
      }
      const summary = (e) => {
        const data = e.measurements
          .filter((r) => r.time > initial.time)
          .map((r) => r.teams[team]);
        if (!data.length) throw Error("benchmark_empty");
        return {
          ...taskWindowSummary(initial.journal,e.journal,team),
          actualDuration: e.time - initial.time,
          shape: data.reduce((s, r) => s + r.shape, 0) / data.length,
          estimation: data.reduce((s, r) => s + r.estimation, 0) / data.length,
          effort: data.reduce((s, r) => s + r.effort, 0) / data.length,
          saturation: data.reduce((s, r) => s + r.saturation, 0) / data.length,
          score: e.score,
          passes: e.stats[team].passes - initial.stats[team].passes,
          shots: e.stats[team].shots - initial.stats[team].shots,
          final: e.metrics?.[team]?.shape ?? 0,
        };
      };
      results.push({
        seed: initial.seed,
        rngState: cp.rng,
        initialCheckpoint: cp,
        branchBTactic: changed,
        a: summary(a),
        b: summary(b),
        seriesA: a.measurements.filter(row=>row.time>=initial.time).slice(-120),
        seriesB: b.measurements.filter(row=>row.time>=initial.time).slice(-120),
      });
    }
    postMessage({
      type: "complete",
      result: {
        kind: "BenchmarkReport",
        schema: 1,
        engine: ENGINE_VERSION,
        team,
        mode: m.checkpoint ? m.checkpoint.mode : m.mode,
        randomization: m.checkpoint
          ? "same_checkpoint_with_paired_rng_states"
          : "paired_seed_initialization",
        intervention: m.intervention,
        duration,
        seeds,
        checkpoint: !!m.checkpoint,
        results,
      },
    });
  } catch (e) {
    postMessage({ type: "error", error: e.message });
  }
};
