import {missionOverlay} from './mission-visual.js';
import { VisualMotion, cameraFocus, cameraOffset, HIP_HEIGHT, THIGH_LENGTH, SHIN_LENGTH } from "./motion-visual.js";
import { ARENA_TEXTURES, appearanceFor, athleteVisible, selectedAthlete, trainingStrokes, pitchMarkings } from "./arena-visual.js";
import * as THREE from "./vendor/three.module.min.js";
const {
  Group,
  Mesh,
  BoxGeometry,
  CylinderGeometry,
  SphereGeometry,
  PlaneGeometry,
  MeshStandardMaterial,
  MeshBasicMaterial,
  Vector3,
  Color,
} = THREE;
const materials = new Map(),
  geometries = new Map();
function mat(color, roughness = 0.8) {
  let k = color + ":" + roughness;
  if (!materials.has(k))
    materials.set(k, new MeshStandardMaterial({ color, roughness }));
  return materials.get(k);
}
function geo(key, fn) {
  if (!geometries.has(key)) geometries.set(key, fn());
  return geometries.get(key);
}
function box(w, h, d, color, x = 0, y = 0, z = 0) {
  const m = new Mesh(
    geo(`b${w},${h},${d}`, () => new BoxGeometry(w, h, d)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}
function sphere(r, color, x = 0, y = 0, z = 0) {
  const m = new Mesh(
    geo("s" + r, () => new SphereGeometry(r, 12, 8)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}
function cylinder(rt, rb, h, color, x = 0, y = 0, z = 0) {
  let m = new Mesh(
    geo(`c${rt},${rb},${h}`, () => new CylinderGeometry(rt, rb, h, 10)),
    mat(color),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}
function line(points, color = "#e5f2dd", opacity = 1) {
  let g = new THREE.BufferGeometry().setFromPoints(
    points.map((p) => new Vector3(...p)),
  );
  let m = new THREE.Line(
    g,
    new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity }),
  );
  return m;
}
function circle(x, z, r, color, y = 0.035) {
  const ps = [];
  for (let i = 0; i <= 80; i++) {
    let a = (i / 80) * Math.PI * 2;
    ps.push([x + Math.cos(a) * r, y, z + Math.sin(a) * r]);
  }
  return line(ps, color);
}
function arenaTextures(renderer) {
  const loader = new THREE.TextureLoader();
  const result = {};
  for (const [name,url] of Object.entries(ARENA_TEXTURES)) {
    const texture=loader.load(url);
    texture.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    if(name==='blades') {
      texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
      texture.repeat.set(20,13);
    } else texture.colorSpace=THREE.SRGBColorSpace;
    result[name]=texture;
  }
  return result;
}
function texturedTerrace(texture,topLeft,across,down) {
  const corner=(u,v)=>topLeft.map((value,key)=>value+across[key]*u+down[key]*v);
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute([
    ...corner(0,0),...corner(1,0),...corner(1,1),...corner(0,1),
  ],3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute([0,1,1,1,1,0,0,0],2));
  geometry.setIndex([0,2,1,0,3,2]);
  geometry.computeVertexNormals();
  return new Mesh(geometry,new MeshBasicMaterial({map:texture,side:THREE.DoubleSide}));
}

const numberMaterials=new Map();
function numberMaterial(number) {
  if(numberMaterials.has(number))return numberMaterials.get(number);
  const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;
  const context=canvas.getContext('2d');
  context.fillStyle='#faf6df';context.textAlign='center';context.font='bold 74px sans-serif';
  context.fillText(String(number).padStart(2,'0'),64,97);
  const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;
  const material=new MeshBasicMaterial({map,transparent:true,alphaTest:.25,depthWrite:false});
  numberMaterials.set(number,material);return material;
}
const athleteSurface = new MeshStandardMaterial({vertexColors:true,roughness:.83});

// Parts fixed to one joint share one vertex-coloured mesh. The torso, trim and
// hair stay detailed while the animation changes only the handful of joint transforms.
function batchParts(parts, fabricSpans) {
  const positions=[],normals=[],colors=[];
  const spans=[];
  for(const [part,role] of parts){
    part.updateMatrix();
    const geometry=part.geometry.index?part.geometry.toNonIndexed():part.geometry.clone();
    geometry.applyMatrix4(part.matrix);
    const start=colors.length/3;
    const position=geometry.getAttribute('position'),normal=geometry.getAttribute('normal');
    const color=part.material.color;
    for(let i=0;i<position.count;i++){
      positions.push(position.getX(i),position.getY(i),position.getZ(i));
      normals.push(normal.getX(i),normal.getY(i),normal.getZ(i));
      colors.push(color.r,color.g,color.b);
    }
    if(role)spans.push({start,count:position.count,role});
    geometry.dispose();
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));
  const attribute=new THREE.Float32BufferAttribute(colors,3);
  geometry.setAttribute('color',attribute);fabricSpans.push({attribute,spans});
  const mesh=new Mesh(geometry,athleteSurface);mesh.castShadow=true;mesh.receiveShadow=true;
  return mesh;
}
function athlete(id) {
  const root=new Group(),body=new Group(),upper=new Group(),fabricSpans=[];
  root.add(body);body.add(upper);upper.position.y=HIP_HEIGHT;
  const strip='#d7e5dd',shirt='#499dd2',skin='#bc9378',shorts='#dae2e2',sock='#c7d5d4';
  const torso=cylinder(.24,.17,.47,shirt,0,1.2-HIP_HEIGHT,0);torso.scale.z=.65;
  const hair=sphere(.152,id%3?'#392b26':'#252324',0,1.76-HIP_HEIGHT,-.016);
  hair.scale.set(.89,.68,.94);
  const head=sphere(.151,skin,0,1.66-HIP_HEIGHT,0);head.scale.set(.88,1.12,.97);
  const chestTrim=box(.032,.34,.015,strip,-.169,1.22-HIP_HEIGHT,.105);chestTrim.rotation.z=-.10;
  upper.add(batchParts([
    [torso,'shirt'],[cylinder(.108,.13,.047,strip,0,1.427-HIP_HEIGHT,0),'trim'],
    [cylinder(.074,.083,.15,skin,0,1.487-HIP_HEIGHT,.004),'skin'],[head,'skin'],[hair],
    [chestTrim,'trim'],[box(.037,.057,.012,strip,.096,1.335-HIP_HEIGHT,.144),'trim'],
  ],fabricSpans));
  const number=new Mesh(geo('shirt-number',()=>new PlaneGeometry(.28,.27)),numberMaterial(id%11+1));
  number.position.set(0,1.231-HIP_HEIGHT,-.152);number.rotation.y=Math.PI;upper.add(number);
  body.add(batchParts([[box(.355,.17,.235,shorts,0,.927,0),'shorts']],fabricSpans));
  const legs=[],arms=[];
  for(const side of [-1,1]){
    const hip=new Group(),knee=new Group(),ankle=new Group();
    hip.position.set(side*.112,HIP_HEIGHT,0);knee.position.y=-THIGH_LENGTH;ankle.position.y=-SHIN_LENGTH;
    body.add(hip);hip.add(knee);knee.add(ankle);
    hip.add(batchParts([
      [cylinder(.106,.096,.22,shorts,0,-.105,0),'shorts'],
      [cylinder(.088,.066,.266,skin,0,-.30,0),'skin'],
    ],fabricSpans));
    knee.add(batchParts([
      [sphere(.066,skin,0,0,.005),'skin'],[cylinder(.071,.045,.37,sock,0,-.223,0),'socks'],
      [cylinder(.072,.072,.032,strip,0,-.063,0),'trim'],
    ],fabricSpans));
    const boot=id%4?'#26343a':'#cfc86e';
    ankle.add(batchParts([
      [box(.118,.092,.228,boot,0,-.008,.043)],
      [box(.123,.018,.239,'#1c2929',0,-.046,.05)],
    ],fabricSpans));
    legs.push({hip,knee,ankle});
    const shoulder=new Group(),elbow=new Group();
    shoulder.position.set(side*.224,1.366-HIP_HEIGHT,0);elbow.position.y=-.29;
    upper.add(shoulder);shoulder.add(elbow);
    shoulder.add(batchParts([
      [cylinder(.085,.071,.174,shirt,0,-.07,0),'shirt'],
      [cylinder(.071,.06,.154,skin,0,-.217,0),'skin'],
      [cylinder(.074,.073,.023,strip,0,-.145,0),'trim'],
    ],fabricSpans));
    const hand=sphere(id%11===0?.067:.048,skin,0,-.257,.013);
    elbow.add(batchParts([
      [cylinder(.057,.039,.25,skin,0,-.121,0),'skin'],[hand,id%11===0?'trim':'skin'],
    ],fabricSpans));
    arms.push({shoulder,elbow});
  }
  const shadow=new Mesh(geo('contact-disc',()=>new THREE.CircleGeometry(.48,20)),new MeshBasicMaterial({color:'#18291e',transparent:true,opacity:.22,depthWrite:false}));
  shadow.scale.set(1,.66,1);shadow.rotation.x=-Math.PI/2;shadow.position.y=.014;root.add(shadow);
  return {root,body,upper,legs,arms,fabricSpans};
}
function dressAthlete(model,p,tactics){
  const style=appearanceFor(tactics,p);
  const key=[style.heightCm,style.build,style.skin,style.shirt].join('/');
  if(model.appearanceKey===key)return;
  model.appearanceKey=key;
  model.root.scale.set(style.heightScale*style.build,style.heightScale,style.heightScale);
  const palette=Object.fromEntries(['skin','shirt','socks','shorts','trim'].map(role=>[role,new Color(style[role])]));
  for(const {attribute,spans} of model.fabricSpans){
    for(const {start,count,role} of spans){
      const c=palette[role];
      for(let i=start;i<start+count;i++)attribute.setXYZ(i,c.r,c.g,c.b);
    }
    attribute.needsUpdate=true;
  }
}
function trainingMeshes(state,selectedId){
  const groups=new Map();
  for(const stroke of trainingStrokes(state,selectedId)){
    const key=stroke.color+stroke.alpha;
    if(!groups.has(key))groups.set(key,{vertices:[],stroke});
    const {vertices}=groups.get(key);
    for(const [a,b] of stroke.segments){
      const dx=b.x-a.x,dy=b.y-a.y,norm=Math.hypot(dx,dy);
      const nx=-dy/norm*stroke.width/2,ny=dx/norm*stroke.width/2,h=stroke.height;
      vertices.push(a.x+nx,h,a.y+ny,b.x+nx,h,b.y+ny,b.x-nx,h,b.y-ny,
                    a.x+nx,h,a.y+ny,b.x-nx,h,b.y-ny,a.x-nx,h,a.y-ny);
    }
  }
  return [...groups.values()].map(({vertices,stroke})=>{
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
    const material=new MeshBasicMaterial({color:stroke.color,side:THREE.DoubleSide,transparent:true,opacity:stroke.alpha,depthWrite:false});
    const mesh=new Mesh(geometry,material);mesh.renderOrder=3+(stroke.id===selectedId?2:0)+(stroke.kind==='actual'?1:0);
    return mesh;
  });
}
export class PitchRenderer {
  constructor(container, onSelect) {
    this.container = container;
    this.onSelect = onSelect;
    this.state = null;
    this.selected = 7;
    this.cameraMode = "broadcast";
    this.zoom = 1;
    this.focus = "overview";
    this.quality = "balanced";
    this.motion = new VisualMotion();
    this.look = new Vector3();
    this.flags = {
      prediction: false,
      command: false,
      history: false,
      centroids: false,
      tactical: false,
      communication: false,
      observation: false,
      targets: false,
    };
    this.scope = "selected";
    this.agentView = false;
    this.fps = 0;
    this.frames = 0;
    this.start = performance.now();
    this.athletes = [];
    this.lastTime = performance.now();
    this.scene = new THREE.Scene();
    this.scene.background = new Color("#8b9da1");
    this.scene.fog = new THREE.Fog("#799093", 160, 320);
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 500);
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    this.renderer.setSize(900, 550);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.setAttribute(
      "aria-label",
      "Interactive 3D football field",
    );
    this.renderer.domElement.setAttribute("role", "img");
    this.scene.add(new THREE.HemisphereLight("#e1f5ff", "#41604b", 1.9));
    const sun = new THREE.DirectionalLight("#fff5dc", 3.4);
    sun.position.set(-32, 70, 30);
    this.sun = sun;
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, {
      left: -65,
      right: 65,
      top: 48,
      bottom: -48,
      near: 5,
      far: 160,
    });
    sun.shadow.bias = -0.0007;
    sun.shadow.normalBias = 0.035;
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight("#b6d9e9", 0.6);
    fill.position.set(60, 40, -50);
    this.scene.add(fill);
    this.arenaTextures=arenaTextures(this.renderer);
    this.buildStadium();
    for (let i = 0; i < 22; i++) {
      let p = athlete(i);
      this.scene.add(p.root);
      this.athletes.push(p);
    }
    this.ball = new Mesh(
      new SphereGeometry(0.19, 16, 12),
      new MeshStandardMaterial({ map: this.ballTexture(), roughness: 0.55 }),
    );
    this.ball.castShadow = true;
    this.scene.add(this.ball);
    this.ballShadow = new Mesh(
      new THREE.CircleGeometry(0.27, 16),
      new MeshBasicMaterial({
        color: "#14271a",
        transparent: true,
        opacity: 0.35,
      }),
    );
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.scene.add(this.ballShadow);
    this.selection = new Mesh(
      new THREE.RingGeometry(0.7, 0.84, 48),
      new MeshBasicMaterial({
        color: "#88edce",
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      }),
    );
    this.selection.rotation.x = -Math.PI / 2;
    this.selection.position.y = 0.04;
    this.scene.add(this.selection);
    this.overlay = new Group();
    this.scene.add(this.overlay);
    // Persistent line buffers for frame-synchronous mission overlays.
    this.missionLines=new Map();
    this.missionTags=document.createElement('div');this.missionTags.className='pitch-mission-tags';
    this.tagNodes=new Map();container.append(this.missionTags);
    this.label = document.createElement("div");
    this.label.className = "pitch-player-label";
    container.appendChild(this.label);
    this.renderer.domElement.addEventListener("pointerup", (e) => {
      const r = this.renderer.domElement.getBoundingClientRect();
      let best = null,
        min = 20;
      this.state?.players.forEach((p) => {
        if (!athleteVisible(this.state, p)) return;
        if (
          this.agentView &&
          p.id !== this.selected &&
          !selectedAthlete(this.state,this.selected)?.visible?.some((q) => q.id === p.id)
        )
          return;
        let v = new Vector3(p.x, 1, p.y).project(this.camera),
          px = (v.x + 1) * 0.5 * r.width,
          py = (1 - v.y) * 0.5 * r.height,
          d = Math.hypot(px - (e.clientX - r.left), py - (e.clientY - r.top));
        if (v.z<1 && v.z>-1 && d < min) {
          min = d;
          best = p.id;
        }
      });
      if (best !== null) {
        this.selected = best;
        this.onSelect(best);
      }
    });
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(container);
    this.resize();
    this.renderer.setAnimationLoop((t) => this.frame(t));
  }
  ballTexture() {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 128;
    const x = c.getContext("2d");
    x.fillStyle = "#f7f5dc";
    x.fillRect(0, 0, 256, 128);
    x.fillStyle = "#243842";
    for (let i = 0; i < 12; i++) {
      let px = (i % 6) * 43,
        py = Math.floor(i / 6) * 64 + 20;
      x.beginPath();
      for (let j = 0; j < 5; j++) {
        const a = (j * Math.PI * 2) / 5;
        x.lineTo(px + Math.cos(a) * 12, py + Math.sin(a) * 12);
      }
      x.closePath();
      x.fill();
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  buildStadium() {
    this.scene.add(box(350,.20,260,'#56635f',0,-.53,-20));
    this.scene.add(box(152,.48,148,'#3e4b46',0,-.32,-5));
    const turf = new Mesh(
      new PlaneGeometry(105, 68),
      new MeshStandardMaterial({map:this.arenaTextures.turf,bumpMap:this.arenaTextures.blades,bumpScale:.007,roughness:.96}),
    );
    turf.rotation.x = -Math.PI / 2;
    turf.receiveShadow = true;
    turf.position.y = 0.002;
    this.scene.add(turf);
    this.scene.add(box(110,.025,72.8,'#365c41',0,-.05,0));
    const paintVertices=[];
    for(const path of pitchMarkings()){
      for(let i=1;i<path.length;i++){
        const [x0,y0]=path[i-1],[x1,y1]=path[i];
        const length=Math.hypot(x1-x0,y1-y0);
        const nx=-(y1-y0)*.06/length,ny=(x1-x0)*.06/length;
        paintVertices.push(x0+nx,.025,y0+ny,x1+nx,.025,y1+ny,x1-nx,.025,y1-ny,
                           x0+nx,.025,y0+ny,x1-nx,.025,y1-ny,x0-nx,.025,y0-ny);
      }
    }
    const paintGeometry=new THREE.BufferGeometry();
    paintGeometry.setAttribute('position',new THREE.Float32BufferAttribute(paintVertices,3));
    const paint=new Mesh(paintGeometry,new MeshBasicMaterial({color:'#dbe3cd',side:THREE.DoubleSide,opacity:.9,transparent:true,depthWrite:false}));
    this.scene.add(paint);
    for(const x of [-41.5,0,41.5])this.scene.add(cylinder(.11,.11,.02,'#dbe3cd',x,.025,0));
    for (const s of [-1,1]) {
      this.goal(s);
      for (let y of [-33.8, 33.8]) {
        this.scene.add(
          cylinder(0.032, 0.032, 1.55, "#e5e6dc", s * 52.3, 0.77, y),
        );
        this.scene.add(
          box(
            0.45,
            0.28,
            0.015,
            s < 0 ? "#87d7e2" : "#f4ca75",
            s * 52.3 + 0.2,
            1.38,
            y,
          ),
        );
      }
    }
    // Each terrace is a sloping, finely textured seating bank bounded by a solid
    // retaining wall and rail. Its source artwork is shared with the Canvas view.
    const banner=this.arenaTextures.board;
    for(const side of [-1,1]){
      this.scene.add(box(128,.9,.21,'#193a43',0,.46,side*38));
      const board=new Mesh(geo('ad-band',()=>new PlaneGeometry(120,.80)),new MeshBasicMaterial({map:banner,side:THREE.DoubleSide}));
      board.position.set(0,.47,side*37.88);if(side===1)board.rotation.y=Math.PI;this.scene.add(board);
      this.scene.add(box(136,.54,.22,'#47575a',0,.26,side*40.85));
      this.scene.add(texturedTerrace(this.arenaTextures.terrace,[-68,8.5,side*57],[136,0,0],[0,-8.2,-side*16]));
      this.scene.add(box(137,.36,2.5,'#42565e',0,8.55,side*57.65));
      this.scene.add(box(136,8.35,.5,'#394b51',0,4.15,side*57.55));
      this.scene.add(texturedTerrace(this.arenaTextures.terrace,[side*69,5.5,-40],[0,0,80],[-side*10,-5.3,0]));
      this.scene.add(box(.45,5.65,82,'#45565b',side*69.25,2.78,0));
      this.scene.add(box(.82,.20,82,'#78898a',side*69,5.61,0));
    }
    this.scene.add(texturedTerrace(this.arenaTextures.terrace,[-71,18,-74],[142,0,0],[0,-8.7,16.4]));
    this.scene.add(box(142,1.1,.45,'#293d45',0,8.78,-57.6));
    this.scene.add(box(142,18,1,'#394b51',0,9,-74.5));
    this.scene.add(box(144,.32,10,'#5b6d72',0,21.4,-72));
    this.scene.add(box(144,.52,.28,'#364952',0,21.1,-67));
    for(let x=-64;x<=66;x+=21){
      this.scene.add(box(.20,3.4,.20,'#53676f',x,19.65,-73));
    }
    for(const x of [-59,59])for(const z of [-53,53]){
      this.scene.add(cylinder(.085,.143,20,'#576a72',x-.25,10,z));
      this.scene.add(cylinder(.085,.145,20,'#748388',x+.25,10,z));
      this.scene.add(box(5.1,1.58,.25,'#4b6067',x,19.6,z));
      for(let lamp=0;lamp<5;lamp++){
        const light=box(.70,1.0,.07,'#dbe7dc',x-1.96+lamp*.94,19.61,z-Math.sign(z)*.17);
        light.material=new MeshBasicMaterial({color:'#d7e1d9'});light.castShadow=false;
        this.scene.add(light);
      }
    }
  }
  goal(side) {
    const gx = side * 52.5,
      back = side * 55;
    for (let y of [-3.66, 3.66]) {
      this.scene.add(cylinder(0.06, 0.06, 2.44, "#e9eee8", gx, 1.22, y));
      this.scene.add(
        line(
          [
            [gx, 2.44, y],
            [back, 1.8, y],
            [back, 0.05, y],
            [gx, 0.05, y],
          ],
          "#b9d0c7",
        ),
      );
    }
    const bar = cylinder(0.06, 0.06, 7.32, "#e9eee8", gx, 2.44, 0);
    bar.rotation.x = Math.PI / 2;
    this.scene.add(bar);
    const pts = [];
    for (let y = -3.66; y <= 3.67; y += 0.22) {
      pts.push([gx, 2.44, y], [back, 1.8, y]);
      pts.push([back, 1.8, y], [back, 0.05, y]);
    }
    for (let h = 0; h <= 1.82; h += 0.2)
      pts.push([back, h, -3.66], [back, h, 3.66]);
    for (let x = 0; x <= 2.5; x += 0.22) {
      let h = 2.44 - (x / 2.5) * 0.64;
      pts.push([gx + side * x, h, -3.66], [gx + side * x, h, 3.66]);
      for (let y of [-3.66, 3.66])
        pts.push([gx + side * x, 0.05, y], [gx + side * x, h, y]);
    }
    const g = new THREE.BufferGeometry().setFromPoints(
      pts.map((p) => new Vector3(...p)),
    );
    this.scene.add(
      new THREE.LineSegments(
        g,
        new THREE.LineBasicMaterial({
          color: "#d4e1d6",
          transparent: true,
          opacity: 0.38,
        }),
      ),
    );
  }
  resize() {
    let w = this.container.clientWidth,
      h = this.container.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  setState(s) {
    this.state = s;
    this.received = performance.now();
    this.motion.receive(s, this.received);
    for(const p of s.players){
      const model=this.athletes[p.id];
      if(model)dressAthlete(model,p,s.tactics);
    }
    this.refreshOverlay();
  }
  configure(opts) {
    const oldQuality=this.quality;
    Object.assign(this, opts);
    if(oldQuality!==this.quality){
      this.renderer.setPixelRatio(Math.min(devicePixelRatio,this.quality==='detail'?2:this.quality==='performance'?1:1.5));
      this.renderer.shadowMap.enabled=this.quality!=='performance';
      const resolution=this.quality==='detail'?2048:1024;
      this.sun.shadow.mapSize.set(resolution,resolution);
      this.sun.shadow.map?.dispose();this.sun.shadow.map=null;
      this.resize();
    }
    this.refreshOverlay();
  }
  refreshOverlay() {
    if (!this.state) return;
    for (let child of [...this.overlay.children]) {
      this.overlay.remove(child);
      child.geometry?.dispose();
      child.material?.dispose();
    }
    const s = this.state;
    if(s.training){
      const selected=selectedAthlete(s,this.selected);
      for(const mesh of trainingMeshes(s,selected?.id))this.overlay.add(mesh);
      return;
    }
    const p = selectedAthlete(s,this.selected),
      team = p.team,
      cfg = s.tactics[team];
    const use = s.players.filter(
      (q) =>
        this.scope === "all" ||
        (this.scope === "team" && q.team === team) ||
        (this.scope === "unit" &&
          cfg.groups.some(
            (g) =>
              g.members.includes(p.index) &&
              g.members.includes(q.index) &&
              q.team === team,
          )) ||
        q.id === p.id,
    );
    const addLine = (points, color, opacity = 0.8) =>
      this.overlay.add(line(points, color, opacity));
    const arrow = (a, b, color) => {
      addLine(
        [
          [a.x, 0.12, a.y],
          [b.x, 0.12, b.y],
        ],
        color,
      );
      let dx = b.x - a.x,
        dy = b.y - a.y,
        n = Math.hypot(dx, dy) || 1,
        ux = dx / n,
        uy = dy / n;
      addLine(
        [
          [b.x - ux * 0.8 - uy * 0.35, 0.12, b.y - uy * 0.8 + ux * 0.35],
          [b.x, 0.12, b.y],
          [b.x - ux * 0.8 + uy * 0.35, 0.12, b.y - uy * 0.8 - ux * 0.35],
        ],
        color,
      );
    };
    for (let q of use) {
      if (this.flags.prediction && q.prediction?.length)
        addLine(
          [[q.x, 0.15, q.y], ...q.prediction.map((v) => [v.x, 0.15, v.y])],
          "#8cf4cc",
        );
      if (this.flags.command && q.command)
        arrow(
          q,
          { x: q.x + q.command.x * 0.8, y: q.y + q.command.y * 0.8 },
          "#f6ce74",
        );
      if (this.flags.history && q.trail?.length)
        addLine(
          q.trail.map((v) => [v.x, 0.07, v.y]),
          "#b6d0de",
          0.5,
        );
      if (this.flags.targets) {
        this.overlay.add(circle(q.target.x, q.target.y, 0.7, "#ffe294", 0.08));
        addLine(
          [
            [q.x, 0.07, q.y],
            [q.target.x, 0.07, q.target.y],
          ],
          "#ffe294",
          0.25,
        );
      }
      if (this.flags.centroids && q.estimate)
        this.overlay.add(
          circle(q.estimate.x, q.estimate.y, 0.4, "#99b1ff", 0.1),
        );
    }
    if (this.flags.centroids) {
      const m = s.metrics[team];
      if (m) {
        this.overlay.add(
          circle(m.centroid.x, m.centroid.y, 1.15, "#faf3c0", 0.12),
        );
        this.overlay.add(
          circle(m.reference.x, m.reference.y, 1.5, "#8cefc9", 0.12),
        );
      }
    }
    if (this.flags.tactical)
      for (let [a, b] of cfg.tacticalEdges) {
        let a1 = s.players[team * 11 + a],
          b1 = s.players[team * 11 + b];
        addLine(
          [
            [a1.x, 0.18, a1.y],
            [b1.x, 0.18, b1.y],
          ],
          "#e8c579",
          0.55,
        );
      }
    if (this.flags.communication)
      for (let [a, b] of cfg.commEdges) {
        let a1 = s.players[team * 11 + a],
          b1 = s.players[team * 11 + b];
        addLine(
          [
            [a1.x, 0.35, a1.y],
            [b1.x, 0.35, b1.y],
          ],
          "#6cd3e9",
          0.6,
        );
      }
    if (this.flags.observation || this.agentView) {
      const radius = p.vision || cfg.vision,
        angle = (cfg.fov * Math.PI) / 180,
        points = [[p.x, 0.08, p.y]];
      for (let i = 0; i <= 48; i++) {
        let a = p.heading - angle / 2 + (angle * i) / 48;
        points.push([
          p.x + Math.cos(a) * radius,
          0.08,
          p.y + Math.sin(a) * radius,
        ]);
      }
      points.push([p.x, 0.08, p.y]);
      addLine(points, "#93efca", 0.7);
    }
  }
  updateMissionOverlay(visual){
    const view=missionOverlay(this.state,{selected:this.selected,scope:this.scope,...this.flags,agentView:this.agentView,players:visual.players});
    const groups=new Map();for(const seg of view.segments){const key=seg.color+':'+seg.alpha;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(seg);}
    for(const [key,obj] of this.missionLines)obj.visible=groups.has(key);
    for(const [key,segments] of groups){let obj=this.missionLines.get(key);if(!obj){const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(new Float32Array(4096*3),3));obj=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:segments[0].color,transparent:true,opacity:segments[0].alpha,depthWrite:false}));obj.frustumCulled=false;this.scene.add(obj);this.missionLines.set(key,obj);}const data=obj.geometry.attributes.position;let i=0;for(const seg of segments)for(const v of [seg.a,seg.b]){data.setXYZ(i++,...v);}data.needsUpdate=true;obj.geometry.setDrawRange(0,i);obj.visible=true;}
    for(const el of this.tagNodes.values())el.style.display='none';
    const w=this.container.clientWidth,h=this.container.clientHeight;
    for(const tag of view.tags){if(tag.selected)continue;let el=this.tagNodes.get(tag.id);if(!el){el=document.createElement('span');this.missionTags.append(el);this.tagNodes.set(tag.id,el);}const p=new Vector3(tag.x,2.2,tag.y).project(this.camera);if(p.z<-1||p.z>1||Math.abs(p.x)>1||Math.abs(p.y)>1)continue;el.textContent=String(tag.index+1);el.style.cssText=`display:block;left:${(p.x+1)*.5*w}px;top:${(1-p.y)*.5*h}px;color:${tag.color}`;}
  }
  frame(now) {
    let elapsed = Math.min(0.08, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.frames++;
    if (now - this.start > 1000) {
      this.fps = Math.round((this.frames * 1000) / (now - this.start));
      this.frames = 0;
      this.start = now;
    }
    if (!this.container.isConnected || this.container.clientWidth === 0) return;
    const s = this.state;
    if (!s) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    const visual = this.motion.sample(now);
    const selected = selectedAthlete({...s,players:visual.players},this.selected);
    if(!selected)return;
    const known = new Set(selected.visible?.map((p) => p.id) || []);
    known.add(selected.id);
    for(const model of this.athletes)model.root.visible=false;
    for(const p of visual.players){
      const m=this.athletes[p.id];
      if (!m || !athleteVisible(s, p) || (this.agentView && !known.has(p.id))) continue;
      m.root.visible=true;
      m.root.position.set(p.x, 0, p.y);
      m.root.rotation.y = Math.PI / 2 - p.heading;
      const pose=p.visual;
      m.body.position.y=pose.bob-pose.crouch;
      m.upper.rotation.x=pose.lean;m.upper.rotation.z=pose.bank;
      m.legs.forEach((joint,index)=>{
        const leg=pose.legs[index];
        joint.hip.rotation.x=-leg.thigh;
        joint.knee.rotation.x=leg.knee;
        joint.ankle.rotation.x=leg.thigh-leg.knee+(leg.ground?0:-.18*pose.amp);
      });
      m.arms.forEach((arm,index)=>{
        const side=index?1:-1;
        arm.shoulder.rotation.x=-pose.save*1.4+Math.sin(pose.phase+index*Math.PI)*.54*pose.amp*(1-pose.save);
        arm.elbow.rotation.x=-.24-pose.amp*.63;
        arm.shoulder.rotation.z=side*(.14+pose.brake*.18+Math.abs(pose.turn)*.15+pose.save*.9);
      });
    }
    const ball=visual.ball;
    const ballVisible=!s.training && !!ball && (!this.agentView || (selected.knownBall?.via==='vision' && s.time-selected.knownBall.time<.2));
    this.ball.visible=this.ballShadow.visible=ballVisible;
    if(ballVisible){
      this.ball.position.set(ball.x,Math.max(.19,ball.z),ball.y);
      this.ball.rotation.x=ball.spin;this.ball.rotation.z=ball.spin*.4;
      this.ballShadow.position.set(ball.x+.3*ball.z,.02,ball.y-.23*ball.z);
      this.ballShadow.material.opacity=Math.max(.07,.35-ball.z*.08);
      this.ballShadow.scale.setScalar(1+Math.max(0,ball.z)*.12);
    }
    this.selection.visible=!s.training;
    this.selection.position.set(selected.x,.04,selected.y);
    const focus=cameraFocus(s,this.selected,this.focus,this.agentView),target=new Vector3(focus.x,0,focus.y);
    this.look.lerp(target,Math.min(1,elapsed*4));
    const offset = cameraOffset(this.cameraMode, this.focus, this.camera.aspect, this.zoom);
    const desired = new Vector3(this.look.x + offset[0], offset[1], this.look.z + offset[2]);
    if(!this.cameraReady){this.camera.position.copy(desired);this.cameraReady=true;}
    else this.camera.position.lerp(desired,Math.min(1,elapsed*5));
    this.camera.lookAt(this.look);
    const pixelScale=this.container.clientHeight/(2*Math.tan(42*Math.PI/360)*this.camera.position.distanceTo(this.ball.position));
    this.ball.scale.setScalar(Math.min(2.2,Math.max(1,2.2/(.19*pixelScale))));
    const lp = new Vector3(selected.x, 2.9, selected.y).project(this.camera),
      w = this.container.clientWidth,
      h = this.container.clientHeight;
    this.label.style.left = (lp.x + 1) * 0.5 * w + "px";
    this.label.style.top = (1 - lp.y) * 0.5 * h + "px";
    this.label.textContent =
      String(selected.index + 1).padStart(2, "0") + " " + selected.name;
    this.label.style.display = athleteVisible(s, selected) && lp.z<1 && lp.z>-1 && Math.abs(lp.x)<1 && Math.abs(lp.y)<1 ? "block" : "none";
    this.updateMissionOverlay(visual);
    this.renderer.render(this.scene, this.camera);
  }
  mount(container) {
    this.observer.disconnect();
    this.container = container;
    container.append(this.renderer.domElement, this.label, this.missionTags);
    this.observer.observe(container);
    this.resize();
  }
  dispose() {
    this.renderer.setAnimationLoop(null);
    this.observer.disconnect();
    const sharedGeometry=new Set(geometries.values());
    const sharedMaterial=new Set([...materials.values(),...numberMaterials.values(),athleteSurface]);
    const geometry=new Set(),material=new Set(),textures=new Set();
    this.scene.traverse(object=>{
      if(object.geometry && !sharedGeometry.has(object.geometry))geometry.add(object.geometry);
      if(object.material && !sharedMaterial.has(object.material))material.add(object.material);
    });
    for(const m of material){
      if(m.map)textures.add(m.map);
      if(m.bumpMap)textures.add(m.bumpMap);
      m.dispose();
    }
    for(const g of geometry)g.dispose();
    for(const texture of textures)texture.dispose();
    this.renderer.dispose();
  }
}
