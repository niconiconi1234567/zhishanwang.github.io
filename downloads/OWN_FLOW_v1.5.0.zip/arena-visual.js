// The renderer receives physical pitch coordinates in metres. The middle
// coordinate of a Three.js world point is its height above the grass.
export const ARENA_TEXTURES = Object.freeze({
  turf: new URL('./assets/turf-v15.jpg', import.meta.url).href,
  blades: new URL('./assets/arena/blade-relief.webp', import.meta.url).href,
  board: new URL('./assets/arena/perimeter-board.webp', import.meta.url).href,
  terrace: new URL('./assets/terrace-v15.jpg', import.meta.url).href,
});
export const TRAINING_COLORS = Object.freeze({reference: '#74c9ff', actual: '#ff9273'});

const skinTones = ['#e2b796', '#c99270', '#a87252', '#895c43', '#604032'];
const defaultHeights = [191, 175, 187, 185, 178, 181, 173, 177, 174, 182, 188];
const defaultBuilds = [1.03, .94, 1.09, 1.05, .96, 1.03, .92, .95, .93, 1, 1.10];

function bounded(value, fallback, min, max) {
  return Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}

export function appearanceFor(tactics, player) {
  const {team, index, id} = player;
  const tactic = tactics?.[team];
  const appearance = tactic?.players?.[index]?.appearance ?? {};
  const keeper = index === 0;
  const heightCm = bounded(appearance.heightCm, defaultHeights[index % 11] + Number(!!team), 145, 220);
  const build = bounded(appearance.build, defaultBuilds[index % 11], .85, 1.2);
  const skinIndex = Math.round(bounded(appearance.skinTone, (id * 3 + 2) % 5, 0, 4));
  const primary = /^#[a-f0-9]{6}$/i.test(tactic?.color) ? tactic.color : (team ? '#eb725b' : '#399be0');
  const shirt = keeper ? (team ? '#a88bcf' : '#c1c668') : primary;
  return {
    heightCm,
    heightScale: heightCm / 186.8,
    build,
    skin: skinTones[skinIndex],
    shirt,
    shorts: keeper ? '#253a36' : (team ? '#442f3a' : '#dde5e3'),
    socks: keeper ? '#576951' : (team ? '#c5cbd4' : '#dce7eb'),
    trim: team ? '#ffe4ca' : '#d4f4ef',
  };
}

export function selectedAthlete(state, id) {
  const team = state?.training?.team;
  const allowed = p => team == null || p.team === team;
  return state?.players?.find(p => p.id === id && allowed(p)) ?? state?.players?.find(allowed);
}

const validPoint = point => Number.isFinite(point?.x) && Number.isFinite(point?.y);
const onPitch = p => validPoint(p) && Math.abs(p.x) <= 52.5 && Math.abs(p.y) <= 34;
export function athleteVisible(state, player) {
  return !state.training || (player.team === state.training.team && onPitch(player));
}

// Liang–Barsky clipping preserves the correct exit point when a divergent
// player's trajectory crosses a field boundary at an oblique angle.
function clipSegment(start, end) {
  if (!validPoint(start) || !validPoint(end)) return null;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const limits = [[-dx, start.x + 52.5], [dx, 52.5 - start.x], [-dy, start.y + 34], [dy, 34 - start.y]];
  let enter = 0;
  let leave = 1;
  for (const [direction, distance] of limits) {
    if (direction === 0) {
      if (distance < 0) return null;
    } else {
      const fraction = distance / direction;
      if (direction < 0) enter = Math.max(enter, fraction);
      else leave = Math.min(leave, fraction);
      if (enter > leave) return null;
    }
  }
  return [
    {x: start.x + enter * dx, y: start.y + enter * dy},
    {x: start.x + leave * dx, y: start.y + leave * dy},
  ];
}

function ringPoints(center, radius) {
  return Array.from({length: 25}, (_, i) => ({
    x: center.x + radius * Math.cos(i * Math.PI / 12),
    y: center.y + radius * Math.sin(i * Math.PI / 12),
  }));
}

function visibleSegments(points, dashed) {
  const segments = [];
  const period = 1.35;
  const ink = .88;
  let travelled = 0;
  for (let i = 1; i < points.length; i++) {
    const clipped = clipSegment(points[i - 1], points[i]);
    if (!clipped) continue;
    const [start, end] = clipped;
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const length = Math.hypot(dx, dy);
    if (length < .0001 || !Number.isFinite(length)) continue;
    if (!dashed) {
      segments.push(clipped);
      continue;
    }
    const pointAt = offset => ({x: start.x + dx * offset / length, y: start.y + dy * offset / length});
    let offset = 0;
    while (offset < length - 1e-7) {
      const phase = travelled % period;
      const visible = phase < ink;
      const remaining = (visible ? ink : period) - phase;
      const next = Math.min(length, offset + Math.max(1e-6, remaining));
      if (visible) segments.push([pointAt(offset), pointAt(next)]);
      travelled += next - offset;
      if (period - (travelled % period) < 1e-6) travelled = Math.round(travelled / period) * period;
      offset = next;
    }
  }
  return segments;
}

function arrowPoints(start, end, active) {
  const visible = clipSegment(start, end);
  if (!visible) return null;
  const [base, tip] = visible;
  const dx = tip.x - base.x;
  const dy = tip.y - base.y;
  const length = Math.hypot(dx, dy);
  if (length < .15) return null;
  const head = Math.min(active ? 1.25 : .78, length * .42);
  const ux = dx / length;
  const uy = dy / length;
  return {
    shaft: visible,
    tip: [
      {x: tip.x - head * ux + head * .45 * uy, y: tip.y - head * uy - head * .45 * ux},
      tip,
      {x: tip.x - head * ux - head * .45 * uy, y: tip.y - head * uy + head * .45 * ux},
    ],
  };
}

// Geometry clipping is display-only. Measurement histories retain raw values.
export function trainingStrokes(state, selectedId) {
  if (!state.training) return [];
  const allowed = new Map(state.players.filter(p => p.team === state.training.team).map(p => [p.id, p]));
  const paths = (state.training.paths ?? []).filter(p => allowed.has(p.id));
  paths.sort((a, b) => Number(a.id === selectedId) - Number(b.id === selectedId));
  const strokes = [];
  for (const path of paths) {
    const active = path.id === selectedId;
    const actual = path.actualPoint ?? allowed.get(path.id);
    const origin = path.origin ?? path.actual?.[0];
    const add = (points, kind, dashed = false, factor = 1) => {
      if (!Array.isArray(points) || points.length < 2) return;
      const segments = visibleSegments(points, dashed);
      if (segments.length === 0) return;
      strokes.push({
        id: path.id,
        kind,
        color: TRAINING_COLORS[kind],
        width: (active ? .22 : .105) * factor,
        pixels: (active ? 2.5 : 1.15) * factor,
        alpha: active ? .97 : .66,
        height: kind === 'reference' ? .085 : .12,
        segments,
      });
    };
    add(path.reference, 'reference', true, 1.25);
    add(path.actual, 'actual');
    for (const [kind, end] of [['reference', path.target], ['actual', actual]]) {
      const arrow = arrowPoints(origin, end, active);
      if (arrow) {
        const reference = kind === 'reference';
        add(arrow.shaft, kind, reference, reference ? 1.15 : .65);
        add(arrow.tip, kind);
      }
    }
    if (onPitch(path.target)) add(ringPoints(path.target, active ? .87 : .57), 'reference');
    if (onPitch(actual)) add(ringPoints(actual, active ? .54 : .33), 'actual');
  }
  return strokes;
}

export function pitchMarkings() {
  const paths = [
    [[-52.44, -33.94], [52.44, -33.94], [52.44, 33.94], [-52.44, 33.94], [-52.44, -33.94]],
    [[0, -34], [0, 34]],
  ];
  const arc = (cx, cy, radius, from, to, steps) => Array.from({length: steps + 1}, (_, i) => {
    const angle = from + (to - from) * i / steps;
    return [cx + radius * Math.cos(angle), cy + radius * Math.sin(angle)];
  });
  paths.push(arc(0, 0, 9.15, 0, 2 * Math.PI, 80));
  const penaltyAngle = Math.acos(5.5 / 9.15);
  for (const side of [-1, 1]) {
    for (const [depth, halfWidth] of [[16.5, 20.16], [5.5, 9.16]]) {
      const front = side * (52.5 - depth);
      paths.push([[side * 52.5, -halfWidth], [front, -halfWidth], [front, halfWidth], [side * 52.5, halfWidth]]);
    }
    const direction = side === 1 ? Math.PI : 0;
    paths.push(arc(side * 41.5, 0, 9.15, direction - penaltyAngle, direction + penaltyAngle, 36));
    for (const lateral of [-1, 1]) {
      const middle = Math.atan2(-lateral, -side);
      paths.push(arc(side * 52.5, lateral * 34, 1, middle - Math.PI / 4, middle + Math.PI / 4, 12));
    }
  }
  return paths;
}
