// Display-only geometry. It never modifies simulation state or player information.
export const DUTY_COLORS={hold:'#91a9b7',collect:'#e7c77e',press:'#f4a08d',screen:'#c1aff2',cover:'#8ddcc0',recover:'#8abdf1',support:'#8ed9e4',carry:'#e4d293'};
const point=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
export function missionOverlay(state,{selected=7,scope='selected',missions=false,tracking=false,agentView=false,players=state?.players}={}){
  const segments=[],tags=[];
  if(!state||state.training||agentView||(!missions&&!tracking))return {segments,tags};
  const p=players?.find(q=>q.id===selected);if(!p)return {segments,tags};
  const cfg=state.tactics?.[p.team];
  const chosen=q=>q.id===p.id||scope==='all'||(scope==='team'&&q.team===p.team)||(scope==='unit'&&q.team===p.team&&cfg?.groups?.some(g=>g.members.includes(p.index)&&g.members.includes(q.index)));
  const line=(a,b,color,alpha=.8)=>{if(point(a)&&point(b))segments.push({a:[a.x,.085,a.y],b:[b.x,.085,b.y],color,alpha});};
  const ring=(q,r,color,alpha=.8)=>{for(let i=0;i<20;i++){const a=i*Math.PI/10,b=(i+1)*Math.PI/10;line({x:q.x+r*Math.cos(a),y:q.y+r*Math.sin(a)},{x:q.x+r*Math.cos(b),y:q.y+r*Math.sin(b)},color,alpha);}};
  const arrow=(a,b,color,alpha=.8)=>{if(!point(a)||!point(b))return;const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<.15)return;line(a,b,color,alpha);const h=Math.min(.95,d*.3),ux=dx/d,uy=dy/d;line(b,{x:b.x-h*ux+h*.45*uy,y:b.y-h*uy-h*.45*ux},color,alpha);line(b,{x:b.x-h*ux-h*.45*uy,y:b.y-h*uy+h*.45*ux},color,alpha);};
  for(const q of players){if(!point(q))continue;const active=state.tactics?.[q.team]?.mission?.enabled;const color=active?(DUTY_COLORS[q.mission?.state]??DUTY_COLORS.hold):DUTY_COLORS.hold;
    if(missions&&q.team===p.team){ring(q,q.id===p.id?1.05:.72,color,q.id===p.id?1:.65);tags.push({id:q.id,x:q.x,y:q.y,index:q.index,color,state:active?q.mission?.state??'hold':'off',selected:q.id===p.id});}
    if((tracking&&chosen(q))||(missions&&q.id===p.id)){arrow(q,q.target,'#74c9ff',q.id===p.id?.95:.5);if(point(q.target))ring(q.target,.38,'#74c9ff',.7);if(Number.isFinite(q.vx)&&Number.isFinite(q.vy))arrow(q,{x:q.x+q.vx,y:q.y+q.vy},'#ff9273',.95);}
  }
  return {segments,tags};
}
