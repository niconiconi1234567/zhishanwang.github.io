// Small dense linear systems for the training pitch (at most five states).
// Eigenvalues come from a shifted complex QR iteration on an upper Hessenberg
// matrix. The input/output model is reduced independently of internal stability.
const dot = (left, right) => left.reduce((sum, value, i) => sum + value * right[i], 0);
const multiplyVector = (matrix, vector) => matrix.map(row => dot(row, vector));
const transpose = matrix => matrix[0].map((_, j) => matrix.map(row => row[j]));
const norm = vector => Math.hypot(...vector);
const complex = (re, im = 0) => ({ re, im });
const conjugate = z => complex(z.re, -z.im);
const magnitude = z => Math.hypot(z.re, z.im);
const scale = (z, factor) => complex(z.re * factor, z.im * factor);
const plus = (a, b) => complex(a.re + b.re, a.im + b.im);
const minus = (a, b) => complex(a.re - b.re, a.im - b.im);
const product = (a, b) => complex(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);

function squareRoot(z) {
  if (z.im === 0 && z.re === 0) return complex(0);
  const large = Math.sqrt((magnitude(z) + Math.abs(z.re)) / 2);
  if (z.re >= 0) return complex(large, z.im / (2 * large));
  return complex(Math.abs(z.im) / (2 * large), z.im < 0 ? -large : large);
}

function pairRoots(matrix, i) {
  const a = matrix[i][i], b = matrix[i][i + 1];
  const c = matrix[i + 1][i], d = matrix[i + 1][i + 1];
  const midpoint = scale(plus(a, d), 0.5);
  const delta = scale(minus(a, d), 0.5);
  const spread = squareRoot(plus(product(delta, delta), product(b, c)));
  return [plus(midpoint, spread), minus(midpoint, spread)];
}

function hessenberg(source) {
  const matrix = source.map(row => row.slice()), n = matrix.length;
  for (let k = 0; k < n - 2; k++) {
    const offset = k + 1;
    const column = matrix.slice(offset).map(row => row[k]);
    const length = norm(column);
    if (!length) continue;
    column[0] += (column[0] < 0 ? -1 : 1) * length;
    const divisor = norm(column);
    const reflector = column.map(value => value / divisor);
    for (let j = k; j < n; j++) {
      let coefficient = 0;
      reflector.forEach((value, i) => { coefficient += value * matrix[offset + i][j]; });
      reflector.forEach((value, i) => { matrix[offset + i][j] -= 2 * coefficient * value; });
    }
    for (let i = 0; i < n; i++) {
      const coefficient = dot(reflector, matrix[i].slice(offset));
      reflector.forEach((value, j) => { matrix[i][offset + j] -= 2 * coefficient * value; });
    }
    for (let i = k + 2; i < n; i++) matrix[i][k] = 0;
  }
  return matrix.map(row => row.map(value => complex(value)));
}

function qrStep(matrix, low, high, shift) {
  for (let i = low; i <= high; i++) matrix[i][i] = minus(matrix[i][i], shift);
  const rotations = [];
  for (let k = low; k < high; k++) {
    const a = matrix[k][k], b = matrix[k + 1][k];
    const aLength = magnitude(a), length = Math.hypot(aLength, magnitude(b));
    const c = length === 0 ? 1 : aLength / length;
    const phase = aLength === 0 ? complex(1) : scale(a, 1 / aLength);
    const s = length === 0 ? complex(0) : scale(product(phase, conjugate(b)), 1 / length);
    rotations.push({ c, s });
    for (let j = k; j <= high; j++) {
      const upper = matrix[k][j], lower = matrix[k + 1][j];
      matrix[k][j] = plus(scale(upper, c), product(s, lower));
      matrix[k + 1][j] = minus(scale(lower, c), product(conjugate(s), upper));
    }
    matrix[k + 1][k] = complex(0);
  }
  rotations.forEach(({ c, s }, offset) => {
    const k = low + offset;
    for (let i = low; i <= high; i++) {
      const left = matrix[i][k], right = matrix[i][k + 1];
      matrix[i][k] = plus(scale(left, c), product(conjugate(s), right));
      matrix[i][k + 1] = minus(scale(right, c), product(s, left));
    }
  });
  for (let i = low; i <= high; i++) matrix[i][i] = plus(matrix[i][i], shift);
}

function eigenvalues(source) {
  if (!source.length) return { roots: [], reliable: true };
  const matrix = hessenberg(source);
  let high = source.length - 1;
  const roots = [];
  let steps = 0;
  while (high >= 0) {
    let low = high;
    while (low > 0) {
      const threshold = 2e-14 * (1 + magnitude(matrix[low][low]) + magnitude(matrix[low - 1][low - 1]));
      if (magnitude(matrix[low][low - 1]) <= threshold) break;
      low--;
    }
    const size = high - low + 1;
    if (size <= 2) {
      if (size === 1) roots.push(matrix[high][high]);
      else roots.push(...pairRoots(matrix, low));
      high = low - 1;
      steps = 0;
      continue;
    }
    if (++steps > 500) return { roots, reliable: false };
    const last = matrix[high][high];
    const candidates = pairRoots(matrix, high - 1);
    let shift = candidates.reduce((a, b) =>
      magnitude(minus(a, last)) <= magnitude(minus(b, last)) ? a : b
    );
    if (steps % 48 === 0) {
      const amount = magnitude(matrix[high][high - 1]);
      shift = plus(last, complex(0.4 * amount, 0.27 * amount));
    }
    qrStep(matrix, low, high, shift);
  }
  for (const root of roots) {
    if (Math.abs(root.im) < 1e-10 * (1 + Math.abs(root.re))) root.im = 0;
  }
  roots.sort((a, b) => a.re - b.re || a.im - b.im);
  return { roots, reliable: roots.length === source.length && roots.every(z => Number.isFinite(magnitude(z))) };
}

export function inspectModes(matrix) {
  const { roots: poles, reliable } = eigenvalues(matrix);
  const radius = Math.max(0, ...poles.map(magnitude));
  const stability = !reliable ? "unresolved" : radius > 1 + 2e-6 ? "unstable"
    : radius < 1 - 2e-6 ? "stable" : "boundary";
  return { poles, radius, stability };
}

function krylovBasis(matrix, seed) {
  const seedNorm = norm(seed);
  if (seedNorm === 0) return [];
  const basis = [seed.map(value => value / seedNorm)];
  const tolerance = 8e-13 * Math.max(1, ...matrix.map(norm));
  while (basis.length < seed.length) {
    const next = multiplyVector(matrix, basis.at(-1));
    // Reorthogonalize weak directions before deciding numerical rank.
    for (let pass = 0; pass < 2; pass++) {
      for (const unit of basis) {
        const component = dot(next, unit);
        unit.forEach((value, i) => { next[i] -= component * value; });
      }
    }
    const length = norm(next);
    if (length < tolerance) break;
    basis.push(next.map(value => value / length));
  }
  return basis;
}

function project(model, basis) {
  const right = basis.map(vector => multiplyVector(model.A, vector));
  return {
    A: basis.map(left => right.map(vector => dot(left, vector))),
    B: basis.map(vector => dot(vector, model.B)),
    C: basis.map(vector => dot(vector, model.C))
  };
}

function minimalModel(model) {
  const reachable = project(model, krylovBasis(model.A, model.B));
  if (!reachable.A.length || norm(reachable.C) < 8e-13 * norm(model.C)) return project(model, []);
  return project(reachable, krylovBasis(transpose(reachable.A), reachable.C));
}

function polynomial(roots) {
  let coefficients = [complex(1)];
  for (const root of roots) {
    const next = Array.from({ length: coefficients.length + 1 }, () => complex(0));
    coefficients.forEach((coefficient, i) => {
      next[i] = plus(next[i], coefficient);
      next[i + 1] = minus(next[i + 1], product(coefficient, root));
    });
    coefficients = next;
  }
  return coefficients.map(z => z.re);
}

function polynomialRoots(coefficients) {
  const n = coefficients.length - 1;
  if (n <= 0) return { roots: [], reliable: true };
  const companion = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (__, j) =>
    i === 0 ? -coefficients[j + 1] / coefficients[0] : Number(i === j + 1)
  ));
  return eigenvalues(companion);
}

export function inspectRealization(model) {
  const internal = inspectModes(model.A);
  const reduced = minimalModel(model);
  const result = eigenvalues(reduced.A);
  const den = polynomial(result.roots);
  let impulse = reduced.B;
  const markov = [];
  for (let i = 0; i < reduced.A.length; i++) {
    markov.push(dot(reduced.C, impulse));
    impulse = multiplyVector(reduced.A, impulse);
  }
  const num = markov.map((_, i) => {
    let coefficient = 0;
    for (let j = 0; j <= i; j++) coefficient += den[j] * markov[i - j];
    return coefficient;
  });
  const scale = Math.max(0, ...num.map(Math.abs));
  const threshold = 2e-12 * scale;
  while (num.length && Math.abs(num[0]) <= threshold) num.shift();
  if (!num.length) num.push(0);
  const zeros = polynomialRoots(num);
  return {
    num, den, poles: result.roots, zeros: zeros.roots, internalPoles: internal.poles,
    stability: internal.stability, radius: internal.radius,
    cancelledModes: model.A.length - reduced.A.length,
    zeroTransfer: num.length === 1 && num[0] === 0,
    numericallyReliable: result.reliable && zeros.reliable && internal.stability !== "unresolved"
  };
}
