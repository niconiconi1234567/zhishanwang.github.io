import { appearanceFor, selectedAthlete } from './arena-visual.js';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const wrapAngle = angle => Math.atan2(Math.sin(angle), Math.cos(angle));
const TAU = Math.PI * 2;
export const THIGH_LENGTH = .435;
export const SHIN_LENGTH = .43;
export const HIP_HEIGHT = .88;

// Visual interpolation does not extrapolate, including when a physical contact,
// reset or rewind moves a player discontinuously between received samples.
export function blendPose(previous, current, alpha, moving = true) {
  if (!current) return null;
  if (!previous || !moving || Math.hypot(current.x-previous.x, current.y-previous.y)>8) {
    return {...current};
  }
  const t = clamp(alpha, 0, 1);
  const out = {...current};
  for (const key of ['x', 'y', 'z', 'vx', 'vy', 'spin']) {
    if (Number.isFinite(previous[key]) && Number.isFinite(current[key])) {
      out[key] = previous[key] + (current[key]-previous[key])*t;
    }
  }
  if (Number.isFinite(previous.heading) && Number.isFinite(current.heading)) {
    out.heading = previous.heading + wrapAngle(current.heading-previous.heading)*t;
  }
  return out;
}

function strideLength(speed, heightScale=1) {
  return clamp(.8+speed*.43, 1.15, 3.8)*heightScale;
}

// Foot positions and both joint angles come from the same two-link leg. During
// stance the foot moves backwards relative to the hips at ground travel speed.
// In swing it clears the surface, and an observed kick extends the striking leg.
function footGoal(phase, speed, kick, tackle, heightScale) {
  const fraction = ((phase/TAU)%1+1)%1;
  const contact = .56-.21*clamp(speed/7.5,0,1);
  const reach = Math.min(.53,.5*strideLength(speed,heightScale)*contact/heightScale) * clamp(speed/.8,0,1);
  let forward, lift=0;
  if (fraction<contact) {
    forward = reach*(1-2*fraction/contact);
  } else {
    const t = (fraction-contact)/(1-contact);
    forward = reach*(2*t*t*(3-2*t)-1);
    lift = Math.sin(Math.PI*t)*(.09+.26*clamp(speed/7,0,1))*clamp(speed/.8,0,1);
  }
  forward = forward*(1-kick) + .58*kick + .18*tackle;
  return {forward, height:.056+lift+.24*kick, ground:lift<.012 && kick<.04};
}

function legAt(goal, hip) {
  const forward=goal.forward;
  const down=hip-goal.height;
  const length = clamp(Math.hypot(forward,down),.03,THIGH_LENGTH+SHIN_LENGTH-.0001);
  const knee = Math.acos(clamp((length*length-THIGH_LENGTH**2-SHIN_LENGTH**2)/(2*THIGH_LENGTH*SHIN_LENGTH),-1,1));
  const thigh = Math.atan2(forward,down)+Math.atan2(SHIN_LENGTH*Math.sin(knee),THIGH_LENGTH+SHIN_LENGTH*Math.cos(knee));
  const kneeHeight = hip-THIGH_LENGTH*Math.cos(thigh);
  const kneeForward = THIGH_LENGTH*Math.sin(thigh);
  return {
    thigh, knee, kneeHeight, kneeForward,
    footHeight:kneeHeight-SHIN_LENGTH*Math.cos(thigh-knee),
    footForward:kneeForward+SHIN_LENGTH*Math.sin(thigh-knee),
    ground:goal.ground,
  };
}

export function actionPose(player, time, distance=0, dynamics={}) {
  const speed = Math.hypot(player.vx,player.vy);
  const amp = clamp(speed/6,0,1);
  const phase = distance*2.8 + player.id*1.37;
  const hasEventEnd=Number.isFinite(player.actionUntil);
  const remaining=hasEventEnd ? clamp(player.actionUntil-time,0,.55) : .275;
  const pulse = Math.sin(Math.PI*(1-remaining/.55));
  const striking=['pass','shoot'].includes(player.action);
  const kick=striking ? pulse : 0;
  const elapsed=time-(player.actionUntil-.55);
  // The release event is already observed when the ball leaves the foot. Start
  // the contact reach at release, then carry the striking leg through recovery.
  const contactReach=striking && hasEventEnd && elapsed>=-1e-7 && elapsed<.55
    ? .82*Math.exp(-Math.pow(Math.max(0,elapsed)/.12,2)) : 0;
  const save = player.action==='save' ? pulse : 0;
  const tackle = player.action==='tackle' ? pulse : 0;
  const brake = clamp(-(dynamics.acceleration??0)/5,0,1);
  const turn = clamp((dynamics.turnRate??0)*speed/13,-1,1);
  const crouch = .065*brake+.06*Math.abs(turn)+.19*tackle+.12*save;
  const heightScale = dynamics.heightScale??1;
  const goals=[footGoal(phase,speed,0,0,heightScale),
    footGoal(phase+Math.PI,speed,Math.max(contactReach,kick),tackle,heightScale)];
  const nominalHip=HIP_HEIGHT+(.025-.037*Math.cos(phase*2))*amp-crouch;
  // Lower the hip slightly during the wide part of a stride so that the contact
  // foot can remain at ground height without extending either bone.
  const maxReach=THIGH_LENGTH+SHIN_LENGTH-.0002;
  const hip=Math.min(nominalHip,...goals.map(({forward,height})=>height+Math.sqrt(Math.max(0,maxReach**2-forward**2))));
  const bob=hip-HIP_HEIGHT+crouch;
  const legs=goals.map(goal=>legAt(goal,hip));
  return {
    amp,phase,bob,kick,save,tackle,brake,crouch,turn,legs,
    lean:amp*.105-brake*.095+tackle*.17,
    bank:turn*.17+save*.38,
  };
}

export function cameraFocus(state, selected=7, mode='overview', agentView=false) {
  const player = selectedAthlete(state,selected);
  if (!player || (mode==='overview' && !agentView)) return {x:0,y:0};
  if (state.training) return {x:clamp(player.x,-52.5,52.5),y:clamp(player.y,-34,34)};
  if (agentView || mode==='player' || !state.ball) return {x:player.x,y:player.y};
  return {x:clamp(state.ball.x,-44,44),y:clamp(state.ball.y,-27,27)};
}

// Broadcast uses a lower touchline angle for player close-ups, with the same
// camera in both backends. The overhead tactical view keeps the entire diagram legible.
export function cameraOffset(cameraMode, focus, aspect, zoom) {
  const fit = Math.max(1, 1.5 / aspect) / zoom;
  if (cameraMode === 'tactical') return [0, 114 * fit, 27 * fit];
  if (focus === 'player') return [8 * fit, 39 * fit, 54 * fit];
  if (focus === 'ball') return [4 * fit, 62 * fit, 83 * fit];
  return [3 * fit, 78 * fit, 80 * fit];
}

export class VisualMotion {
  constructor() {
    this.previous = null;
    this.current = null;
    this.phases = new Map();
    this.previousPlayers = new Map();
  }
  receive(state,now) {
    this.previous = this.current;
    this.duration = clamp(now-(this.received??now-100),30,180);
    this.received = now;
    this.current = state;
    const reset = !this.previous || state.time<this.previous.time ||
      state.time-this.previous.time>2 || !!state.training!==!!this.previous.training;
    if (reset) {
      this.previous = null;
      this.phases.clear();
    }
    this.previousPlayers = new Map(this.previous?.players.map(p=>[p.id,p])??[]);
  }
  sample(now) {
    const state = this.current, old = this.previous;
    const alpha = clamp((now-this.received)/this.duration,0,1);
    const interpolate = !!state.running && !!old;
    const time = interpolate ? old.time+(state.time-old.time)*alpha : state.time;
    const dt = old ? state.time-old.time : 0;
    const players = state.players.map(player=>{
      const before = this.previousPlayers.get(player.id);
      const pose = blendPose(before,player,alpha,interpolate);
      const last = this.phases.get(player.id);
      const speed = Math.hypot(pose.vx,pose.vy);
      const heightScale = appearanceFor(state.tactics,player).heightScale;
      let distance = last?.distance??0;
      if (last && interpolate) {
        const step = Math.hypot(pose.x-last.x,pose.y-last.y);
        const forward = pose.vx*Math.cos(pose.heading)+pose.vy*Math.sin(pose.heading);
        if (step<4) distance += step*(forward<-.1?-1:1)*TAU/(2.8*strideLength(speed,heightScale));
      }
      this.phases.set(player.id,{x:pose.x,y:pose.y,distance});
      // Use physical snapshot time for acceleration and turning, including when
      // presentation frames are sparse. Repeated paused frames stay identical.
      let acceleration=0,turnRate=0;
      if (before && dt>1e-5) {
        acceleration=(Math.hypot(player.vx,player.vy)-Math.hypot(before.vx,before.vy))/dt;
        turnRate=wrapAngle(player.heading-before.heading)/dt;
      }
      return {...pose,visual:actionPose(pose,time,distance,{acceleration,turnRate,heightScale})};
    });
    return {players,ball:blendPose(old?.ball,state.ball,alpha,interpolate),time};
  }
}
