// Native sub/sup layout avoids relying on rare modifier-letter glyphs.
const sub={'ᵢ':'i','ⱼ':'j','ₓ':'x','ᵧ':'y','ₘ':'m','ₐ':'a','ₖ':'k','₀':'0','₁':'1','₂':'2'}, sup={'ᶠ':'f','ᶜ':'c','ᵇ':'b','ᵍ':'g','ᵃ':'a','ᵣ':'r','ʳ':'r','ᵢ':'i','⁰':'0','⁺':'+','²':'2','³':'3'};
export function typesetMath(root=document) {
  const scopes=root.querySelectorAll('.formula,.form-field label,.data-row > span,.vector-table th,.data-table th,.diagram-symbol,.wire-label,.signal-item');
  for(const el of scopes){
    const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT), texts=[];
    while(walker.nextNode()){const n=walker.currentNode;if(!n.parentElement.closest('sub,sup,tspan,.math-glyph')&&/[ᵢⱼₓᵧₘₐₖ₀₁₂ᶠᶜᵇᵍᵃᵣʳ⁰⁺²³]/.test(n.textContent))texts.push(n);}
    for(const n of texts){
      const frag=document.createDocumentFragment(),isSvg=n.parentElement.namespaceURI==='http://www.w3.org/2000/svg';
      let plain='';
      const flush=()=>{if(plain){frag.append(document.createTextNode(plain));plain='';}};
      for(const c of n.textContent){
        const type=sub[c]?'sub':sup[c]?'sup':null;
        if(!type){plain+=c;continue;}
        flush();
        const span=isSvg?document.createElementNS('http://www.w3.org/2000/svg','tspan'):document.createElement(type);
        if(isSvg){span.setAttribute('baseline-shift',type==='sub'?'sub':'super');span.setAttribute('font-size','75%');}
        span.textContent=(sub[c]||sup[c]);frag.append(span);
      }
      flush();n.replaceWith(frag);
    }
  }
}
