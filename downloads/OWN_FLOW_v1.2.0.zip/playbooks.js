import { defaultTactic, validateTactic } from './engine.js';

// A historical observation and its design translation are kept in separate fields.
// The 55 avatars, kits, graphs, controller gains and unmeasured ability values are original.
const text = (en, zh) => ({ en, zh });
const source = (title, url) => ({ title, url });
const sources = {
  barcelona: source('UEFA · 2011 final match analysis', 'https://www.uefa.com/uefachampionsleague/news/025d-0f7f9500b15e-f0e6e7aec729-1000--background-barcelona-vs-united/'),
  messi: source('FC Barcelona · Lionel Messi player record', 'https://www.fcbarcelona.com/en/football/first-team/players/4974/lionel-andres-messi'),
  milan2010: source('UEFA · Barcelona–Inter, 28 April 2010', 'https://www.uefa.com/uefachampionsleague/news/01e4-0e746dee4629-e22f0b2f81cf-1000--barcelona-dethroned-by-resilient-inter/'),
  milito: source('FC Internazionale · Diego Milito, Hall of Fame', 'https://www.inter.it/en/club/hall-of-fame/diego-milito'),
  liverpool: source('UEFA · 2018/19 Champions League technical report, Fitness', 'https://www.uefa.com/MultimediaFiles/Download/Publications/uefaorg/General/02/61/96/22/2619622_DOWNLOAD.pdf'),
  press: source('UEFA Direct 186 · 2018/19 technical review', 'https://editorial.uefa.com/resources/0257-0f842fb20b33-e02faf92f7dd-1000/uefa_direct_186_09.09.2019_.pdf'),
  italy: source('UEFA · EURO 2016 technical report, Italy team profile', 'https://www.uefa.com/MultimediaFiles/Download/TechnicalReport/competitions/EURO/02/40/26/69/2402669_DOWNLOAD.pdf'),
  libero: source('UEFA · Inter 1962–67 tactical history', 'https://www.uefa.com/uefachampionsleague/news/0253-0d7ff54821f7-e2055930d1e0-1000--the-greatest-teams-of-all-time-inter-1962-67/'),
  picchi: source('FC Internazionale · Armando Picchi player archive', 'https://www.inter.it/it/archivio_giocatore/G0503'),
};

export const PLAYBOOKS = [
  {
    id: 'triangles', formation: '4-3-3', teamName: 'Glass Harbor XI',
    title: text('Tiki-taka triangles', '短传控球 · 三角接应'),
    historical: text('Guardiola’s Barcelona won the 2011 European final 3–1. Xavi supplied Pedro’s opener in the 27th minute.', '瓜迪奥拉的巴塞罗那在 2011 年欧冠决赛以 3–1 取胜。第 27 分钟，哈维助攻佩德罗首开纪录。'),
    translation: text('A midfield pivot joins overlapping triangles. Short passing lanes, quick release and a supporting centre-forward keep two nearby options available.', '后腰连接相邻三角形。短传倾向、较快出球和中锋回接，有助于在持球人附近形成多个传球选择。'),
    sources: [sources.barcelona, sources.messi],
    referencePlayers: [{ name: 'Lionel Messi', role: 'ST', slot: 9, heightCm: 170, source: sources.messi,
      fact: text('Barcelona lists its forward at 170 cm. The central attacker uses this stature. His acceleration and technique are scenario settings.', '巴萨球员档案记载其身高为 170 cm。中央前锋采用这一身高，加速度和技术值由实验设定。') }],
  },
  {
    id: 'transition', formation: '4-2-3-1', teamName: 'Copper Ridge XI',
    title: text('Deep block and counter', '深位防守 · 快速反击'),
    historical: text('Mourinho’s Inter protected a 3–1 first-leg advantage against Barcelona in the 2010 semi-final and advanced 3–2 on aggregate after an early dismissal in the return leg.', '穆里尼奥的国际米兰在 2010 年欧冠半决赛首回合以 3–1 领先。次回合早早少打一人，最终以总比分 3–2 晋级。'),
    translation: text('A low reference centre and two holding midfielders keep the block compact. The first outlet favours a visible runner gaining ground through a clear lane.', '降低阵型中心，两个后腰缩短中后场距离。夺球后优先寻找本地视野中能沿空当向前推进的接应者。'),
    sources: [sources.milan2010, sources.milito],
    referencePlayers: [{ name: 'Diego Milito', role: 'ST', slot: 10, source: sources.milito,
      fact: text('Inter records 75 goals in 171 appearances and a brace in the 2010 final. He provides the central finishing role for this scenario.', '国米档案记录米利托出场 171 次、进球 75 个，包括 2010 年欧冠决赛的两球。这里用中锋终结角色体现该参照。') }],
  },
  {
    id: 'press', formation: '4-3-3', teamName: 'North Forge XI',
    title: text('High press and recovery', '高位压迫 · 就地夺回'),
    historical: text('UEFA’s technical review highlights the speed and intensity of Liverpool’s press in the 2018/19 semi-final return against Barcelona.', 'UEFA 技术复盘将利物浦 2018/19 欧冠半决赛次回合对巴萨时的压迫速度与强度列为重要特征。'),
    translation: text('The front line starts higher, two nearby pressers can pursue, and the midfield links both wings. The centre-back has a recovery sprint reserve.', '提高阵型中心，两名临近球员可参与逼抢。中场连接两翼，中卫保有回追所需的速度储备。'),
    sources: [sources.press, sources.liverpool],
    referencePlayers: [{ name: 'Virgil van Dijk', role: 'CB', slot: 2, sprintKmh: 34.5, source: sources.liverpool,
      fact: text('UEFA measured 34.5 km/h away to Barcelona in the 2018/19 semi-final first leg. Divide by 3.6 for the heterogeneous centre-back speed cap of 9.583 m/s.', 'UEFA 记录范戴克在 2018/19 欧冠半决赛首回合客战巴萨时的峰值为 34.5 km/h。除以 3.6 后得到异构中卫的实验速度上限 9.583 m/s。') }],
  },
  {
    id: 'wingbacks', formation: '3-5-2', teamName: 'Estuary Wings XI',
    title: text('Three back, two wing-backs', '三中卫 · 双翼卫'),
    historical: text('Italy’s EURO 2016 profile describes Conte’s 3-5-2 opening into 3-3-4 in attack. Italy attempted 387 passes against Spain with 41% possession.', 'UEFA 记录孔蒂的意大利队在 2016 年欧洲杯以 3-5-2 为基础，进攻时可展开到 3-3-4。对西班牙一战，意大利尝试传球 387 次，控球率为 41%。'),
    translation: text('This 3-5-2 starts wide. Wing-backs belong to flank units, the central defender links the back three and the pass selector rewards available width.', '3-5-2 拉开场地宽度。两名翼卫加入侧翼子系统，居中中卫连接三人后防，传球选择会奖励可利用的边路宽度。'),
    sources: [sources.italy],
    referencePlayers: [{ name: 'Leonardo Bonucci', role: 'CB', slot: 2, source: sources.italy,
      fact: text('The UEFA team profile singles out Bonucci’s distribution from the back. The central defender in the experiment links both sides of the pitch.', 'UEFA 球队档案特别提到博努奇的后场出球。实验中由居中中卫承担连通左右两侧的职责。') }],
  },
  {
    id: 'libero', formation: '5-3-2', teamName: 'Stonegate XI',
    title: text('Catenaccio and a spare defender', '链式防守 · 自由人保护'),
    historical: text('Herrera’s Inter used Armando Picchi behind the markers and gave the left-back room to advance. The club won the European Cup in 1964 and 1965.', '埃雷拉的国际米兰由皮基在盯人后卫身后提供保护，同时给左后卫前插空间。球队在 1964 和 1965 年连续夺得欧洲冠军杯。'),
    translation: text('Our 5-3-2 adaptation places a sweeper eight metres behind the centre-back pair in its unscaled template. A left outlet advances while the defensive spine stays connected.', '原创 5-3-2 模板把自由人放在两名中卫后方 8 米处，再按纵深参数缩放。左侧出口前插，防守中轴保持局部连接。'),
    sources: [sources.libero, sources.picchi],
    referencePlayers: [{ name: 'Armando Picchi', role: 'SW', slot: 3, source: sources.picchi,
      fact: text('Inter’s archive lists the defender with 257 appearances. UEFA identifies his libero role. The covering player starts centrally behind the marking line.', '国米档案记载这位后卫出场 257 次。UEFA 将其描述为自由人，实验中的补位球员从盯防线后方中央启动。') }],
  },
];

// Original laboratory athlete templates. speed is m/s, acceleration m/s², and vision m.
const templates = {
  keeper:     {speed: 6.25, acceleration: 3.55, skill: .72, stamina: .95, vision: 55, heightCm: 192, build: 1.08},
  stopper:    {speed: 7.05, acceleration: 3.90, skill: .75, stamina: .94, vision: 43, heightCm: 188, build: 1.10},
  sweeper:    {speed: 7.45, acceleration: 4.25, skill: .83, stamina: .94, vision: 58, heightCm: 183, build: 1.03},
  fullback:   {speed: 7.90, acceleration: 4.62, skill: .78, stamina: .97, vision: 44, heightCm: 179, build: .98},
  wingback:   {speed: 8.55, acceleration: 4.95, skill: .80, stamina: .99, vision: 48, heightCm: 178, build: .96},
  anchor:     {speed: 7.00, acceleration: 4.05, skill: .87, stamina: .98, vision: 56, heightCm: 186, build: 1.03},
  connector:  {speed: 7.35, acceleration: 4.50, skill: .93, stamina: .96, vision: 58, heightCm: 175, build: .94},
  runner:     {speed: 8.25, acceleration: 5.05, skill: .83, stamina: .99, vision: 44, heightCm: 181, build: 1.00},
  wide:       {speed: 8.70, acceleration: 5.40, skill: .85, stamina: .94, vision: 44, heightCm: 176, build: .94},
  link:       {speed: 8.05, acceleration: 5.32, skill: .95, stamina: .91, vision: 53, heightCm: 174, build: .95},
  finisher:   {speed: 8.15, acceleration: 4.72, skill: .91, stamina: .93, vision: 40, heightCm: 184, build: 1.04},
  target:     {speed: 7.48, acceleration: 4.16, skill: .88, stamina: .92, vision: 45, heightCm: 190, build: 1.11},
};

function unit(name, members, weight, dx, dy = 0) {
  return {name, members, weight, dx, dy};
}

// The connected paths specify undirected local information/formation edges by zero-based slot.
const designs = {
  triangles: {
    colors: ['#4fc8bb', '#ef9370'],
    shape: {width: 1.06, depth: .77, flow: 1.06, press: .78, tempo: .90, centerX: 3, kFormation: .85, kCentroid: .31, kSupport: .76},
    names: ['Arlen','Vale','Darnel','Miro','Tarin','Oris','Senn','Arel','Iven','Leo','Noll'],
    profiles: ['keeper','fullback','stopper','sweeper','fullback','anchor','connector','connector','wide','link','wide'],
    paths: [[0,2,3,0],[1,2,5,1],[3,4,5,3],[5,6,7,5],[1,6,8,1],[4,7,10,4],[6,9,7],[8,9,10]],
    groups: [unit('Pivot triangle',[5,6,7],.48,-.25),unit('Left links',[1,6,8],.29,.5,.35),unit('Right links',[4,7,10],.29,.5,-.35),unit('Forward checks',[9],.55,-1.45)],
  },
  transition: {
    colors: ['#579ace', '#e4a351'],
    shape: {width: .89, depth: .86, flow: .59, press: .36, tempo: .84, centerX: -7, kFormation: .91, kCentroid: .34, kSupport: .99},
    names: ['Eiran','Pavo','Davin','Venn','Orlen','Tevin','Vilo','Kori','Aven','Silvan','Diego'],
    profiles: ['keeper','fullback','stopper','sweeper','fullback','anchor','anchor','runner','connector','wide','finisher'],
    paths: [[0,2,3,0],[1,2,5,1],[3,4,6,3],[5,6,8,5],[1,7,8,9,4],[5,7,10,9,6],[8,10]],
    groups: [unit('Shield',[2,3,5,6],.52,-1.25),unit('Left exit',[5,7],.33,.9,.50),unit('Vertical outlet',[8,9,10],.43,1.75)],
  },
  press: {
    colors: ['#5aabcf', '#e87f79'],
    shape: {width: .97, depth: .82, flow: 1.14, press: .96, tempo: .82, centerX: 7, kFormation: .82, kCentroid: .38, kSupport: 1.11},
    names: ['Arden','Rian','Virgil','Beck','Tovin','Nerin','Soren','Amon','Renn','Olen','Tavi'],
    profiles: ['keeper','wingback','stopper','sweeper','wingback','anchor','runner','connector','wide','runner','wide'],
    paths: [[0,2,3,0],[1,2,5,3,4],[1,6,5,7,4],[6,8,9,10,7],[6,9,7],[5,9]],
    groups: [unit('Front pressure',[8,9,10],.4,1.05),unit('Second line',[5,6,7],.38,.75),unit('Cover pair',[2,3],.38,-.55)],
  },
  wingbacks: {
    colors: ['#7299db', '#d68e70'],
    shape: {width: 1.14, depth: .92, flow: .89, press: .65, tempo: .72, centerX: 0, kFormation: .77, kCentroid: .30, kSupport: .88},
    names: ['Elo','Tallo','Leon','Piero','Arvo','Milo','Galen','Kian','Taro','Sandro','Nivo'],
    profiles: ['keeper','stopper','sweeper','stopper','wingback','runner','anchor','connector','wingback','target','finisher'],
    paths: [[0,2,1,0],[2,3,0],[1,4,5,2],[2,6,5],[2,7,8,3],[6,7],[4,9,10,8],[5,9],[7,10]],
    groups: [unit('Three build',[1,2,3],.31,-.35),unit('Left wing',[4,5],.41,1.16,1.02),unit('Right wing',[7,8],.41,1.16,-1.02),unit('Front pair',[9,10],.31,.6)],
  },
  libero: {
    colors: ['#638abc', '#dc9261'],
    shape: {width: .91, depth: .90, flow: .51, press: .30, tempo: .70, centerX: -6, kFormation: .98, kCentroid: .40, kSupport: .76},
    names: ['Savi','Corvin','Rollo','Armando','Edrin','Aro','Gio','Rivo','Enar','Omar','Vani'],
    profiles: ['keeper','wingback','stopper','sweeper','stopper','fullback','connector','anchor','runner','wide','finisher'],
    paths: [[0,3,2,0],[3,4,0],[1,2,7,3],[4,5,8,7,4],[1,6,7],[6,9,10,8],[7,9]],
    groups: [unit('Free cover',[3],.62,-1.2),unit('Marking line',[2,4,7],.53,-.65),unit('Left release',[1,6],.38,1.05,.6),unit('First outlet',[9,10],.35,.8)],
  },
};

function profileFor(id) {
  const profile = PLAYBOOKS.find(entry => entry.id === id);
  if (!profile) throw new RangeError('Unknown team playbook');
  return profile;
}

const abilityKeys = ['speed', 'acceleration', 'skill', 'stamina', 'vision'];

/** Return fresh athlete records. Homogeneous controls preserve each original column mean. */
export function playbookRoster(id, {homogeneous = false} = {}) {
  const card = profileFor(id);
  const design = designs[id];
  const players = design.profiles.map((profileId, index) => {
    const {heightCm, build, ...abilities} = templates[profileId];
    const reference = card.referencePlayers.find(ref => ref.slot === index);
    if (reference?.sprintKmh !== undefined) abilities.speed = reference.sprintKmh / 3.6;
    return {
      name: design.names[index], ...abilities, override: null,
      appearance: {heightCm: reference?.heightCm ?? heightCm, build, skinTone: (index * 3 + id.length) % 5},
    };
  });
  if (homogeneous) {
    for (const key of abilityKeys) {
      const average = players.reduce((sum, player) => sum + player[key], 0) / players.length;
      for (const player of players) player[key] = average;
    }
  }
  return players;
}

function edgesFromPaths(paths) {
  const edges = new Map();
  for (const path of paths) {
    for (let i = 1; i < path.length; i++) {
      const a = Math.min(path[i - 1], path[i]);
      const b = Math.max(path[i - 1], path[i]);
      edges.set(`${a}:${b}`, [a,b]);
    }
  }
  return [...edges.values()];
}

/** Independent, importable match configuration using the engine's existing physical units. */
export function buildPlaybook(id, team = 0, options = {}) {
  const card = profileFor(id);
  const design = designs[id];
  const edges = edgesFromPaths(design.paths);
  return validateTactic({
    ...defaultTactic(team), ...design.shape,
    id: `flow-${id}-${team}-${options.homogeneous ? 'mean' : 'mixed'}`,
    name: card.title.en, teamName: card.teamName, color: design.colors[team ? 1 : 0],
    formation: card.formation, passStyle: id, abilityMode: 'custom',
    players: playbookRoster(id, options), groups: structuredClone(design.groups),
    tacticalEdges: edges, commEdges: structuredClone(edges),
  });
}
