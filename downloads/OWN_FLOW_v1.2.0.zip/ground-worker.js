import {compareTrials} from './ground-simulation.js';
self.onmessage=({data})=>{
  try {
    const result=compareTrials(data.design,data.tactic,data.comparison,value=>postMessage({type:'progress',value}));
    postMessage({type:'result',result});
  } catch(error) {postMessage({type:'error',message:error.message});}
};
