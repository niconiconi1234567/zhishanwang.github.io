// A connection is stored by its destination socket. Each socket accepts one driver.
export const SIGNAL_TYPES = {
  'F.in': ['R'], 'E.r': ['R', 'F'], 'C.in': ['E'], 'P.in': ['C', 'E'],
  'H.in': ['P'], 'G.in': ['P', 'H'], 'E.fb': ['G'],
};
export const DIRECT_WIRES = {
  'F.in': null, 'E.r': 'R', 'C.in': 'E', 'P.in': 'C',
  'H.in': null, 'G.in': 'P', 'E.fb': 'G',
};
export const DEFAULT_LAYOUT = {
  R:[20,52], F:[162,194], E:[337,52], C:[505,52],
  P:[688,52], H:[688,226], G:[388,226],
};
export const SCENARIOS = {
  zero: {title:['Return to zero','归零共识'], target:0, pins:'all', network:'mesh'},
  setpoint: {title:['Shared setpoint','指定值共识'], target:6, pins:'all', network:'mesh'},
  average: {title:['Average consensus','平均共识'], target:0, pins:'none', network:'ring'},
  islands: {title:['Two islands','断网分群'], target:0, pins:'none', network:'split'},
  unstable: {title:['Positive feedback','正反馈发散'], target:0, pins:'all', network:'mesh'},
  moving: {title:['Moving reference','移动参考跟踪'], target:3, pins:'all', network:'mesh'},
};
const keys = Object.keys;
export function link(wires, source, socket) {
  if (!Object.hasOwn(SIGNAL_TYPES,socket) || !SIGNAL_TYPES[socket].includes(source)) {
    throw Error('invalid_wire');
  }
  return {...wires,[socket]:source};
}
export function validateWires(wires) {
  if (!wires || typeof wires !== 'object') throw Error('invalid_wire');
  const result = {};
  for (const [socket,types] of Object.entries(SIGNAL_TYPES)) {
    const source=wires[socket] ?? null;
    if (source !== null && !types.includes(source)) throw Error('invalid_wire');
    result[socket]=source;
  }
  return result;
}
export function validateLayout(value = DEFAULT_LAYOUT) {
  const result = {};
  for (const key of keys(DEFAULT_LAYOUT)) {
    const point=value[key];
    if (!Array.isArray(point) || point.length!==2 || !point.every(Number.isFinite)) throw Error('invalid_layout');
    result[key]=[Math.max(5, Math.min(760,point[0])),Math.max(8,Math.min(274,point[1]))];
  }
  return result;
}
export function compileWires(design) {
  const w=design.wires, missing=[];
  if (!w['E.r']) missing.push('E.r');
  if (w['E.r']==='F' && !w['F.in']) missing.push('F.in');
  if (!w['P.in']) missing.push('P.in');
  if (w['P.in']==='C' && !w['C.in']) missing.push('C.in');
  const useMeasurement=w['G.in']==='H';
  if (w['E.fb'] && !w['G.in']) missing.push('G.in');
  if (useMeasurement && !w['H.in']) missing.push('H.in');
  const config = {...design.control,
    sign:w['E.fb'] ? design.polarity : 0,
    refTau:w['E.r']==='F' ? design.refTime : 0,
    sensorTau:useMeasurement ? design.sensorTime : 0,
  };
  if (w['P.in']==='E') {config.type='p';config.kp=1;}
  return {valid:missing.length===0,missing,config};
}
export function wireTemplate(name) {
  const wires={...DIRECT_WIRES};
  if (name==='filtered') Object.assign(wires,{'F.in':'R','E.r':'F','H.in':'P','G.in':'H'});
  if (name==='open') wires['E.fb']=null;
  if (name==='bypass') wires['P.in']='E';
  return wires;
}
