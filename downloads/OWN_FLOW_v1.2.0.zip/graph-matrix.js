// Eigenvalues of a real symmetric matrix. Jacobi rotations are sufficient for 11 agents.
export function symmetricEigenvalues(matrix) {
  const n=matrix.length;
  const a=matrix.map(row=>[...row]);
  for (let pass=0;pass<80*n*n;pass++) {
    let largest=0,p=0,q=0;
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
      if(Math.abs(a[i][j])>largest){largest=Math.abs(a[i][j]);p=i;q=j;}
    }
    if(largest<1e-12)break;
    const angle=.5*Math.atan2(2*a[p][q],a[q][q]-a[p][p]);
    const c=Math.cos(angle),s=Math.sin(angle);
    const pp=a[p][p],qq=a[q][q],pq=a[p][q];
    for(let k=0;k<n;k++){
      if(k===p||k===q)continue;
      const kp=a[k][p],kq=a[k][q];
      a[p][k]=a[k][p]=c*kp-s*kq;
      a[q][k]=a[k][q]=s*kp+c*kq;
    }
    a[p][p]=c*c*pp-2*s*c*pq+s*s*qq;
    a[q][q]=s*s*pp+2*s*c*pq+c*c*qq;
    a[p][q]=a[q][p]=0;
  }
  return a.map((row,i)=>row[i]).sort((x,y)=>x-y);
}
