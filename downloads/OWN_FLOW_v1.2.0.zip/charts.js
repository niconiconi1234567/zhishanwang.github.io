const f=(v,n=1)=>Number.isFinite(v)?v.toFixed(n):'—';
// A chart uses real physical timestamps, never the array index as elapsed time.
export function plotChart(canvas,series,{lang='en',unit='',title='',spark=false}={}){
 const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(2,devicePixelRatio||1);if(!w||!h)return;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
 const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
 const pts=series.flatMap(s=>s.points).filter(p=>Number.isFinite(p.y)&&Number.isFinite(p.x));
 canvas.setAttribute('role','img');canvas.setAttribute('aria-label',title+' · '+unit);
 if(pts.length<2){c.fillStyle='#a7bcc9';c.font='12px system-ui';if(!spark)c.fillText(lang==='zh'?'等待至少两个采样点…':'Waiting for two samples…',16,h/2);return;}
 const left=spark?1:49,right=w-(spark?2:16),top=spark?3:24,bottom=h-(spark?3:36),minX=Math.min(...pts.map(p=>p.x)),maxX=Math.max(minX+.5,...pts.map(p=>p.x)),minY=Math.min(0,...pts.map(p=>p.y)),maxY=Math.max(.1,...pts.map(p=>p.y))*1.12;
 const X=v=>left+(v-minX)/(maxX-minX)*(right-left),Y=v=>bottom-(v-minY)/(maxY-minY)*(bottom-top);
 c.font='11px system-ui';c.lineWidth=1;
 if(!spark){
  for(let i=0;i<=4;i++){const value=minY+(maxY-minY)*i/4,y=Y(value);c.strokeStyle='#30465488';c.setLineDash([3,5]);c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke();c.fillStyle='#a5b9c6';c.textAlign='right';c.fillText(f(value,maxY>30?0:1),left-8,y+4);}
  c.setLineDash([]);c.textAlign='center';for(let i=0;i<=4;i++){const t=minX+(maxX-minX)*i/4;c.fillStyle='#91a6b6';c.fillText(f(t,maxX-minX>8?0:1),X(t),bottom+19);}
  c.fillStyle='#a8bfcd';c.textAlign='left';c.fillText(unit,left,14);c.textAlign='right';c.fillText(lang==='zh'?'物理时间 / s':'Physical time / s',right,h-2);
 }
 series.forEach((s,j)=>{
  const valid=s.points.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y));if(!valid.length)return;
  if(!spark&&j===0){const grad=c.createLinearGradient(0,top,0,bottom);grad.addColorStop(0,s.color+'28');grad.addColorStop(1,s.color+'00');c.beginPath();c.moveTo(X(valid[0].x),bottom);valid.forEach(p=>c.lineTo(X(p.x),Y(p.y)));c.lineTo(X(valid.at(-1).x),bottom);c.closePath();c.fillStyle=grad;c.fill();}
  c.beginPath();c.strokeStyle=s.color;c.lineWidth=spark?1.7:2.2;valid.forEach((p,i)=>i?c.lineTo(X(p.x),Y(p.y)):c.moveTo(X(p.x),Y(p.y)));c.stroke();
  if(!spark){const last=valid.at(-1);c.fillStyle=s.color;c.beginPath();c.arc(X(last.x),Y(last.y),3,0,Math.PI*2);c.fill();}
 });
 if(spark)return;
 canvas._plot={series,minX,maxX,left,right,unit,lang};
 if(!canvas._hoverBound){canvas._hoverBound=true;canvas.addEventListener('pointermove',e=>{
  const p=canvas._plot;if(!p)return;const rect=canvas.getBoundingClientRect(),x=e.clientX-rect.left,t=p.minX+Math.max(0,Math.min(1,(x-p.left)/(p.right-p.left)))*(p.maxX-p.minX);
  let tooltip=canvas.parentElement.querySelector('.chart-tooltip');if(!tooltip){tooltip=document.createElement('div');tooltip.className='chart-tooltip';canvas.parentElement.append(tooltip);}
  const selected=p.series.filter(s=>s.points.length).map(s=>({s,p:s.points.reduce((a,b)=>Math.abs(a.x-t)<Math.abs(b.x-t)?a:b)}));
  tooltip.textContent=`t = ${f(selected[0].p.x,2)} s · `+selected.map(({s,p:q})=>`${s.name}: ${f(q.y,3)} ${p.unit}`).join('  |  ');tooltip.style.display='block';
 });canvas.addEventListener('pointerleave',()=>{const t=canvas.parentElement.querySelector('.chart-tooltip');if(t)t.style.display='none';});}
}
