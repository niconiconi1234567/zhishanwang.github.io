import { validateTactic, supportedEngine } from "./engine.js";
const numeric = (x, keys) => keys.every((k) => Number.isFinite(x?.[k]));
const vector = (x) => numeric(x, ["x", "y"]);
const array = (x, max, fn) =>
  Array.isArray(x) && x.length <= max && x.every(fn);
const action = ["idle", "run", "sprint", "pass", "shoot", "save", "tackle"];
const phases = ["kickoff", "live", "goal", "restart", "halftime", "finished"];
const events = [
  "kickoff",
  "pass",
  "shot",
  "tackle",
  "save",
  "goal",
  "throwIn",
  "corner",
  "goalKick",
  "offside",
  "halftime",
  "fulltime",
];
function fail() {
  throw Error("checkpoint_state");
}
function metrics(v) {
  return (
    Array.isArray(v) &&
    v.length === 2 &&
    v.every(
      (m) =>
        numeric(m, [
          "shape",
          "estimation",
          "disagreement",
          "effort",
          "saturation",
        ]) &&
        vector(m.centroid) &&
        vector(m.reference),
    )
  );
}
export function validateReplay(value) {
  if (
    !value ||
    value.kind !== "ReplayRecord" ||
    value.schema !== 1 ||
    !supportedEngine(value.engine) ||
    !Array.isArray(value.frames) ||
    !value.frames.length ||
    value.frames.length > 360 ||
    !Array.isArray(value.tactics) ||
    value.tactics.length !== 2
  )
    throw Error("checkpoint_schema");
  const r = structuredClone(value);
  r.tactics = r.tactics.map(validateTactic);
  if (
    !Number.isInteger(r.seed) ||
    !array(
      r.events,
      200,
      (e) =>
        numeric(e, ["time", "clock", "id", "team", "player"]) &&
        events.includes(e.type) &&
        Number.isInteger(e.player) &&
        e.player >= -1 &&
        e.player < 22 &&
        [-1, 0, 1].includes(e.team),
    )
  )
    fail();
  let previous = -1;
  for (const f of r.frames) {
    if (
      !numeric(f, [
        "time",
        "clock",
        "tick",
        "minutes",
        "clockRate",
        "queued",
      ]) ||
      f.time <= previous ||
      f.time < 0 ||
      !Number.isInteger(f.tick) ||
      ![1, 2].includes(f.half) ||
      !phases.includes(f.phase) ||
      !Array.isArray(f.score) ||
      f.score.length !== 2 ||
      !f.score.every((x) => Number.isInteger(x) && x >= 0) ||
      !metrics(f.metrics) ||
      !numeric(f.ball, ["x", "y", "z", "vx", "vy", "vz", "spin", "owner"]) ||
      !Array.isArray(f.stats) ||
      f.stats.length !== 2 ||
      !f.stats.every((v) =>
        numeric(v, [
          "possession",
          "passes",
          "completed",
          "shots",
          "saves",
          "received",
          "sent",
          "samples",
          "effort",
          "prediction",
          "predictionN",
        ]),
      )
    )
      fail();
    previous = f.time;
    if (!Array.isArray(f.tactics) || f.tactics.length !== 2) fail();
    f.tactics = f.tactics.map(validateTactic);
    if (!Array.isArray(f.players) || f.players.length !== 22) fail();
    for (let [i, p] of f.players.entries()) {
      if (
        p.id !== i ||
        p.team !== Math.floor(i / 11) ||
        p.index !== i % 11 ||
        typeof p.name !== "string" ||
        p.name.length > 32 ||
        !numeric(p, [
          "x",
          "y",
          "vx",
          "vy",
          "heading",
          "stamina",
          "vision",
          "speed",
          "acc",
          "skill",
        ]) ||
        !action.includes(p.action) ||
        !["estimate", "target", "reference", "command", "raw"].every((k) =>
          vector(p[k]),
        ) ||
        !p.parts ||
        !Object.values(p.parts).every(vector) ||
        !array(
          p.visible,
          22,
          (q) =>
            Number.isInteger(q.id) &&
            q.id >= 0 &&
            q.id < 22 &&
            q.team === Math.floor(q.id / 11),
        ) ||
        !array(p.prediction, 30, (q) => numeric(q, ["x", "y", "t"])) ||
        !array(p.trail, 30, vector) ||
        typeof p.saturated !== "boolean" ||
        !p.belief ||
        !["unknown", "left", "right", "central"].includes(p.belief.mode) ||
        !numeric(p.belief, ["evidence", "meanY"])
      )
        fail();
      if (
        p.knownBall &&
        (!numeric(p.knownBall, [
          "x",
          "y",
          "vx",
          "vy",
          "time",
          "source",
          "owner",
        ]) ||
          !["vision", "message"].includes(p.knownBall.via))
      )
        fail();
    }
  }
  return r;
}
