// Public numerical contract for the sampled multi-agent training pitch.
import { predictiveMove } from "./control-mpc.js";
import { inspectRealization, inspectModes } from "./control-linear.js";

export const CONTROL_DEFAULTS = Object.freeze({
  type: "p", dt: 0.1, a: 0, b: 1, kp: 1.2, ki: 0.35, kd: 0.12,
  derivativeTau: 0.18, wc: 1.5, wo: 6, b0: 1,
  horizon: 10, q: 1, r: 0.16, limit: 8, refTau: 0, sensorTau: 0, sign: -1
});

const ranges = {
  dt: [0.01, 0.25], a: [-3, 3], b: [-5, 5], kp: [-30, 30], ki: [0, 20],
  kd: [0, 10], derivativeTau: [0, 5], wc: [0.01, 30], wo: [0.01, 80],
  b0: [-5, 5], horizon: [1, 24], q: [0.001, 50], r: [0.005, 50],
  limit: [0.01, 1000], refTau: [0, 10], sensorTau: [0, 10], sign: [-1, 1]
};
const validated = new WeakSet();

export function normalizeControl(values = {}) {
  if (validated.has(values)) return values;
  if (!values || typeof values !== "object" || Array.isArray(values)) {
    throw new TypeError("Invalid control configuration");
  }
  const config = {};
  config.type = String(values.type ?? CONTROL_DEFAULTS.type).toLowerCase();
  if (!["p", "pid", "adrc", "mpc"].includes(config.type)) throw new RangeError("Invalid controller type");
  for (const [key, [minimum, maximum]] of Object.entries(ranges)) {
    const value = values[key] === undefined ? CONTROL_DEFAULTS[key] : values[key];
    if (!Number.isFinite(value) || value < minimum || value > maximum) {
      throw new RangeError("Invalid controller parameter: " + key);
    }
    config[key] = value;
  }
  if (!Number.isInteger(config.horizon) || !Number.isInteger(config.sign) || Math.abs(config.b0) < 0.01) {
    throw new RangeError("Invalid horizon, feedback sign or observer gain");
  }
  if (config.type === "mpc" && config.a * config.dt * config.horizon > 6) {
    throw new RangeError("Shorten the MPC horizon for this unstable model");
  }
  Object.freeze(config);
  validated.add(config);
  return config;
}

export function zohPlant(a, b, dt = 0.1) {
  const A = Math.exp(a * dt);
  const B = a === 0 ? b * dt : b * Math.expm1(a * dt) / a;
  return { A, B };
}

export function sampleFilter(previous, input, tau, dt = 0.1) {
  return tau <= 0 ? input : previous - Math.expm1(-dt / tau) * (input - previous);
}

export function newControlMemory(measurement = 0) {
  if (!Number.isFinite(measurement)) throw new RangeError("Invalid initial observation");
  return { integral: 0, derivativeState: 0, predictedY: measurement, estimatedDisturbance: 0 };
}

export function isControlMemory(value) {
  return value != null && [value.integral, value.derivativeState, value.predictedY,
    value.estimatedDisturbance].every(Number.isFinite);
}

function applyLimit(raw, limit, linear) {
  if (!Number.isFinite(raw)) throw new RangeError("Controller output exceeds numerical range");
  const u = linear ? raw : Math.max(-limit, Math.min(limit, raw));
  const saturated = !linear && Math.abs(raw) >= limit;
  return { u, raw, saturated, constrained: saturated, converged: true };
}

export function stepControl(values, memory, signals, options = {}) {
  const config = normalizeControl(values);
  if (!isControlMemory(memory)) throw new RangeError("Invalid private controller state");
  const { measurement, error } = signals;
  const reference = signals.virtualReference ?? measurement + error;
  if (![measurement, error, reference].every(Number.isFinite)) {
    throw new RangeError("Invalid controller signal");
  }
  const linear = options.linear === true;
  if (config.type === "p") return applyLimit(config.kp * error, config.limit, linear);
  if (config.type === "pid") {
    // Forward-Euler integral, backward-Euler filtered derivative on the error.
    let derivative = 0;
    if (config.kd > 0) {
      derivative = (error - memory.derivativeState) / (config.dt + config.derivativeTau);
      memory.derivativeState += config.dt * derivative;
    }
    const raw = config.kp * error + config.ki * memory.integral + config.kd * derivative;
    const result = applyLimit(raw, config.limit, linear);
    if (config.ki > 0 && (!result.saturated || error * Math.sign(raw) < 0)) {
      memory.integral += config.dt * error;
    }
    return result;
  }
  if (config.type === "adrc") {
    // Current observer: correct the existing prediction using this sample.
    // The two error poles of the nominal ESO are both exp(-wo*dt).
    const pole = Math.exp(-config.wo * config.dt);
    const innovation = measurement - memory.predictedY;
    const observedY = memory.predictedY + (1 - pole * pole) * innovation;
    const disturbance = memory.estimatedDisturbance + ((1 - pole) ** 2 / config.dt) * innovation;
    const raw = (config.wc * (reference - observedY) - disturbance) / config.b0;
    const result = applyLimit(raw, config.limit, linear);
    memory.predictedY = observedY + config.dt * (disturbance + config.b0 * result.u);
    memory.estimatedDisturbance = disturbance;
    return result;
  }
  const { A, B } = zohPlant(config.a, config.b, config.dt);
  return predictiveMove(config, A, B, measurement, reference, linear);
}

function modalRealization(config, lambda, inputGain) {
  if (!Number.isFinite(lambda) || lambda < -1e-9 || !Number.isFinite(inputGain)) {
    throw new RangeError("Invalid graph mode");
  }
  const names = ["x"];
  if (config.refTau > 0) names.push("filteredReference");
  if (config.sensorTau > 0) names.push("filteredMeasurement");
  if (config.type === "pid" && config.ki > 0) names.push("integral");
  if (config.type === "pid" && config.kd > 0) names.push("derivativeState");
  if (config.type === "adrc") names.push("predictedY", "estimatedDisturbance");
  const plant = zohPlant(config.a, config.b, config.dt);

  // Evaluate the identical unsaturated update on each state/input basis vector.
  function advance(state, r) {
    const memory = newControlMemory();
    names.forEach((name, index) => { memory[name] = state[index]; });
    memory.filteredReference = sampleFilter(memory.filteredReference ?? 0, r, config.refTau, config.dt);
    memory.filteredMeasurement = sampleFilter(memory.filteredMeasurement ?? 0, memory.x, config.sensorTau, config.dt);
    const error = inputGain * memory.filteredReference + config.sign * lambda * memory.filteredMeasurement;
    const { u } = stepControl(config, memory, { measurement: memory.filteredMeasurement, error }, { linear: true });
    memory.x = plant.A * memory.x + plant.B * u;
    return names.map(name => memory[name]);
  }
  const zero = names.map(() => 0);
  const columns = names.map((_, j) => advance(zero.map((__, k) => Number(j === k)), 0));
  const A = names.map((_, i) => columns.map(column => column[i]));
  const B = advance(zero, 1), C = zero.map((_, i) => Number(i === 0));
  return { A, B, C, D: 0, stateNames: names };
}

export function analyzeLoop(values, { lambda = 1, inputGain = 1 } = {}) {
  const config = normalizeControl(values);
  const model = modalRealization(config, lambda, inputGain);
  const analysis = inspectRealization(model);
  return { ...model, ...analysis, lambda, inputGain, dt: config.dt,
    scope: "homogeneous-unsaturated", transferDefined: analysis.numericallyReliable };
}

export function analyzeNetwork(values, eigenvalues) {
  if (!Array.isArray(eigenvalues) || eigenvalues.length === 0) throw new RangeError("Empty graph spectrum");
  const config = normalizeControl(values);
  // A common external command filter contributes one autonomous pole. The
  // independent graph modes below contain the local plant, sensor and controller.
  const core = normalizeControl({ ...config, refTau: 0 });
  const modes = eigenvalues.map(lambda => {
    const model = modalRealization(core, lambda, 0);
    return { lambda, ...inspectModes(model.A) };
  });
  const referencePole = config.refTau > 0 ? Math.exp(-config.dt / config.refTau) : null;
  const radius = Math.max(referencePole ?? 0, ...modes.map(mode => mode.radius));
  const stability = modes.some(mode => mode.stability === "unresolved") ? "unresolved"
    : radius > 1 + 2e-6 ? "unstable" : radius < 1 - 2e-6 ? "stable" : "boundary";
  return { modes, radius, stability, referencePole, scope: "homogeneous-unsaturated" };
}
