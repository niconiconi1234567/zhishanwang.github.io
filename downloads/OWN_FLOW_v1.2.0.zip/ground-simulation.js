import {FORMATIONS, graphEdges, resolveSquad} from './engine.js';
import {CONTROL_DEFAULTS,normalizeControl,zohPlant,newControlMemory,sampleFilter,stepControl} from './control-kernel.js';
import {SCENARIOS,DIRECT_WIRES,DEFAULT_LAYOUT,validateWires,validateLayout,compileWires} from './ground-design.js';
import {symmetricEigenvalues} from './graph-matrix.js';

export const TRIAL_SECONDS = 30;
const count = 11;
const avg = values => values.reduce((total,value)=>total+value,0)/values.length;
const rms = values => Math.sqrt(avg(values.map(value=>value*value)));
export function topology(name) {
  if (name==='none') return [];
  if (name==='split') return [[0,1],[1,2],[2,3],[3,4],[4,5],[5,0],[6,7],[7,8],[8,9],[9,10],[10,6]];
  return graphEdges(name);
}
export function scenarioDesign(scenario='zero') {
  const spec=SCENARIOS[scenario];
  return {
    kind:'FlowGroundDesign',schema:1,scenario,control:{...CONTROL_DEFAULTS,type:'p',dt:.1,a:0,b:1,limit:scenario==='average'?16:8},
    target:spec.target,pins:spec.pins,network:spec.network,edges:topology(spec.network),
    coupling:.50,heterogeneity:0,disturbance:0,seed:361,polarity:scenario==='unstable'?1:-1,
    refTime:.6,sensorTime:.25,wires:{...DIRECT_WIRES},layout:structuredClone(DEFAULT_LAYOUT),
  };
}
export function validateDesign(input) {
  if (input?.kind!=='FlowGroundDesign' || input.schema!==1 || !Object.hasOwn(SCENARIOS,input.scenario)) throw Error('design_format');
  const design=scenarioDesign(input.scenario);
  for (const [key,low,high] of [['target',-12,12],['coupling',0,2],['heterogeneity',0,1],['disturbance',0,4],['refTime',.05,3],['sensorTime',.05,3],['seed',1,2147483647]]) {
    const value=input[key];
    if (!Number.isFinite(value) || value<low || value>high) throw Error('design_parameter');
    design[key]=value;
  }
  if (!Number.isInteger(design.seed) || ![-1,1].includes(input.polarity) || !['all','leader','none'].includes(input.pins)) throw Error('design_parameter');
  if (!['mesh','ring','star','full','split','none','custom','team'].includes(input.network)) throw Error('design_graph');
  if (!Array.isArray(input.edges) || input.edges.length>55) throw Error('design_graph');
  const seen=new Set();
  design.edges=input.edges.map(pair=>{
    if (!Array.isArray(pair) || pair.length!==2 || !pair.every(i=>Number.isInteger(i)&&i>=0&&i<count) || pair[0]===pair[1]) throw Error('design_graph');
    const key=[...pair].sort((a,b)=>a-b).join(':');
    if (seen.has(key)) throw Error('design_graph');
    seen.add(key);
    return [...pair];
  });
  if (input.control?.dt!==.1) throw Error('design_clock');
  design.control={...normalizeControl(input.control)};
  return {...design,polarity:input.polarity,pins:input.pins,network:input.network,
    wires:validateWires(input.wires),layout:validateLayout(input.layout)};
}
export function pinWeights(design) {
  return Array.from({length:count},(_,i)=>Number(design.pins==='all'||(design.pins==='leader'&&i===0)));
}
export function modalGains(design) {
  const pins=pinWeights(design);
  const matrix=pins.map((v,i)=>pins.map((_,j)=>i===j?v:0));
  for(const [i,j] of design.edges) {
    matrix[i][i]+=design.coupling;
    matrix[j][j]+=design.coupling;
    matrix[i][j]-=design.coupling;
    matrix[j][i]-=design.coupling;
  }
  return symmetricEigenvalues(matrix).map(x=>Math.max(0,x));
}
function randomInitial(seed) {
  let value=seed>>>0;
  return Array.from({length:count},(_,index)=>{
    value=(Math.imul(1664525,value)+1013904223)>>>0;
    return (index<6?-4.2:5.6)+3.8*(value/4294967296-.5);
  });
}
export function referenceAt(design,time,initialMean) {
  if (design.pins==='none') return initialMean;
  if (design.scenario==='moving') return design.target+3*Math.sin(.45*time);
  return design.target;
}
function feedbackComponents(design,sign) {
  const neighbours=Array.from({length:count},()=>[]);
  if(sign!==0 && design.coupling>0) {
    for(const [i,j] of design.edges){neighbours[i].push(j);neighbours[j].push(i);}
  }
  const visited=new Set(),groups=[];
  for(let i=0;i<count;i++) {
    if(visited.has(i))continue;
    const group=[i];visited.add(i);
    for(const node of group){
      for(const other of neighbours[node])if(!visited.has(other)){visited.add(other);group.push(other);}
    }
    groups.push(group.sort((a,b)=>a-b));
  }
  return groups;
}
export class GroundSimulation {
  constructor(design,tactic) {
    this.design=validateDesign(design);
    const compiled=compileWires(this.design);
    if (!compiled.valid) throw Error('incomplete_wires');
    this.control=normalizeControl(compiled.config);
    this.tactic=structuredClone(tactic);
    this.roster=resolveSquad(tactic);
    const meanAcceleration=avg(this.roster.map(p=>p.acceleration));
    const meanSpeed=avg(this.roster.map(p=>p.speed));
    const strength=design.heterogeneity;
    this.plants=this.roster.map(p=>zohPlant(this.control.a,this.control.b*(1+strength*(p.acceleration/meanAcceleration-1)),this.control.dt));
    this.controllers=this.roster.map(p=>normalizeControl({...this.control,limit:Math.min(1000,Math.max(.01,this.control.limit*(1+strength*(p.speed/meanSpeed-1))))}));
    this.x=randomInitial(design.seed);
    this.initialMean=avg(this.x);
    this.pins=pinWeights(design);
    this.components=feedbackComponents(design,this.control.sign);
    this.sensed=[...this.x];
    this.referenceFilter=0;
    this.memory=this.x.map(y=>newControlMemory(y));
    this.frames=[];
    this.elapsedTicks=0;
    this.inputCost=0;
    this.errorIntegral=0;
    this.limitedCount=0;
    this.peak=0;
    this.stopReason=null;
    this.record(Array(count).fill(0),0);
  }
  get time(){return this.elapsedTicks*this.control.dt;}
  record(input,limited) {
    const mean=avg(this.x), ref=referenceAt(this.design,this.time,this.initialMean);
    const tracking=rms(this.x.map(x=>x-ref));
    const disagreement=rms(this.x.map(x=>x-mean));
    this.peak=Math.max(this.peak,...this.x.map(Math.abs));
    this.frames.push({time:this.time,x:[...this.x],u:input,ref,mean,tracking,disagreement,limited});
  }
  step() {
    if (this.stopReason) return;
    const d=this.design,c=this.control,dt=c.dt;
    const ref=referenceAt(d,this.time,this.initialMean);
    this.referenceFilter=sampleFilter(this.referenceFilter,ref,c.refTau,dt);
    this.sensed=this.x.map((x,i)=>sampleFilter(this.sensed[i],x,c.sensorTau,dt));
    // All agents read the same sampling instant; no sequential update leaks a future state.
    const feedback=this.sensed.map((y,i)=>this.pins[i]*y);
    for(const [i,j] of d.edges) {
      const difference=d.coupling*(this.sensed[i]-this.sensed[j]);
      feedback[i]+=difference;
      feedback[j]-=difference;
    }
    let limited=0;
    const input=this.x.map((_,i)=>{
      const measurement=this.sensed[i];
      const error=this.pins[i]*this.referenceFilter+c.sign*feedback[i];
      const result=stepControl(this.controllers[i],this.memory[i],{measurement,error,virtualReference:measurement+error});
      if (result.saturated) limited++;
      return result.u;
    });
    const disturbance=this.time>=5 && this.time<12 ? d.disturbance : 0;
    this.x=this.x.map((x,i)=>this.plants[i].A*x+this.plants[i].B*(input[i]+disturbance));
    this.elapsedTicks++;
    this.inputCost+=avg(input.map(u=>u*u))*dt;
    this.limitedCount+=limited;
    this.record(input,limited);
    this.errorIntegral+=this.frames.at(-1).tracking**2*dt;
    if (this.x.some(x=>Math.abs(x)>=80)) this.stopReason='range';
    else if (this.elapsedTicks>=Math.round(TRIAL_SECONDS/dt)) this.stopReason='complete';
  }
  finish(){while(!this.stopReason)this.step();return this;}
  summary() {
    const last=this.frames.at(-1);
    let settling=null;
    if(this.stopReason==='complete') {
      const outside=this.frames.findLastIndex(f=>f.x.some(x=>Math.abs(x-f.ref)>.2));
      const entered=this.frames[outside+1]?.time;
      if(entered!==undefined && this.time-entered>=2)settling=entered;
    }
    return {time:this.time,tracking:last.tracking,disagreement:last.disagreement,
      runRmse:this.time?Math.sqrt(this.errorIntegral/this.time):last.tracking,
      effort:this.time?this.inputCost/this.time:0,peak:this.peak,settling,
      saturation:this.elapsedTicks?this.limitedCount/(count*this.elapsedTicks):0,reason:this.stopReason};
  }
  position(index,x,time) {
    const [baseX,baseY]=FORMATIONS[this.tactic.formation][index];
    return {x:.64*baseX+.7*(time-15),y:.58*baseY+x};
  }
  snapshot(running=false) {
    const last=this.frames.at(-1), previous=this.frames.at(-2)||last;
    const history=this.frames.filter((frame,i)=>frame.time>=last.time-12 && (i%3===0||frame===last));
    const points=this.x.map((x,i)=>this.position(i,x,last.time));
    const paths=points.map((p,i)=>({
      id:i,origin:this.position(i,this.frames[0].x[i],0),target:this.position(i,last.ref,last.time),actualPoint:p,
      reference:history.map(f=>this.position(i,f.ref,f.time)),
      actual:history.map(f=>this.position(i,f.x[i],f.time)),
    }));
    return {time:last.time,running:running&&!this.stopReason,tactics:[this.tactic,this.tactic],
      training:{team:0,paths},players:points.map((p,i)=>{
        const vy=(last.x[i]-previous.x[i])/this.control.dt;
        return {...p,id:i,index:i,team:0,name:this.roster[i].name,vx:this.time>0 ? .7 : 0,vy,
          heading:Math.atan2(vy,.7),target:paths[i].target,action:'run',visible:[]};
      })};
  }
}
export function compareTrials(design,tactic,comparison='controllers',progress=()=>{}) {
  const d=validateDesign(design);
  const variants=comparison==='abilities'?['homogeneous','roster']:['p','pid','adrc','mpc'];
  const seeds=[d.seed,1+(d.seed+96)%2147483647,1+(d.seed+210)%2147483647];
  if(compileWires(d).config.type==='p' && d.wires['P.in']==='E' && comparison==='controllers')throw Error('controller_bypassed');
  const rows=variants.map((name,index)=>{
    const variant=structuredClone(d);
    if(comparison==='abilities')variant.heterogeneity=name==='roster'?1:0;
    else variant.control.type=name;
    let firstTrajectory;
    const runs=seeds.map((seed,n)=>{
      const trial=new GroundSimulation({...variant,seed},tactic).finish();
      if(!n)firstTrajectory=trial.frames.map(f=>({t:f.time,x:f.x,ref:f.ref}));
      progress((index*seeds.length+n+1)/(variants.length*seeds.length));
      return {seed,...trial.summary()};
    });
    const summary={};
    for(const key of ['time','runRmse','tracking','disagreement','effort','saturation'])summary[key]=avg(runs.map(r=>r[key]));
    return {name,runs,summary,firstTrajectory,completed:runs.filter(r=>r.reason==='complete').length};
  });
  return {kind:'FlowGroundComparison',schema:1,comparison,seeds,design:d,squad:structuredClone(tactic),rows};
}
