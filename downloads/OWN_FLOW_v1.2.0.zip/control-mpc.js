// Box-constrained finite-horizon scalar MPC. The live graph and its linear
// analysis share the prediction model and the unconstrained optimum.
const modelCache = new Map();
const dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);

function cholesky(matrix) {
  const n = matrix.length;
  const factor = Array.from({ length: n }, () => Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = 0; j <= i; j++) {
      let value = matrix[i][j];
      for (let k = 0; k < j; k++) value -= factor[i][k] * factor[j][k];
      if (i === j) {
        if (!(value > 0)) throw new RangeError("MPC Hessian is not positive definite");
        factor[i][j] = Math.sqrt(value);
      } else {
        factor[i][j] = value / factor[j][j];
      }
    }
  }
  return factor;
}

function solvePositive(factor, rhs) {
  const result = rhs.slice();
  for (let i = 0; i < result.length; i++) {
    for (let j = 0; j < i; j++) result[i] -= factor[i][j] * result[j];
    result[i] /= factor[i][i];
  }
  for (let i = result.length - 1; i >= 0; i--) {
    for (let j = i + 1; j < result.length; j++) result[i] -= factor[j][i] * result[j];
    result[i] /= factor[i][i];
  }
  return result;
}

function buildModel(A, B, horizon, q, r) {
  const key = [A, B, horizon, q, r].join("/");
  if (modelCache.has(key)) return modelCache.get(key);
  const horizonIndices = Array.from({ length: horizon }, (_, i) => i);
  const freeResponse = horizonIndices.map(i => A ** (i + 1));
  const columns = horizonIndices.map(j => horizonIndices.map(i =>
    i < j ? 0 : B * A ** (i - j)
  ));
  // Cost/2 = U'HU/2 + gradient' U + constant. R > 0 makes H SPD.
  const hessian = columns.map((column, i) =>
    columns.map((other, j) => q * dot(column, other) + (i === j ? r : 0))
  );
  const factor = cholesky(hessian);
  const gradMeasured = columns.map(column => q * dot(column, freeResponse));
  const gradReference = columns.map(column => -q * column.reduce((a, b) => a + b, 0));
  const model = {
    hessian, gradMeasured, gradReference,
    gainMeasured: solvePositive(factor, gradMeasured.map(value => -value)),
    gainReference: solvePositive(factor, gradReference.map(value => -value))
  };
  if (modelCache.size >= 32) modelCache.delete(modelCache.keys().next().value);
  modelCache.set(key, model);
  return model;
}

function solveBox(hessian, gradient, unconstrained, bound) {
  const n = unconstrained.length;
  const plan = unconstrained.map(value => Math.max(-bound, Math.min(bound, value)));
  // An active value is -1 at the lower bound, +1 at the upper bound.
  const active = unconstrained.map(value => value < -bound ? -1 : value > bound ? 1 : 0);
  const tolerance = 2e-10 * (1 + Math.max(...gradient.map(Math.abs)));
  const maxIterations = 12 * n + 30;
  for (let iteration = 0; iteration < maxIterations; iteration++) {
    const slope = hessian.map((row, i) => dot(row, plan) + gradient[i]);
    const free = [];
    for (let i = 0; i < n; i++) if (active[i] === 0) free.push(i);
    if (free.some(i => Math.abs(slope[i]) > tolerance)) {
      const subproblem = free.map(i => free.map(j => hessian[i][j]));
      const direction = solvePositive(cholesky(subproblem), free.map(i => -slope[i]));
      let step = 1;
      let blockingIndex = -1;
      let blockingSide = 0;
      for (let j = 0; j < free.length; j++) {
        const index = free[j], delta = direction[j];
        if (delta === 0) continue;
        const side = Math.sign(delta);
        const feasible = (side * bound - plan[index]) / delta;
        if (feasible < step) {
          step = Math.max(0, feasible);
          blockingIndex = index;
          blockingSide = side;
        }
      }
      free.forEach((i, j) => {
        plan[i] = Math.max(-bound, Math.min(bound, plan[i] + step * direction[j]));
      });
      if (blockingIndex >= 0) {
        plan[blockingIndex] = blockingSide * bound;
        active[blockingIndex] = blockingSide;
      }
      continue;
    }
    let release = -1;
    let violation = tolerance;
    for (let i = 0; i < n; i++) {
      const multiplierViolation = active[i] * slope[i];
      if (multiplierViolation > violation) {
        violation = multiplierViolation;
        release = i;
      }
    }
    if (release < 0) return { plan, converged: true, iterations: iteration + 1 };
    active[release] = 0;
  }
  return { plan, converged: false, iterations: maxIterations };
}

export function predictiveMove(config, A, B, measurement, reference, linear) {
  const model = buildModel(A, B, config.horizon, config.q, config.r);
  const plan = model.gainMeasured.map((gain, i) =>
    gain * measurement + model.gainReference[i] * reference
  );
  const raw = plan[0];
  const constrained = !linear && plan.some(value => Math.abs(value) > config.limit);
  if (!constrained) {
    return { u: raw, raw, plan, saturated: !linear && Math.abs(raw) >= config.limit,
      constrained: false, converged: true, iterations: 0 };
  }
  const gradient = model.gradMeasured.map((value, i) =>
    value * measurement + model.gradReference[i] * reference
  );
  const result = solveBox(model.hessian, gradient, plan, config.limit);
  const u = result.plan[0];
  return { u, raw, ...result, constrained, saturated: Math.abs(u) >= config.limit - 1e-9 };
}
