import { MatchEngine, DT } from "./engine.js";
let engine = new MatchEngine(),
  running = true,
  speed = 1,
  last = performance.now(),
  acc = 0,
  send = 0;
const respond = (id, data) => postMessage({ type: "result", id, data });
setInterval(() => {
  const now = performance.now(),
    elapsed = Math.min(0.15, (now - last) / 1000);
  last = now;
  if (running) {
    acc += elapsed * speed;
    let n = 0;
    while (acc >= DT && n++ < 90) {
      engine.step();
      acc -= DT;
    }
    if (engine.phase === "finished") running = false;
  }
  if (now - send > 90) {
    postMessage({ type: "state", state: engine.snapshot(), running, speed });
    send = now;
  }
}, 16);
self.onmessage = ({ data: m }) => {
  try {
    if (m.type === "run") {
      running = m.value;
      acc = 0;
      last = performance.now();
    }
    if (m.type === "speed") speed = m.value;
    if (m.type === "new") {
      engine = new MatchEngine(m.options);
      running = true;
      acc = 0;
    }
    if (m.type === "tactic") engine.setTactic(m.team, m.value);
    if (m.type === "checkpoint") respond(m.id, engine.checkpoint());
    if (m.type === "restore") {
      const restored = MatchEngine.restore(m.value);
      engine = restored;
      acc = 0;
      running = false;
      respond(m.id, { ok: true });
    }
    if (m.type === "history")
      respond(m.id, {
        kind: "ReplayRecord",
        schema: 1,
        engine: engine.snapshot().engine,
        frames: engine.history,
        events: engine.events,
        tactics: engine.tactics,
        seed: engine.seed,
      });
    if (m.type === "step") {
      running = false;
      for (let i = 0; i < 3; i++) engine.step();
    }
    if (m.type === "exportMetrics")
      respond(m.id, {
        measurements: engine.measurements,
        stats: engine.stats,
        seed: engine.seed,
        engine: engine.snapshot().engine,
      });
    send = 0;
  } catch (e) {
    postMessage({ type: "error", id: m.id, error: e.message });
  }
};
