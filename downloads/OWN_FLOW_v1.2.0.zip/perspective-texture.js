// Adaptive grid of affine triangles for a textured plane under a pinhole camera.
// The small grid avoids a GPU dependency. Clip at the eye plane before computing
// affine coefficients so close cameras can safely pass the stadium's front row.
function nearIntersection(a,b,near){
  const t=(near-a.depth)/(b.depth-a.depth);
  const point={
    x:((a.clipX??a.x*a.depth)*(1-t)+(b.clipX??b.x*b.depth)*t)/near,
    y:((a.clipY??a.y*a.depth)*(1-t)+(b.clipY??b.y*b.depth)*t)/near,
    depth:near,
  };
  if(Number.isFinite(a.u)&&Number.isFinite(b.u)){
    point.u=a.u+(b.u-a.u)*t;
    point.v=a.v+(b.v-a.v)*t;
  }
  return point;
}
export function clipProjectedPolygon(points){
  const near=.5;
  if(points.every(p=>p.depth>=near))return points;
  const result=[];
  let last=points.at(-1);
  for(const p of points){
    if((p.depth>=near)!==(last.depth>=near))result.push(nearIntersection(last,p,near));
    if(p.depth>=near)result.push(p);
    last=p;
  }
  return result;
}
export function clipProjectedLine(a,b){
  const near=.5;
  if(a.depth<near && b.depth<near)return null;
  if(a.depth<near)return [nearIntersection(a,b,near),b];
  if(b.depth<near)return [a,nearIntersection(a,b,near)];
  return [a,b];
}
function triangle(ctx,image,a,b,c,width,height){
  if(Math.max(a.x,b.x,c.x)<0 || Math.min(a.x,b.x,c.x)>width ||
     Math.max(a.y,b.y,c.y)<0 || Math.min(a.y,b.y,c.y)>height)return;
  const ub=b.u-a.u, vb=b.v-a.v, uc=c.u-a.u, vc=c.v-a.v;
  const determinant=ub*vc-uc*vb;
  if(Math.abs(determinant)<.00001)return;
  const dxB=b.x-a.x,dxC=c.x-a.x,dyB=b.y-a.y,dyC=c.y-a.y;
  const xx=(dxB*vc-dxC*vb)/determinant,xy=(dxC*ub-dxB*uc)/determinant;
  const yx=(dyB*vc-dyC*vb)/determinant,yy=(dyC*ub-dyB*uc)/determinant;
  const midX=(a.x+b.x+c.x)/3,midY=(a.y+b.y+c.y)/3;
  const minU=Math.max(0,Math.floor(Math.min(a.u,b.u,c.u))-1);
  const minV=Math.max(0,Math.floor(Math.min(a.v,b.v,c.v))-1);
  const maxU=Math.min(image.naturalWidth,Math.ceil(Math.max(a.u,b.u,c.u))+1);
  const maxV=Math.min(image.naturalHeight,Math.ceil(Math.max(a.v,b.v,c.v))+1);
  if(maxU<=minU||maxV<=minV)return;
  ctx.save();ctx.beginPath();
  // A subpixel overlap hides independent antialiasing along shared triangle edges.
  for(const [i,p] of [a,b,c].entries()){
    const dx=p.x-midX,dy=p.y-midY,scale=.6/Math.max(.01,Math.hypot(dx,dy));
    if(i===0)ctx.moveTo(p.x+dx*scale,p.y+dy*scale);
    else ctx.lineTo(p.x+dx*scale,p.y+dy*scale);
  }
  ctx.closePath();ctx.clip();
  ctx.transform(xx,yx,xy,yy,a.x-xx*a.u-xy*a.v,a.y-yx*a.u-yy*a.v);
  ctx.drawImage(image,minU,minV,maxU-minU,maxV-minV,minU,minV,maxU-minU,maxV-minV);
  ctx.restore();
}
export function paintSurface(view,image,topLeft,across,down,columns,rows){
  if(!image.complete||!image.naturalWidth)return false;
  const grid=[];
  for(let row=0;row<=rows;row++){
    const v=row/rows;
    const vertices=[];
    for(let col=0;col<=columns;col++){
      const u=col/columns;
      const point=topLeft.map((value,key)=>value+across[key]*u+down[key]*v);
      vertices.push({...view.project(point),u:u*image.naturalWidth,v:v*image.naturalHeight});
    }
    grid.push(vertices);
  }
  for(let row=0;row<rows;row++)for(let col=0;col<columns;col++){
    const a=grid[row][col],b=grid[row][col+1],c=grid[row+1][col+1],d=grid[row+1][col];
    for(const corners of [[a,b,c],[a,c,d]]){
      const clipped=clipProjectedPolygon(corners);
      for(let i=1;i<clipped.length-1;i++)triangle(view.ctx,image,clipped[0],clipped[i],clipped[i+1],view.w,view.h);
    }
  }
  return true;
}
