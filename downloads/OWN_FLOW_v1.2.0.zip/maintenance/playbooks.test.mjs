import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {buildPlaybook, playbookRoster, PLAYBOOKS} from '../playbooks.js';
import {selectPlaybookReceiver} from '../passing-style.js';
import {MatchEngine, FORMATIONS, ROLES, graphHealth, validateTactic} from '../engine.js';

const dimensions = ['speed', 'acceleration', 'skill', 'stamina', 'vision'];
const mean = (roster, key) => roster.reduce((sum, p) => sum + p[key], 0) / roster.length;

test('all downloadable classic playbooks survive the normal import and engine initialisation for either team', () => {
  const bundle = JSON.parse(fs.readFileSync(new URL('../examples/ClassicPlaybooks.json', import.meta.url), 'utf8'));
  assert.equal(bundle.kind, 'FlowLibrary');
  assert.equal(bundle.presets.length, 5);
  for (const source of bundle.presets) {
    // The tactical library assigns a new ID to every imported preset.
    const imported = validateTactic({...source, id:'independent-library-id'});
    const book = buildPlaybook(imported.passStyle, 1);
    assert.deepEqual(imported.players, book.players);
    const game = new MatchEngine({tactics:[imported,book]});
    assert.equal(game.players.length, 22);
    for (const player of game.players) {
      const template = imported.players[player.index];
      assert.equal(player.speed, template.speed);
      assert.equal(player.acc, template.acceleration);
      assert.equal(player.vision, template.vision);
      assert.equal(player.role, ROLES[imported.formation][player.index]);
    }
    assert.equal(graphHealth(imported.commEdges, imported.gamma).connected, true);
  }
});

test('homogeneous ablation preserves all five team-wise ability means and identical formation and network', () => {
  for (const entry of PLAYBOOKS) {
    const mixed = buildPlaybook(entry.id);
    const control = buildPlaybook(entry.id, 0, {homogeneous:true});
    for (const key of dimensions) {
      assert.ok(new Set(mixed.players.map(p=>p[key])).size > 1);
      assert.equal(new Set(control.players.map(p=>p[key])).size, 1);
      assert.ok(Math.abs(mean(mixed.players,key)-mean(control.players,key)) < 1e-10);
    }
    assert.deepEqual(mixed.tacticalEdges, control.tacticalEdges);
    assert.deepEqual(mixed.commEdges, control.commEdges);
    assert.deepEqual(mixed.groups,control.groups);
    assert.deepEqual(mixed.players.map(p=>p.appearance), control.players.map(p=>p.appearance));
  }
});

test('historical physical anchors enter the model in correct units and the libero covers behind both markers', () => {
  assert.equal(playbookRoster('triangles')[9].appearance.heightCm, 170);
  assert.equal(playbookRoster('press')[2].speed, 34.5/3.6);
  const sweeper = buildPlaybook('libero');
  const positions = FORMATIONS[sweeper.formation];
  for (const marker of [2,4]) assert.equal(positions[marker][0] - positions[3][0], 8);
  assert.equal(ROLES[sweeper.formation][3], 'SW');
});

test('receiver policy rejects an occupied passing lane and can hold with no visible safe outlet', () => {
  const marked = {id:6,team:0,x:10,y:0,vx:0,vy:0};
  const alternative = {id:8,team:0,x:4,y:8,vx:0,vy:0};
  const blocker = {id:12,team:1,x:5,y:0,vx:0,vy:0};
  const carrier = {id:5,team:0,x:0,y:0,visible:[marked,alternative,blocker]};
  assert.equal(selectPlaybookReceiver('triangles',carrier,1)?.id,8);
  carrier.visible = [blocker,marked];
  assert.equal(selectPlaybookReceiver('triangles',carrier,1), null);
  carrier.visible = [];
  assert.equal(selectPlaybookReceiver('transition',carrier,1), null);
});

// Run a normal football tick with identical local options. A short triangle releases left,
// while the breakaway runner is farther ahead and to the right. Zero kick noise isolates selection.
function kickInDecisionScene(style) {
  const game = new MatchEngine({tactics:[buildPlaybook(style),buildPlaybook('press',1)]});
  for (const p of game.players) Object.assign(p,{x:-47, y:29, vx:0, vy:0});
  const carrier = game.players[5];
  Object.assign(carrier,{x:0,y:0,skill:1,heading:0,lastCarry:0,cooldown:0});
  Object.assign(game.players[6],{x:9,y:3});
  Object.assign(game.players[9],{x:32,y:-8});
  carrier.visible=[6,9].map(i=>{const {id,team,x,y,vx,vy}=game.players[i];return {id,team,x,y,vx,vy};});
  Object.assign(game.ball,{owner:5,x:0,y:0,vx:0,vy:0});
  game.time=15;
  game.football();
  assert.equal(game.stats[0].passes,1);
  return game.ball.vy;
}
test('loading different playbooks changes the issued match pass for the same decision scene',()=>{
  assert.ok(kickInDecisionScene('triangles')>0);
  assert.ok(kickInDecisionScene('transition')<0);
});

test('mixed and mean-matched squads produce different physical trajectories from the same seed',()=>{
  const mixed = buildPlaybook('press');
  const meanSquad = buildPlaybook('press',0,{homogeneous:true});
  const a = new MatchEngine({mode:'formation',seed:91,tactics:[mixed,buildPlaybook('triangles',1)]});
  const b = new MatchEngine({mode:'formation',seed:91,tactics:[meanSquad,buildPlaybook('triangles',1)]});
  assert.deepEqual(a.players.map(p=>[p.x,p.y]),b.players.map(p=>[p.x,p.y]));
  for(let i=0;i<120;i++){a.step();b.step();}
  assert.ok(a.players.slice(0,11).some((p,i)=>Math.hypot(p.x-b.players[i].x,p.y-b.players[i].y)>.03));
});
