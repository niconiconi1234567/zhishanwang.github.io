import test from 'node:test';
import assert from 'node:assert/strict';
import {MatchEngine, defaultTactic} from '../engine.js';
import {empiricalNetwork, effectiveNetworkPanel, footballTaskOutcomes, footballOutcomePanel} from '../effective-network.js';

function cachedState(team, edges) {
  const state = new MatchEngine().snapshot();
  state.time = 5;
  state.tactics[team].commEdges = edges;
  function receive(from, to, age) {
    const sender = team * 11 + from;
    state.players[team * 11 + to].neighbors[sender] = {x: 0, y: 0, ex: 0, ey: 0, time: state.time - age};
  }
  return {state, receive};
}

test('directed reception distinguishes mutual, one-way and unreachable pairs on the away team', () => {
  const {state, receive} = cachedState(1, [[0,1],[1,2],[2,3],[3,0],[5,6]]);
  receive(0, 1, .25); receive(1, 0, .75); receive(1, 2, 1.25); receive(2, 3, .5); receive(5, 6, 1);
  receive(3, 0, 2.5); // Expiration is strict, even if the timestamp remains cached.
  receive(4, 5, .1);  // A previously configured edge has been removed.
  const data = empiricalNetwork(state, 1);
  assert.equal(data.arcs.length, 5);
  assert.equal(data.mutual, 1);
  assert.equal(data.oneWay, 3);
  assert.deepEqual(data.absent, {stale: 1, unseen: 4, muted: 0});
  assert.equal(data.reachablePairs, 8);
  assert.equal(data.components.length, 10);
  assert.deepEqual(data.components[0], [0,1]);
  assert.equal(data.receivers[2].coverage, .5);
  assert.equal(data.receivers[4].coverage, null);
  assert.equal(data.meanAge, .75);
});

test('ball-only observer omits cached state directions; compact replay memory is unavailable', () => {
  const {state, receive} = cachedState(0, [[0,1]]);
  receive(0, 1, 2.5 - .001);
  assert.equal(empiricalNetwork(state, 0).arcs.length, 1);
  state.tactics[0].information = 'ball';
  const disabled = empiricalNetwork(state, 0);
  assert.equal(disabled.arcs.length, 0);
  assert.equal(disabled.absent.muted, 2);
  assert.equal(disabled.components.length, 11);
  assert.equal(disabled.meanAge, null);
  delete state.players[1].neighbors;
  assert.deepEqual(empiricalNetwork(state, 0), {available: false});
  assert.match(effectiveNetworkPanel(state, 0, 'zh'), /未记录接收方/);
});

test('delayed physical packets contribute to the diagnostic only after delivery', () => {
  const tactic = defaultTactic();
  tactic.delay = 1000;
  tactic.loss = 0;
  const e = new MatchEngine({mode: 'formation', tactics: [tactic, defaultTactic(1)]});
  for (let i = 0; i < 18; i++) e.step();
  assert.ok(e.queue.length > 0);
  assert.equal(empiricalNetwork(e.snapshot(), 0).arcs.length, 0);
  for (let i = 0; i < 24; i++) e.step();
  const live = empiricalNetwork(e.snapshot(), 0);
  assert.equal(live.arcs.length, tactic.commEdges.length * 2);
  assert.equal(live.components.length, 1);
  assert.equal(live.reachablePairs, 110);
  assert.ok(live.meanAge >= .99 && live.meanAge < 1.3);
  assert.ok(live.receivers.every(p => Number.isFinite(p.estimationError)));
});

test('football outcomes subtract checkpoint goals once and preserve interval event counts', () => {
  const first = {initialCheckpoint: {score: [4,3]}, a: {score: [5,3], passes: 7, shots: 2}, b: {score: [4,4], passes: 3, shots: 1}};
  const second = {initialCheckpoint: {score: [1,2]}, a: {score: [1,2], passes: 2, shots: 3}, b: {score: [3,2], passes: 5, shots: 4}};
  const report = {mode: 'match', results: [first, second]};
  const result = footballTaskOutcomes(report);
  assert.equal(result.count, 2);
  assert.deepEqual(result.metrics.goals, {a: .5, b: 1, delta: .5});
  assert.deepEqual(result.metrics.conceded, {a: 0, b: .5, delta: .5});
  assert.deepEqual(result.metrics.passes, {a: 4.5, b: 4, delta: -.5});
  assert.deepEqual(result.metrics.shots, {a: 2.5, b: 2.5, delta: 0});
  assert.equal(footballOutcomePanel({...report, mode:'formation'}, 'en'), '');
  assert.equal(footballTaskOutcomes({mode:'match', results:[{...first, initialCheckpoint:{}}]}), null);
});
