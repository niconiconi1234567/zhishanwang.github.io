import test from "node:test";
import assert from "node:assert/strict";
import { MatchEngine, defaultTactic } from "../engine.js";
globalThis.self = globalThis;
let messages = [];
globalThis.postMessage = (m) => messages.push(m);
await import("../benchmark-worker.js");
function benchmark(overrides = {}) {
  messages = [];
  self.onmessage({
    data: {
      tactics: [defaultTactic(), defaultTactic(1)],
      mode: "formation",
      duration: 5,
      seeds: [361, 458, 572],
      intervention: "gain",
      ...overrides,
    },
  });
  return messages.at(-1);
}
test("three benchmark environments execute matched A/B branches with reproducible inputs", () => {
  for (const mode of ["formation", "moving", "match"]) {
    const out = benchmark({ mode });
    assert.equal(out.type, "complete");
    assert.equal(out.result.results.length, 3);
    for (const r of out.result.results) {
      assert.ok(Number.isFinite(r.a.shape) && Number.isFinite(r.b.shape));
      assert.equal(r.a.actualDuration, 5);
      assert.ok(
        r.branchBTactic.kFormation > r.initialCheckpoint.tactics[0].kFormation,
      );
      assert.equal(r.seed, r.initialCheckpoint.seed);
      const e = MatchEngine.restore(r.initialCheckpoint);
      for (let i = 0; i < 150; i++) e.step();
      assert.equal(e.metrics[0].shape, r.a.final);
    }
  }
});
test("checkpoint forks retain exact first RNG state and record later branch seeds", () => {
  let e = new MatchEngine();
  for (let i = 0; i < 90; i++) e.step();
  const cp = e.checkpoint(),
    out = benchmark({ checkpoint: cp, intervention: "loss" });
  assert.equal(out.type, "complete");
  assert.equal(out.result.results[0].rngState, cp.rng);
  assert.equal(out.result.results[1].rngState, 458);
  assert.equal(out.result.results[0].branchBTactic.loss, 0.35);
  assert.equal(out.result.mode, "match");
  assert.equal(out.result.results[0].a.actualDuration, 5);
});
test("a finished checkpoint produces a clear error instead of empty metrics", () => {
  const e = new MatchEngine();
  e.phase = "finished";
  const out = benchmark({ checkpoint: e.checkpoint() });
  assert.equal(out.type, "error");
  assert.equal(out.error, "benchmark_finished");
});

test("a role-tracker intervention on Coral removes its own tracker and reports Coral metrics", () => {
  const tactics=[defaultTactic(0),defaultTactic(1)];
  tactics[1].tracker={dt:.1,type:"pid",kp:2};
  const out=benchmark({tactics,team:1,mode:"match",intervention:"tracker"});
  assert.equal(out.type,"complete");
  assert.equal(out.result.team,1);
  const first=out.result.results[0];
  assert.equal(first.initialCheckpoint.tactics[1].tracker.type,"pid");
  assert.equal(first.branchBTactic.tracker,null);
  const reference=MatchEngine.restore(first.initialCheckpoint);
  for(let i=0;i<150;i++)reference.step();
  assert.equal(first.a.final,reference.metrics[1].shape);
  assert.equal(first.a.shots,reference.stats[1].shots);
});
