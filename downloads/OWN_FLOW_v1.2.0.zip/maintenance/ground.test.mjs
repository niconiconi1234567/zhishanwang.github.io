import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {MatchEngine,defaultTactic,ENGINE_VERSION} from '../engine.js';
import {GroundSimulation,scenarioDesign,modalGains,compareTrials,validateDesign} from '../ground-simulation.js';
import {compileWires,link,wireTemplate} from '../ground-design.js';
import {analyzeLoop,analyzeNetwork} from '../control-kernel.js';
import {buildPlaybook} from '../playbooks.js';
const close=(a,b,tol=1e-8)=>assert.ok(Math.abs(a-b)<=tol,`${a} ≠ ${b}`);
const mean=values=>values.reduce((a,b)=>a+b,0)/values.length;
const run=(preset,tactic=defaultTactic())=>new GroundSimulation(scenarioDesign(preset),tactic).finish();

test('all 11 players track zero and a six metre command; field offsets agree with the recorded output',()=>{
  for(const [preset,r] of [['zero',0],['setpoint',6]]){
    const s=run(preset),end=s.frames.at(-1),snapshot=s.snapshot(false);
    end.x.forEach(x=>close(x,r));assert.equal(s.stopReason,'complete');
    assert.ok(s.summary().settling>0 && s.summary().settling<10);
    snapshot.training.paths.forEach((path,i)=>{
      close(path.actualPoint.y-path.target.y,end.x[i]-r);
      close(snapshot.players[i].y,path.actualPoint.y);
      assert.deepEqual(path.actual.at(-1),path.actualPoint);
    });
  }
});
test('unanchored symmetric P conserves the average before limiting; separated components retain different means',()=>{
  const s=run('average');
  assert.equal(s.limitedCount,0);
  s.frames.forEach(frame=>close(frame.mean,s.initialMean));
  assert.ok(s.frames.at(-1).disagreement<.02);
  const islands=run('islands');
  const x=islands.frames.at(-1).x;
  for(const group of [x.slice(0,6),x.slice(6)])assert.ok(Math.max(...group)-Math.min(...group)<1e-5);
  close(mean(x.slice(0,6)),mean(islands.frames[0].x.slice(0,6)));
  assert.ok(islands.summary().disagreement>4);
  assert.equal(modalGains(scenarioDesign('islands')).filter(l=>l<1e-8).length,2);
});
test('positive feedback moves the nominal pole outside the unit circle and preserves the measured exit state',()=>{
  const s=run('unstable');
  assert.equal(s.stopReason,'range');
  assert.ok(s.time<30);assert.ok(s.summary().peak>=80);
  assert.ok(analyzeNetwork(s.control,modalGains(s.design)).radius>1);
  const t=s.time;s.step();assert.equal(s.time,t);
});
test('wiring changes actual trajectories; moving a drawing alone preserves each sample',()=>{
  const d=scenarioDesign('setpoint'),team=defaultTactic();
  const base=new GroundSimulation(d,team).finish();
  const moved=structuredClone(d);moved.layout.C=[200,130];
  assert.deepEqual(new GroundSimulation(moved,team).finish().frames,base.frames);
  for(const name of ['open','filtered','bypass']){
    const edit={...d,wires:wireTemplate(name)};
    assert.notDeepEqual(new GroundSimulation(edit,team).finish().frames[1],base.frames[1]);
  }
  assert.throws(()=>link(d.wires,'P','E.r'));
  const invalid={...d,wires:{...d.wires,'P.in':null}};
  assert.deepEqual(compileWires(invalid).missing,['P.in']);
  assert.throws(()=>new GroundSimulation(invalid,team),/incomplete_wires/);
});
test('local self-loop reference test agrees with the analytical transfer for every sample',()=>{
  const d=scenarioDesign('setpoint');d.coupling=0;d.control.kp=2;d.control.limit=40;
  const s=new GroundSimulation(d,defaultTactic());
  const x0=s.x[4],model=analyzeLoop(s.control);
  close(model.den[1],-.8);close(model.num[0],.2);
  for(let n=1;n<=40;n++){s.step();close(s.x[4],6+.8**n*(x0-6));}
});
test('ability changes alter actual input gain and the legal actuation bound, preserving initial samples',()=>{
  const team=buildPlaybook('press',0),d=scenarioDesign('setpoint');
  const homogeneous=new GroundSimulation(d,team),mixed=new GroundSimulation({...d,heterogeneity:1},team);
  assert.deepEqual(homogeneous.x,mixed.x);
  assert.ok(new Set(mixed.plants.map(p=>p.B)).size>1);
  close(mean(mixed.plants.map(p=>p.B)),homogeneous.plants[0].B);
  close(mean(mixed.controllers.map(c=>c.limit)),homogeneous.controllers[0].limit);
  for(let i=0;i<20;i++){homogeneous.step();mixed.step();}
  assert.notDeepEqual(mixed.x,homogeneous.x);
  mixed.frames.forEach(f=>f.u.forEach((u,i)=>assert.ok(Math.abs(u)<=mixed.controllers[i].limit+1e-9)));
});
test('paired experiments retain the exact seeds, squad, and numerical history needed to reproduce a variant',()=>{
  const team=buildPlaybook('triangles',0),d=scenarioDesign('moving');
  d.disturbance=1.5;
  const report=compareTrials(d,team);
  assert.deepEqual(report.rows.map(r=>r.name),['p','pid','adrc','mpc']);
  for(const row of report.rows){
    assert.equal(row.completed,3);
    const repeat=new GroundSimulation({...report.design,seed:row.runs[0].seed,control:{...d.control,type:row.name}},report.squad).finish();
    close(row.runs[0].runRmse,repeat.summary().runRmse);
    assert.deepEqual(row.firstTrajectory.at(-1).x,repeat.x);
  }
  assert.throws(()=>compareTrials({...d,wires:wireTemplate('bypass')},team),/bypassed/);
});
test('network design import rejects duplicate links, non-finite settings and malformed diagrams',()=>{
  const d=scenarioDesign();
  assert.throws(()=>validateDesign({...d,edges:[[1,2],[2,1]]}));
  assert.throws(()=>validateDesign({...d,coupling:Infinity}));
  assert.throws(()=>validateDesign({...d,layout:{...d.layout,P:[null,20]}}));
  assert.throws(()=>validateDesign({...d,wires:{...d.wires,'G.in':'R'}}));
});
test('a real v1.0 checkpoint continues the original trajectory under the v1.2 engine',()=>{
  const fixture=JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/v1-checkpoint.json.gz',import.meta.url))));
  const e=MatchEngine.restore(fixture.checkpoint);
  for(let i=0;i<90;i++)e.step();
  assert.equal(e.checkpoint().engine,ENGINE_VERSION);
  assert.deepEqual(e.players.map(p=>[p.x,p.y]),fixture.expected.positions);
  assert.deepEqual(e.ball,fixture.expected.ball);
  assert.deepEqual(e.score,fixture.expected.score);
  assert.equal(e.rng.s,fixture.expected.rng);
});
test('deploying each tracker changes physical match behavior and its private memory survives JSON checkpoints',()=>{
  for(const type of ['p','pid','adrc','mpc']){
    const d=scenarioDesign(),team=defaultTactic();d.control.type=type;d.control.kp=2;
    team.tracker=compileWires(d).config;
    const altered=new MatchEngine({tactics:[team,defaultTactic(1)],seed:361});
    const original=new MatchEngine({seed:361});
    for(let i=0;i<90;i++){altered.step();original.step();}
    assert.ok(altered.players[4].trackMemory?.x);
    assert.notDeepEqual(altered.players[4].command,original.players[4].command);
    const checkpoint=JSON.parse(JSON.stringify(altered.checkpoint()));
    const continued=MatchEngine.restore(checkpoint);
    for(let i=0;i<45;i++){altered.step();continued.step();}
    assert.deepEqual(JSON.parse(JSON.stringify(continued.checkpoint())),JSON.parse(JSON.stringify(altered.checkpoint())));
    delete checkpoint.players[2].trackMemory.x.controller.predictedY;
    assert.throws(()=>MatchEngine.restore(checkpoint),/checkpoint_player/);
  }
});
