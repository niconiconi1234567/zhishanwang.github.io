import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeControl, zohPlant, sampleFilter, newControlMemory,
  stepControl, analyzeLoop, analyzeNetwork
} from "../control-kernel.js";

function close(actual, expected, tolerance = 1e-8) {
  assert.ok(Math.abs(actual - expected) <= tolerance * Math.max(1, Math.abs(expected)),
    `${actual} differs from ${expected}`);
}

function outputSequence(config, input, lambda = 1, inputGain = 1) {
  const c = normalizeControl(config), { A, B } = zohPlant(c.a, c.b, c.dt);
  let x = 0, measured = 0, reference = 0;
  const memory = newControlMemory(), y = [];
  for (const value of input) {
    y.push(x);
    measured = sampleFilter(measured, x, c.sensorTau, c.dt);
    reference = sampleFilter(reference, value, c.refTau, c.dt);
    const error = inputGain * reference + c.sign * lambda * measured;
    const { u } = stepControl(c, memory, { measurement: measured, error });
    x = A * x + B * u;
  }
  return y;
}

function transferSequence({ num, den }, input) {
  const padded = [...Array(den.length - num.length).fill(0), ...num], output = [];
  for (let k = 0; k < input.length; k++) {
    const direct = padded.reduce((sum, coefficient, j) => sum + coefficient * (input[k-j] ?? 0), 0);
    const feedback = den.slice(1).reduce((sum, coefficient, j) => sum + coefficient * (output[k-j-1] ?? 0), 0);
    output.push(direct - feedback);
  }
  return output;
}

test("exact ZOH handles the integrator limit, stable drift and uncontrollable input", () => {
  close(zohPlant(0, 2, 0.1).B, 0.2);
  close(zohPlant(1e-12, 2, 0.1).B, 0.2, 1e-12);
  const { A, B } = zohPlant(-0.7, 2, 0.1);
  close(A * 4 + B * 0.7, 2 + 2 * Math.exp(-0.07));
  close(zohPlant(1.2, 0).B, 0);
});

test("P loop exposes the correct discrete transfer, feedback sign and internal stability", () => {
  const base = { type: "p", kp: 2, a: 0, b: 1, dt: 0.1 };
  for (const [sign, pole, stability] of [[-1, 0.8, "stable"], [0, 1, "boundary"], [1, 1.2, "unstable"]]) {
    const model = analyzeLoop({ ...base, sign });
    assert.equal(model.stability, stability);
    assert.equal(model.den.length, 2);
    close(model.num[0], 0.2); close(model.den[1], -pole);
    close(model.poles[0].re, pole);
    assert.deepEqual(model.zeros, []);
  }
  const blockedInput = analyzeLoop({ ...base, sign: 1 }, { inputGain: 0 });
  assert.deepEqual(blockedInput.num, [0]);
  assert.deepEqual(blockedInput.den, [1]);
  assert.equal(blockedInput.poles.length, 0);
  assert.equal(blockedInput.stability, "unstable");
  close(blockedInput.internalPoles[0].re, 1.2);
});

test("all four reference transfer functions reproduce ordinary sampled responses through both dynamic filters", () => {
  const input = Array.from({ length: 100 }, (_, i) => 0.04 * Math.cos(i * 0.23) + 0.02 * Math.sin(i * 0.59));
  for (const type of ["p", "pid", "adrc", "mpc"]) {
    const c = normalizeControl({ type, a: -0.23, b: 1.13, refTau: 0.24, sensorTau: 0.41, limit: 20 });
    const model = analyzeLoop(c, { lambda: 0.6, inputGain: 0.8 });
    assert.ok(model.numericallyReliable, type);
    const physical = outputSequence(c, input, 0.6, 0.8), transfer = transferSequence(model, input);
    physical.forEach((value, k) => close(value, transfer[k], 2e-8));
  }
});

test("PID memory is private, serializable and prevents windup against active input limits", () => {
  const c = normalizeControl({ type: "pid", kp: 2, ki: 1, kd: 0, limit: 0.5 });
  const left = newControlMemory(), right = newControlMemory();
  for (let k = 0; k < 100; k++) stepControl(c, left, { measurement: 0, error: 20 });
  close(left.integral, 0); close(right.integral, 0);
  stepControl(c, left, { measurement: 0, error: 0.1 });
  close(left.integral, 0.01);
  const restored = JSON.parse(JSON.stringify(left));
  const measure = { measurement: 0.2, error: 0.12 };
  assert.deepEqual(stepControl(c,left,measure), stepControl(c,restored,measure));
  assert.deepEqual(left,restored);
  close(right.integral,0);
});

test("current ESO has the prescribed observer poles and rejects a constant matched disturbance", () => {
  const c = normalizeControl({ type: "adrc", a: 0, b: 1, b0: 1, wc: 1.5, wo: 6 });
  const model = analyzeLoop(c);
  close(model.poles[0].re, 1 - c.dt*c.wc);
  assert.equal(model.cancelledModes,2);
  const observerPole = Math.exp(-c.wo*c.dt);
  assert.equal(model.internalPoles.filter(z=>Math.hypot(z.re-observerPole,z.im)<2e-7).length,2);
  let x = 0; const memory = newControlMemory();
  for(let k=0;k<250;k++){
    const result = stepControl(c,memory,{measurement:x,error:3-x});
    x += c.dt*(result.u+0.7);
  }
  close(x,3,1e-8);close(memory.estimatedDisturbance,0.7,1e-8);
});

test("one-step MPC matches its exact optimizer and horizon/penalty changes the first move",()=>{
  const base = {type:"mpc",a:0,b:1,horizon:1,q:2,r:0.5,dt:.1,limit:50};
  const signal = {measurement:1,error:2};
  const expected = (2*.1*2)/(.5+2*.1**2);
  close(stepControl(base,newControlMemory(),signal).u,expected);
  const long = stepControl({...base,horizon:5},newControlMemory(),signal).u;
  assert.ok(long>expected);
  assert.ok(stepControl({...base,r:2},newControlMemory(),signal).u<expected);
});

test("active future MPC bounds change today's unsaturated first move and the full plan satisfies box KKT conditions",()=>{
  const c=normalizeControl({type:"mpc",a:-2,b:1,horizon:4,limit:.3});
  const signal={measurement:-6,error:2};
  const feasible=stepControl(c,newControlMemory(),signal);
  const free=stepControl(c,newControlMemory(),signal,{linear:true});
  assert.ok(feasible.converged && feasible.constrained && !feasible.saturated);
  assert.ok(Math.abs(free.u)<c.limit);
  assert.ok(Math.abs(feasible.u-free.u)>.05);
  const {A,B}=zohPlant(c.a,c.b,c.dt);
  function cost(plan){
    let x=signal.measurement,J=0;
    for(const u of plan){x=A*x+B*u;J+=c.q*(x+4)**2+c.r*u*u;}
    return J;
  }
  for(let i=0;i<c.horizon;i++){
    const plus=feasible.plan.slice(),minus=feasible.plan.slice();
    plus[i]+=1e-5;minus[i]-=1e-5;
    const slope=(cost(plus)-cost(minus))/2e-5,u=feasible.plan[i];
    assert.ok(Math.abs(u)<=c.limit+1e-12);
    if(Math.abs(u+c.limit)<1e-8)assert.ok(slope>=-1e-7);
    else if(Math.abs(u-c.limit)<1e-8)assert.ok(slope<=1e-7);
    else close(slope,0,1e-7);
  }
  const clipped=free.plan.map(u=>Math.max(-c.limit,Math.min(c.limit,u)));
  assert.ok(cost(feasible.plan)<cost(clipped)-1e-5);
});

test("all graph-mode poles agree with the pinning and graph eigenvalues of a two-agent network",()=>{
  // L + diag(1,0) = [[2,-1],[-1,1]], eigenvalues (3 ± sqrt(5))/2.
  const lambda=[(3-Math.sqrt(5))/2,(3+Math.sqrt(5))/2];
  const c={type:"p",a:0,b:1,kp:2};
  const network=analyzeNetwork(c,lambda);
  assert.equal(network.stability,"stable");
  network.modes.forEach((mode,i)=>close(mode.poles[0].re,1-.2*lambda[i]));
  assert.equal(analyzeNetwork(c,[0,2]).stability,"boundary");
  assert.equal(analyzeNetwork({...c,sign:1},lambda).stability,"unstable");
  const withFilter=analyzeNetwork({...c,refTau:2},lambda);
  close(withFilter.referencePole,Math.exp(-.1/2));
});

test("rank reduction removes exact shared filter cancellation but retains a resolvable near cancellation",()=>{
  const matched=analyzeLoop({type:"p",refTau:.3,sensorTau:.3});
  const near=analyzeLoop({type:"p",refTau:.31,sensorTau:.3});
  assert.equal(matched.cancelledModes,1);
  assert.equal(near.cancelledModes,0);
  assert.equal(near.internalPoles.length,3);
});

test("invalid control parameters are rejected before simulation",()=>{
  for(const invalid of [{a:NaN},{horizon:3.5},{b0:0},{r:0},{sign:.5},{type:"javascript"},{dt:0},{type:"mpc",a:3,dt:.25,horizon:24}]){
    assert.throws(()=>normalizeControl(invalid));
  }
  assert.throws(()=>stepControl({},newControlMemory(),{measurement:Infinity,error:0}));
  assert.throws(()=>stepControl({type:"pid"}, {integral:NaN}, {measurement:0,error:1}));
});
