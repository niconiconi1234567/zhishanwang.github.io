import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  MatchEngine,
  defaultTactic,
  validateTactic,
  graphEdges,
  graphHealth,
  DT,
} from "../engine.js";
import { validateReplay } from "../replay.js";
import {
  ALGORITHM_EXAMPLE,
  validateAlgorithm,
  parseExpression,
  evaluate,
  executeAlgorithm,
} from "../algorithm.js";
const run = (e, seconds) => {
  for (let i = 0; i < seconds * 30; i++) e.step();
  return e;
};
const json = (x) => JSON.parse(JSON.stringify(x));
test("all built-in tactics validate and both graphs are connected", () => {
  for (let t of [0, 1]) {
    let c = validateTactic(defaultTactic(t));
    assert.equal(c.players.length, 11);
    assert.ok(graphHealth(c.commEdges, c.gamma).connected);
  }
});
test("bounded arithmetic grammar uses correct precedence and associativity", () => {
  for (let [s, v] of [
    ["2+3*4", 14],
    ["12/3/2", 2],
    ["8-3-2", 3],
    ["-(2+3)*4", -20],
    ["clamp(12,0,5)", 5],
    ["1/0", 0],
    ["max(3,5)+sqrt(9)", 8],
  ])
    assert.equal(evaluate(parseExpression(s), {}), v);
});
test("arbitrary code, unknown state and excessive expressions are rejected", () => {
  for (let x of [
    "window.location",
    "fetch(1)",
    "self.constructor",
    "opponent.secret",
    "1;alert(1)",
    "(()=>2)()",
    "self.x = 2",
    "[" + "1,".repeat(200) + "]",
  ])
    assert.throws(() => parseExpression(x));
  assert.throws(() => parseExpression("(".repeat(50) + "1" + ")".repeat(50)));
});
test("algorithm validates and enforces finite output bounds", () => {
  let a = validateAlgorithm(ALGORITHM_EXAMPLE),
    out = executeAlgorithm(a, {
      self: { x: -20, y: 0, vx: 0, vy: 0 },
      target: { x: 20, y: 10 },
      ball: { vx: 100, vy: 100 },
    });
  assert.ok(Math.hypot(out.x, out.y) <= 7 + 1e-10);
  assert.throws(() =>
    validateAlgorithm({ ...ALGORITHM_EXAMPLE, sampleTime: 0.001 }),
  );
});
test("tactic validation rejects duplicates, out of range values and bad groups", () => {
  for (let mutate of [
    (c) => c.commEdges.push(c.commEdges[0]),
    (c) => (c.kFormation = Infinity),
    (c) => (c.players[0].speed = -1),
    (c) => (c.groups[0].members = [50]),
    (c) => (c.algorithm = { kind: "evil" }),
    (c) => (c.loss = 5),
  ]) {
    const c = defaultTactic();
    mutate(c);
    assert.throws(() => validateTactic(c));
  }
});
test("same seed and configurations produce identical complete trajectories", () => {
  let a = run(new MatchEngine({ seed: 727 }), 20),
    b = run(new MatchEngine({ seed: 727 }), 20);
  assert.deepEqual(a.checkpoint(), b.checkpoint());
});
test("checkpoint is JSON portable and gives bit-identical continuation", () => {
  const a = run(new MatchEngine(), 42),
    cp = json(a.checkpoint()),
    b = MatchEngine.restore(cp);
  run(a, 21);
  run(b, 21);
  assert.deepEqual(a.checkpoint(), b.checkpoint());
  assert.throws(() => MatchEngine.restore({ ...cp, engine: "0.0.0" }));
  assert.throws(() => MatchEngine.restore({ ...cp, time: 9 }));
});
test("cloning a tactic does not share agent memory or queues", () => {
  const c = defaultTactic(),
    e = new MatchEngine({ tactics: [c, c] });
  e.players[0].integral.x = 3;
  e.players[0].inbox.push({ id: "test" });
  assert.equal(e.players[11].integral.x, 0);
  assert.equal(e.players[11].inbox.length, 0);
  e.tactics[0].groups[0].weight = 0.99;
  assert.notEqual(e.tactics[1].groups[0].weight, 0.99);
  assert.notEqual(c.groups[0].weight, 0.99);
});
test("no sensing or communication means ball remains unknown", () => {
  const c = defaultTactic();
  c.commEdges = [];
  c.vision = 12;
  const e = new MatchEngine({ tactics: [c, defaultTactic(1)] });
  e.players[0].x = -49;
  e.players[0].y = 0;
  e.players[0].heading = Math.PI;
  e.ball.x = 45;
  e.ball.y = 0;
  e.sense();
  assert.equal(e.players[0].knownBall, null);
  assert.equal(e.players[0].inbox.length, 0);
});
test("communication respects packet delay and erasure", () => {
  let c = defaultTactic();
  c.delay = 1000;
  c.loss = 0;
  const e = new MatchEngine({ tactics: [c, defaultTactic(1)] });
  e.communicate();
  e.sense();
  assert.equal(e.players[0].inbox.length, 0);
  e.time = 1.01;
  e.sense();
  assert.ok(e.players[0].inbox.length > 0);
  c.loss = 0.8;
  const f = new MatchEngine({ tactics: [c, defaultTactic(1)] });
  for (let i = 0; i < 10; i++) f.communicate();
  assert.ok(f.stats[0].dropped > f.stats[0].sent * 0.5);
});
test("control terms reconstruct desired command, physical limits hold", () => {
  const e = run(new MatchEngine(), 30);
  for (let p of e.players) {
    const sx = Object.values(p.parts).reduce((s, v) => s + v.x, 0),
      sy = Object.values(p.parts).reduce((s, v) => s + v.y, 0);
    assert.ok(Math.abs(sx - p.raw.x) < 1e-10);
    assert.ok(Math.abs(sy - p.raw.y) < 1e-10);
    assert.ok(Math.hypot(p.command.x, p.command.y) <= p.speed + 1e-9);
    assert.ok(Math.abs(p.x) <= 52 && Math.abs(p.y) <= 33.6);
  }
});
test("custom algorithm changes the physical trajectory", () => {
  let a = new MatchEngine(),
    c = defaultTactic();
  c.algorithm = ALGORITHM_EXAMPLE;
  let b = new MatchEngine({ tactics: [c, defaultTactic(1)] });
  run(a, 20);
  run(b, 20);
  assert.ok(
    Math.hypot(
      a.players[7].x - b.players[7].x,
      a.players[7].y - b.players[7].y,
    ) > 1,
  );
});
test("formation, communication and compensator edits change command behavior", () => {
  for (let mutate of [
    (c) => (c.kFormation = 1.8),
    (c) => {
      c.commEdges = [];
      c.gamma = 0;
    },
    (c) => {
      c.compensator = "pi";
      c.compGain = 0.7;
    },
  ]) {
    let a = new MatchEngine({ mode: "formation" }),
      b = MatchEngine.restore(a.checkpoint()),
      c = defaultTactic();
    mutate(c);
    b.setTactic(0, c);
    run(a, 15);
    run(b, 15);
    assert.ok(
      a.players.some(
        (p, i) =>
          Math.abs(p.x - b.players[i].x) + Math.abs(p.y - b.players[i].y) > 0.1,
      ),
    );
  }
});
test("all compensators and disconnected networks remain finite under stress", () => {
  for (let comp of ["none", "damping", "lowpass", "pi"]) {
    let c = defaultTactic();
    c.compensator = comp;
    c.compGain = 0.95;
    c.loss = 0.8;
    c.delay = 1500;
    c.gamma = 0.45;
    c.commEdges = graphEdges("full");
    const e = run(
      new MatchEngine({ mode: "moving", tactics: [c, defaultTactic(1)] }),
      45,
    );
    for (let p of e.players)
      for (let key of ["x", "y", "vx", "vy"])
        assert.ok(Number.isFinite(p[key]));
  }
});
test("goal, touchline, offside and goal kick restarts are executable", () => {
  let e = new MatchEngine();
  e.phase = "live";
  e.ball = { x: 52.7, y: 0, z: 0.2, vx: 1, vy: 0, vz: 0, spin: 0, owner: -1 };
  e.football();
  assert.equal(e.score[0], 1);
  assert.equal(e.phase, "goal");
  e = new MatchEngine();
  e.ball = { x: 30, y: 34.4, z: 0.2, vx: 0, vy: 1, vz: 0, spin: 0, owner: -1 };
  e.lastTouch = 5;
  e.football();
  assert.equal(e.events[0].type, "throwIn");
  assert.equal(e.restartTeam, 1);
  e = new MatchEngine();
  e.ball = { x: 52.7, y: 15, z: 0.2, vx: 1, vy: 0, vz: 0, spin: 0, owner: -1 };
  e.lastTouch = 5;
  e.football();
  assert.equal(e.events[0].type, "goalKick");
  e = new MatchEngine();
  e.phase = "live";
  e.players[10].x = 30;
  e.players[10].y = 0;
  e.ball = { x: 30, y: 0, z: 0.11, vx: 0, vy: 0, vz: 0, spin: 0, owner: -1 };
  e.pass = { from: 8, time: 0 };
  e.pendingOffside = [10];
  e.football();
  assert.equal(e.events[0].type, "offside");
});
test("full 90 minute matches finish, swap ends and remain bounded across 3 seeds", () => {
  let reports = [];
  for (let seed of [361, 727, 2026]) {
    const start = performance.now(),
      e = new MatchEngine({ seed });
    for (let i = 0; i < 27001; i++) {
      e.step();
      if (i % 600 === 0)
        for (let p of e.players) {
          assert.ok(Number.isFinite(p.x) && Number.isFinite(p.y));
          assert.ok(Math.hypot(p.vx, p.vy) < 10.1);
        }
    }
    assert.equal(e.phase, "finished");
    assert.equal(e.half, 2);
    assert.equal(e.time, 900);
    assert.ok(e.stats[0].passes + e.stats[1].passes > 30);
    assert.ok(e.stats[0].shots + e.stats[1].shots > 5);
    assert.ok(e.history.length <= 360);
    assert.ok(e.measurements.length <= 600);
    assert.ok(e.queue.length < 10000);
    reports.push({
      seed,
      score: e.score,
      passes: e.stats.map((x) => x.passes),
      shots: e.stats.map((x) => x.shots),
      saves: e.stats.map((x) => x.saves),
      time_s: e.time,
      wall_s: (performance.now() - start) / 1000,
      history: e.history.length,
      queue: e.queue.length,
    });
  }
  fs.mkdirSync("qa-results", { recursive: true });
  fs.writeFileSync(
    "qa-results/full-matches.json",
    JSON.stringify(reports, null, 2),
  );
});

test("ball-only messages do not contain or update neighbor state and preserve original source", () => {
  const c = defaultTactic();
  c.information = "ball";
  c.delay = 100;
  c.commEdges = [[0, 1]];
  const e = new MatchEngine({ tactics: [c, defaultTactic(1)] });
  e.players[0].knownBall = {
    x: 40,
    y: 0,
    vx: 1,
    vy: 0,
    owner: -1,
    time: 0,
    source: 7,
    via: "message",
  };
  e.players[1].x = -40;
  e.players[1].heading = Math.PI;
  e.players[1].vision = 12;
  e.ball.x = 45;
  e.communicate();
  const packet = e.queue.find((x) => x.from === 0 && x.to === 1);
  assert.equal(packet.x, undefined);
  e.time = 0.11;
  e.sense();
  assert.equal(e.players[1].neighbors[0], undefined);
  assert.equal(e.players[1].knownBall.source, 7);
  assert.equal(e.players[1].knownBall.relay, 0);
});
test("malformed nested checkpoint state is rejected before restore", () => {
  const cp = json(run(new MatchEngine(), 3).checkpoint());
  for (let mutate of [
    (c) => (c.players[4].prediction[0].x = "bad"),
    (c) => (c.stats[0].shots = null),
    (c) => (c.measurements[0].teams = null),
    (c) => (c.events[0].type = "<script>"),
    (c) => (c.players[0].command = {}),
  ]) {
    const broken = json(cp);
    mutate(broken);
    assert.throws(() => MatchEngine.restore(broken));
  }
  assert.doesNotThrow(() => MatchEngine.restore(cp));
});
test("replay freezes statistics, tactics and predictions and imports its compact export", () => {
  const e = run(new MatchEngine(), 5),
    first = structuredClone(e.history[0]);
  let changed = defaultTactic();
  changed.width = 1.2;
  e.setTactic(0, changed);
  run(e, 3);
  assert.deepEqual(e.history[0], first);
  const record = {
    kind: "ReplayRecord",
    schema: 1,
    engine: "1.0.0",
    seed: e.seed,
    frames: e.history,
    events: e.events,
    tactics: e.tactics,
  };
  const compact = JSON.parse(
    JSON.stringify(record, (_k, v) =>
      typeof v === "number" ? Math.round(v * 1e4) / 1e4 : v,
    ),
  );
  assert.equal(validateReplay(compact).frames.length, 16);
  assert.notEqual(
    record.frames[0].tactics[0].width,
    record.frames.at(-1).tactics[0].width,
  );
  for (let mutate of [
    (r) => (r.frames[0].stats = []),
    (r) => (r.frames[0].players[0].prediction = "bad"),
    (r) => (r.events[0].type = "bad"),
    (r) => (r.frames[0].metrics = null),
  ]) {
    const broken = json(record);
    mutate(broken);
    assert.throws(() => validateReplay(broken));
  }
});
