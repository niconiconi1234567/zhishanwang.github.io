// Run with Node from any directory. Redirect stdout to save the complete JSON.
import {defaultTactic,ENGINE_VERSION} from '../engine.js';
import {buildPlaybook} from '../playbooks.js';
import {GroundSimulation,scenarioDesign,compareTrials,modalGains} from '../ground-simulation.js';
import {compileWires} from '../ground-design.js';
import {analyzeLoop,analyzeNetwork} from '../control-kernel.js';

const baseline=defaultTactic(0);
const examples=['zero','setpoint','average','islands','unstable','moving'].map(name=>{
  const design=scenarioDesign(name),trial=new GroundSimulation(design,baseline).finish();
  const last=trial.frames.at(-1);
  return {
    name,seed:design.seed,reference:last.ref,summary:trial.summary(),
    components:trial.components.map(members=>{
      const values=members.map(i=>trial.x[i]);
      return {players:members.map(i=>i+1),mean:values.reduce((a,b)=>a+b,0)/values.length,
        withinGroupSpan:Math.max(...values)-Math.min(...values)};
    }),
    nominalStability:analyzeNetwork(trial.control,modalGains(design)).stability,
  };
});
const numericalExample=scenarioDesign('zero');
numericalExample.control.kp=2;
const loop=compileWires(numericalExample).config;
const feedback=[-1,0,1].map(sign=>{
  const model=analyzeLoop({...loop,sign});
  return {sign,num:model.num,den:model.den,internalPoles:model.internalPoles};
});
const moving=scenarioDesign('moving');
moving.control.type='adrc';
const squad=buildPlaybook('press',0);
const abilityReport=compareTrials(moving,squad,'abilities');
const controllerReport=compareTrials(moving,squad,'controllers');
function compact(report) {
  return {comparison:report.comparison,seeds:report.seeds,design:report.design,squad:report.squad.name,
    results:report.rows.map(({name,runs,summary,completed})=>({name,runs,summary,completed}))};
}
console.log(JSON.stringify({engine:ENGINE_VERSION,dt:.1,examples,feedback,paired:[compact(controllerReport),compact(abilityReport)]},null,2));
