import test from 'node:test';
import assert from 'node:assert/strict';
import {spectrum,teamAnalysis,pairedMetric} from '../analysis.js';
import {blendPose,actionPose,cameraFocus,VisualMotion} from '../motion-visual.js';
import {MatchEngine} from '../engine.js';
const close=(a,b,t=1e-8)=>assert.ok(Math.abs(a-b)<t,`${a} != ${b}`);

test('Laplacian spectrum matches exact path, complete and disconnected graphs',()=>{
 const path=spectrum([[0,1],[1,2]],3);[0,1,3].forEach((x,i)=>close(path.eigenvalues[i],x));assert.equal(path.components,1);
 const complete=spectrum([[0,1],[0,2],[1,2]],3);close(complete.lambda2,3);close(complete.density,1);
 const split=spectrum([[0,1],[2,3]],4);assert.equal(split.components,2);close(split.lambda2,0);assert.deepEqual(split.degrees,[1,1,1,1]);
});
test('analysis distinguishes shared estimator bias from disagreement',()=>{
 const e=new MatchEngine(),state=e.snapshot();let center={x:0,y:0};
 state.players.filter(p=>p.team===0).forEach(p=>{center.x+=p.x/11;center.y+=p.y/11;});
 state.players.filter(p=>p.team===0).forEach((p,i)=>p.estimate={x:center.x+3+(i-5),y:center.y+4});
 const a=teamAnalysis(state,0);close(a.bias,5);close(a.disagreement,Math.sqrt(10));close(a.rmse*a.rmse,a.bias*a.bias+a.disagreement*a.disagreement);
});
test('relational residual ignores common translation but target tracking does not',()=>{
 const e=new MatchEngine(),s=e.snapshot();s.players.forEach(p=>{p.x=p.target.x+4;p.y=p.target.y-3;});
 const a=teamAnalysis(s,0);close(a.relational,0);a.agents.forEach(p=>close(p.tracking,5));
});
test('analyst diagnostics do not mutate the engine or checkpoint',()=>{
 const e=new MatchEngine();for(let i=0;i<90;i++)e.step();const before=JSON.stringify(e.checkpoint());
 const s=e.snapshot();teamAnalysis(s,0);spectrum(s.tactics[0].commEdges);assert.equal(JSON.stringify(e.checkpoint()),before);
});
test('paired statistics use paired differences with correct sign and Student t interval',()=>{
 const p=pairedMetric([{a:{x:10},b:{x:9}},{a:{x:20},b:{x:18}},{a:{x:30},b:{x:27}}],'x');
 close(p.delta,-2);close(p.percent,-10);close(p.high,-2+4.3026527299/Math.sqrt(3));
 assert.equal(pairedMetric([{a:{x:0},b:{x:1}}],'x').percent,null);
});
test('pose interpolation takes the short angle route and does not extrapolate',()=>{
 const a={x:0,y:0,heading:Math.PI-.1},b={x:2,y:4,heading:-Math.PI+.1};
 const mid=blendPose(a,b,.5);close(mid.x,1);close(mid.y,2);close(mid.heading,Math.PI);
 close(blendPose(a,b,2).x,2);assert.deepEqual(a,{x:0,y:0,heading:Math.PI-.1});
 assert.deepEqual(blendPose(a,b,.5,false),b);assert.equal(blendPose(a,{...b,x:30},.5).x,30);
});
test('local camera follows the agent instead of leaking hidden ball position',()=>{
 const e=new MatchEngine(),s=e.snapshot();s.ball.x=40;s.ball.y=20;
 assert.deepEqual(cameraFocus(s,7,'ball',true),{x:s.players[7].x,y:s.players[7].y});
 assert.deepEqual(cameraFocus(s,7,'overview'),{x:0,y:0});assert.deepEqual(cameraFocus(s,7,'ball'),{x:40,y:20});
});
test('gait phase is distance-based and kick pose follows the actual event envelope',()=>{
 const p={id:7,vx:2,vy:0,action:'pass',actionUntil:10.55};
 const a=actionPose(p,10,4),b=actionPose({...p,vx:6},10.275,4);close(a.phase,b.phase);close(a.kick,0);close(b.kick,1);close(actionPose(p,10.55,4).kick,0);
});
test('render sampling freezes on pause and snaps cleanly after replay rewind',()=>{
 const e=new MatchEngine(),m=new VisualMotion(),a=e.snapshot();a.running=true;m.receive(a,0);m.sample(0);
 const b=structuredClone(a);b.time=.1;b.players[7].x+=2;m.receive(b,100);const v=m.sample(150);close(v.players[7].x,a.players[7].x+1);
 b.running=false;m.receive(b,200);const frozen=m.sample(250);assert.deepEqual(m.sample(600),frozen);
 const rewind=structuredClone(a);rewind.running=false;m.receive(rewind,700);close(m.sample(750).players[7].x,a.players[7].x);
});
