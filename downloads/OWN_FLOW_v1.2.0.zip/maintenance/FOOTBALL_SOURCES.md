# 经典战术、球员资料与实验映射

教练手册提供五支原创实验队。每支球队使用独立的阵型、子系统、战术图、通信图、传球偏好和 11 人能力配置。资料卡记录启发这些实验的历史队伍和公开事实。比赛显示原创队名、球衣、号码和程序化人物。

## 资料与使用范围

| 实验队 | 历史依据 | 进入模型的内容 |
|---|---|---|
| Glass Harbor XI，4-3-3 | 2011 欧冠决赛中，巴塞罗那以 3–1 击败曼联。哈维在第 27 分钟助攻佩德罗。俱乐部把梅西列为前锋，身高 170 cm。[UEFA 决赛回顾](https://www.uefa.com/uefachampionsleague/news/025d-0f7f9500b15e-f0e6e7aec729-1000--background-barcelona-vs-united/) · [FC Barcelona 球员档案](https://www.fcbarcelona.com/en/football/first-team/players/4974/lionel-andres-messi) | 原创中央前锋 Leo 的模型身高采用 170 cm，控制参数来自角色模板。临近接应、三角拓扑和较快出球体现短传控球思路。 |
| Copper Ridge XI，4-2-3-1 | 穆里尼奥的国际米兰在 2010 年欧冠半决赛客场 0–1，但以总比分 3–2 晋级。米利托的俱乐部档案记载 171 场 75 球，2010 年欧冠决赛攻入两球。[UEFA 半决赛报道](https://www.uefa.com/uefachampionsleague/news/01e4-0e746dee4629-e22f0b2f81cf-1000--barcelona-dethroned-by-resilient-inter/) · [FC Internazionale 球员档案](https://www.inter.it/en/club/hall-of-fame/diego-milito) | 双后腰保护中路，防守中心后移，安全纵向传球在反击时获得较高优先级。Diego 承担中锋终结职责。档案进球数作为角色背景。 |
| North Forge XI，4-3-3 | UEFA 对 2018/19 赛季的技术复盘强调利物浦的压迫。赛事体能表记录范戴克客战巴萨的冲刺峰值为 34.5 km/h。[UEFA Direct 186](https://editorial.uefa.com/resources/0257-0f842fb20b33-e02faf92f7dd-1000/uefa_direct_186_09.09.2019_.pdf) · [UEFA 2018/19 技术报告](https://www.uefa.com/MultimediaFiles/Download/Publications/uefaorg/General/02/61/96/22/2619622_DOWNLOAD.pdf) | 中卫 Virgil 的异构速度上限按 34.5 ÷ 3.6 = 9.5833… m/s 设置。这个数值来自特定比赛的一次峰值。提高阵型中心与压迫强度后，局部控制逻辑允许临近的第二名防守者参与追抢。 |
| Estuary Wings XI，3-5-2 | UEFA 的意大利队资料记录孔蒂使用 3-5-2，进攻阶段可展开为 3-3-4。对西班牙一场，意大利有 41% 控球率，尝试传球 387 次。报告指出博努奇的后场出球作用。[UEFA EURO 2016 技术报告](https://www.uefa.com/MultimediaFiles/Download/TechnicalReport/competitions/EURO/02/40/26/69/2402669_DOWNLOAD.pdf) | 侧翼子系统给两翼提供向前和向外的局部速度偏置，传球选择奖励可用宽度。Leon 在三中卫之间承担组织角色。历史数据用于说明战术背景，仿真结果取决于对手、种子及参数。 |
| Stonegate XI，5-3-2 | 埃雷拉时期的国际米兰在 1964 和 1965 年连夺欧洲冠军杯。UEFA 记述皮基在盯防线后担当自由人，左后卫获得前插空间。俱乐部档案记录皮基出场 257 次。[UEFA 战术史](https://www.uefa.com/uefachampionsleague/news/0253-0d7ff54821f7-e2055930d1e0-1000--the-greatest-teams-of-all-time-inter-1962-67/) · [FC Internazionale 球员档案](https://www.inter.it/it/archivio_giocatore/G0503) | 此处采用原创 5-3-2 近似。自由人 Armando 在未缩放基准阵型中比两名中卫深 8 米，左翼卫可以前插。比赛使用局部区域和关系控制。 |

## 参数解释

`playbooks.js` 定义 55 个球员槽位、12 种原创角色模板和各队的局部关系。速度以 m/s 计，加速度以 m/s² 计，视野为米。技术与体能为归一化实验参数。角色模板内的肤色索引和身材宽度用于程序化渲染。球员姓名和历史球员的对应范围由资料卡说明。参考球员的真实姓名用于引述来源。身高资料作用于外观，范戴克的赛事冲刺记录作用于速度上限，其余技能和体能采用原创数值。

异构阵容保留角色之间的能力差异。同质均值阵容将速度、加速度、技术、初始体能、视野五列分别替换为原阵容该列的算术平均，保留编队和局部网络。要对照初始体能，加载阵容后使用同一种子开始新比赛。运行中载入战术会更新命令所使用的能力，已消耗的体能属于当前比赛状态。

`passing-style.js` 仅使用持球人看到的队友、对手、位置和速度。先排除被明显封堵的路线，再考虑接应点空间、向前推进、传球距离和可利用的球场宽度。选择传球对象与球的实际飞行、接球及防守过程分别计算。金色战术箭头将当前子系统按权重合成的速度偏置在 8 秒尺度上画出，实际速度还受到战术误差、持球任务和运动约束的影响。

`examples/ClassicPlaybooks.json` 是五套异构阵容的标准 `FlowLibrary`。可直接在战术资料库导入，也可在经典战术页单独加载和另存。`passStyle` 独立存储在战术配置中，因此另存或更换资料库内部 ID 之后仍采用对应的出球规则。

## 已执行的断言

`node --test maintenance/playbooks.test.mjs` 验证五套 JSON 通过引擎导入与初始化、两队角色配置、公平均值对照、实测锚点换算、自由人保护深度、被封堵时的选择、同一局部态势下实际出球方向不同，以及同一种子下异构性改变球员实际轨迹。
