"""Rebuild OWN / FLOW's original stadium textures. Runtime uses the bundled images.

Run with Python 3, NumPy and Pillow. All marks, colours, seating and wear patterns
are generated here in pitch coordinates without photographs or club graphics.
"""
from pathlib import Path
import math
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ASSETS = Path(__file__).resolve().parents[1] / 'assets' / 'arena'
ASSETS.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(7204361)
W, H = 2048, 1328

def noise(cols, rows):
    samples = RNG.normal(128, 24, (rows, cols)).clip(0, 255).astype('uint8')
    image = Image.fromarray(samples).resize((W, H), Image.Resampling.BICUBIC)
    return (np.asarray(image).astype('float32') - 128) / 24

def save_turf():
    x = np.linspace(-52.5, 52.5, W, dtype='float32')[None, :]
    y = np.linspace(-34, 34, H, dtype='float32')[:, None]
    broad, clumps, tufts = noise(12, 9), noise(63, 41), noise(370, 235)
    fibre = RNG.normal(0, 1, (H, W)).astype('float32')
    # Short organic grain with a subtly raked direction; keep the grain soft at distance.
    grain = fibre + .65*np.roll(fibre, (1, 1), (0, 1)) + .3*np.roll(fibre, (2, 1), (0, 1))
    lane = np.tanh(np.sin(np.pi * (x + 52.5 + .09*broad) / 6.56)*5)
    sewing = np.sin((y + .05*clumps)*18) * .35
    field_light = 9*np.exp(-((x+21)/49)**2-((y-7)/30)**2)
    north_shade = -6.5*np.clip((-y - 23 + .09*x)/11, 0, 1)
    shade = 5.8*lane + 2.1*broad + 1.75*clumps + 1.3*tufts + 2.5*grain + sewing + field_light + north_shade
    goal_wear = np.exp(-((52.0-np.abs(x))/5.2)**2 - (y/5.3)**2)
    centre_wear = np.exp(-(x/6)**2 - (y/5.3)**2)*.27
    wear = np.clip((goal_wear+centre_wear) * (.73+.17*clumps+.08*tufts), 0, .94)
    turf = np.stack([60 + .87*shade + 32*wear, 106 + shade + 4*wear,
                     64 + .62*shade - 16*wear], axis=2)
    Image.fromarray(turf.clip(0,255).astype('uint8')).save(ASSETS/'playing-surface.webp', quality=91, method=5)
    # This small repeating map supplies close-camera directional blade normals via bump mapping.
    seed = RNG.normal(126, 27, (256,256)).astype('float32')
    bump = .48*seed + .34*np.roll(seed,(1,1),(0,1)) + .18*np.roll(seed,(2,1),(0,1))
    Image.fromarray(bump.clip(0,255).astype('uint8')).save(ASSETS/'blade-relief.webp', lossless=True)

def save_terrace():
    rng = random.Random(271902)
    width, height, row_height = 2048, 192, 20
    image = Image.new('RGB',(width,height),'#26383f')
    draw = ImageDraw.Draw(image)
    coats = [(49,83,99),(104,104,101),(132,118,100),(132,149,152),(66,90,97),(116,80,76),(51,70,76),(146,137,122),(65,106,117),(183,166,144)]
    skin = [(178,132,105),(140,99,74),(200,158,124),(120,86,71),(188,144,121)]
    for row in range(9):
        y = row*row_height+10
        draw.rectangle((0,y,width,y+row_height),fill=(44+row,58+row,64+row))
        draw.line((0,y+row_height-1,width,y+row_height-1),fill='#84908c',width=2)
        draw.line((0,y+row_height-3,width,y+row_height-3),fill='#253a42',width=3)
        for col in range(184):
            x=col*11 + (row%2)*3
            aisle=(col+7)%39
            if aisle < 3 or (row>=6 and col in range(84,93)):
                draw.rectangle((x,y-1,x+11,y+row_height-5),fill='#536164')
                continue
            chair = rng.choice(('#39515d','#455d66','#405661','#425b64'))
            draw.rounded_rectangle((x+1,y+4,x+8,y+15),radius=2,fill=chair)
            draw.line((x+2,y+15,x+9,y+15),fill='#233942',width=2)
            if rng.random()>.79: continue
            px=x+rng.choice((4,5,6)); base=y+rng.randint(11,13)
            coat=rng.choice(coats); highlight=tuple(min(255,c+15) for c in coat)
            draw.ellipse((px-4,base-1,px+5,base+4),fill='#213039')
            draw.polygon([(px-1,base-9),(px+2,base-9),(px+4,base-6),(px+4,base-1),(px-4,base-1),(px-3,base-6)],fill=coat)
            draw.line((px-2,base-6,px-3,base-3),fill=highlight)
            draw.ellipse((px-2,base-13,px+2,base-8),fill=rng.choice(skin))
            draw.arc((px-2,base-13,px+2,base-9),170,350,fill='#403a32',width=2)
        if row in (3,7):
            draw.line((0,y+15,width,y+15), fill='#71868a')
    draw.rectangle((0,0,width,4),fill='#182c35')
    image.save(ASSETS/'home-terrace.webp', quality=91, method=5)

def save_board():
    image=Image.new('RGB',(3072,24),'#193a43')
    draw=ImageDraw.Draw(image)
    try:
        font=ImageFont.truetype('DejaVuSans-Bold.ttf',15)
    except OSError:
        font=ImageFont.load_default(size=15)
    for i in range(8):
        x=i*384
        draw.rectangle((x,0,x+383,23),fill='#234c50' if i%2 else '#193c46')
        draw.line((x,1,x+383,1),fill='#5d8b82')
        draw.polygon([(x+14,16),(x+21,6),(x+26,6),(x+19,16)],fill='#9cbeae')
        label='OWN  /  FLOW' if i%2==0 else 'TRAINING GROUND'
        draw.text((x+205,12),label,font=font,anchor='mm',fill='#c2d5ce')
    image.save(ASSETS/'perimeter-board.webp',lossless=True)

if __name__ == '__main__':
    save_turf()
    save_terrace()
    save_board()
