import {GroundSimulation,scenarioDesign,validateDesign,topology} from './ground-simulation.js';
import {link,wireTemplate,compileWires,validateLayout} from './ground-design.js';
import {boardPage,boardContents,wirePreview} from './ground-board.js';
import {designStrip,tuning,networkPanel,analysisPanel,tr,escapeHtml,choose} from './ground-panels.js';
import {fieldView,updateField,compareView,drawComparison} from './ground-view.js';
import {validateTactic} from './engine.js';
import {download} from './storage.js';

const storageKey='flow.ground.v12';
const local=(root,selector)=>root?.querySelector(selector);
export class GroundStudio {
  constructor(hooks) {
    this.hooks=hooks;
    this.design=scenarioDesign();
    try{
      const saved=JSON.parse(localStorage.getItem(storageKey));
      if(saved)this.design=validateDesign(saved);
    }catch{} // A malformed local draft falls back to the first exercise.
    this.tab='field';
    this.camera='tactical';
    this.selected=7;
    this.speed=1;
    this.comparison='controllers';
    this.modeIndex=-1;
    this.firstNode=null;
    this.pending=null;
    this.active=false;
    this.running=false;
    this.report=null;
    this.rosterOverride=null;
    this.worker=null;
  }
  get lang(){return this.hooks.lang();}
  get root(){return document.getElementById('ground-studio');}
  get tactic(){return this.rosterOverride??this.hooks.squad();}
  enter(){
    const signature=JSON.stringify(this.tactic);
    if(!this.active && (!this.sim || signature!==this.squadSignature)){
      this.report=null;
      this.resetTrial();
    }
    this.active=true;
  }
  leave(){
    this.pause();this.active=false;this.abandonWorker();this.drag=null;
  }
  pause(){
    this.running=false;
    if(this.timer)clearInterval(this.timer);
    this.timer=null;
  }
  abandonWorker(){this.worker?.terminate();this.worker=null;}
  persist(){
    try{localStorage.setItem(storageKey,JSON.stringify(this.design));}catch{}
  }
  resetTrial() {
    this.pause();
    this.squadSignature=JSON.stringify(this.tactic);
    this.sim=compileWires(this.design).valid?new GroundSimulation(this.design,this.tactic):null;
  }
  refresh(){
    if(!this.active)return;
    this.detailsOpen=local(this.root,'.ground-tuning details')?.open??this.detailsOpen;
    this.hooks.render();
  }
  change(mutator, rosterOverride=this.rosterOverride){
    const next=structuredClone(this.design);
    mutator(next);
    const checked=validateDesign(next);
    const sim=compileWires(checked).valid?new GroundSimulation(checked,rosterOverride??this.hooks.squad()):null;
    this.pause();this.abandonWorker();
    this.rosterOverride=rosterOverride;this.squadSignature=JSON.stringify(this.tactic);
    this.design=checked;this.sim=sim;this.report=null;
    this.pending=null;this.firstNode=null;
    this.persist();this.refresh();
  }
  select(id){
    if(!Number.isInteger(id)||id<0||id>10)return;
    this.selected=id;this.refresh();
  }
  error(err) {
    const L=tr(this.lang);
    const messages={
      invalid_wire:L('This output cannot drive that socket. Choose a compatible blue port.','该输出不能接入这个端口，请选择兼容的蓝色端口。'),
      incomplete_wires:L('Reconnect the missing signal path in Wiring.','请先在接线台接通缺失的信号链。'),
      controller_bypassed:L('Reconnect the controller before comparing controller types.','请先接入控制器，再比较控制器类型。'),
    };
    this.hooks.toast(messages[err.message]||L('Check the design, bounds or file format.','请检查设计、参数范围或文件格式。'));
  }
  webpage(){
    const L=tr(this.lang),d=this.design;
    const tabs=[['field','Training pitch','球场演示'],['wiring','Wiring desk','拖拽接线'],['poles','Transfer & poles','传递函数与极点'],['compare','Compare designs','配对评测']];
    let content;
    if(this.tab==='field')content=fieldView(this);
    if(this.tab==='wiring')content=`<div class="ground-stack">${boardPage(d,this.lang,this.pending)}<div class="ground-low-grid">${networkPanel(d,this.tactic,this.lang,this.firstNode)}${tuning(d,this.lang)}</div></div>`;
    if(this.tab==='poles')content=analysisPanel(d,this.lang,this.modeIndex);
    if(this.tab==='compare')content=compareView(this);
    const deployed=this.hooks.squad().tracker?.type?.toUpperCase();
    return `<div id="ground-studio"><div class="ground-heading"><div><span class="eyebrow">OWN / FLOW  ·  SYSTEMS ENGINEERING</span><h1>${L('Control Ground','控制训练场')}</h1>
      <p>${L('Give eleven players a reference. Wire their feedback and follow what each controller actually does.','给 11 名球员一个参考位移，接入反馈，观察每个控制器产生的实际运动。')}</p></div>
      <div class="ground-file-actions">${choose("squad",L("Training squad","训练阵容"),[...this.hooks.teams(),...(this.rosterOverride?[["file",this.rosterOverride.teamName]]:[])],this.rosterOverride?"file":this.hooks.team())}<button data-g-action="save-design">${L('Export design','导出设计')}</button><button data-g-action="load-design">${L('Import design','导入设计')}</button><input type="file" id="ground-file" accept=".json,application/json" hidden></div></div>
      <div class="tabs ground-tabs" role="tablist">${tabs.map(([id,en,zh])=>`<button role="tab" aria-selected="${id===this.tab}" class="tab ${id===this.tab?'active':''}" data-g-action="tab" data-value="${id}">${L(en,zh)}</button>`).join('')}</div>
      ${designStrip(d,this.lang)}${content}
      <section class="ground-deploy"><div><span class="eyebrow">MATCH APPLICATION</span><h3>${L('Use this controller in a match','让控制器进入比赛')}</h3>
      <p>${L('The selected team uses these parameters and local feedback filters for the role-tracking term. The match supplies moving role targets, neighbour relations, football tasks and physical limits.','将控制器参数与本地反馈滤波用于所选球队的角色跟踪项。比赛引擎提供移动角色参考、邻居关系、足球任务和运动约束。')}</p>
      <small>${escapeHtml(this.hooks.squad().teamName)} · ${deployed?L('Active tracker','已启用跟踪器')+' '+deployed:L('Standard role tracking','常规角色跟踪')}</small></div>
      <div class="ground-pills"><button data-g-action="apply" ${this.sim?'':'disabled'}>${L('Apply role tracker','应用角色跟踪器')}</button>${deployed?`<button data-g-action="remove">${L('Restore standard tracking','恢复常规跟踪')}</button><button data-action="nav" data-page="match">${L('Watch match','观看比赛')}</button><button data-action="ground-ab">${L('Match A/B','比赛消融对照')}</button>`:''}</div></section></div>`;
  }
  mount(){
    const root=this.root;if(!root)return;
    if(this.detailsOpen&&local(root,'.ground-tuning details'))local(root,'.ground-tuning details').open=true;
    root.addEventListener('click',e=>{try{this.click(e);}catch(err){this.error(err);}});
    root.addEventListener('change',e=>{this.changeEvent(e).catch(err=>this.error(err));});
    root.addEventListener('input',e=>{
      if(e.target.type==='range'){
        const output=e.target.closest('label')?.querySelector('output');
        if(output)output.textContent=`${e.target.value} ${e.target.dataset.unit||''}`;
      }
    });
    root.addEventListener('pointerdown',e=>this.pointerDown(e));
    root.addEventListener('pointermove',e=>this.pointerMove(e));
    root.addEventListener('pointerup',e=>this.pointerUp(e));
    root.addEventListener('pointercancel',()=>{this.drag=null;this.redrawBoard();});
    root.addEventListener('keydown',e=>this.key(e));
    if(this.tab==='field')updateField(this);
    if(this.tab==='compare')drawComparison(this);
  }
  paint(){
    if(!this.active||this.tab!=='field'||!this.sim)return;
    this.hooks.scene(this.sim.snapshot(this.running));
    updateField(this);
  }
  run(){
    if(!this.sim)throw Error('incomplete_wires');
    if(this.running){this.pause();this.paint();return;}
    if(this.sim.stopReason)this.resetTrial();
    this.running=true;
    let last=performance.now(),accumulated=0;
    this.timer=setInterval(()=>{
      if(!this.active||document.hidden){this.pause();this.paint();return;}
      const now=performance.now();
      accumulated+=Math.min(.5,(now-last)/1000)*this.speed;last=now;
      let changed=false;
      try{
        while(accumulated+1e-9>=.1&&!this.sim.stopReason){this.sim.step();accumulated-=.1;changed=true;}
        if(this.sim.stopReason)this.pause();
        if(changed)this.paint();
      }catch(error){this.pause();this.error(error);}
    },45);
    this.paint();
  }
  compare(){
    if(!this.sim)throw Error('incomplete_wires');
    if(this.comparison==='controllers'&&this.design.wires['P.in']==='E')throw Error('controller_bypassed');
    this.abandonWorker();this.report=null;
    const worker=new Worker('./ground-worker.js',{type:'module'});
    this.worker=worker;this.refresh();
    worker.onmessage=({data})=>{
      if(this.worker!==worker)return;
      if(data.type==='progress'){
        const progress=local(this.root,'#ground-progress');
        if(progress)progress.textContent=`${Math.round(data.value*100)}%`;
        return;
      }
      this.abandonWorker();
      if(data.type==='result')this.report=data.result;
      else this.error(Error(data.message));
      this.refresh();
    };
    worker.onerror=()=>{this.abandonWorker();this.error(Error('worker'));this.refresh();};
    worker.postMessage({design:this.design,tactic:this.tactic,comparison:this.comparison});
  }
  showTab(tab){this.pause();this.pending=null;this.firstNode=null;this.tab=tab;this.refresh();}
  click(e){
    const target=e.target.closest('[data-g-action],[data-wire-out],[data-wire-in],[data-wire-remove],[data-g-node]');
    if(!target)return;
    if(target.hasAttribute('data-wire-out')){
      this.pending=target.dataset.wireOut;this.redrawBoard();
      const selector=local(this.root,'#ground-source');if(selector)selector.value=this.pending;
      this.status(tr(this.lang)('Choose a blue destination port.','请选择蓝色输入端。'));return;
    }
    if(target.hasAttribute('data-wire-in')){
      if(!this.pending){this.status(tr(this.lang)('Select an output port first.','请先选择绿色输出端。'));return;}
      this.connect(this.pending,target.dataset.wireIn);return;
    }
    if(target.hasAttribute('data-wire-remove')){this.change(d=>{d.wires[target.dataset.wireRemove]=null;});return;}
    if(target.hasAttribute('data-g-node')){
      const id=Number(target.dataset.gNode);
      if(this.firstNode===null){this.firstNode=id;this.refresh();return;}
      if(this.firstNode===id){this.firstNode=null;this.refresh();return;}
      const first=this.firstNode;
      this.change(d=>{
        const idx=d.edges.findIndex(edge=>edge.includes(id)&&edge.includes(first));
        if(idx<0)d.edges.push([first,id]);else d.edges.splice(idx,1);
        d.network='custom';
      });return;
    }
    const action=target.dataset.gAction,value=target.dataset.value;
    switch(action){
      case 'tab':this.showTab(value);break;
      case 'show-wiring':this.showTab('wiring');break;
      case 'show-poles':this.showTab('poles');break;
      case 'controller':this.change(d=>{d.control.type=value;d.wires['C.in']='E';d.wires['P.in']='C';});break;
      case 'run':this.run();break;
      case 'step':this.pause();this.sim.step();this.paint();break;
      case 'finish':this.pause();this.sim.finish();this.paint();break;
      case 'reset':this.resetTrial();this.paint();break;
      case 'wire-template':this.change(d=>{d.wires=wireTemplate(value);d.polarity=value==='positive'?1:-1;});break;
      case 'wire-connect':this.connect(local(this.root,'#ground-source').value,local(this.root,'#ground-destination').value);break;
      case 'wire-disconnect':this.change(d=>{d.wires[local(this.root,'#ground-destination').value]=null;});break;
      case 'compare':this.compare();break;
      case 'export-result':if(this.report)download('OWN_FLOW_Ground_Results.json',this.report);break;
      case 'save-design':download('OWN_FLOW_Ground_Experiment.json',{kind:'FlowGroundExperiment',schema:1,design:this.design,squad:this.tactic});break;
      case 'load-design':local(this.root,'#ground-file').click();break;
      case 'apply':if(this.sim)this.hooks.apply(compileWires(this.design).config);break;
      case 'remove':this.hooks.apply(null);break;
    }
  }
  async changeEvent(event){
    const el=event.target,key=el.dataset.groundKey;
    if(el.id==='ground-file'){
      const file=el.files[0];if(!file)return;
      if(file.size>262144)throw Error('design_format');
      const record=JSON.parse(await file.text());
      const wrapped=record.kind==='FlowGroundExperiment'&&record.schema===1;
      const design=validateDesign(wrapped?record.design:record);
      const squad=wrapped?validateTactic(record.squad):null;
      if(!this.active)return;
      this.change(d=>Object.assign(d,design),squad);
      this.hooks.toast(tr(this.lang)('Experiment loaded','训练设计已加载'));return;
    }
    if(!key)return;
    const val=el.value;
    if(key==='squad'){
      if(val==='file')return;
      this.rosterOverride=null;
      this.hooks.chooseTeam(Number(val));
      this.report=null;this.abandonWorker();this.resetTrial();this.refresh();return;
    }
    if(key==='selected'){this.select(Number(val));return;}
    if(key==='modeIndex'){this.modeIndex=Number(val);this.refresh();return;}
    if(key==='camera'){this.camera=val;this.refresh();return;}
    if(key==='speed'){this.speed=Number(val);return;}
    if(key==='comparison'){this.abandonWorker();this.report=null;this.comparison=val;this.refresh();return;}
    if(key==='scenario'){
      this.change(d=>Object.assign(d,scenarioDesign(val)),null);return;
    }
    this.change(d=>{
      if(key==='network'){
        if(val==='custom')return;
        d.network=val;d.edges=val==='team'?structuredClone(this.tactic.commEdges):topology(val);
      }else if(key==='pins'){d.pins=val;}
      else if(key.startsWith('control.')){d.control[key.slice(8)]=Number(val);}
      else{d[key]=Number(val);}
    });
  }
  connect(source,dest){this.change(d=>{d.wires=link(d.wires,source,dest);});}
  status(text){const el=local(this.root,'#ground-wire-status');if(el)el.textContent=text;}
  redrawBoard(){const board=local(this.root,'#ground-board');if(board)board.innerHTML=boardContents(this.design,this.lang,this.pending);}
  coordinates(event,svg){
    const p=svg.createSVGPoint();p.x=event.clientX;p.y=event.clientY;
    const mapped=p.matrixTransform(svg.getScreenCTM().inverse());
    return [mapped.x,mapped.y];
  }
  pointerDown(e){
    const svg=e.target.closest('#ground-board');if(!svg||e.button!==0)return;
    const handle=e.target.closest('[data-handle]'),out=e.target.closest('[data-wire-out]');
    if(!handle&&!out)return;
    this.drag={svg,pointer:e.pointerId,start:this.coordinates(e,svg),source:out?.dataset.wireOut,key:handle?.dataset.handle,moved:false};
    if(handle)this.drag.origin=[...this.design.layout[this.drag.key]];
  }
  pointerMove(e){
    const drag=this.drag;if(!drag||drag.pointer!==e.pointerId)return;
    const point=this.coordinates(e,drag.svg),dx=point[0]-drag.start[0],dy=point[1]-drag.start[1];
    if(!drag.moved&&Math.hypot(dx,dy)<4)return;
    if(!drag.moved){drag.moved=true;drag.svg.setPointerCapture(e.pointerId);}
    if(drag.key){
      this.design.layout=validateLayout({...this.design.layout,[drag.key]:[drag.origin[0]+dx,drag.origin[1]+dy]});
      this.redrawBoard();
    }else local(drag.svg,'#ground-cable')?.setAttribute('d',wirePreview(this.design.layout,drag.source,point));
  }
  pointerUp(e){
    const drag=this.drag;if(!drag||drag.pointer!==e.pointerId)return;
    this.drag=null;if(!drag.moved)return;
    if(drag.svg.hasPointerCapture(e.pointerId))drag.svg.releasePointerCapture(e.pointerId);
    if(drag.key){this.persist();return;}
    const dest=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-wire-in]');
    if(dest){
      try{this.connect(drag.source,dest.dataset.wireIn);}catch(error){this.error(error);this.redrawBoard();}
    }else{this.pending=drag.source;this.redrawBoard();}
  }
  key(e) {
    const handle=e.target.closest('[data-handle]');
    if(handle&&['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){
      e.preventDefault();
      const key=handle.dataset.handle,[x,y]=this.design.layout[key],amount=e.shiftKey?16:4;
      this.design.layout=validateLayout({...this.design.layout,[key]:[x+amount*((e.key==='ArrowRight')-(e.key==='ArrowLeft')),y+amount*((e.key==='ArrowDown')-(e.key==='ArrowUp'))]});
      this.redrawBoard();local(this.root,'[data-handle="'+key+'"]')?.focus();this.persist();return;
    }
    if((e.key==='Enter'||e.key===' ')&&e.target.closest('svg [role=button]')){e.preventDefault();this.click(e);}
  }
}
