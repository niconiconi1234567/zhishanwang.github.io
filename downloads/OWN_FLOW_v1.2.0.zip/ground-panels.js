import {analyzeLoop,analyzeNetwork,zohPlant} from './control-kernel.js';
import {compileWires,SCENARIOS} from './ground-design.js';
import {modalGains,pinWeights} from './ground-simulation.js';
import {FORMATIONS} from './engine.js';

export const escapeHtml=text=>String(text??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
export const fmt=(value,digits=3)=>Number.isFinite(value)?Number(value.toPrecision(digits)).toString():'—';
export const tr=lang=>(en,zh)=>lang==='zh'?zh:en;
export function choose(key,label,items,current) {
  return `<label class="ground-control"><span>${label}</span><select aria-label="${escapeHtml(label)}" data-ground-key="${key}">${items.map(([value,name])=>`<option value="${escapeHtml(value)}" ${String(value)===String(current)?'selected':''}>${escapeHtml(name)}</option>`).join('')}</select></label>`;
}
function slider(key,label,value,min,max,step,unit='') {
  return `<label class="ground-slider"><span>${label}<output>${fmt(value,4)} ${unit}</output></span><input aria-label="${escapeHtml(label)}" type="range" data-ground-key="${key}" data-unit="${unit}" value="${value}" min="${min}" max="${max}" step="${step}"></label>`;
}
export function tuning(design,lang) {
  const L=tr(lang),c=design.control;
  const settings=[
    ['p','kp','Kp',.05,5,.05],['pid','kp','Kp',.05,5,.05],['pid','ki','Ki',0,2,.05],['pid','kd','Kd',0,1,.01],['pid','derivativeTau',L('Derivative filter τ','微分滤波 τ'),.02,1,.02],
    ['adrc','wc',L('Control bandwidth ωc','控制带宽 ωc'),.25,4,.05],['adrc','wo',L('Observer bandwidth ωo','观测器带宽 ωo'),1,15,.25],['adrc','b0',L('Estimated input gain b₀','估计输入增益 b₀'),.4,2,.05],
    ['mpc','horizon',L('Prediction steps N','预测步数 N'),2,20,1],['mpc','q',L('Tracking weight Q','跟踪权重 Q'),.1,5,.1],['mpc','r',L('Input penalty R','输入代价 R'),.02,2,.02],
  ];
  const descriptions={
    p:L('The command follows the instantaneous error.','按当前误差给出比例指令。'),
    pid:L('Filtered error derivative and an integral with anti-windup.','累积误差修正稳态偏差，微分项带滤波，积分项带抗饱和处理。'),
    adrc:L('A two-state observer estimates the output and total disturbance.','两状态扩张观测器估计输出与总扰动，并进行补偿。'),
    mpc:L('At each sample, solve a bounded finite-horizon quadratic tracking problem and apply the first move.','每个采样时刻求解带输入边界的有限时域二次优化，只执行第一步。'),
  };
  return `<section class="panel ground-card ground-tuning"><span class="eyebrow">CONTROLLER</span><h2>${L('Tune a controller','调节控制器')}</h2>
    <div class="ground-pills control-types">${['p','pid','adrc','mpc'].map(type=>`<button data-g-action="controller" data-value="${type}" aria-pressed="${type===c.type}" class="${type===c.type?'selected':''}">${type.toUpperCase()}</button>`).join('')}</div>
    <p class="ground-guide">${descriptions[c.type]}</p>
    ${settings.filter(([type])=>type===c.type).map(([,key,name,min,max,step])=>slider('control.'+key,name,c[key],min,max,step)).join('')}
    ${slider('control.limit',L('Input bound ±U','输入限幅 ±U'),c.limit,1,20,.5,'m/s')}
    <details class="ground-details"><summary>${L('Plant, filters and squad','对象、滤波与阵容参数')}</summary>
      <p class="ground-guide">ẋ = ax + bu · T<sub>s</sub> = 0.1 s</p>
      ${slider('control.a',L('Free dynamics a','自然动态 a'),c.a,-1,1,.05,'s⁻¹')}
      ${slider('control.b',L('Nominal gain b','名义增益 b'),c.b,.4,2,.05)}
      ${slider('refTime',L('Prefilter time τF','参考滤波 τF'),design.refTime,.05,2,.05,'s')}
      ${slider('sensorTime',L('Sensor time τH','测量滤波 τH'),design.sensorTime,.05,2,.05,'s')}
      ${slider('heterogeneity',L('Squad heterogeneity','阵容异构强度'),design.heterogeneity,0,1,.05)}
      ${slider('disturbance',L('Input disturbance, 5–12 s','输入扰动，5–12 秒'),design.disturbance,0,4,.1,'m/s')}
      <p class="ground-guide">${L('At full strength, each input gain scales with acceleration and the input bound scales with maximum speed relative to the squad mean. F and H time constants apply when wired in.','异构强度为 1 时，Bᵢ 按球员加速度相对全队均值缩放，Uᵢ 按最高速度相对均值缩放。F、H 接上线时使用对应滤波时间常数。')}</p>
    </details></section>`;
}
export function designStrip(d,lang) {
  const L=tr(lang);
  return `<div class="ground-scenario-strip">${choose('scenario',L('Starting exercise','起始示例'),Object.entries(SCENARIOS).map(([k,v])=>[k,v.title[lang==='zh'?1:0]]),d.scenario)}
    ${d.pins==='none'?`<div class="ground-guide">${L('Free consensus · the initial mean is the evaluation reference.','自由共识 · 以初始全队均值作为评价参考。')}</div>`:slider('target',L('Requested displacement','指定位移'),d.target,-12,12,.5,'m')}
    ${choose('pins',L('Who receives r?','谁接收参考值？'),[['all',L('All 11 players','全队锚定')],['leader',L('Captain #01 only','仅队长 #01')],['none',L('No reference anchor','无参考锚点')]],d.pins)}
    <label class="ground-control seed"><span>${L('Seed','种子')}</span><input type="number" min="1" max="2147483647" data-ground-key="seed" value="${d.seed}"></label></div>`;
}
export function networkPanel(d,tactic,lang,first) {
  const L=tr(lang),pins=pinWeights(d);
  const positions=FORMATIONS[tactic.formation].map(([x,y])=>[159+x*2.65,99-y*2.48]);
  const wires=d.edges.map(([i,j])=>`<line x1="${positions[i][0]}" y1="${positions[i][1]}" x2="${positions[j][0]}" y2="${positions[j][1]}"/>`).join('');
  const nodes=positions.map(([x,y],i)=>`<g tabindex="0" role="button" data-g-node="${i}" aria-label="${L('Link player','编辑连接 球员')} ${i+1}" class="${first===i?'armed':''}">
    ${pins[i]?`<circle class="pin" cx="${x}" cy="${y}" r="12"/>`:''}<circle cx="${x}" cy="${y}" r="9"/><text x="${x}" y="${y+3.5}">${i+1}</text></g>`).join('');
  return `<section class="panel ground-card"><div class="ground-section-title"><h2>${L('Design the 11-agent network','设计 11 人通信网络')}</h2><span class="ground-badge">${d.edges.length} ${L('links','条通信边')}</span></div>
    <div class="ground-network-config"><svg viewBox="0 0 318 198" class="ground-network" role="group" aria-label="${L('Edit communication links','编辑通信边')}"><rect x="5" y="5" width="308" height="188" rx="8"/><path d="M159 5v188" stroke="#476656"/><g class="links">${wires}</g>${nodes}</svg>
    <div>${choose('network',L('Topology','拓扑'),[['mesh',L('Mesh','网状')],['ring',L('Ring','环形')],['star',L('Star','星形')],['full',L('Complete','全连接')],['split',L('Two components','两个连通分量')],['none',L('No links','无边')],['team',L('Current tactic graph','当前战术通信图')],...(d.network==='custom'?[['custom',L('Custom','自定义')]]:[])],d.network)}
    ${slider('coupling',L('Edge weight g','边权重 g'),d.coupling,0,2,.05)}
    <p class="ground-guide" id="ground-node-status">${first===null?L('Tap two players to toggle their link. A gold ring marks a reference anchor.','依次点击两名球员添加或移除通信边。金色圆环表示参考锚点。'):L('Select the other end for #','请选择另一端，已选球员 #')+(first+1)}</p></div></div></section>`;
}
function polynomial(coefficients) {
  const degree=coefficients.length-1;
  const terms=[];
  coefficients.forEach((value,i)=>{
    if(Math.abs(value)<1e-10)return;
    const exponent=degree-i,mag=Math.abs(value);
    const number=exponent && Math.abs(mag-1)<1e-9?'':escapeHtml(fmt(mag,5));
    const variable=exponent>1?`z<sup>${exponent}</sup>`:exponent===1?'z':'';
    const sign=value<0?'−':terms.length?'+':'';
    terms.push(`${sign} ${number}${variable}`);
  });
  return terms.join(' ')||'0';
}
function rootText(value) {
  if(Math.hypot(value.re,value.im)<1e-10)return '0';
  return Math.abs(value.im)<1e-7?fmt(value.re,5):`${fmt(value.re,4)} ${value.im<0?'−':'+'} ${fmt(Math.abs(value.im),4)}j`;
}
function stabilityText(state,L) {
  return {stable:L('Schur stable','渐近稳定'),boundary:L('Unit-circle boundary','单位圆边界'),unstable:L('Unstable','不稳定'),unresolved:L('Numerically unresolved','数值判定未定')}[state];
}
function polePlot(model,lang) {
  const L=tr(lang);
  const extent=Math.max(1.18,...[...model.internalPoles,...model.zeros].map(p=>Math.hypot(p.re,p.im)*1.18));
  const scale=104/extent;
  const place=(p,zero)=>{
    const x=135+scale*p.re,y=122-scale*p.im;
    return zero?`<circle cx="${x}" cy="${y}" r="5" fill="none" stroke="#8fc7fb" stroke-width="2"><title>${rootText(p)}</title></circle>`:
      `<path d="M${x-4} ${y-4}l8 8m0 -8l-8 8" stroke="#ffa88f" stroke-width="2"><title>${rootText(p)}</title></path>`;
  };
  return `<svg class="ground-poleplot" viewBox="0 0 275 250" role="img" aria-label="${L('Poles and zeros on the complex plane','零极点与单位圆')}"><path d="M16 122H259M135 13V232" stroke="#40515e"/>
    <circle cx="135" cy="122" r="${scale}" fill="#83d7b50b" stroke="#78bca3" stroke-dasharray="4 4"/>
    <g fill="#9db2c0" font-size="10"><text x="244" y="116">Re</text><text x="141" y="18">Im</text><text x="${135+scale}" y="140">1</text><text x="${128-scale}" y="140">−1</text></g>
    ${model.internalPoles.map(p=>place(p,false)).join('')}${model.zeros.map(p=>place(p,true)).join('')}</svg>`;
}
export function analysisPanel(d,lang,modeIndex) {
  const L=tr(lang),chain=compileWires(d);
  if(!chain.valid)return `<div class="ground-alert">${L('Complete the main signal path first.','请先接通主信号链。')} ${chain.missing.join(' · ')}</div>`;
  const c=chain.config,lambdas=modalGains(d);
  const network=analyzeNetwork(c,lambdas);
  const lambda=modeIndex<0?1:lambdas[modeIndex];
  const loop=analyzeLoop(c,{lambda,inputGain:1}),p=zohPlant(c.a,c.b,c.dt);
  const zeroModes=lambdas.filter(v=>v<1e-8).length;
  const modeRows=network.modes.map((m,i)=>`<tr><td>${String(i+1).padStart(2,'0')}</td><td>${fmt(m.lambda,5)}</td><td>${fmt(m.radius,5)}</td><td>${stabilityText(m.stability,L)}</td></tr>`).join('');
  return `<div class="ground-analysis-grid"><section class="panel ground-card"><div class="ground-section-title"><div><span class="eyebrow">TRANSFER FUNCTION</span><h2>${L('From wiring to equations','接线对应的方程')}</h2></div><span class="ground-badge">T<sub>s</sub> = 0.1 s</span></div>
    ${choose('modeIndex',L('Transfer channel','传递通道'),[[-1,L('Isolated pinned player, λ = 1','独立锚定球员，λ = 1')],...lambdas.map((v,i)=>[i,`${L('Network mode','网络模态')} ${i+1} · λ = ${fmt(v,4)}`])],modeIndex)}
    <div class="ground-equation"><small>${L('Continuous plant / exact sampled plant','连续对象与精确采样对象')}</small><div>ẋ = ${fmt(c.a)}x + ${fmt(c.b)}u</div><div>x[k+1] = ${fmt(p.A,5)} x[k] + ${fmt(p.B,5)} u[k]</div><div>P(s) = ${fmt(c.b)} / (s ${c.a>=0?"−":"+"} ${fmt(Math.abs(c.a))})</div><div>P(z) = ${fmt(p.B,5)} / (z − ${fmt(p.A,5)})</div></div>
    <div class="ground-equation transfer"><small>${modeIndex<0?L('Closed-loop reference → position','参考到位置的闭环传递函数'):L('Modal reference injection → modal position','模态参考输入到模态位置的传递函数')}</small><div class="transfer-row"><b>T(z) =</b><span class="fraction"><span>${polynomial(loop.num)}</span><span>${polynomial(loop.den)}</span></span></div></div>
    <p class="ground-guide">${L('Zero initial state. For a graph mode, the displayed channel has unit modal injection. A common reference excites a mode in proportion to the projection of the anchor vector onto that eigenvector.','传递函数取零初态。模态通道取单位模态参考输入。实际公共指令对各模态的激励由锚点向量在该特征向量上的投影决定。')}</p>
    <dl class="ground-numbers"><div><dt>${L('Transfer poles','约分后极点')}</dt><dd>${loop.poles.map(rootText).join(' · ')||'∅'}</dd></div><div><dt>${L('Finite transfer zeros','有限传递零点')}</dt><dd>${loop.zeroTransfer?L('Zero map','零映射'):loop.zeros.map(rootText).join(' · ')||'∅'}</dd></div><div><dt>${L('Internal poles','全部内部极点')}</dt><dd>${loop.internalPoles.map(rootText).join(' · ')}</dd></div></dl></section>
    <section class="panel ground-card"><span class="eyebrow">Z PLANE</span><h2>${L('Internal stability','内部稳定性')}</h2>${polePlot(loop,lang)}
    <div class="ground-key"><i class="actual">×</i>${L('Internal poles','内部极点')} <i class="reference">○</i>${L('I/O zeros','传递零点')} · |z| = 1</div>
    <p class="ground-verdict ${loop.stability==='stable'?'':'warning'}">${stabilityText(loop.stability,L)} <small>ρ = ${fmt(loop.radius,5)}</small></p>
    <p class="ground-guide">${L('For this discrete linear realization, all internal poles must lie strictly inside the unit circle for asymptotic stability. Cancellation in the transfer function can hide internal dynamics.','该离散线性实现渐近稳定的条件是全部内部极点严格位于单位圆内。传递函数的极零相消可能隐藏内部动态。')}</p></section></div>
    <section class="panel ground-card"><div class="ground-section-title"><div><span class="eyebrow">TEAM MODES</span><h2>${L('11 network modes','11 个网络模态')}</h2></div><span class="ground-badge ${network.stability==='stable'?'':'warm'}">${stabilityText(network.stability,L)} · ρ ${fmt(network.radius,5)}</span></div>
    <p>${L('Nominal homogeneous plants, synchronous sampling, inactive limits.','名义条件为同质对象、同步采样、执行器未触发限幅。')} ${c.type==='mpc'?L('The MPC transfer function is local to the unconstrained region.','MPC 的线性传递函数对应约束未激活区域。'):''}</p>
    <p class="ground-guide">${L('Eigenvalues are from gL + D. The field run also includes the selected player gains, limits and disturbance.','特征值取自 gL + D。球场实验还执行已设置的个体增益、限幅与扰动。')} ${zeroModes?L(`There are ${zeroModes} unanchored zero modes.`,`其中有 ${zeroModes} 个未锚定的零模态。`):''}</p>
    <div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Mode','模态')}</th><th>λ(gL+D)</th><th>ρ(A<sub>cl</sub>)</th><th>${L('Status','判定')}</th></tr></thead><tbody>${modeRows}</tbody></table></div></section>`;
}
