import { VisualMotion, cameraFocus, cameraOffset, HIP_HEIGHT } from "./motion-visual.js";
import { ARENA_TEXTURES, appearanceFor, athleteVisible, selectedAthlete, trainingStrokes, pitchMarkings } from "./arena-visual.js";
import { paintSurface, clipProjectedPolygon, clipProjectedLine } from "./perspective-texture.js";
// Perspective software renderer: the same physical world, for devices without WebGL.
const add = (a, b) => a.map((v, i) => v + b[i]),
  sub = (a, b) => a.map((v, i) => v - b[i]),
  dot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0),
  unit = (a) => {
    let n = Math.hypot(...a);
    return a.map((v) => v / n);
  },
  cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
const pigment = new Map();
function lightingTones(hex) {
  if (pigment.has(hex)) return pigment.get(hex);
  const rgb = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
  const tint = (light, amount) => `rgb(${rgb.map((v, i) => Math.round(v + (light[i] - v) * amount)).join(',')})`;
  const tones = {light:tint([255,244,217],.24), shade:tint([24,37,45],.36)};
  if (pigment.size > 400) pigment.clear();
  pigment.set(hex, tones);
  return tones;
}

export class CanvasPitchRenderer {
  constructor(container, onSelect) {
    this.container = container;
    this.onSelect = onSelect;
    this.canvas = document.createElement("canvas");
    this.ctx = this.canvas.getContext("2d");
    this.canvas.setAttribute("role", "img");
    this.canvas.setAttribute(
      "aria-label",
      "Interactive perspective football field · compatibility renderer",
    );
    container.append(this.canvas);
    this.state = null;
    this.cameraMode = "broadcast";
    this.zoom = 1;
    this.focus = "overview";
    this.quality = "balanced";
    this.motion = new VisualMotion();
    this.look = {x:0,y:0};
    this.flags = {};
    this.scope = "selected";
    this.selected = 7;
    this.agentView = false;
    this.fps = 0;
    this.start = performance.now();
    this.frames = 0;
    this.positions = [];
    this.dead = false;
    this.cachedScene = document.createElement('canvas');
    this.arenaImages = {};
    for (const key of ['turf','terrace','board']) {
      const image = new Image();
      image.onload = () => { this.background = null; };
      image.src = ARENA_TEXTURES[key];
      this.arenaImages[key] = image;
    }
    this.label = document.createElement("div");
    this.label.className = "pitch-player-label";
    container.append(this.label);
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(container);
    this.canvas.addEventListener("pointerup", (e) => {
      const r = this.canvas.getBoundingClientRect();
      let chosen = null,
        best = 17;
      this.state?.players.forEach((p) => {
        if (!athleteVisible(this.state, p)) return;
        if (
          this.agentView &&
          p.id !== this.selected &&
          !selectedAthlete(this.state,this.selected)?.visible?.some((q) => q.id === p.id)
        )
          return;
        let v = this.project([p.x, 1, p.y]),
          d = Math.hypot(v.x - e.clientX + r.left, v.y - e.clientY + r.top);
        if (v.depth>0 && d < best) {
          chosen = p.id;
          best = d;
        }
      });
      if (chosen !== null) this.onSelect(chosen);
    });
    this.resize();
    this.frame();
  }
  resize() {
    this.w = this.container.clientWidth;
    this.h = this.container.clientHeight;
    if (!this.w || !this.h) return;
    let pr = Math.min(devicePixelRatio, this.quality === "detail" ? 2 : this.quality === "performance" ? 1 : 1.5);
    this.ratio = pr;
    this.canvas.width = Math.round(this.w * pr);
    this.canvas.height = Math.round(this.h * pr);
    this.canvas.style.width = this.w + "px";
    this.canvas.style.height = this.h + "px";
    this.setupCamera();
    this.background = null;
  }
  setupCamera() {
    const focus = this.look;
    const offset = cameraOffset(this.cameraMode, this.focus, this.w / this.h, this.zoom || 1);
    this.eye = [focus.x + offset[0], offset[1], focus.y + offset[2]];
    this.forward = unit(sub([focus.x, 0, focus.y], this.eye));
    this.right = unit(cross(this.forward, [0, 1, 0]));
    this.up = cross(this.right, this.forward);
    this.focal = this.h / (2 * Math.tan((42 * Math.PI) / 360));
  }
  project(point) {
    const dx=point[0]-this.eye[0],dy=point[1]-this.eye[1],dz=point[2]-this.eye[2];
    const depth=dx*this.forward[0]+dy*this.forward[1]+dz*this.forward[2];
    const divisor=Math.abs(depth)<1e-8?1e-8:depth;
    const clipX=this.w/2*depth+(dx*this.right[0]+dy*this.right[1]+dz*this.right[2])*this.focal;
    const clipY=this.h/2*depth-(dx*this.up[0]+dy*this.up[1]+dz*this.up[2])*this.focal;
    return {x:clipX/divisor,y:clipY/divisor,scale:this.focal/divisor,depth,clipX,clipY};
  }
  configure(opts) {
    let old = this.cameraMode + ":" + this.zoom + ":" + this.quality + ":" + this.focus;
    const oldSelected=this.selected;
    Object.assign(this, opts);
    if(this.state?.training && oldSelected!==this.selected) {
      this.trainingLines=trainingStrokes(this.state,selectedAthlete(this.state,this.selected)?.id);
    }
    if (old !== this.cameraMode + ":" + this.zoom + ":" + this.quality + ":" + this.focus) {
      this.resize();
      this.background = null;
    }
  }
  setState(s) {
    this.previous = this.state;
    this.received = performance.now();
    this.state = s;
    this.motion.receive(s, this.received);
    this.trainingLines=s.training?trainingStrokes(s,selectedAthlete(s,this.selected)?.id):null;
  }
  path(points, color, width = 1, fill = null, alpha = 1) {
    const ctx=this.ctx;
    let projected=points.map(point=>this.project(point));
    if(projected.length<2)return;
    const behind=projected.some(point=>point.depth<.5);
    if(behind && fill)projected=clipProjectedPolygon(projected);
    if(projected.length<2 || (fill && projected.length<3))return;
    ctx.globalAlpha=alpha;
    ctx.beginPath();
    if(behind && !fill){
      for(let i=1;i<projected.length;i++){
        const clipped=clipProjectedLine(projected[i-1],projected[i]);
        if(clipped){ctx.moveTo(clipped[0].x,clipped[0].y);ctx.lineTo(clipped[1].x,clipped[1].y);}
      }
    } else {
      ctx.moveTo(projected[0].x,projected[0].y);
      for(let i=1;i<projected.length;i++)ctx.lineTo(projected[i].x,projected[i].y);
    }
    if(fill){ctx.closePath();ctx.fillStyle=fill;ctx.fill();}
    if(color){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
    ctx.globalAlpha=1;
  }
  rect(x, z, w, d, y, color) {
    this.path(
      [
        [x, y, z],
        [x + w, y, z],
        [x + w, y, z + d],
        [x, y, z + d],
      ],
      null,
      0,
      color,
    );
  }
  ring(x, z, r, color, y = 0.03, width = 1, alpha = 1) {
    let pts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * 2 * Math.PI;
      pts.push([x + Math.cos(a) * r, y, z + Math.sin(a) * r]);
    }
    this.path(pts, color, width, null, alpha);
  }
  sphere(point, r, color) {
    const c = this.ctx,
      p = this.project(point);
    if(p.depth<=.5)return;
    c.beginPath();
    c.ellipse(p.x, p.y, r * p.scale, r * p.scale, 0, 0, Math.PI * 2);
    c.fillStyle = color;
    c.fill();
  }
  staticScene() {
    const c = this.ctx;
    const sky = c.createLinearGradient(0, 0, 0, this.h);
    sky.addColorStop(0, "#86999d");
    sky.addColorStop(.38, "#657e83");
    sky.addColorStop(1, "#374c46");
    c.fillStyle = sky;
    c.fillRect(0, 0, this.w, this.h);
    this.rect(-175,-155,350,250,-.4,'#56635f');
    this.rect(-77,-74,154,134,-.13,'#414b46');
    this.path([[-71,18,-74],[71,18,-74],[71,9.3,-57.6],[-71,9.3,-57.6]],null,0,'#40545c');
    paintSurface(this,this.arenaImages.terrace,[-71,18,-74],[142,0,0],[0,-8.7,16.4],4,2);
    this.path([[-70,9.3,-57.6],[70,9.3,-57.6],[70,8.2,-57.6],[-70,8.2,-57.6]],null,0,'#283f49');
    for (const side of [-1,1]) {
      const back=side*57, front=side*41;
      this.path([[-68,.3,front],[68,.3,front],[68,8.5,back],[-68,8.5,back]],null,0,'#3a4d56');
      paintSurface(this,this.arenaImages.terrace,[-68,8.5,back],[136,0,0],[0,-8.2,front-back],4,2);
      this.path([[-68,.3,front],[68,.3,front]],'#92a09e',1.2);
      this.rect(-69,back-side*.8,138,side*2.6,8.65,'#364a52');
      this.path([[-68,8.8,back],[68,8.8,back]],'#829393',1.1);
      // A low fascia and a shallow canopy make the end terraces read as architecture.
      const end=side*69, start=side*59;
      this.path([[start,.2,-40],[start,.2,40],[end,5.5,40],[end,5.5,-40]],null,0,'#3b5056');
      paintSurface(this,this.arenaImages.terrace,[end,5.5,-40],[0,0,80],[start-end,-5.3,0],4,2);
      this.rect(end-side*.45,-41,side*.9,82,5.55,'#627275');
    }
    // A narrow rear canopy and visible lattice masts anchor the far stand to
    // the skyline. The front edge sits behind the playing surface.
    this.path([[-72,21.8,-77],[72,21.8,-77],[72,21,-67],[-72,21,-67]],null,0,'#5a6a70');
    this.path([[-72,21,-67],[72,21,-67],[72,20.55,-67],[-72,20.55,-67]],null,0,'#354952');
    for(let x=-64;x<=66;x+=21){
      this.limb([x,18,-73],[x,21.65,-74],.16,'#68797d');
      this.limb([x,21.65,-74],[x,20.6,-67],.15,'#3b5158');
    }
    for(const x of [-59,59]){
      const z=-53;
      this.limb([x-.42,.6,z],[x-.14,20,z],.18,'#4c6068');
      this.limb([x+.42,.6,z],[x+.14,20,z],.18,'#73868a');
      for(let row=0;row<4;row++){
        this.limb([x-.36,4+row*3.5,z],[x+.30,7.5+row*3.5,z],.09,'#52666b');
      }
      this.path([[x-2.5,18.8,z],[x+2.5,18.8,z],[x+2.5,20.4,z],[x-2.5,20.4,z]],null,0,'#56676b');
      for(let lamp=0;lamp<5;lamp++){
        const left=x-2.32+lamp*.94;
        this.path([[left,19.1,z+.02],[left+.70,19.1,z+.02],[left+.70,20.07,z+.02],[left,20.07,z+.02]],null,0,'#d7e1d9');
      }
    }
    this.rect(-55,-36.4,110,72.8,-.02,'#3c6447');
    for (let z of [-38,38]) {
      this.path([[-61,0,z],[61,0,z],[61,.95,z],[-61,.95,z]],null,0,'#193a43');
      this.path([[-61,.97,z],[61,.97,z]],'#56988d',1);
      paintSurface(this,this.arenaImages.board,[-61,.95,z],[122,0,0],[0,-.95,0],6,1);
    }
    this.rect(-52.5,-34,105,68,0,'#46724a');
    const cols=this.quality==='performance'?4:this.quality==='detail'?8:6;
    const rows=this.quality==='detail'?6:4;
    paintSurface(this,this.arenaImages.turf,[-52.5,.001,-34],[105,0,0],[0,0,68],cols,rows);
    for(const path of pitchMarkings()) {
      const middle=path[Math.floor(path.length/2)];
      const width=Math.max(.82,.12*this.project([middle[0],.025,middle[1]]).scale);
      this.path(path.map(([x,y])=>[x,.025,y]),'#dbe3cd',width,null,.89);
    }
    for(const x of [-41.5,0,41.5])this.sphere([x,.035,0],.105,'#dbe3cd');
    for(const s of [-1,1]){
      this.drawGoal(s);
      for (let y of [-33.8, 33.8]) {
        this.path(
          [
            [s * 52.3, 0, y],
            [s * 52.3, 1.6, y],
          ],
          "#ebedd5",
          1,
        );
        this.path(
          [
            [s * 52.3, 1.6, y],
            [s * 52.3 + 0.4, 1.6, y],
            [s * 52.3 + 0.4, 1.3, y],
            [s * 52.3, 1.3, y],
          ],
          null,
          0,
          "#e9c867",
        );
      }
    }
    this.background = this.cachedScene;
    if(this.background.width!==this.canvas.width)this.background.width=this.canvas.width;
    if(this.background.height!==this.canvas.height)this.background.height=this.canvas.height;
    this.background.getContext("2d").drawImage(this.canvas, 0, 0);
  }
  drawGoal(side) {
    const x = side * 52.5,
      back = side * 55;
    for (let y of [-3.66, 3.66])
      this.path(
        [
          [x, 0, y],
          [x, 2.44, y],
          [back, 1.8, y],
          [back, 0, y],
        ],
        "#d9e1d8",
        1.15,
      );
    this.path(
      [
        [x, 2.44, -3.66],
        [x, 2.44, 3.66],
      ],
      "#f4f5e8",
      1.5,
    );
    this.path(
      [
        [back, 0, -3.66],
        [back, 1.8, -3.66],
        [back, 1.8, 3.66],
        [back, 0, 3.66],
      ],
      "#c6d6cd",
      0.6,
    );
    for (let y = -3.66; y < 3.67; y += 0.32) {
      this.path(
        [
          [x, 2.44, y],
          [back, 1.8, y],
          [back, 0, y],
        ],
        "#d7e5d2",
        0.45,
        null,
        0.4,
      );
    }
    for (let h = 0.2; h < 1.9; h += 0.25)
      this.path(
        [
          [back, h, -3.66],
          [back, h, 3.66],
        ],
        "#d7e5d2",
        0.45,
        null,
        0.4,
      );
  }
  limb(a, b, width, color) {
    const A = this.project(a),
      B = this.project(b),
      c = this.ctx;
    if(A.depth<=.5 || B.depth<=.5)return;
    c.beginPath();
    c.moveTo(A.x, A.y);
    c.lineTo(B.x, B.y);
    c.lineWidth = Math.max(0.6, (width * (A.scale + B.scale)) / 2);
    c.strokeStyle = color;
    if (this.quality !== 'performance' && c.lineWidth > 2.1 && /^#[0-9a-f]{6}$/i.test(color)) {
      const dx=B.x-A.x, dy=B.y-A.y;
      const length=Math.hypot(dx,dy);
      if(length>.1){
        const radius=.48*c.lineWidth*(dy-dx>0?-1:1);
        const nx=dy/length*radius,ny=-dx/length*radius;
        const gradient=c.createLinearGradient(A.x+nx,A.y+ny,A.x-nx,A.y-ny);
        const tone=lightingTones(color);
        gradient.addColorStop(0,tone.light);gradient.addColorStop(.43,color);gradient.addColorStop(1,tone.shade);
        c.strokeStyle=gradient;
      }
    }
    c.lineCap = "round";
    c.stroke();
  }
  drawPlayer(p) {
    const style=appearanceFor(this.state.tactics,p);
    const pose=p.visual, scale=style.heightScale;
    const cos=Math.cos(p.heading),sin=Math.sin(p.heading);
    const bodyOffset=pose.bob-pose.crouch;
    const joint=(lat,h,forward)=>[
      p.x+(cos*forward-sin*lat*style.build)*scale,
      h*scale,
      p.y+(sin*forward+cos*lat*style.build)*scale,
    ];
    const upper=(lat,h,forward)=>joint(lat-pose.bank*(h-HIP_HEIGHT),h+bodyOffset,forward+pose.lean*(h-HIP_HEIGHT));
    const c=this.ctx, shadow=this.project([p.x+.26*scale,.015,p.y-.17*scale]);
    if(shadow.depth<=.5) return;
    if(this.quality==='performance'){
      const silhouette=Math.max(1.2,shadow.scale*.56*scale);
      c.beginPath();c.ellipse(shadow.x,shadow.y,silhouette,silhouette*.31,-.23,0,Math.PI*2);
      c.fillStyle='#15251d44';c.fill();
    } else {
      const cast=([x,h,z])=>[x+.52*h,.012,z-.35*h];
      const shadowLimb=(a,b,w)=>this.limb(cast(a),cast(b),scale*w,'#15251d4a');
      for(const [index,leg] of pose.legs.entries()){
        const side=index?1:-1;
        const hip=joint(side*.112,HIP_HEIGHT+bodyOffset,0);
        const knee=joint(side*.115,leg.kneeHeight,leg.kneeForward);
        const foot=joint(side*.117,leg.footHeight,leg.footForward);
        shadowLimb(hip,knee,.145);shadowLimb(knee,foot,.105);
      }
      shadowLimb(upper(0,.94,0),upper(0,1.38,0),.35);
      const h=this.project(cast(upper(0,1.68,.015)));
      if(h.depth>.5){
        c.beginPath();c.ellipse(h.x,h.y,.145*scale*h.scale,.091*scale*h.scale,-.23,0,Math.PI*2);
        c.fillStyle='#15251d51';c.fill();
      }
    }
    const limbs=(a,b,width,color)=>this.limb(a,b,width*scale*style.build,color);
    const lateralView=(-sin*(this.eye[0]-p.x)+cos*(this.eye[2]-p.y));
    const sides=lateralView>0?[-1,1]:[1,-1];
    const facing=cos*(this.eye[0]-p.x)+sin*(this.eye[2]-p.y)>0?1:-1;
    for(const side of sides){
      const leg=pose.legs[side<0?0:1];
      const hip=joint(side*.112,HIP_HEIGHT+bodyOffset,0);
      const knee=joint(side*.115,leg.kneeHeight,leg.kneeForward);
      const foot=joint(side*.117,leg.footHeight,leg.footForward);
      const thigh=hip.map((v,i)=>v+(knee[i]-v)*.53);
      limbs(hip,knee,.142,style.skin);limbs(hip,thigh,.195,style.shorts);
      limbs(knee,foot,.112,style.socks);
      const sockTop=knee.map((v,i)=>v+(foot[i]-v)*.15);
      limbs(knee,sockTop,.118,style.trim);
      if(leg.ground){
        const contact=this.project([foot[0],.012,foot[2]]);
        c.beginPath();c.ellipse(contact.x,contact.y,.145*contact.scale,.058*contact.scale,-.16,0,Math.PI*2);
        c.fillStyle='#14252092';c.fill();
      }
      limbs(foot,add(foot,[cos*.15*scale,0,sin*.15*scale]),.105,p.id%4?'#263438':'#d8c66c');
    }
    const drawArm=side=>{
      const swing=Math.sin(pose.phase+(side>0?Math.PI:0))*.28*pose.amp;
      const shoulder=upper(side*.222,1.365,0);
      const elbow=upper(side*(.272+pose.brake*.05+pose.save*.16),1.10+pose.save*.38,-swing);
      const hand=upper(side*(.25+pose.brake*.09+pose.save*.37),.98+pose.save*.61,-swing+.14+pose.amp*.09);
      const cuff=shoulder.map((v,i)=>v+(elbow[i]-v)*.54);
      limbs(shoulder,elbow,.105,style.skin);limbs(shoulder,cuff,.155,style.shirt);
      limbs(elbow,hand,.091,style.skin);
      if(p.index===0)this.sphere(hand,.066*scale,'#d7e4d2');
    };
    drawArm(sides[0]);
    const face=facing*.12;
    let cloth=style.shirt;
    if(shadow.scale*scale>6 && this.quality!=='performance'){
      const left=this.project(upper(-.21,1.37,face));
      const right=this.project(upper(.15,1.04,face));
      const tones=lightingTones(style.shirt);
      cloth=c.createLinearGradient(left.x,left.y,right.x,right.y);
      cloth.addColorStop(0,tones.light);cloth.addColorStop(.38,style.shirt);cloth.addColorStop(1,tones.shade);
    }
    this.path([upper(-.16,.94,face),upper(-.225,1.36,face*.8),upper(-.13,1.44,0),
      upper(.13,1.44,0),upper(.225,1.36,face*.8),upper(.16,.94,face)],null,0,cloth);
    limbs(upper(-.16,.94,face),upper(.16,.94,face),.095,style.shorts);
    limbs(upper(-.173,1.02,face),upper(-.195,1.32,face),.034,style.trim);
    limbs(upper(-.092,1.414,face*.72),upper(.092,1.414,face*.72),.036,style.trim);
    limbs(upper(0,1.4,0),upper(0,1.54,.012),.14,style.skin);
    drawArm(sides[1]);
    const head=this.project(upper(0,1.65,.025));
    if(head.depth>.5){
      const rx=.137*scale*head.scale,ry=.174*scale*head.scale;
      c.save();c.beginPath();c.ellipse(head.x,head.y,rx,ry,pose.bank*.35,0,Math.PI*2);c.clip();
      const faceLight=c.createLinearGradient(head.x-rx,head.y-ry,head.x+rx,head.y+ry);
      const tones=lightingTones(style.skin);
      faceLight.addColorStop(0,tones.light);faceLight.addColorStop(.5,style.skin);faceLight.addColorStop(1,tones.shade);
      c.fillStyle=faceLight;c.fillRect(head.x-rx*1.2,head.y-ry*1.2,rx*2.4,ry*2.4);
      const temple=head.y+(facing<0?.42:-.17)*ry;
      c.beginPath();c.moveTo(head.x-rx*1.3,head.y-ry*1.2);c.lineTo(head.x+rx*1.3,head.y-ry*1.2);
      c.lineTo(head.x+rx*1.15,temple+.18*ry);
      c.quadraticCurveTo(head.x+rx*.3,temple+(p.id%3-.9)*ry*.18,head.x-rx*.7,temple-.12*ry);
      c.lineTo(head.x-rx*1.2,temple+.2*ry);c.closePath();
      c.fillStyle=['#342b27','#3d3029','#282725','#514238'][p.id%4];c.fill();c.restore();
    }
    const chest=this.project(upper(0,1.15,face*1.14));
    if(chest.scale*scale>8){
      c.font=`700 ${.265*chest.scale*scale}px sans-serif`;c.fillStyle='#f7f4df';c.textAlign='center';
      c.fillText(String(p.index+1),chest.x,chest.y);
    }
  }
  drawOverlay() {
    if(this.state.training){
      const c=this.ctx;
      c.lineCap='round';c.lineJoin='round';
      for(const stroke of this.trainingLines??[]){
        c.beginPath();
        for(const [a,b] of stroke.segments){
          const from=this.project([a.x,stroke.height,a.y]);
          const to=this.project([b.x,stroke.height,b.y]);
          if(from.depth<=.5||to.depth<=.5)continue;
          c.moveTo(from.x,from.y);c.lineTo(to.x,to.y);
        }
        c.lineWidth=stroke.pixels;c.strokeStyle=stroke.color;c.globalAlpha=stroke.alpha;c.stroke();
      }
      c.globalAlpha=1;
      return;
    }
    const s = this.state,
      p = s.players[this.selected],
      cfg = s.tactics[p.team];
    const use = s.players.filter(
      (q) =>
        this.scope === "all" ||
        (this.scope === "team" && q.team === p.team) ||
        (this.scope === "unit" &&
          q.team === p.team &&
          cfg.groups.some(
            (g) => g.members.includes(p.index) && g.members.includes(q.index),
          )) ||
        q.id === p.id,
    );
    for (let q of use) {
      if (this.flags.prediction && q.prediction?.length)
        this.path(
          [[q.x, 0.1, q.y], ...q.prediction.map((v) => [v.x, 0.1, v.y])],
          "#a5f3cf",
          1.25,
        );
      if (this.flags.history && q.trail?.length)
        this.path(
          q.trail.map((v) => [v.x, 0.08, v.y]),
          "#b5d4e0",
          1,
          null,
          0.6,
        );
      if (this.flags.command) {
        let end = [q.x + q.command.x * 0.8, 0.1, q.y + q.command.y * 0.8];
        this.path([[q.x, 0.1, q.y], end], "#f7d27c", 1.3);
        const a = this.project([q.x, 0.1, q.y]),
          b = this.project(end),
          d = Math.atan2(b.y - a.y, b.x - a.x),
          ctx = this.ctx;
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - Math.cos(d - 0.5) * 5, b.y - Math.sin(d - 0.5) * 5);
        ctx.lineTo(b.x - Math.cos(d + 0.5) * 5, b.y - Math.sin(d + 0.5) * 5);
        ctx.fillStyle = "#f7d27c";
        ctx.fill();
      }
      if (this.flags.targets) this.ring(q.target.x, q.target.y, 0.7, "#f8d78a");
      if (this.flags.centroids)
        this.ring(q.estimate.x, q.estimate.y, 0.45, "#98b9ef", 0.08, 1);
    }
    if (this.flags.centroids) {
      let m = s.metrics[p.team];
      if (m) {
        this.ring(m.centroid.x, m.centroid.y, 1.15, "#fff0bc", 0.08, 1.5);
        this.ring(m.reference.x, m.reference.y, 1.5, "#a5f3cf", 0.08, 1.4);
      }
    }
    for (let [key, color, edges] of [
      ["tactical", "#f0cf82", cfg.tacticalEdges],
      ["communication", "#79d4e7", cfg.commEdges],
    ])
      if (this.flags[key])
        for (let [a, b] of edges) {
          let A = s.players[p.team * 11 + a],
            B = s.players[p.team * 11 + b];
          this.path(
            [
              [A.x, 0.12, A.y],
              [B.x, 0.12, B.y],
            ],
            color,
            0.8,
            null,
            0.65,
          );
        }
    if (this.flags.observation || this.agentView) {
      let angle = (cfg.fov * Math.PI) / 180,
        points = [[p.x, 0.05, p.y]];
      for (let j = 0; j <= 48; j++) {
        let a = p.heading - angle / 2 + (angle * j) / 48;
        points.push([
          p.x + Math.cos(a) * p.vision,
          0.05,
          p.y + Math.sin(a) * p.vision,
        ]);
      }
      points.push([p.x, 0.05, p.y]);
      this.path(points, "#9fe7c9", 1, "#8ef3cb", 0.14);
      this.path(points, "#a7ebd2", 1, null, 0.6);
    }
  }
  frame() {
    if (this.dead) return;
    requestAnimationFrame(() => this.frame());
    let now = performance.now();
    this.frames++;
    if (now - this.start > 1000) {
      this.fps = Math.round((this.frames * 1000) / (now - this.start));
      this.frames = 0;
      this.start = now;
    }
    if (!this.container.isConnected || !this.state || !this.w || !this.h)
      return;
    this.visual = this.motion.sample(now);
    const desired = cameraFocus(this.state, this.selected, this.focus, this.agentView);
    const next = {x:this.look.x+(desired.x-this.look.x)*.22,y:this.look.y+(desired.y-this.look.y)*.22};
    if (Math.hypot(next.x-this.look.x,next.y-this.look.y)>.025) {
      this.look=next;this.setupCamera();this.background=null;
    }
    const c = this.ctx;
    c.setTransform(this.ratio, 0, 0, this.ratio, 0, 0);
    if (!this.background) this.staticScene();
    else c.drawImage(this.background, 0, 0, this.w, this.h);
    let s = this.state,
      p = selectedAthlete(s,this.selected);
    if(!p)return;
    const known=new Set([p.id,...(p.visible??[]).map(q=>q.id)]);
    this.drawOverlay();
    if(!s.training)this.ring(p.x,p.y,.8,'#b0f6d4',.05,1.4);
    let draw = this.visual.players
      .filter(q=>athleteVisible(s, q) && (!this.agentView || known.has(q.id)))
      .map((q) => ({ depth: this.project([q.x, 0, q.y]).depth, p: q }));
    if(!s.training && s.ball)draw.push({
      depth: this.project([s.ball.x, 0, s.ball.y]).depth,
      ball: true,
    });
    draw.sort((a, b) => b.depth - a.depth);
    for (let item of draw) {
      if (item.ball) {
        if (
          this.agentView &&
          (p.knownBall?.via !== "vision" || s.time - p.knownBall.time >= 0.12)
        )
          continue;
        let b = this.visual.ball,
          a = this.project([b.x, 0, b.y]);
        const v=this.project([b.x,Math.max(.19,b.z),b.y]);
        if(a.depth<=.5 || v.depth<=.5)continue;
        c.beginPath();
        c.ellipse(a.x, a.y, 0.22 * a.scale, 0.1 * a.scale, 0, 0, Math.PI * 2);
        c.fillStyle = "#1229207a";
        c.fill();
        const r=Math.max(2.2,.2*v.scale);
        const light=c.createRadialGradient(v.x-r*.35,v.y-r*.4,.1,v.x,v.y,r);
        light.addColorStop(0,"#ffffff");light.addColorStop(.55,"#f3f2de");light.addColorStop(1,"#98a6a0");
        c.beginPath();c.arc(v.x,v.y,r,0,Math.PI*2);c.fillStyle=light;c.fill();
        c.strokeStyle="#172d36";c.lineWidth=.65;c.stroke();
        c.save();c.translate(v.x,v.y);c.rotate(b.spin||0);c.fillStyle="#273a41";
        c.beginPath();for(let k=0;k<5;k++){let a=k*Math.PI*2/5;c.lineTo(Math.cos(a)*r*.42,Math.sin(a)*r*.42);}c.fill();c.restore();
      } else this.drawPlayer(item.p);
    }
    const labelPlayer=this.visual.players.find(q=>q.id===p.id)??p;
    let v = this.project([labelPlayer.x, 2.6, labelPlayer.y]);
    this.label.textContent =
      String(p.index + 1).padStart(2, "0") + " " + p.name;
    this.label.style.display=athleteVisible(s, p) && v.depth>.5&&v.x>=0&&v.x<=this.w&&v.y>=0&&v.y<=this.h?'block':'none';
    this.label.style.left = v.x + "px";
    this.label.style.top = v.y + "px";
  }
  mount(container) {
    this.observer.disconnect();
    this.container = container;
    container.append(this.canvas, this.label);
    this.observer.observe(container);
    this.resize();
  }
  dispose() {
    this.dead = true;
    this.observer.disconnect();
  }
}
