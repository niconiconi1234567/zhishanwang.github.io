// These coefficients express coaching choices. All observations belong to the ball carrier.
// Distances are metres; positive forwardGain favours progression toward the opponent's goal.
const PASS_POLICIES = Object.freeze({
  triangles:  { maxRange: 25, idealRange: 11, rangeCost: 0.85, forwardGain: 0.15, widthGain: 0,    laneGain: 1.6 },
  transition: { maxRange: 42, idealRange: 26, rangeCost: 0.26, forwardGain: 0.72, widthGain: 0.04, laneGain: 1.4 },
  press:      { maxRange: 32, idealRange: 16, rangeCost: 0.36, forwardGain: 0.40, widthGain: 0.03, laneGain: 1.6 },
  wingbacks:  { maxRange: 39, idealRange: 20, rangeCost: 0.27, forwardGain: 0.34, widthGain: 0.35, laneGain: 1.5 },
  libero:     { maxRange: 37, idealRange: 22, rangeCost: 0.34, forwardGain: 0.51, widthGain: 0.08, laneGain: 1.9 },
});
export const PASS_STYLE_IDS = Object.freeze(Object.keys(PASS_POLICIES));

function localClearance(carrier, receiver, opponents, length) {
  const dx = receiver.x - carrier.x;
  const dy = receiver.y - carrier.y;
  let corridor = 8;
  let reception = 12;
  for (const defender of opponents) {
    reception = Math.min(reception, Math.hypot(defender.x - receiver.x, defender.y - receiver.y));
    const fraction = ((defender.x - carrier.x) * dx + (defender.y - carrier.y) * dy) / (length * length);
    if (fraction <= 0 || fraction >= 1) continue;
    const arrival = Math.min(0.7, fraction * length / 16);
    const predictedX = defender.x + (defender.vx || 0) * arrival;
    const predictedY = defender.y + (defender.vy || 0) * arrival;
    const laneX = carrier.x + fraction * dx;
    const laneY = carrier.y + fraction * dy;
    corridor = Math.min(corridor, Math.hypot(predictedX - laneX, predictedY - laneY));
  }
  return {corridor, reception};
}

/** Pick a visible team-mate or hold the ball. The engine owns the release decision and kick. */
export function selectPlaybookReceiver(styleId, carrier, attackDirection) {
  if (!Object.hasOwn(PASS_POLICIES, styleId)) return null;
  const policy = PASS_POLICIES[styleId];
  const opponents = carrier.visible.filter(player => player.team !== carrier.team);
  let best = null;
  let bestScore = -Infinity;
  for (const player of carrier.visible) {
    if (player.team !== carrier.team || player.id === carrier.id) continue;
    const length = Math.hypot(player.x - carrier.x, player.y - carrier.y);
    if (length < 4 || length > policy.maxRange) continue;
    const {corridor, reception} = localClearance(carrier, player, opponents, length);
    if (corridor < 0.8 || reception < 0.85) continue;
    const progress = (player.x - carrier.x) * attackDirection;
    const widthChange = Math.abs(player.y) - Math.abs(carrier.y);
    const goalkeeperOutlet = player.id % 11 === 0 ? 5 : 0;
    const score = policy.forwardGain * progress + policy.widthGain * widthChange
      - policy.rangeCost * Math.abs(length - policy.idealRange)
      + policy.laneGain * corridor + 0.7 * reception - goalkeeperOutlet;
    if (!best || score > bestScore || (score === bestScore && player.id < best.id)) {
      best = player;
      bestScore = score;
    }
  }
  return best;
}
