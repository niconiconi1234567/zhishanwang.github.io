import {tr,fmt,escapeHtml,choose,tuning} from './ground-panels.js';
import {pairedMetric} from './analysis.js';
import {plotChart} from './charts.js';

const seriesColors=['#87dbba','#85bfff','#e7bb7f','#cc9bda'];
const button=(action,label,cls='')=>`<button data-g-action="${action}" class="${cls}">${label}</button>`;
function chart(id,label,description='') {
  return `<div class="chart-wrap"><div class="chart-title"><strong>${label}</strong></div><canvas id="${id}" class="chart"></canvas><p class="ground-guide">${description}</p></div>`;
}
function playerSelector(studio) {
  const L=tr(studio.lang);
  return choose('selected',L('Tracked player','观察球员'),studio.tactic.players.map((p,i)=>[i,`${String(i+1).padStart(2,'0')} · ${p.name}`]),studio.selected);
}
export function fieldView(studio) {
  const L=tr(studio.lang);
  if(!studio.sim)return `<div class="ground-alert">${L('The signal path is incomplete. Open Wiring to reconnect it.','主信号链尚未接通，请到接线台连接。')} ${button('show-wiring',L('Open wiring','去接线'))}</div>`;
  const metric=(key,label,unit)=>`<div><span>${label}</span><strong data-ground-live="${key}">—</strong><small>${unit}</small></div>`;
  return `<div class="ground-field-grid"><div class="ground-field-stack"><section class="ground-stage"><div class="ground-stage-head"><div><span class="ground-led"></span><b>${escapeHtml(studio.tactic.teamName)}</b> <span>· ${escapeHtml(studio.tactic.formation)}</span></div><span data-ground-live="time"></span></div>
    <div class="ground-pitch-wrap"><div id="pitch-host" class="pitch-host"></div><div class="ground-overlay-key"><span class="reference">━ ${L('Reference','参考')}</span><span class="actual">━ ${L('Actual','实际')}</span></div></div>
    <div class="ground-transport">${button('run',L('Run','运行'),'primary')} ${button('step','+0.1 s')} ${button('finish',L('Run to end','算到终点'))} ${button('reset',L('Reset','复位'))}
    <select data-ground-key="speed" aria-label="${L('Trial speed','训练播放速度')}">${[1,2,4].map(n=>`<option value="${n}" ${n===studio.speed?'selected':''}>${n}×</option>`).join('')}</select><span data-ground-live="status"></span></div></section>
    <div class="ground-metrics">${metric('ref',studio.design.pins==='none'?L('Initial mean','初始均值'):L('Reference','参考位移'),'m')}
    ${metric('tracking',L('Tracking RMSE','跟踪 RMSE'),'m')}${metric('disagreement',L('Disagreement RMS','队内分歧 RMS'),'m')}${metric('effort',L('Mean squared command','平均指令代价'),'m²/s²')}</div>
    <section class="panel ground-card">
      <div class="ground-section-title"><h2>${L('Reference and actual output','参考与实际输出')}</h2>${playerSelector(studio)}</div>
      <p class="ground-guide" data-ground-live="player"></p>
      ${chart('ground-response',L('Lateral displacement over physical time','横向位移随物理时间变化'),L('Blue: reference or initial mean. Coral: selected player. Mint: team mean.','蓝线为参考或初始均值，红线为所选球员，绿色为队内均值。'))}
      <p class="ground-verdict" data-ground-live="interpretation"></p><div class="ground-components" data-ground-live="groups"></div></section></div>
    <aside class="ground-side">${tuning(studio.design,studio.lang)}
      <section class="panel ground-card"><span class="eyebrow">FIELD GUIDE</span><h2>${L('Read the drill','怎样看这次训练')}</h2>
      <p>${L('Each player controls lateral displacement from a formation slot. The shared 0.7 m/s forward run makes both trajectories visible.','每名球员控制相对阵型位置的横向位移。全队以 0.7 m/s 共同向前，让参考和实际轨迹在球场上展开。')}</p>
      <p class="ground-guide">${L('With no anchors, blue marks the initial team mean for evaluation. Gold rings mark reference anchors. Off-pitch outputs are drawn at the boundary. Charts retain the measured value.','没有锚点时，蓝线是用于评价的初始均值。金环表示接收参考的锚点。越界输出以边线箭头显示，图表保留完整数值。')}</p>
      ${choose('camera',L('Drill camera','训练镜头'),[['tactical',L('Tactical','战术全景')],['broadcast',L('Broadcast','转播镜头')],['player',L('Follow player','球员近景')]],studio.camera)}
      <div class="ground-pills">${button('show-wiring',L('Edit wires','编辑接线'))}${button('show-poles',L('See poles','查看极点'))}</div></section></aside></div>`;
}
function elapsedLabel(sim,lang) {
  const L=tr(lang);
  if(sim.stopReason==='range')return L('Stopped · |x| reached 80 m','已停止 · |x| 达到 80 m');
  if(sim.stopReason==='complete')return L('30 s completed','30 秒完成');
  return L('30 s trial','30 秒试验');
}
export function updateField(studio) {
  const sim=studio.sim;
  if(!sim)return;
  const L=tr(studio.lang),summary=sim.summary(),sample=sim.frames.at(-1);
  const write=(key,value)=>{const el=document.querySelector(`[data-ground-live="${key}"]`);if(el)el.textContent=value;};
  const play=document.querySelector('[data-g-action="run"]');
  if(play)play.textContent=studio.running?L('Pause','暂停'):sim.stopReason?L('Run again','重跑'):L('Run','运行');
  write('time',`${sim.time.toFixed(1)} / 30.0 s`);
  write('status',elapsedLabel(sim,studio.lang));
  for(const [key,v] of Object.entries({ref:sample.ref,tracking:sample.tracking,disagreement:sample.disagreement,effort:summary.effort}))write(key,v.toFixed(3));
  const agent=sim.roster[studio.selected];
  const person=sim.controllers[studio.selected];
  write('player',L('Speed cap','最高速度')+' '+fmt(agent.speed)+' m/s · '+L('Acceleration','加速度')+' '+fmt(agent.acceleration)+' m/s² · Bᵢ = '+fmt(sim.plants[studio.selected].B,5)+' · Uᵢ = '+fmt(person.limit,4)+' m/s · u = '+fmt(sample.u[studio.selected],4)+' m/s');
  const groupHost=document.querySelector('[data-ground-live="groups"]');
  if(groupHost)groupHost.innerHTML=sim.components.map((members,index)=>{
    const values=members.map(i=>sample.x[i]);
    const mu=values.reduce((sum,x)=>sum+x,0)/values.length;
    const spread=Math.max(...values)-Math.min(...values);
    return '<div><b>'+L('Component ','通信分量 ')+(index+1)+'</b> · #'+members.map(i=>i+1).join(', ')+'<br>'+L('Mean ','均值 ')+mu.toFixed(3)+' m · '+L('within-group span ','组内跨度 ')+spread.toFixed(3)+' m</div>';
  }).join('');
  const player=sample.x[studio.selected];
  const inBand=sample.x.every(x=>Math.abs(x-sample.ref)<=.2);
  const text=sim.stopReason==='range'?L('A player crossed the 80 m diagnostic limit. The final measured state is retained.','球员位移达到 80 m 诊断边界，末样本保留越界测量值。'):
    L(`Player #${studio.selected+1} is at ${player.toFixed(2)} m. ${inBand?'All eleven are within ±0.2 m.':`Squad span ${(Math.max(...sample.x)-Math.min(...sample.x)).toFixed(2)} m.`}`,
      `#${studio.selected+1} 的实际位移为 ${player.toFixed(2)} m。${inBand?'11 人均进入 ±0.2 m 容差带。':`当前最大与最小位移相差 ${(Math.max(...sample.x)-Math.min(...sample.x)).toFixed(2)} m。`}`);
  write('interpretation',text+(summary.settling===null?'':L(` Settled from ${fmt(summary.settling)} s through the end.`,` 从 ${fmt(summary.settling)} s 起保持在容差带内直至结束。`)));
  const canvas=document.querySelector('#ground-response');
  if(canvas)plotChart(canvas,[
    {name:L('Reference','参考'),color:'#85bfff',points:sim.frames.map(f=>({x:f.time,y:f.ref}))},
    {name:`#${studio.selected+1}`,color:'#f39781',points:sim.frames.map(f=>({x:f.time,y:f.x[studio.selected]}))},
    {name:L('Team mean','队内均值'),color:'#87dbba',points:sim.frames.map(f=>({x:f.time,y:f.mean}))},
  ],{lang:studio.lang,unit:'m',title:L('Lateral displacement','横向位移')});
}
export function compareView(studio) {
  const L=tr(studio.lang),report=studio.report;
  const kindName=name=>({homogeneous:L('Homogeneous','同质'),roster:L('Squad abilities','阵容异构')}[name]||name.toUpperCase());
  const header=`<section class="panel ground-card"><div class="ground-section-title"><div><span class="eyebrow">MATCHED TRIALS</span><h2>${L('Compare on the same initial states','在相同初态上比较')}</h2></div><span class="ground-badge">3 ${L('seeds','个种子')} × 30 s</span></div>
    <p>${L('Each variant gets the same squad, seed, graph, wiring and disturbance for each paired run. Controller comparisons use your parameter settings.','每次配对使用相同阵容、种子、通信图、接线与扰动。控制器比较使用当前所设参数。')}</p>
    <div class="ground-compare-controls">${choose('comparison',L('Change one factor','只改变一个因素'),[['controllers',L('P / PID / ADRC / MPC','P / PID / ADRC / MPC')],['abilities',L('Homogeneous / selected roster','同质 / 所选阵容异构')]],studio.comparison)}
    ${button('compare',L('Run comparison','运行对照'),'primary')} <span role="status" id="ground-progress">${studio.worker?L('Computing…','计算中…'):''}</span></div></section>`;
  if(!report)return header+`<div class="ground-empty">${L('Run the comparison to see measured errors, input costs and trajectories.','运行对照后，这里显示实测误差、指令代价和各算法的响应曲线。')}</div>`;
  const row=r=>`<tr><th>${kindName(r.name)}</th><td>${fmt(r.summary.runRmse,4)}</td><td>${fmt(r.summary.disagreement,4)}</td><td>${fmt(r.summary.effort,4)}</td><td>${fmt(100*r.summary.saturation)}%</td><td>${r.completed}/3</td></tr>`;
  return header+`<section class="panel ground-card"><div class="ground-section-title"><div><span class="eyebrow">RESULTS</span><h2>${L('Accuracy and input cost','精度与执行代价')}</h2></div>${button('export-result',L('Export results','导出完整结果'))}</div>
    <div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Variant','方案')}</th><th>RMSE · m</th><th>${L('Final disagreement','终点分歧')} · m</th><th>mean u² · m²/s²</th><th>${L('Limited','限幅率')}</th><th>${L('Completed','完整运行')}</th></tr></thead><tbody>${report.rows.map(row).join('')}</tbody></table></div>
    <p class="ground-guide">${L('Mean of three per-run measurements. Runs crossing |x| = 80 m end early; use the completion column before comparing costs.','表中是三个种子逐次指标的均值。|x| 达到 80 m 时提前停止，请结合完整运行次数比较代价。')}</p>
    <details class="ground-details"><summary>${L('Paired differences from baseline','相对基线的配对差值')}</summary><p class="ground-guide">${L('Differences use the same three seeds and complete 30 s windows. Intervals are 95% paired t intervals.','差值取自三个相同种子的完整 30 秒窗口，区间为 95% 配对 t 区间。')}</p>
    ${report.rows.slice(1).map(row=>{
      const base=report.rows[0];
      if(row.completed!==3||base.completed!==3)return '<p>'+kindName(row.name)+' · '+L('Incomplete windows','含提前终止的运行')+'</p>';
      const pairs=row.runs.map((b,i)=>({a:base.runs[i],b}));
      const m=pairedMetric(pairs,'runRmse'),u=pairedMetric(pairs,'effort');
      return '<p><b>'+kindName(row.name)+' − '+kindName(base.name)+'</b> · ΔRMSE '+fmt(m.delta)+' m ['+fmt(m.low)+', '+fmt(m.high)+'] · Δmean u² '+fmt(u.delta)+' m²/s² ['+fmt(u.low)+', '+fmt(u.high)+']</p>';
    }).join('')}</details>
    <div class="ground-section-title"><h3>${L('First matched seed','首个配对种子')} ${report.seeds[0]}</h3>${playerSelector(studio)}</div>
    <div class="ground-key">${report.rows.map((r,i)=>`<span style="color:${seriesColors[i]}">━ ${kindName(r.name)}</span>`).join('')} <span>┄ ${L('Reference','参考')}</span></div>
    ${chart('ground-comparison-chart',L('Actual output by variant','各方案的实际输出'))}
    <details class="ground-details"><summary>${L('Per-seed results','逐种子结果')}</summary><div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Variant','方案')}</th><th>Seed</th><th>t / s</th><th>RMSE / m</th><th>${L('Settling / s','调节时间 / s')}</th></tr></thead><tbody>${report.rows.flatMap(r=>r.runs.map(x=>`<tr><td>${kindName(r.name)}</td><td>${x.seed}</td><td>${fmt(x.time)}</td><td>${fmt(x.runRmse,4)}</td><td>${x.settling===null?'—':fmt(x.settling)}</td></tr>`)).join('')}</tbody></table></div></details></section>`;
}
export function drawComparison(studio) {
  const canvas=document.querySelector('#ground-comparison-chart'),r=studio.report;
  if(!r||!canvas)return;
  const rows=r.rows.map((row,i)=>({name:row.name.toUpperCase(),color:seriesColors[i],points:row.firstTrajectory.map(f=>({x:f.t,y:f.x[studio.selected]}))}));
  rows.push({name:tr(studio.lang)('Reference','参考'),color:'#c4d2dc',points:r.rows[0].firstTrajectory.map(f=>({x:f.t,y:f.ref}))});
  plotChart(canvas,rows,{lang:studio.lang,title:tr(studio.lang)('Paired responses','配对响应'),unit:'m'});
}
