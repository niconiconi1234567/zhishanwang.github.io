import {FORMATIONS, ROLES} from './engine.js';
import {PLAYBOOKS, buildPlaybook} from './playbooks.js';

const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[character]);

const routes = {
  triangles: ['Barcelona · 2011', '巴塞罗那 · 2011'],
  transition: ['Inter · 2010', '国际米兰 · 2010'],
  press: ['Liverpool · 2019', '利物浦 · 2019'],
  wingbacks: ['Italy · 2016', '意大利 · 2016'],
  libero: ['Inter · 1960s', '国际米兰 · 1960 年代'],
};

// World coordinates are shown in the selected team's attacking frame, left to right.
const pitchX = x => 306 + x * 5.34;
const pitchY = y => 204 - y * 5.34;
const pitchPoint = ([x, y]) => [pitchX(x), pitchY(y)];

function roleBias(tactic, slot) {
  const groups = tactic.groups.filter(group => group.members.includes(slot));
  const scale = Math.max(1, groups.reduce((sum, group) => sum + group.weight, 0));
  return groups.reduce((bias, group) => [
    bias[0] + group.weight * group.dx / scale,
    bias[1] + group.weight * group.dy / scale,
  ], [0, 0]);
}

function pitchGraphic(card, tactic, language) {
  const L = (en, zh) => language === 'zh' ? zh : en;
  const roles = ROLES[tactic.formation];
  const referenceSlot = card.referencePlayers[0].slot;
  const positions = FORMATIONS[tactic.formation].map(([x, y]) => [
    Math.max(-49, Math.min(49, tactic.centerX + x * tactic.depth)),
    Math.max(-31, Math.min(31, tactic.centerY + y * tactic.width)),
  ]);
  const points = positions.map(pitchPoint);
  const edges = tactic.tacticalEdges.map(([a, b]) =>
    `<line class="coach-edge" x1="${points[a][0]}" y1="${points[a][1]}" x2="${points[b][0]}" y2="${points[b][1]}"/>`
  ).join('');
  const intentions = positions.map(([x, y], slot) => {
    const [vx, vy] = roleBias(tactic, slot);
    if (Math.hypot(vx, vy) < .12) return '';
    return `<path class="coach-intent" d="M${pitchX(x)} ${pitchY(y)} L${pitchX(x + 8 * vx)} ${pitchY(y + 8 * vy)}" marker-end="url(#coach-vector-tip)"/>`;
  }).join('');
  const nodes = points.map(([x, y], slot) => {
    const mark = slot === referenceSlot ? `<circle r="15" class="coach-reference-ring"/>` : '';
    return `<g transform="translate(${x},${y})"><title>${escapeHtml(tactic.players[slot].name)} · ${roles[slot]}</title>${mark}<circle r="10.7" class="coach-role-dot"/><text class="coach-role-number" y="3.8">${slot + 1}</text><text class="coach-role-name" y="25">${roles[slot]}</text></g>`;
  }).join('');
  return `<svg class="coach-pitch" viewBox="0 0 612 408" role="img" aria-label="${L('Formation, tactical links and local motion bias', '阵型、战术连接与各角色移动偏好')}">
    <defs><pattern id="coach-turf" width="80" height="408" patternUnits="userSpaceOnUse"><path fill="#163a31" d="M0 0h80v408H0z"/><path fill="#173e34" d="M0 0h40v408H0z"/></pattern><marker id="coach-vector-tip" viewBox="0 0 8 8" markerWidth="5" markerHeight="5" refX="6.5" refY="4" orient="auto"><path d="M0 0L8 4L0 8Z" fill="#f2cd78"/></marker></defs>
    <rect x="0" y="0" width="612" height="408" fill="#102d27"/><rect x="25.6" y="22.4" width="560.8" height="363.2" fill="url(#coach-turf)"/>
    <g class="coach-marking"><rect x="25.6" y="22.4" width="560.8" height="363.2"/><path d="M306 22.4v363.2 M25.6 96.3h88.1v215.4H25.6 M25.6 155.1H55v97.8H25.6 M586.4 96.3h-88.1v215.4h88.1 M586.4 155.1H557v97.8h29.4"/><circle cx="306" cy="204" r="48.9"/><path d="M25.6 184.5h-9v39h9 M586.4 184.5h9v39h-9"/></g>
    <circle cx="306" cy="204" r="2.2" fill="#b1ccad"/>${edges}${intentions}${nodes}
  </svg>`;
}

function coachTuning(tactic, L) {
  const bars = [
    [L('Press', '压迫强度'), tactic.press, 1],
    [L('Tempo', '传球节奏'), tactic.tempo, 1],
    [L('Formation flow', '阵型流动性'), tactic.flow, 1.5],
    [L('Width scale', '阵型宽度'), tactic.width, 1.3],
  ];
  return bars.map(([name, value, max]) => `<div class="coach-meter"><span>${name}</span><span class="coach-meter-track"><i style="width:${100 * value / max}%"></i></span><b>${value.toFixed(2)}</b></div>`).join('');
}

function attribution(card, tactic, language, L) {
  const refs = card.referencePlayers.map(ref => `<div class="coach-observation"><span class="coach-shirt" aria-hidden="true">${String(ref.slot + 1).padStart(2, '0')}</span><div><div class="coach-mini-label">${L('Historical player reference', '历史球员参照')}</div><strong>${escapeHtml(ref.name)} <small>→ ${escapeHtml(tactic.players[ref.slot].name)} · ${escapeHtml(ref.role)}</small></strong><p>${escapeHtml(ref.fact[language])}</p></div></div>`).join('');
  const links = card.sources.map(item => `<a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(item.title)} <span aria-hidden="true">↗</span></a>`).join('');
  return `<section class="coach-source-box"><div class="coach-mini-label">${L('Historical record', '历史资料')}</div><p>${escapeHtml(card.historical[language])}</p>${refs}<div class="coach-source-links">${links}</div><small class="coach-disclosure">${L('Squads, kits, builds, local networks and unmeasured abilities are original exercise settings. Sources document the stated match events and measured anchors.', '队伍、球衣、体型、局部网络及其余能力值采用原创实验设定。以上来源对应注明的比赛事实和实测锚点。')}</small></section>`;
}

function playersTable(tactic, card, L) {
  const roles = ROLES[tactic.formation];
  const anchorSlot = card.referencePlayers[0].slot;
  const rows = tactic.players.map((player, slot) => `<tr class="${slot === anchorSlot ? 'coach-anchor-row' : ''}"><td>${String(slot + 1).padStart(2, '0')}</td><th scope="row">${escapeHtml(player.name)}</th><td>${roles[slot]}</td><td>${player.speed.toFixed(2)}</td><td>${player.acceleration.toFixed(2)}</td><td>${player.skill.toFixed(2)}</td><td>${player.stamina.toFixed(2)}</td><td>${player.vision.toFixed(1)}</td><td>${player.appearance.heightCm}</td></tr>`).join('');
  return `<div class="coach-table-scroll" role="region" aria-label="${L('Scrollable athlete parameters', '可横向滚动的球员参数表')}" tabindex="0"><table class="coach-roster"><thead><tr><th>#</th><th>${L('Athlete', '球员')}</th><th>${L('Role', '角色')}</th><th>${L('Speed · m/s', '速度 · m/s')}</th><th>${L('Accel. · m/s²', '加速 · m/s²')}</th><th>${L('Technique', '技术')}</th><th>${L('Stamina', '初始体能')}</th><th>${L('Sight · m', '视野 · m')}</th><th>${L('Height · cm', '身高 · cm')}</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

/** Visual board for the five local playbooks. App-level event delegation owns all mutations. */
export function coachBoard({id = 'triangles', team = 0, lang = 'en', homogeneous = false, currentTactic} = {}) {
  const language = lang === 'zh' ? 'zh' : 'en';
  const L = (en, zh) => language === 'zh' ? zh : en;
  const card = PLAYBOOKS.find(entry => entry.id === id) || PLAYBOOKS[0];
  const tactic = buildPlaybook(card.id, team, {homogeneous});
  const teamTitle = team ? L('Coral', '珊瑚红队') : L('Blue', '蓝队');
  const currentLabel = currentTactic?.name || L('Default setup', '默认配置');
  const menu = PLAYBOOKS.map((entry, index) => `<button type="button" class="coach-choice ${entry.id === card.id ? 'is-chosen' : ''}" data-action="coach-preset" data-id="${entry.id}" aria-pressed="${entry.id === card.id}"><span><em>0${index + 1}</em>${entry.formation}</span><b>${escapeHtml(entry.title[language])}</b><small>${routes[entry.id][language === 'zh' ? 1 : 0]}</small></button>`).join('');
  const abilityOptions = [
    [false, L('Heterogeneous roles', '异构角色')],
    [true, L('Equal team means', '同质均值对照')],
  ].map(([flag, label]) => `<button type="button" data-action="coach-abilities" data-homogeneous="${flag}" aria-pressed="${homogeneous === flag}" class="${homogeneous === flag ? 'is-chosen' : ''}">${label}</button>`).join('');
  const speeds = tactic.players.map(player => player.speed);
  const speedRange = `${Math.min(...speeds).toFixed(2)}–${Math.max(...speeds).toFixed(2)}`;
  return `<section class="coach-book" style="--coach-accent:${tactic.color}">
    <div class="coach-eyeline"><span>OWN / FLOW</span><i></i>${L('COACHING NOTEBOOK', '教练战术手册')}</div>
    <div class="coach-intro"><div><h2>${L('Classic playbooks', '经典战术')}</h2><p>${L('Choose a tactical intention, inspect the eleven roles and load the exercise onto a team.', '选择战术思路，查看 11 个角色如何配合，再将配置载入球队。')}</p></div><span class="coach-count">05 <small>${L('STYLES', '种风格')}</small></span></div>
    <div class="coach-catalog" role="group" aria-label="${L('Choose a playbook', '选择战术方案')}">${menu}</div>
    <div class="coach-spread"><figure class="coach-diagram"><div class="coach-figure-head"><span>${L('ROLE MAP', '角色地图')}</span><strong>${card.formation}</strong><span>${L('ATTACK', '进攻方向')} →</span></div>${pitchGraphic(card, tactic, language)}<figcaption><span><i class="coach-legend-line"></i>${L('Configured tactical links', '实际战术边')} · ${tactic.tacticalEdges.length}</span><span><i class="coach-legend-arrow"></i>${L('Unit velocity bias × 8 s', '子系统速度偏置 × 8 秒')}</span><span class="coach-legend-ref">○ ${L('Historical role', '资料参照角色')}</span></figcaption></figure>
    <div class="coach-plan"><div class="coach-mini-label">${escapeHtml(tactic.teamName)} · ${L('SETUP', '实验配置')}</div><h3>${escapeHtml(card.title[language])}</h3><p>${escapeHtml(card.translation[language])}</p><div class="coach-meters">${coachTuning(tactic, L)}</div><div class="coach-control"><div class="coach-mini-label">${L('ATHLETE ABILITIES', '球员能力')}</div><div class="coach-ability-group" role="group" aria-label="${L('Ability distribution', '能力分布')}">${abilityOptions}</div><p>${homogeneous ? L('Each physical and sensing attribute is fixed at the eleven-player mean. Formation, roles and links are identical.', '每项运动及感知能力均取该阵容 11 人的均值，阵型、职责与关系边相同。') : L('Each role has its own movement, kicking and sensing parameters. Speed caps span ', '各角色拥有独立的运动、踢球与感知参数。速度上限范围为 ') +speedRange+' m/s.'}</p></div>
    <button type="button" class="coach-apply" data-action="coach-apply">${L('Load onto '+teamTitle, '加载到'+teamTitle)} <span>↗</span></button><small class="coach-active-tactic">${L('Currently loaded', '当前已载入')} · ${escapeHtml(currentLabel)}</small></div></div>
    <div class="coach-details">${attribution(card, tactic, language, L)}<section class="coach-transfer"><div class="coach-mini-label">${L('FROM DESIGN TO PLAY', '从参数到场上运动')}</div><h3>${L('What changes on the pitch?', '球场上会改变什么？')}</h3><p>${L('The match caps the velocity command using speed and stamina. Acceleration bounds each physical step, technique affects kick direction, and sight limits local observations.', '比赛用速度和体能限制指令幅值，以加速度限制每个物理步内的实际变速。技术影响出球方向精度，视野限制球员可用的局部观测。')}</p><p>${L('Loading applies the playing setup to the selected team. Starting stamina takes effect in a new match. The training ground displays reference and output displacement for a controlled experiment.', '加载后配置即应用到当前球队，初始体能在新比赛中生效。进入控制训练场，可在受控实验中比较参考位移与实际输出。')}</p><div class="coach-model-actions"><button type="button" class="small quiet" data-action="nav" data-page="ground">${L('Open control training ground', '进入控制训练场')} →</button><a href="./examples/ClassicPlaybooks.json" download="ClassicPlaybooks.json">${L('Download all five tactics (JSON)', '下载五套战术（JSON）')}</a></div></section></div>
    <section class="coach-roster-card"><div class="coach-roster-head"><div><div class="coach-mini-label">${L('SQUAD SHEET', '教练阵容表')}</div><h3>${escapeHtml(tactic.teamName)}</h3></div><span>${L('11 autonomous players', '11 名自主球员')}</span></div>${playersTable(tactic, card, L)}</section>
  </section>`;
}
