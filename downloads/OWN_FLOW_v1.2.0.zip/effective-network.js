// Read-only match diagnostics. A directed arc runs from the sender to the
// receiver that currently holds its usable centroid estimate.
const MAX_STATE_AGE = 2.5;
const finite = Number.isFinite;
const mean = (values) => values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
const number = (value, digits = 2) => finite(value) ? value.toFixed(digits) : '—';
const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[c]);

function connectivity(count, arcs) {
  const reachable = Array.from({length: count}, (_, i) =>
    Array.from({length: count}, (_, j) => i === j));
  for (const {from, to} of arcs) reachable[from][to] = true;
  for (let k = 0; k < count; k++) {
    for (let i = 0; i < count; i++) {
      if (reachable[i][k]) {
        for (let j = 0; j < count; j++) reachable[i][j] ||= reachable[k][j];
      }
    }
  }
  const components = [];
  const assigned = new Set();
  for (let i = 0; i < count; i++) {
    if (assigned.has(i)) continue;
    const group = [];
    for (let j = i; j < count; j++) {
      if (reachable[i][j] && reachable[j][i]) {
        group.push(j);
        assigned.add(j);
      }
    }
    components.push(group);
  }
  const reachCounts = reachable.map(row => row.filter(Boolean).length - 1);
  return {components, reachCounts, reachablePairs: reachCounts.reduce((a, b) => a + b, 0)};
}

export function empiricalNetwork(state, team) {
  const tactic = state?.tactics?.[team];
  const players = state?.players?.filter(p => p.team === team).sort((a, b) => a.index - b.index);
  if (!tactic || !finite(state.time) || players?.length !== 11 ||
      players.some((p, i) => p.index !== i || !p.neighbors || typeof p.neighbors !== 'object')) {
    return {available: false};
  }
  const center = {x: mean(players.map(p => p.x)), y: mean(players.map(p => p.y))};
  const receivers = players.map(p => ({
    index: p.index, name: p.name, x: p.x, y: p.y, configured: 0, usable: 0,
    ages: [], estimationError: Math.hypot(p.estimate.x - center.x, p.estimate.y - center.y)
  }));
  const arcs = [];
  const pairs = [];
  const absent = {stale: 0, unseen: 0, muted: 0};
  // For each configured pair, look at the *receiver's* memory. Recent state
  // records may remain after switching to ball-only communication, but the
  // consensus update skips them until state exchange is enabled again.
  for (const [i, j] of tactic.commEdges) {
    const pair = {a: i, b: j, usable: []};
    for (const [from, to] of [[i, j], [j, i]]) {
      const receiver = receivers[to];
      receiver.configured++;
      const packet = players[to].neighbors[players[from].id];
      if (tactic.information === 'ball') {
        absent.muted++;
      } else if (!packet || !finite(packet.time)) {
        absent.unseen++;
      } else {
        const age = state.time - packet.time;
        if (age >= MAX_STATE_AGE) {
          absent.stale++;
        } else {
          const arc = {from, to, age};
          pair.usable.push(arc);
          arcs.push(arc);
          receiver.ages.push(age);
          receiver.usable++;
        }
      }
    }
    pairs.push(pair);
  }
  const flow = connectivity(players.length, arcs);
  const ages = arcs.map(arc => arc.age);
  for (const receiver of receivers) {
    receiver.coverage = receiver.configured ? receiver.usable / receiver.configured : null;
    receiver.meanAge = mean(receiver.ages);
    receiver.reaches = flow.reachCounts[receiver.index];
  }
  return {
    available: true, time: state.time, ballOnly: tactic.information === 'ball',
    receivers, arcs, pairs, absent, components: flow.components,
    reachablePairs: flow.reachablePairs, possiblePairs: players.length * (players.length - 1),
    mutual: pairs.filter(pair => pair.usable.length === 2).length,
    oneWay: pairs.filter(pair => pair.usable.length === 1).length,
    meanAge: mean(ages), maxAge: ages.length ? Math.max(...ages) : null
  };
}

function pitchDiagram(data, localize) {
  const point = p => ({x: 210 + p.x * 3.65, y: 140 - p.y * 3.65});
  const positions = data.receivers.map(point);
  const edges = data.pairs.map(({a, b, usable}) => {
    const start = positions[usable.length ? usable[0].from : a];
    const end = positions[usable.length ? usable[0].to : b];
    const style = ['missing', 'single', 'mutual'][usable.length];
    let triangle = '';
    if (usable.length === 1) {
      const angle = Math.atan2(end.y - start.y, end.x - start.x) * 180 / Math.PI;
      const midX = (start.x + end.x) / 2;
      const midY = (start.y + end.y) / 2;
      triangle = `<path class="net-arrow" transform="translate(${midX} ${midY}) rotate(${angle})" d="M4 0 -3 3 -3 -3Z"/>`;
    }
    return `<line class="net-link ${style}" x1="${start.x}" y1="${start.y}" x2="${end.x}" y2="${end.y}"/>${triangle}`;
  }).join('');
  const nodes = data.receivers.map((p, i) => {
    const {x, y} = positions[i];
    const title = `#${i + 1} ${escape(p.name)} · ${p.usable}/${p.configured} ${localize('incoming', '可用接收方向')}`;
    return `<g class="net-node"><title>${title}</title><circle cx="${x}" cy="${y}" r="6.3"/><text x="${x}" y="${y + 2.8}">${i + 1}</text></g>`;
  }).join('');
  return `<svg class="net-pitch" viewBox="0 0 420 280" role="img" aria-label="${localize('Usable directed state links on the match pitch', '球场上当前可用的定向状态消息')}">
    <rect class="net-surface" x="6" y="7" width="408" height="266" rx="9"/>
    <g class="net-markings"><rect x="18.4" y="15.9" width="383.2" height="248.2"/><path d="M210 16V264M18 67H78V213H18M402 67H342V213H402"/><circle cx="210" cy="140" r="33.4"/></g>
    ${edges}${nodes}</svg>`;
}

export function effectiveNetworkPanel(state, team, lang) {
  const L = (en, zh) => lang === 'zh' ? zh : en;
  const heading = L('Effective centroid-observer network', '中心观测器的有效通信网络');
  const data = empiricalNetwork(state, team);
  if (!data.available) {
    return `<section class="panel network-evidence"><div class="panel-head"><h2>${heading}</h2></div><div class="panel-body"><p class="hint">${L('Receiver memory is absent from this snapshot. Use a live match or a full checkpoint to inspect effective links.', '该快照未记录接收方的邻居记忆。请在实时比赛或完整存档中查看有效链路。')}</p></div></section>`;
  }
  const metric = (name, value, detail) => `<div class="net-stat"><span>${name}</span><b>${value}</b><small>${detail}</small></div>`;
  const configured = 2 * data.pairs.length;
  const arcDetail = `${data.mutual} ${L('two-way', '双向')} · ${data.oneWay} ${L('one-way pairs', '单向球员对')}`;
  const groupDetail = data.components.map(c => c.length).join(' + ');
  const timeText = data.ballOnly
    ? L('Ball-only messaging is active. The centroid observer omits all neighbor state estimates.', '当前仅传足球消息，中心观测器跳过全部邻居状态估计。')
    : L('Each direction requires a configured edge and a cached state less than 2.5 physical seconds old. Age starts at the sender’s timestamp.', '每个有效方向都要求存在配置边，且接收方缓存的状态消息年龄小于 2.5 物理秒。年龄从发送方时间戳起算。');
  const rows = data.receivers.map(p => {
    const label = `#${String(p.index + 1).padStart(2, '0')} ${escape(p.name)}`;
    const coverage = p.coverage === null ? '—' : `${Math.round(p.coverage * 100)}%`;
    return `<tr><td>${label}</td><td>${p.usable}/${p.configured}</td><td>${coverage}</td><td>${number(p.meanAge)}</td><td>${number(p.estimationError)}</td></tr>`;
  }).join('');
  return `<section class="panel network-evidence">
    <div class="panel-head"><h2>${heading}</h2><span class="chip">t = ${number(data.time)} s</span></div>
    <div class="panel-body">
      <div class="net-stats">
        ${metric(L('Available directions', '可用传递方向'), `${data.arcs.length}/${configured}`, arcDetail)}
        ${metric(L('Strong components', '强连通分量'), data.components.length, `${L('Group sizes', '各分量人数')} · ${groupDetail}`)}
        ${metric(L('Reachable ordered pairs', '可达有序对'), `${data.reachablePairs}/${data.possiblePairs}`, L('Multi-hop paths in this snapshot', '本帧有向图的多跳路径'))}
        ${metric(L('Mean sample age', '可用样本平均年龄'), `${number(data.meanAge)} s`, `${L('Oldest', '最大年龄')} · ${number(data.maxAge)} s`)}
      </div>
      <div class="net-layout"><figure>${pitchDiagram(data, L)}<figcaption><span class="net-key mutual">${L('Both ways', '双向')}</span><span class="net-key single">${L('One way', '单向')}</span><span class="net-key missing">${L('Neither way', '均不可用')}</span></figcaption></figure>
        <div class="net-guide"><h3>${L('Reading a direction', '怎样读一个方向')}</h3><p>${L('An arrow from 3 to 7 means player 7 can use player 3’s latest state. A chain gives a path in this snapshot. Future updates depend on when the next packets arrive.', '从 3 号指向 7 号，表示 7 号此刻可使用 3 号的状态。相接的方向构成本帧的一条路径，后续传播还取决于新的消息何时到达。')}</p><p>${timeText}</p>
          <div class="net-breakdown"><span>${L('Expired', '已过期')} <b>${data.absent.stale}</b></span><span>${L('No cached state', '无缓存')} <b>${data.absent.unseen}</b></span><span>${L('State disabled', '停用状态')} <b>${data.absent.muted}</b></span></div>
        </div></div>
      <div class="table-scroll net-table"><table class="data-table"><caption>${L('Receiver coverage and centroid estimation error', '接收覆盖与中心估计误差')}</caption><thead><tr><th>${L('Receiver', '接收方')}</th><th>${L('Usable / configured', '有效／配置入向')}</th><th>${L('Coverage', '覆盖率')}</th><th>${L('Mean age (s)', '平均年龄（s）')}</th><th>${L('Estimate error (m)', '估计误差（m）')}</th></tr></thead><tbody>${rows}</tbody></table></div>
    </div></section>`;
}

// The benchmark worker already subtracts initial cumulative shot/pass counters.
// Its scores are final totals, so goals must instead be differenced here, once.
export function footballTaskOutcomes(report) {
  if (report?.mode !== 'match' || !report.results?.length) return null;
  const team=report.team===1?1:0;
  const samples = [];
  for (const result of report.results) {
    const start = result.initialCheckpoint?.score;
    if (!Array.isArray(start) || start.length !== 2 || !start.every(finite)) return null;
    const branches = [result.a, result.b].map(branch => {
      if (!Array.isArray(branch?.score) || branch.score.length !== 2 || !branch.score.every(finite) ||
          !finite(branch.passes) || !finite(branch.shots)) return null;
      return {goals: branch.score[team] - start[team], conceded: branch.score[1-team] - start[1-team],
        shots: branch.shots, passes: branch.passes};
    });
    if (branches.includes(null)) return null;
    samples.push({a: branches[0], b: branches[1]});
  }
  const metrics = {};
  for (const key of ['goals', 'conceded', 'shots', 'passes']) {
    metrics[key] = {a: mean(samples.map(s => s.a[key])), b: mean(samples.map(s => s.b[key])),
      delta: mean(samples.map(s => s.b[key] - s.a[key]))};
  }
  return {count: samples.length, metrics};
}

export function footballOutcomePanel(report, lang) {
  const result = footballTaskOutcomes(report);
  if (!result) return '';
  const L = (en, zh) => lang === 'zh' ? zh : en;
  const labels = {goals: L('Goals scored', '进球'), conceded: L('Goals conceded', '失球'),
    shots: L('Shots attempted', '射门尝试'), passes: L('Passes attempted', '传球尝试')};
  const rows = Object.entries(result.metrics).map(([key, row]) => {
    const signed = `${row.delta > 0 ? '+' : ''}${number(row.delta)}`;
    return `<tr><td>${labels[key]}</td><td>${number(row.a)}</td><td>${number(row.b)}</td><td>${signed}</td></tr>`;
  }).join('');
  return `<section class="panel football-outcomes"><div class="panel-head"><h2>${L('On-pitch outcomes', '足球任务表现')}</h2><span class="chip">${report.team===1?L('Coral','红队'):L('Blue','蓝队')} · ${result.count} ${L('pairs', '组配对')}</span></div>
    <div class="panel-body"><p class="hint">${L('Counts per experimental window, averaged over matched pairs. Goals count only play after the branch point. Passes count attempts.', '表中是每个实验窗口的事件数，再对配对运行取均值。进失球仅计分支开始后的变化，传球按尝试次数统计。')}</p>
    <div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Team event', '球队事件')}</th><th>A</th><th>B</th><th>Δ (B − A)</th></tr></thead><tbody>${rows}</tbody></table></div></div></section>`;
}
