import {SIGNAL_TYPES,compileWires} from './ground-design.js';

const NODES={
  R:{w:108,tag:'r[k]',name:['Reference','参考输入'],detail:['Position request','位移指令']},
  F:{w:128,tag:'F(z)',name:['Prefilter','参考预滤波'],detail:['Reference memory','参考平滑']},
  E:{w:112,tag:'Σ',name:['Error','误差求和'],detail:['Pinned reference','锚点参考']},
  C:{w:138,tag:'C(z)',name:['Controller','控制器'],detail:['Private memory','独立记忆']},
  P:{w:150,tag:'P(z)',name:['Player plant','球员模型'],detail:['Exact ZOH','零阶保持']},
  H:{w:144,tag:'H(z)',name:['Sensor filter','测量滤波'],detail:['Measured position','测量位移']},
  G:{w:180,tag:'gL + D',name:['Agent network','智能体网络'],detail:['Links + anchors','邻居与锚点']},
};
const height=76;
const socketName={'F.in':'F · in','E.r':'Σ · r','C.in':'C · e','P.in':'P · u','H.in':'H · y','G.in':'G · y','E.fb':'Σ · feedback'};
const nodeOf=socket=>socket.split('.')[0];
function port(layout,id,output=false) {
  const key=output?id:nodeOf(id);
  const [x,y]=layout[key],w=NODES[key].w;
  if (output) {
    if(key==='P')return [x+w*.5,y+height,0,1];
    if(key==='G'||key==='H')return [x,y+height*.5,-1,0];
    return [x+w,y+height*.5,1,0];
  }
  if(id==='E.fb')return [x+w*.5,y+height,0,1];
  if(id==='H.in')return [x+w*.5,y,0,-1];
  if(id==='G.in')return [x+w,y+height*.5,1,0];
  return [x,y+height*.5,-1,0];
}
function route(from,to) {
  const [x,y,dx,dy]=from,[endX,endY,endDx,endDy]=to;
  const bend=Math.max(28,Math.min(78,Math.hypot(endX-x,endY-y)*.46));
  return `M ${x} ${y} C ${x+bend*dx} ${y+bend*dy}, ${endX+bend*endDx} ${endY+bend*endDy}, ${endX} ${endY}`;
}
function socket(x,y,dir,key,label,pending,compatible) {
  return `<g class="ground-port ${dir} ${pending?'armed':''} ${compatible?'accepts':''}" role="button" tabindex="0" aria-label="${label}" data-wire-${dir}="${key}" transform="translate(${x} ${y})">
    <title>${label}</title><circle r="11" fill="transparent"/><circle class="plug" r="5.5"/></g>`;
}
export function boardContents(design,lang,pending=null) {
  const idx=lang==='zh'?1:0,layout=design.layout,compiled=compileWires(design);
  const wires=Object.entries(design.wires).filter(([,source])=>source).map(([dest,source])=>{
    const d=route(port(layout,source,true),port(layout,dest));
    const kind=dest==='E.fb'?'return':dest.startsWith('G.')||dest.startsWith('H.')?'sense':'signal';
    return `<g class="ground-wire ${kind}" role="button" tabindex="0" data-wire-remove="${dest}" aria-label="${idx?'断开':'Unplug'} ${source} → ${socketName[dest]}"><title>${source} → ${socketName[dest]}</title><path class="wire-hit" d="${d}"/><path class="wire-line" d="${d}" marker-end="url(#ground-tip-${kind})"/></g>`;
  }).join('');
  const nodes=Object.entries(NODES).map(([key,def])=>{
    const [x,y]=layout[key];
    const unused=(key==='F' && !compiled.config.refTau)||(key==='H' && !compiled.config.sensorTau)||(key==='C' && design.wires['P.in']==='E');
    let description=def.detail[idx];
    if(key==='C')description=design.control.type.toUpperCase();
    if(key==='E')description=design.wires['E.fb']?(design.polarity===1?(idx?'正反馈 +':'Positive feedback +'):(idx?'负反馈 −':'Negative feedback −')):(idx?'外环断开':'Outer loop open');
    if(key==='G')description=`11 ${idx?'名球员':'agents'} · ${design.edges.length} ${idx?'条边':'edges'}`;
    const inputs=Object.keys(SIGNAL_TYPES).filter(k=>nodeOf(k)===key).map(k=>{
      const [px,py]=port(layout,k);
      return socket(px,py,'in',k,`${idx?'接入':'Connect to'} ${socketName[k]}`,false,pending&&SIGNAL_TYPES[k].includes(pending));
    }).join('');
    const [ox,oy]=port(layout,key,true);
    return `<g class="ground-block ${unused?'bypassed':''}"><g data-handle="${key}" role="button" tabindex="0" aria-label="${idx?'移动模块':'Move block'} ${key}">
      <rect x="${x}" y="${y}" width="${def.w}" height="${height}" rx="10"/><text class="block-symbol" x="${x+12}" y="${y+18}">${def.tag}</text>
      <text class="block-title" x="${x+12}" y="${y+39}">${def.name[idx]}</text><text class="block-hint" x="${x+12}" y="${y+59}">${description}</text></g>
      ${inputs}${socket(ox,oy,'out',key,`${idx?'输出端口':'Output port'} ${key}`,pending===key,false)}</g>`;
  }).join('');
  // Observer-based/predictive controllers also consume their own local observation.
  let measurementWire='';
  if(design.wires['P.in']==='C' && ['adrc','mpc'].includes(design.control.type)) {
    const measured=compiled.config.sensorTau?'H':'P';
    const [x,y]=layout.C;
    const dest=[x+55,y+height,0,1];
    measurementWire='<g class="ground-wire sense internal" aria-label="Local measurement"><path class="wire-line" d="'+route(port(layout,measured,true),dest)+'" marker-end="url(#ground-tip-sense)"/><text x="'+(dest[0]+6)+'" y="'+(dest[1]+16)+'" fill="#99c8e8" font-size="11">mᵢ</text></g>';
  }
  const defs=['signal','sense','return'].map((k,i)=>`<marker id="ground-tip-${k}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,1 L7,4 L0,7" fill="none" stroke="${['#9cddc5','#80bce9','#efa78b'][i]}"/></marker>`).join('');
  return `<defs>${defs}</defs>${wires}${measurementWire}${nodes}<path id="ground-cable" fill="none" stroke="#ecc77a" stroke-dasharray="4 3"/>`;
}
export function boardPage(design,lang,pending) {
  const L=(en,zh)=>lang==='zh'?zh:en;
  const graph=compileWires(design);
  return `<section class="panel ground-card"><div class="ground-section-title"><div><span class="eyebrow">SIGNAL WORKSPACE</span><h2>${L('Wire the feedback loop','搭建反馈回路')}</h2></div><span class="ground-badge ${graph.valid?'':'warm'}">${graph.valid?L('Ready to run','可运行'):L('Incomplete main path','主链未接通')}</span></div>
    <div class="ground-pills">${[['direct','Direct feedback','直接反馈'],['filtered','Filtered feedback','双滤波反馈'],['positive','Positive feedback','正反馈'],['open','Open outer loop','外环断开'],['bypass','Unit gain','单位增益直通']].map(([key,en,zh])=>`<button data-g-action="wire-template" data-value="${key}">${L(en,zh)}</button>`).join('')}</div>
    <p class="ground-guide">${L('Drag blocks to arrange. Connect a mint output to a blue input by dragging or tapping both ports. Click a wire to unplug it. Arrow keys move a focused block.','拖动模块排列。可从绿色输出端拖线到蓝色输入端，也可依次点两个端口。点击连线即可断开。选中模块后可用方向键移动。')}</p>
    <div class="ground-board-scroll"><svg id="ground-board" viewBox="0 0 950 366" aria-label="${L('Editable feedback wiring','可编辑反馈接线图')}" role="group">${boardContents(design,lang,pending)}</svg></div>
    <div class="ground-wire-tools"><label>${L('Output','输出端')}<select id="ground-source">${Object.keys(NODES).map(k=>`<option value="${k}">${k} · ${NODES[k].name[lang==='zh'?1:0]}</option>`).join('')}</select></label>
      <label>${L('Input','输入端')}<select id="ground-destination">${Object.keys(SIGNAL_TYPES).map(k=>`<option value="${k}">${socketName[k]}</option>`).join('')}</select></label>
      <button data-g-action="wire-connect">${L('Connect','连接')}</button><button data-g-action="wire-disconnect">${L('Unplug input','断开输入')}</button>
      <label>${L('Return sign','反馈符号')}<select data-ground-key="polarity"><option value="-1" ${design.polarity===-1?'selected':''}>− ${L('negative','负')}</option><option value="1" ${design.polarity===1?'selected':''}>+ ${L('positive','正')}</option></select></label></div>
    ${['adrc','mpc'].includes(graph.config.type)?'<p class="ground-guide">'+L('The dashed mᵢ connection supplies the local observer or predictor with its measurement, including when the outer network loop is open.','虚线 mᵢ 为本地观测器或预测器提供测量值，断开外层网络反馈时仍使用该通道。')+'</p>':''}
    <p role="status" id="ground-wire-status">${graph.valid?L('The active wires determine the sampled equations. Layout only changes the drawing.','接线决定执行方程。拖动模块的位置只改变排布。'):L('Reconnect: ','待接端口 ')+graph.missing.join(', ')}</p>
  </section>`;
}
export function wirePreview(layout,source,point){
  return route(port(layout,source,true),[...point,0,0]);
}
