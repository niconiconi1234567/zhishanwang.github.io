export const ENGINE_VERSION = "1.4.0";
export const ALGORITHM_EXAMPLE = {
  kind: "FlowController",
  schema: 1,
  name: "Anticipatory support",
  sampleTime: 0.1,
  description: "Local target feedback, velocity damping and ball anticipation.",
  parameters: { kp: 1.05, kd: 0.05, support: 0.06 },
  output: {
    x: "kp * base.x - kd * self.vx + support * ball.vx",
    y: "kp * base.y - kd * self.vy + support * ball.vy",
  },
  blend: 0.45,
  maxOutput: 7,
};
const SIGNALS = new Set([
  "base.x",
  "base.y",
  "self.x",
  "self.y",
  "self.vx",
  "self.vy",
  "target.x",
  "target.y",
  "centroid.x",
  "centroid.y",
  "reference.x",
  "reference.y",
  "ball.x",
  "ball.y",
  "ball.vx",
  "ball.vy",
  "ball.known",
  "time",
  "memory.x",
  "memory.y",
]);
const FNS = {
  abs: [Math.abs, 1],
  sqrt: [(x) => Math.sqrt(Math.max(0, x)), 1],
  sin: [Math.sin, 1],
  cos: [Math.cos, 1],
  tanh: [Math.tanh, 1],
  min: [Math.min, 2],
  max: [Math.max, 2],
  clamp: [(x, a, b) => Math.max(a, Math.min(b, x)), 3],
};
export function parseExpression(source, parameters = {}) {
  if (typeof source !== "string" || source.length > 1000)
    throw Error("expression_length");
  let tokens = [],
    i = 0;
  while (i < source.length) {
    const s = source.slice(i),
      ws = /^\s+/.exec(s);
    if (ws) {
      i += ws[0].length;
      continue;
    }
    const num = /^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i.exec(s);
    const id = /^[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?/.exec(s);
    const token = num?.[0] || id?.[0] || s[0];
    if (!num && !id && !"+-*/(),".includes(token)) throw Error("invalid_token");
    tokens.push(token);
    i += token.length;
    if (tokens.length > 160) throw Error("expression_budget");
  }
  let at = 0,
    depth = 0;
  function expr(min = 0) {
    if (++depth > 24) throw Error("expression_budget");
    let t = tokens[at++],
      node;
    if (t === "-" || t === "+")
      node = { op: t === "-" ? "neg" : "pos", a: expr(3) };
    else if (t === "(") {
      node = expr();
      if (tokens[at++] !== ")") throw Error("parenthesis");
    } else if (t && /^(?:\d|\.)/.test(t)) {
      node = { op: "num", v: Number(t) };
      if (!Number.isFinite(node.v)) throw Error("nonfinite");
    } else if (t && Object.hasOwn(FNS, t)) {
      if (tokens[at++] !== "(") throw Error("function_syntax");
      let args = [];
      if (tokens[at] !== ")") {
        do {
          args.push(expr());
          if (tokens[at] !== ",") break;
          at++;
        } while (true);
      }
      if (tokens[at++] !== ")" || args.length !== FNS[t][1])
        throw Error("function_arity");
      node = { op: "fn", fn: t, args };
    } else if (SIGNALS.has(t) || Object.hasOwn(parameters, t))
      node = { op: "signal", name: t };
    else throw Error("unknown_signal");
    while (at < tokens.length) {
      const o = tokens[at],
        prec = o === "+" || o === "-" ? 1 : o === "*" || o === "/" ? 2 : 0;
      if (!prec || prec <= min) break;
      at++;
      node = { op: o, a: node, b: expr(prec) };
    }
    depth--;
    return node;
  }
  const ast = expr();
  if (at !== tokens.length) throw Error("trailing_token");
  return ast;
}
export function evaluate(ast, data, parameters = {}) {
  const ev = (n) => {
    switch (n.op) {
      case "num":
        return n.v;
      case "signal": {
        if (Object.hasOwn(parameters, n.name)) return parameters[n.name];
        const [a, b] = n.name.split(".");
        return b ? (data[a]?.[b] ?? 0) : (data[a] ?? 0);
      }
      case "neg":
        return -ev(n.a);
      case "pos":
        return ev(n.a);
      case "+":
        return ev(n.a) + ev(n.b);
      case "-":
        return ev(n.a) - ev(n.b);
      case "*":
        return ev(n.a) * ev(n.b);
      case "/": {
        const b = ev(n.b);
        return Math.abs(b) < 1e-8 ? 0 : ev(n.a) / b;
      }
      case "fn":
        return FNS[n.fn][0](...n.args.map(ev));
      default:
        return 0;
    }
  };
  const v = ev(ast);
  return Number.isFinite(v) ? Math.max(-1e4, Math.min(1e4, v)) : 0;
}
export function validateAlgorithm(value) {
  const a =
    typeof value === "string" ? JSON.parse(value) : structuredClone(value);
  if (!a || a.kind !== "FlowController" || a.schema !== 1)
    throw Error("algorithm_schema");
  if (typeof a.name !== "string" || !a.name.trim() || a.name.length > 64)
    throw Error("algorithm_name");
  if (a.sampleTime !== 0.1) throw Error("sample_time");
  if (
    !a.parameters ||
    typeof a.parameters !== "object" ||
    Array.isArray(a.parameters) ||
    Object.keys(a.parameters).length > 16
  )
    throw Error("parameters");
  for (const [k, v] of Object.entries(a.parameters))
    if (
      !/^[a-zA-Z][a-zA-Z0-9_]{0,20}$/.test(k) ||
      Object.hasOwn(FNS, k) ||
      [
        "self",
        "base",
        "target",
        "time",
        "memory",
        "ball",
        "reference",
        "centroid",
        "constructor",
        "prototype",
        "__proto__",
      ].includes(k) ||
      typeof v !== "number" ||
      !Number.isFinite(v) ||
      Math.abs(v) > 100
    )
      throw Error("parameters");
  if (
    !Number.isFinite(a.blend) ||
    a.blend < 0 ||
    a.blend > 1 ||
    !Number.isFinite(a.maxOutput) ||
    a.maxOutput <= 0 ||
    a.maxOutput > 12
  )
    throw Error("output_bounds");
  const x = parseExpression(a.output?.x, a.parameters),
    y = parseExpression(a.output?.y, a.parameters);
  return {
    config: {
      kind: a.kind,
      schema: 1,
      name: a.name,
      description: String(a.description || "").slice(0, 300),
      sampleTime: 0.1,
      parameters: a.parameters,
      output: a.output,
      blend: a.blend,
      maxOutput: a.maxOutput,
    },
    x,
    y,
  };
}
export function executeAlgorithm(compiled, data) {
  const { config: a } = compiled;
  const x = evaluate(compiled.x, data, a.parameters),
    y = evaluate(compiled.y, data, a.parameters),
    n = Math.hypot(x, y),
    s = Math.min(1, a.maxOutput / (n || 1));
  return { x: x * s, y: y * s };
}
