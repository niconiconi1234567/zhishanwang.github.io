// Local Information -> Mission -> Execution. No global player/ball array is read.
export const MISSION_STATES=['hold','collect','press','screen','cover','recover','support','carry'];
export const MISSION_GUARDS=['unknown','own_ball','loose_candidate','press_candidate','cover_candidate','screen_candidate','team_ball','displaced','always'];
export const MISSION_ROLES=['auto','press','cover','screen','support','hold'];
export const STAGES=['gain','attack','loss','defend','loose','stopped'];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export function defaultMission(){return {enabled:false,structure:'balanced',aggression:.5,pressRange:22,coverDepth:8,
  compactness:.6,taskGain:1.3,shapeWeight:.45,recoverDistance:14,minDwell:.6,guardDwell:.2,
  maxEvidenceAge:1.2,deadline:2,pressRadius:3,coverRadius:5,laneRadius:2,revision:0,
  roles:Array(11).fill('auto'),rules:[
    {guard:'unknown',state:'recover',enabled:true},{guard:'own_ball',state:'carry',enabled:true},
    {guard:'loose_candidate',state:'collect',enabled:true},
    {guard:'press_candidate',state:'press',enabled:true},{guard:'cover_candidate',state:'cover',enabled:true},
    {guard:'screen_candidate',state:'screen',enabled:true},{guard:'team_ball',state:'support',enabled:true},
    {guard:'displaced',state:'recover',enabled:true},{guard:'always',state:'hold',enabled:true}]};}
export function missionPreset(name){
  const p=defaultMission();p.enabled=true;p.structure=name;
  if(name==='shield')Object.assign(p,{aggression:.2,pressRange:15,coverDepth:10,compactness:.85,shapeWeight:.7});
  if(name==='hunt')Object.assign(p,{aggression:.85,pressRange:30,coverDepth:7,compactness:.55,shapeWeight:.3});
  if(name==='lanes')Object.assign(p,{aggression:.45,pressRange:23,coverDepth:8,compactness:.7,shapeWeight:.5});
  if(name==='lanes')p.roles[5]='screen';
  return p;
}
export function validateMission(input){
  if(input==null)return defaultMission();
  const p={...defaultMission(),...structuredClone(input)};
  if(typeof p.enabled!=='boolean'||!['balanced','shield','hunt','lanes'].includes(p.structure))throw Error('mission_policy');
  for(const [k,a,b] of [['aggression',0,1],['pressRange',5,40],['coverDepth',3,18],['compactness',0,1],
    ['taskGain',.1,3],['shapeWeight',0,1],['recoverDistance',3,30],['minDwell',0,3],['guardDwell',0,1],
    ['maxEvidenceAge',.1,3],['deadline',.3,6],['pressRadius',1,5],['coverRadius',1,10],['laneRadius',.5,4]])
    if(!Number.isFinite(p[k])||p[k]<a||p[k]>b)throw Error('mission_policy');
  if(!Number.isInteger(p.revision)||p.revision<0||p.revision>10000000)throw Error('mission_policy');
  if(!Array.isArray(p.roles)||p.roles.length!==11||!p.roles.every(r=>MISSION_ROLES.includes(r)))throw Error('mission_policy');
  if(!Array.isArray(p.rules)||p.rules.length<1||p.rules.length>16||p.rules.some(r=>!MISSION_GUARDS.includes(r.guard)||!MISSION_STATES.includes(r.state)||typeof r.enabled!=='boolean'))throw Error('mission_policy');
  p.rules=p.rules.map(({guard,state,enabled})=>({guard,state,enabled}));
  return Object.fromEntries(Object.keys(defaultMission()).map(k=>[k,p[k]]));
}
export function segmentPoint(a,b,f){return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f};}
export function pointSegmentDistance(p,a,b){
  const dx=b.x-a.x,dy=b.y-a.y,f=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1),0,1);
  return dist(p,segmentPoint(a,b,f));
}
export function validMissionMemory(m,time){
  const vec=v=>v&&Number.isFinite(v.x)&&Number.isFinite(v.y);
  return !!m&&MISSION_STATES.includes(m.state)&&Number.isFinite(m.enteredAt)&&m.enteredAt<=time+1e-6&&
    Number.isFinite(m.pendingSince)&&m.pendingSince<=time+1e-6&&MISSION_STATES.includes(m.pending)&&
    Number.isInteger(m.transitions)&&m.transitions>=0&&Number.isInteger(m.revision)&&m.revision>=0&&
    vec(m.target)&&vec(m.baseTarget)&&m.evidence&&typeof m.evidence==='object'&&
    typeof m.rule==='string'&&typeof m.pendingRule==='string'&&Number.isFinite(m.sampleTime)&&m.sampleTime<=time+1e-6;
}
export function localMission(p,policy,baseTarget,time,d,publicPhase='live'){
  const ball=p.knownBall,age=ball?time-ball.time:null;
  const known=!!ball&&age>=-1e-8&&age<=policy.maxEvidenceAge;
  const owned=known&&ball.owner>=0,attack=owned&&Math.floor(ball.owner/11)===p.team;
  const defend=owned&&!attack,own=known&&ball.owner===p.id;
  const mates=new Map([[p.id,{id:p.id,x:p.x,y:p.y,time,via:'self',mission:p.mission}]]);
  for(const [id,n] of Object.entries(p.neighbors||{}))if(time-n.time>=-1e-8&&time-n.time<=policy.maxEvidenceAge)
    mates.set(+id,{...n,id:+id,via:'message'});
  for(const q of p.visible||[])if(q.team===p.team)mates.set(q.id,{...q,via:'vision'});
  const peers=[...mates.values()].filter(q=>q.id%11!==0&&Math.floor(q.id/11)===p.team);
  const ranked=known?peers.filter(q=>policy.roles[q.id%11]!=='hold')
    .sort((a,b)=>((dist(a,ball)-(policy.roles[a.id%11]==='press'?4:0))-(dist(b,ball)-(policy.roles[b.id%11]==='press'?4:0)))||a.id-b.id):[];
  const presser=ranked.find(q=>!['cover','screen','support'].includes(policy.roles[q.id%11]))??ranked[0];
  const coverPoint=known?{x:clamp(ball.x-d*policy.coverDepth,-49,49),y:ball.y*(1-.35*policy.compactness)}:baseTarget;
  const others=ranked.filter(q=>q.id!==presser?.id);
  others.sort((a,b)=>(dist(a,coverPoint)-(policy.roles[a.id%11]==='cover'?5:0))-(dist(b,coverPoint)-(policy.roles[b.id%11]==='cover'?5:0))||a.id-b.id);
  const coverer=others.find(q=>!['screen','support'].includes(policy.roles[q.id%11]))??others[0];
  const outlets=known?(p.visible||[]).filter(q=>q.team!==p.team&&q.id!==ball.owner&&dist(q,ball)>4)
    .sort((a,b)=>((a.x-ball.x)*d-(b.x-ball.x)*d)||a.id-b.id).slice(0,2):[];
  const screeners=ranked.filter(q=>q.id!==presser?.id&&q.id!==coverer?.id);
  const screenIndex=screeners.findIndex(q=>q.id===p.id),outlet=outlets[Math.max(0,screenIndex)%Math.max(1,outlets.length)];
  const role=policy.roles[p.index],shapeError=dist(p,baseTarget);
  const recoverThreshold=policy.recoverDistance*(p.mission?.state==='recover'?.75:1);
  const active=publicPhase==='live';
  const guards={unknown:!known||!active,own_ball:active&&own,
    loose_candidate:active&&known&&!owned&&p.id===presser?.id&&role!=='hold',
    press_candidate:active&&defend&&p.id===presser?.id&&dist(p,ball)<=policy.pressRange*(.8+.4*policy.aggression)&&role!=='hold',
    cover_candidate:active&&defend&&p.id===coverer?.id&&role!=='hold',
    screen_candidate:active&&defend&&screenIndex>=0&&screenIndex<2&&!!outlet&&role!=='hold',
    team_ball:active&&attack&&!own&&role!=='hold',displaced:shapeError>recoverThreshold,always:true};
  let rule=policy.rules.find(r=>r.enabled&&guards[r.guard])??{guard:'always',state:'hold'};
  // Task preconditions are execution guards, even for user-edited transition rules.
  if(['press','cover','screen'].includes(rule.state)&&!defend)rule={guard:'unavailable',state:'recover'};
  if(rule.state==='screen'&&!outlet)rule={guard:'no_lane',state:'recover'};
  if(rule.state==='carry'&&!own)rule={guard:'no_possession',state:'hold'};
  if(rule.state==='support'&&!attack)rule={guard:'no_team_possession',state:'hold'};
  if(rule.state==='collect'&&(!known||owned))rule={guard:'unavailable',state:'recover'};
  const old=p.mission??{state:'hold',enteredAt:time,revision:policy.revision,pending:null,pendingSince:time,transitions:0};
  const acceptedCover=Object.entries(p.neighbors||{}).map(([id,n])=>({...n,id:+id})).find(q=>q.id!==p.id&&Math.floor(q.id/11)===p.team&&q.id%11!==0&&q.mission?.state==='cover'&&
    time-q.time>=-1e-8&&time-q.time<=policy.maxEvidenceAge&&dist(q,coverPoint)<=policy.coverRadius);
  // The incumbent retains coverage until a fresh state message acknowledges a
  // replacement already in the region. Visual proximity alone is not an ACK.
  const handoffPending=old.state==='cover'&&defend&&rule.state!=='cover'&&!acceptedCover;
  if(handoffPending)rule={guard:'await_cover_ack',state:'cover'};
  let next={...old};
  if(next.pending!==rule.state||next.pendingRule!==rule.guard){next.pending=rule.state;next.pendingRule=rule.guard;next.pendingSince=time;}
  const urgent=!active||!known||own||(['press','cover','screen'].includes(old.state)&&!defend)||(old.state==='carry'&&!own)||(old.state==='support'&&!attack)||(old.state==='screen'&&!outlet)||(old.state==='collect'&&owned);
  let changed=false;
  if(rule.state!==old.state&&(urgent||(time-next.pendingSince+1e-8>=policy.guardDwell&&time-old.enteredAt+1e-8>=policy.minDwell))){
    next.state=rule.state;next.enteredAt=time;next.transitions++;changed=true;
  }
  let target={...baseTarget};
  if(['press','collect'].includes(next.state)&&known)target={x:ball.x+ball.vx*.2,y:ball.y+ball.vy*.2};
  if(next.state==='cover'&&known)target={...coverPoint};
  if(next.state==='screen'&&outlet)target=segmentPoint(ball,outlet,.42+.12*policy.aggression);
  if(next.state==='support'&&known)target={x:baseTarget.x+d*(2+5*policy.aggression),y:baseTarget.y*(1-.15*policy.compactness)+ball.y*.15};
  if(next.state==='carry'&&known)target={x:p.x+d*10,y:p.y*.85};
  target={x:clamp(target.x,-49,49),y:clamp(target.y,-31,31)};
  const evidence={ballSource:known?ball.via:'none',ballAge:age,localPhase:!active?'stopped':!known?'unknown':attack?'attack':defend?'defend':'loose',
    shapeError,peers:peers.length,presser:presser?.id??null,coverer:coverer?.id??null,outlet:outlet?.id??null,
    handoffPending,handoffAccepted:acceptedCover?.id??null,
    guards,observedCover:coverer?{id:coverer.id,distance:dist(coverer,coverPoint),source:coverer.via,time:coverer.time}:null};
  Object.assign(next,{target,baseTarget:{...baseTarget},rule:rule.guard,evidence,revision:policy.revision,sampleTime:time,
    lane:outlet?{from:{x:ball.x,y:ball.y},to:{x:outlet.x,y:outlet.y},receiver:outlet.id}:null});
  const transition=changed?{from:old.state,to:next.state,rule:rule.guard,evidence,revision:policy.revision,
    target:{...target},baseTarget:{...baseTarget},duration:time-old.enteredAt}:null;
  return {mission:next,transition};
}
export function phaseState(previous,owner,phase,time){
  const p=previous??{lastTeam:-1,changedAt:time,serial:0,labels:['stopped','stopped']};
  const team=owner>=0?Math.floor(owner/11):-1;
  const n={...p};
  if(team>=0&&team!==p.lastTeam){n.changedAt=time;n.lastTeam=team;}
  n.labels=[0,1].map(t=>phase!=='live'?'stopped':team<0?'loose':team===t?(time-n.changedAt<3?'gain':'attack'):(time-n.changedAt<3?'loss':'defend'));
  if(n.labels.some((x,i)=>x!==p.labels[i]))n.serial=p.serial+1;
  return n;
}
