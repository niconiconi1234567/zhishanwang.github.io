import {groupMetrics} from './mas-model.js';
export const tr=lang=>(en,zh)=>lang==='zh'?zh:en;
export const fmt=(v,n=2)=>Number.isFinite(v)?v.toFixed(n):'—';
export const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const panel=(title,body,extra='')=>`<section class="panel"><div class="panel-head"><h2>${title}</h2>${extra}</div><div class="panel-body">${body}</div></section>`;
export const stat=(label,value,unit,detail='')=>`<div class="mas-stat"><span>${label}</span><strong>${value}<small>${unit}</small></strong><p>${detail}</p></div>`;
const length=v=>Math.hypot(v?.x||0,v?.y||0);
const vector=v=>`(${fmt(v?.x)}, ${fmt(v?.y)})`;

export function calibrationGraph(calibration,lang){
  const L=tr(lang),nodes=Array.from({length:11},(_,i)=>({x:250+145*Math.cos(i*2*Math.PI/11-Math.PI/2),y:178+145*Math.sin(i*2*Math.PI/11-Math.PI/2)}));
  const path=(edge,color,width,dash='')=>{
    const a=nodes[edge.from],b=nodes[edge.to],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
    return `<path d="M${a.x+dx*13/d} ${a.y+dy*13/d}L${b.x-dx*15/d} ${b.y-dy*15/d}" fill="none" stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}" marker-end="url(#calibration-arrow)"/>`;
  };
  const known=calibration.weights.map(w=>path(w,'#687c8b',1,'3 4')).join('');
  const recovered=calibration.report.agents.filter(a=>a.identifiable).flatMap(a=>a.weights.filter(w=>Math.abs(w.weight)>.04)).map(w=>path(w,'#9be5c6',2)).join('');
  return `<svg class="mas-calibration-graph" viewBox="0 0 500 356" role="img" aria-label="${L('Known graph compared with recovered associations','已知网络与恢复的关联比较')}"><defs><marker id="calibration-arrow" markerWidth="5" markerHeight="5" refX="4.5" refY="2.5" orient="auto"><path d="M0 0L5 2.5L0 5Z" fill="#a1bdb8"/></marker></defs>${known}${recovered}${nodes.map((p,i)=>`<circle cx="${p.x}" cy="${p.y}" r="12" fill="#173347" stroke="#75b8e2"/><text x="${p.x}" y="${p.y+4}" text-anchor="middle" fill="#def0ff" font-size="11">${i+1}</text>`).join('')}</svg><p class="hint">${L('Dashed grey · known graph. Mint · recovered weights above 0.04 s⁻¹ when the design is full rank. Arrows point toward the receiver.','灰色虚线为已知网络，薄荷绿为满秩情况下恢复的 >0.04 s⁻¹ 系数，箭头指向接收方。')}</p>`;
}

export function nodeScene(state,{team,selected,mode='world',layer='relations',all=false,fit=null,lang='en'}={}) {
  const L=tr(lang),players=state.players.filter(p=>p.team===team),m=groupMetrics(state,team);
  const point=p=>mode==='error'?{x:p.x-p.target.x,y:p.y-p.target.y}:
    mode==='observer'?{x:p.estimate.x-m.center.x,y:p.estimate.y-m.center.y}:p;
  const data=players.map(point);
  const extent=mode==='world'?56:Math.max(5,Math.ceil(Math.max(...data.map(p=>Math.max(Math.abs(p.x),Math.abs(p.y))))/5)*5);
  // Equal metre scale on both axes. The current extent is printed in the view.
  const scale=mode==='world'?4.5:158/extent;
  const xy=p=>({x:300+p.x*scale,y:200-p.y*scale});
  const coords=data.map(xy);
  const line=(a,b,color,width=1,dash='',arrow=false)=>`<path d="M${a.x} ${a.y}L${b.x} ${b.y}" stroke="${color}" stroke-width="${width}" ${dash?`stroke-dasharray="${dash}"`:''} ${arrow?'marker-end="url(#mas-arrow)"':''} fill="none"/>`;
  let edges=[];
  for(const p of players){
    if(!all&&p.index!==selected)continue;
    if(layer==='relations')edges.push(...(p.controlTrace?.relations||[]).map(e=>({from:e.from%11,to:p.index,color:'#cfb775',value:length(e.error)})));
    if(layer==='messages')edges.push(...(p.controlTrace?.observerInputs||[]).map(e=>({from:e.from%11,to:p.index,color:'#72b6f7',value:e.age})));
    if(layer==='fit'){
      const model=fit?.agents?.[p.index];
      if(model?.informative)edges.push(...model.weights.filter(e=>Math.abs(e.weight)>=.025).sort((a,b)=>Math.abs(b.weight)-Math.abs(a.weight)).slice(0,4).map(e=>({...e,color:e.weight>=0?'#9be5c6':'#f58672',value:e.weight})));
    }
  }
  const links=edges.map(e=>{
    const start=coords[e.from],end=coords[e.to],dx=end.x-start.x,dy=end.y-start.y,d=Math.hypot(dx,dy)||1;
    const a={x:start.x+dx/d*13,y:start.y+dy/d*13},b={x:end.x-dx/d*15,y:end.y-dy/d*15};
    return `<g><title>#${e.from+1} → #${e.to+1} · ${fmt(e.value,3)} ${layer==='messages'?'s':layer==='fit'?'s⁻¹':'m'}</title>${line(a,b,e.color,layer==='fit'?Math.min(4,1+4*Math.abs(e.weight)):1.3,layer==='fit'?'5 4':'',true)}</g>`;
  }).join('');
  const p=players[selected],origin=coords[selected];
  let arrows='';
  if(p&&mode==='world'){
    const target=xy(p.target);
    arrows=line(origin,target,'#72b6f7',1.8,'5 5')+`<circle cx="${target.x}" cy="${target.y}" r="7" fill="none" stroke="#72b6f7"/><text x="${target.x+10}" y="${target.y-8}" fill="#72b6f7">r${selected+1}</text>`;
    arrows+=line(origin,xy({x:p.x+p.command.x,y:p.y+p.command.y}),'#dec58e',2.5,'',true);
    arrows+=line(origin,xy({x:p.x+p.vx,y:p.y+p.vy}),'#9be5c6',2,'',true);
  }
  if(p&&mode!=='world')arrows=line(origin,xy({x:0,y:0}),'#72b6f7',1.5,'5 4');
  const grid=Array.from({length:9},(_,i)=>{const x=60+i*60;return `<path d="M${x} 28V372M35 ${40+i*40}H565"/>`;}).join('');
  const nodes=players.map((p,i)=>{
    const a=coords[i],active=i===selected;
    return `<g role="button" tabindex="0" data-n-action="select" data-index="${i}" aria-label="${L('Inspect agent','检查智能体')} ${i+1} ${esc(p.name)}" class="mas-node ${active?'selected':''}">
      <title>#${i+1} ${esc(p.name)} · ${vector(point(p))} m</title>
      ${active?`<circle cx="${a.x}" cy="${a.y}" r="21" class="mas-halo"/>`:''}
      <circle cx="${a.x}" cy="${a.y}" r="${active?13:10}" style="fill:${active?'#9be5c6':team?'#f58672':'#72b6f7'}"/>
      <text x="${a.x}" y="${a.y+3.5}">${i+1}</text></g>`;
  }).join('');
  return `<svg class="mas-nodes" viewBox="0 0 600 400" role="group" aria-label="${L('Synchronized moving agent graph','同步运动的智能体网络')}">
    <defs><marker id="mas-arrow" markerWidth="5" markerHeight="5" refX="4.5" refY="2.5" orient="auto"><path d="M0 0L5 2.5L0 5Z" fill="#abc3cc"/></marker></defs>
    <g stroke="#233d50" stroke-width=".65" opacity=".6">${grid}</g>
    <path d="M300 28V372M35 200H565" stroke="#486274" stroke-dasharray="4 5"/>
    <circle cx="300" cy="200" r="3" fill="#72b6f7"/>
    <text x="316" y="190" fill="#8fa9bc" font-size="10">${mode==='world'?L('Pitch centre','球场中心'):mode==='error'?'p − r = 0':'ĉ − c = 0'}</text>
    ${links}${arrows}${nodes}
    <path d="M42 374h${10*scale}" stroke="#9eb5c3"/><text x="42" y="391" fill="#9eb5c3" font-size="10">10 m</text>
    <text x="560" y="22" text-anchor="end" fill="#9eb5c3" font-size="11">${mode==='world'?'WORLD':mode==='error'?'FORMATION ERROR':'OBSERVER ERROR'} · t ${fmt(state.time)} s</text>
  </svg>`;
}

export function tracePanel(state,team,index,lang) {
  const L=tr(lang),p=state.players.find(p=>p.team===team&&p.index===index),t=p?.controlTrace;
  if(!t)return `<p class="hint">${L('Waiting for the first control sample.','等待第一个控制采样。')}</p>`;
  const e={x:t.target.x-t.position.x,y:t.target.y-t.position.y};
  const parts=Object.entries(t.parts),maximum=Math.max(.1,...parts.map(([,v])=>length(v)));
  const names={formation:L('Formation & tracker','队形与跟踪器'),centroid:L('Centre feedback','中心反馈'),support:L('Ball task','足球任务'),group:L('Unit offset','子系统偏移'),avoidance:L('Avoidance','避碰'),compensator:L('Compensation','补偿'),algorithm:L('Custom algorithm','自定义算法'),mission:L('Mission reference','任务参考')};
  const summed=parts.reduce((s,[,v])=>({x:s.x+v.x,y:s.y+v.y}),{x:0,y:0});
  const closure=Math.hypot(summed.x-t.raw.x,summed.y-t.raw.y);
  const blocks=[['rᵢ',L('Role target','角色目标'),vector(t.target),'m'],['eᵢ',L('Position error','位置误差'),vector(e),'m'],['Σu',L('Desired command','期望指令'),vector(t.raw),'m/s'],['sat',L('Limited command','限幅后指令'),vector(t.command),'m/s']];
  return `<div class="mas-trace-head"><div><span class="eyebrow">AGENT ${String(index+1).padStart(2,'0')}</span><h3>${esc(p.name)} · ${esc(p.role)}</h3></div><span class="chip">${L('Control sample','控制采样')} ${fmt(t.time)} s</span></div>
    <div class="mas-signal-chain">${blocks.map(([symbol,name,value,unit])=>`<div><span>${symbol} · ${name}</span><b>${value}</b><small>${unit}</small></div>`).join('')}</div>
    <div class="mas-feedback">↳ ${L('Plant → measured position → error → local controller','球员动力学 → 实测位置 → 误差 → 局部控制器')} <span>${L('Current velocity','当前速度')} ${vector({x:p.vx,y:p.vy})} m/s</span></div>
    <div class="mas-command-bars">${parts.map(([key,v])=>`<div><label>${names[key]}</label><div class="mas-bar"><i style="width:${100*length(v)/maximum}%"></i></div><span>${vector(v)}</span></div>`).join('')}</div>
    <p class="hint">${L('Signed vectors in m/s. Sum-to-command residual','有符号向量，单位 m/s。分项求和残差')} ${closure.toExponential(1)} m/s · ${t.saturated?L('Speed limit active','速度限幅生效'):L('Within speed limit','指令位于速度范围内')}.</p>
    <div class="actions"><button data-action="open-local-loop">${L('Inspect controller','检查控制器')}</button><button data-action="fork">${L('Fork this state for A/B','从此刻分叉 A/B')}</button></div>`;
}

export function neighborPanel(state,team,index,lang) {
  const L=tr(lang),p=state.players.find(p=>p.team===team&&p.index===index),t=p?.controlTrace;
  if(!t)return '';
  const rows=t.relations.map(e=>{
    const q=state.players[e.from],d=Math.hypot(q.x-p.x,q.y-p.y),desired=length(e.offset);
    return `<tr><td>#${e.from%11+1} → #${index+1}</td><td>${e.source==='vision'?L('Vision','视觉'):L('Message','消息')} · ${fmt(e.age)} s</td><td>${fmt(d)} / ${fmt(desired)}</td><td>${vector(e.error)}</td></tr>`;
  }).join('');
  const sum=t.observerInputs.reduce((s,n)=>({x:s.x+n.correction.x,y:s.y+n.correction.y}),{x:0,y:0});
  return `<p class="hint">${L('A relationship compares the observed relative position with its desired formation offset. The distances below are current physical / desired metres. The error vector is sampled at the controller time.','关系反馈比较观测相对位置与期望队形偏移。下表距离为当前物理距离／期望距离，误差向量取自控制采样。')}</p>
    <div class="mas-equation">εᵢⱼ = (pⱼ,observed − pᵢ) − dᵢⱼ</div>
    <div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Sender → receiver','发送方 → 接收方')}</th><th>${L('Evidence / age','证据／年龄')}</th><th>${L('Distance / desired (m)','距离／期望（m）')}</th><th>εᵢⱼ (m)</th></tr></thead><tbody>${rows||`<tr><td colspan="4">${L('No usable relationship inputs in this sample.','该采样没有可用的关系输入。')}</td></tr>`}</tbody></table></div>
    <div class="mas-observer-update"><h3>${L('Local centroid observer','局部中心观测器')}</h3><div class="mas-equation">ĉᵢ⁺ = clip(ĉᵢ + Δpᵢ + γ Σⱼ (ĉⱼ,received − ĉᵢ))</div>
    <p>${L('Before','更新前')} ${vector(t.estimateBefore)} + ${L('own displacement','自身位移')} ${vector(t.displacement)} + ${L('message correction','消息修正')} ${vector(sum)} → ${L('after bounds','约束后')} ${vector(t.estimateAfter)} m</p>
    <div class="mas-message-tags">${t.observerInputs.map(e=>`<span>#${e.from%11+1} → #${index+1} · ${fmt(e.age)} s</span>`).join('')||L('No state packets used.','未使用状态消息。')}</div></div>`;
}

export function fitSummary(report,index,lang) {
  const L=tr(lang);
  if(!report)return `<div class="mas-empty"><span class="eyebrow">MOTION → MODEL → CHECK</span><h3>${L('Let the match provide evidence','让比赛积累运动证据')}</h3><p>${L('Collect at least 8 seconds of continuous play, then fit the current window. The first 70% trains the model. One interval is held out as a gap, then the remaining samples test it.','至少积累 8 秒连续比赛后，拟合当前窗口。前 70% 用于训练，隔开一个采样间隔后，使用剩余样本检验。')}</p></div>`;
  if(!report.available)return `<div class="note warn">${L('Need 40 usable intervals. Collected','需要 40 个有效间隔，当前已有')} ${report.intervals}. ${L('Continue the match or use a longer window.','请继续比赛或选择更长窗口。')}</div>`;
  const a=report.agents[index];
  const status=!a.identifiable?L('Ambiguous coefficients','系数不可区分'):a.informative?L('Predictive improvement','预测有改善'):L('No useful improvement','尚无有效改善');
  const metrics=stat(L('HELD-OUT RMSE','留出段 RMSE'),fmt(a.rmse,3),'m/s',L('Network response model','含邻居响应模型'))+
    stat(L('BASELINE RMSE','基线 RMSE'),fmt(a.baselineRmse,3),'m/s',L('Target + own velocity','目标＋自身速度'))+
    stat(L('RELATIVE GAIN','相对改善'),fmt(a.gain===null?null:a.gain*100,1),'%',L('Negative means a worse fit','负值表示预测变差'))+
    stat(L('DESIGN RANK','设计矩阵秩'),`${a.rank}/${a.columns}`,'',`${L('Condition','条件数')} ${fmt(a.condition,1)}`);
  const weights=[...a.weights].sort((a,b)=>Math.abs(b.weight)-Math.abs(a.weight));
  return `<div class="mas-fit-heading"><span class="chip ${a.informative?'live':''}">${status}</span><span class="hint">${L('Frozen window','固定分析窗口')} ${fmt(report.start,1)}–${fmt(report.end,1)} s · ${report.intervals} ${L('intervals','间隔')}</span></div>
    <div class="mas-stats">${metrics}</div>
    <p class="hint">${L('Training ends','训练截至')} ${fmt(report.trainEnd,1)} s · ${L('Validation starts','验证始于')} ${fmt(report.splitTime,1)} s · ${L('Excluded transitions','排除的跨界间隔')} ${report.excluded} · ${L('Training RMSE','训练 RMSE')} ${fmt(a.trainRmse,3)} m/s · ${L('Constant-velocity baseline','匀速基线')} ${fmt(a.constantVelocityRmse,3)} m/s.</p>
    <p class="mas-fit-verdict">${!a.identifiable?L('The sampled motions do not separate all candidate effects. Ridge gives a prediction, but the individual edge weights remain ambiguous. Fitted graph edges are withheld.','这段运动不能区分所有候选作用。正则化可以产生预测，但各条边的系数仍有歧义，图中暂不展示拟合边。'):!a.informative?L('Neighbor terms do not reduce future-window error by more than 5%. Keep collecting varied movement before interpreting a network.','邻居项未让后续窗口误差下降超过 5%。请积累更多不同的运动后，再解释交互网络。'):L('Neighbor terms improve this held-out prediction. Treat the displayed edges as motion associations; shared targets, football tasks and saturation can also create them.','邻居项改善了该留出段的预测。图中连线表示运动关联，共同目标、足球任务和限幅也可能造成这种关联。')}</p>
    <div class="mas-equation"><div>v̄<sub>i,k+1</sub> ≈ β<sub>i</sub>(r<sub>i</sub> − p<sub>i</sub>) + α<sub>i</sub>v<sub>i</sub></div><div>+ Σ<sub>j</sub> w<sub>ij</sub>(z<sub>j</sub> − z<sub>i</sub>) + b<sub>i</sub></div><small>z<sub>i</sub> = p<sub>i</sub> − r<sub>i</sub></small><br><small>v̄<sub>i,k+1</sub> = [p<sub>i</sub>(k+1) − p<sub>i</sub>(k)] / (0.2 s)</small></div>
    <div class="mas-coefficients"><span>βᵢ ${fmt(a.beta[0],3)} s⁻¹</span><span>αᵢ ${fmt(a.beta[1],3)}</span><span>bᵢ (${fmt(a.beta[2],3)}, ${fmt(a.beta[3],3)}) m/s</span></div>
    <details class="mas-coefficient-details"><summary>${L('Inspect all directed coefficients','查看全部有向系数')}</summary><div class="table-scroll"><table class="data-table"><thead><tr><th>${L('Candidate','候选关系')}</th><th>wᵢⱼ (s⁻¹)</th></tr></thead><tbody>${weights.map(w=>`<tr><td>#${w.from+1} → #${w.to+1}</td><td>${fmt(w.weight,4)}</td></tr>`).join('')}</tbody></table></div></details>`;
}
