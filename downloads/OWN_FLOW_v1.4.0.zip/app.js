import {NetworkStudio} from "./mas-studio.js";
import {MissionStudio} from './mission-studio.js';
import {GroundStudio} from "./ground-studio.js";
import {coachBoard} from "./coach-board.js";
import {buildPlaybook} from "./playbooks.js";
import {effectiveNetworkPanel,footballOutcomePanel} from "./effective-network.js";
import {closedLoop, networkArchitecture} from "./control-diagrams.js";
import {networkInsights, commandGraphic, benchmarkInsights} from "./insights.js";
import {plotChart} from "./charts.js";
import {typesetMath} from "./math-display.js";
const APP_VERSION = "1.4.0";
import { PitchRenderer } from "./renderer.js";
import { CanvasPitchRenderer } from "./renderer-canvas.js";
import {
  defaultTactic,
  validateTactic,
  graphEdges,
  graphHealth,
  FORMATIONS,
  ROLES,
  ENGINE_VERSION,
} from "./engine.js";
import { ALGORITHM_EXAMPLE, validateAlgorithm } from "./algorithm.js";
import { validateReplay } from "./replay.js";
import * as storage from "./storage.js";
const $ = (s) => document.querySelector(s),
  $$ = (s) => [...document.querySelectorAll(s)];
const escape = (x) =>
  String(x ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const makeId = () =>
  typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : Array.from(crypto.getRandomValues(new Uint32Array(4)), (n) =>
        n.toString(16).padStart(8, "0"),
      ).join("-");
const clone = (x) => structuredClone(x),
  num = (x, n = 2) => (Number.isFinite(x) ? x.toFixed(n) : "—"),
  clock = (t) =>
    `${Math.floor((t || 0) / 60)
      .toString()
      .padStart(2, "0")}:${Math.floor((t || 0) % 60)
      .toString()
      .padStart(2, "0")}`;
let lang = "en";
try {
  lang = localStorage.getItem("flow.lang") || "en";
} catch {}
const ui = {
  lang,
  page: "match",
  tabs: {
    tactics: "playbooks",
    control: "architecture",
    diagnostics: "why",
    agent: "local",
    research: "benchmark",
  },
  team: 0,
  selected: 7,
  block: "observer",
  camera: "broadcast",
  zoom: 1,
  focus: "overview",
  quality: "balanced",
  benchmarkView: "mean",
  coachPreset:"triangles",
  coachHomogeneous:false,
  scope: "selected",
  flags: {
    prediction: false,
    command: false,
    history: false,
    targets: false,
    centroids: false,
    tactical: false,
    communication: false,
    observation: false,
  },
  graph: "commEdges",
  edgeStart: null,
  controlScope: "team",
  scenario: "formation",
  intervention: "gain",
  duration: 45,
  seed: 361,
  benchmark: null,
  benchmarkTeam:0,
  benchmarkProgress: null,
  algorithmText: JSON.stringify(ALGORITHM_EXAMPLE, null, 2),
  algorithmValidated: null,
  compileError: null,
  replay: null,
  replayIndex: 0,
  replayActive: false,
  restoreAvailable: false,
  autosaveReady: false,
  autoPaused: false,
};
const L = (en, zh) => (ui.lang === "zh" ? zh : en);
let tactics = [defaultTactic(0), defaultTactic(1)],
  state = null,
  running = true,
  speed = 1,
  renderer = null,
  worker,
  requests = new Map(),
  requestId = 0,
  presets = storage.readPresets(),
  lastPaint = 0,
  lastSave = 0,
  benchWorker = null,
  importType = "preset",
  toaster;
let resumeAfterGround=false;
const ground=new GroundStudio({
  lang:()=>ui.lang,
  squad:()=>tactics[ui.team],
  teams:()=>tactics.map((team,i)=>[i,team.teamName]),
  team:()=>ui.team,
  chooseTeam:team=>{const index=ui.selected%11;ui.team=team;ui.selected=team*11+index;},
  render:()=>renderPage(),
  scene:snapshot=>{if (ui.page==="ground" && $("#pitch-host"))renderer?.setState(snapshot);},
  toast:message=>toast(message),
  apply:tracker=>{
    const tactic=clone(tactics[ui.team]);
    tactic.tracker=tracker;
    updateTactic(ui.team,tactic);
    toast(tracker?L("Role tracker applied to ","已应用角色跟踪器：")+tactic.teamName:L("Standard tracking restored","已恢复常规角色跟踪"));
    renderPage();
  },
});
const network = new NetworkStudio({
  lang:()=>ui.lang, team:()=>ui.team, selected:()=>ui.selected,
  state:()=>state, pickers:()=>teamPicker()+selectedControl(), pitch:()=>pitchCard(),
  tuning:()=>`<div class="two-cols">${slider(L("Formation gain","队形增益"),"kFormation",0,3,.05,cfg().kFormation)}${slider(L("Consensus step γ","共识步长 γ"),"gamma",0,.5,.01,cfg().gamma)}</div>`,
  select:id=>selectPlayer(id), render:()=>renderPage(), toast:message=>toast(message),
  tasks:()=>missions.live()
});
const missions=new MissionStudio({lang:()=>ui.lang,team:()=>ui.team,selected:()=>ui.selected,
  tactic:()=>cfg(),state:()=>state,select:id=>selectPlayer(id),render:()=>renderPage(),
  toast:message=>toast(message),report:()=>ask('missionReport'),
  apply:policy=>{const c=clone(cfg());c.mission=policy;updateTactic(ui.team,c);},
  open:where=>{if(where==='edit'){ui.page='tactics';ui.tabs.tactics='missions';}else{ui.page='network';network.tab='tasks';}renderPage();window.scrollTo(0,0);}
});
const iconPaths = {
  network:"M5 5l14 3-7 12z M5 5v10 M3 3h4v4H3z M17 6h4v4h-4z M10 18h4v4h-4z",
  ground:"M3 6h5v5H3z M10 6h5v5h-5z M17 6h4v5h-4z M8 8h2 M15 8h2 M19 11v6H6v-6",
  match:
    "M4 4h16v16H4z M12 4v16 M4 9h4v6H4 M20 9h-4v6h4 M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  tactics: "M5 5h4v4H5z M15 15h4v4h-4z M6 17h2 M16 7h2 M8 7h8v8 M7 9v6",
  control: "M3 6h6v6H3z M15 12h6v6h-6z M9 9h6v6 M6 12v6h9 M18 12V6H9",
  agent: "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M4 21v-2a8 8 0 0 1 16 0v2",
  diagnostics: "M3 12h4l3-7 4 14 3-7h4",
  library: "M4 4h5v16H4z M10 4h5v16h-5z M17 4l4 15-4 1-4-15",
  algorithm:
    "M8 4H5v6l-2 2 2 2v6h3 M16 4h3v6l2 2-2 2v6h-3 M11 8l-2 4 2 4 M13 8l2 4-2 4",
  research: "M6 3h12 M9 3v6L4 19v2h16v-2L15 9V3 M7 15h10",
  play: "M8 5l11 7-11 7z",
  pause: "M7 5v14 M17 5v14",
  save: "M4 3h13l3 3v15H4z M8 3v6h8V3 M8 21v-8h8v8",
  download: "M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5",
  upload: "M12 16V4 M7 9l5-5 5 5 M4 17v4h16v-4",
  arrow: "M4 12h16 M14 6l6 6-6 6",
  reset: "M4 10a8 8 0 1 1 1 8 M4 3v7h7",
  eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7 M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  help: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20 M9 8a3 3 0 0 1 6 0c0 2-3 2-3 5 M12 17v.2",
  menu: "M4 6h16 M4 12h16 M4 18h16",
  close: "M6 6l12 12 M18 6L6 18",
  expand: "M8 3H3v5 M16 3h5v5 M3 16v5h5 M21 16v5h-5",
  plus: "M12 4v16 M4 12h16",
  step: "M6 5l10 7-10 7z M19 5v14",
  check: "M4 12l5 5L20 6",
  graph:
    "M6 6l12 3-6 11z M8 6a2 2 0 1 1-4 0 2 2 0 0 1 4 0 M20 9a2 2 0 1 1-4 0 2 2 0 0 1 4 0 M14 20a2 2 0 1 1-4 0 2 2 0 0 1 4 0",
  settings: "M4 7h16 M4 17h16 M8 4v6 M16 14v6",
};
const icon = (k) =>
  `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${iconPaths[k] || iconPaths.control}"/></svg>`;
const button = (label, action, cls = "", attrs = "", ic = "") =>
  `<button class="${cls}" data-action="${action}" ${attrs}>${ic ? icon(ic) : ""}${label}</button>`;
const panel = (title, body, extra = "", footer = "") =>
  `<section class="panel"><div class="panel-head"><h2>${title}</h2>${extra}</div><div class="panel-body">${body}</div>${footer ? `<div class="panel-footer">${footer}</div>` : ""}</section>`;
const dataRow = (label, value, id = "") =>
  `<div class="data-row"><span>${label}</span><strong ${id ? `data-live="${id}"` : ""}>${value}</strong></div>`;
const heading = (
  title,
  subtitle,
  actions = "",
  kicker = "FOOTBALL × MULTI-AGENT INTELLIGENCE",
) =>
  `<div class="page-head"><div class="page-title"><div class="eyebrow">${kicker}</div><h1>${title}</h1><p>${subtitle}</p></div><div class="head-actions">${actions}</div></div>`;
const tabBar = (page, items) =>
  `<div class="tabs" role="tablist">${items.map(([id, en, zh]) => `<button role="tab" aria-selected="${ui.tabs[page] === id}" class="tab ${ui.tabs[page] === id ? "active" : ""}" data-action="tab" data-page="${page}" data-tab="${id}">${L(en, zh)}</button>`).join("")}</div>`;
const teamPicker = () =>
  `<div class="team-picker" aria-label="${L("Editing team", "编辑球队")}">${tactics.map((c, t) => `<button data-action="team" data-team="${t}" class="${ui.team === t ? "active" : ""}"><i class="dot" style="background:${c.color}"></i>${L(t ? "Coral" : "Blue", t ? "珊瑚红队" : "蓝队")}</button>`).join("")}</div>`;
const cfg = () =>
    ui.replayActive && ui.replay
      ? (ui.replay.frames[ui.replayIndex].tactics || ui.replay.tactics)[ui.team]
      : tactics[ui.team],
  player = () => viewState()?.players[ui.selected],
  selectedIndex = () => ui.selected % 11;
const option = (value, label, current) =>
  `<option value="${escape(value)}" ${String(value) === String(current) ? "selected" : ""}>${escape(label)}</option>`;
let fieldCount = 0;
const field = (label, content, hint = "") => {
  const existing = content.match(/\bid="([^"]+)"/),
    id = existing ? existing[1] : "field-" + ++fieldCount;
  if (!existing)
    content = content.replace(/<(input|select|textarea)\b/, `<$1 id="${id}"`);
  return `<div class="form-field"><label for="${id}">${label}</label>${content}${hint ? `<small>${hint}</small>` : ""}</div>`;
};
const selectField = (label, key, choices, value, source = "config") =>
  field(
    label,
    `<select data-source="${source}" data-key="${key}" aria-label="${escape(label)}">${choices.map(([v, l]) => option(v, l, value)).join("")}</select>`,
  );
const slider = (
  label,
  key,
  min,
  max,
  step,
  value,
  unit = "",
  source = "config",
) =>
  `<div class="form-field"><label for="slider-${source}-${key}">${label}<output id="out-${source}-${key}">${num(value, step >= 1 ? 0 : 2)}${unit}</output></label><input id="slider-${source}-${key}" type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-source="${source}" data-key="${key}" data-unit="${unit}"></div>`;
const empirical = () =>
  `<span class="chip empirical">${L("Empirical simulation", "数值仿真")}</span>`;
function metric(label, value, unit = "", id = "", foot = "", spark = "") {
  return `<div class="metric"><div class="metric-label">${label}</div><div class="metric-value"><span ${id ? `data-live="${id}"` : ""}>${value}</span><small>${unit}</small></div>${spark ? `<canvas class="spark" data-chart="${spark}"></canvas>` : ""}${foot ? `<div class="metric-foot">${foot}</div>` : ""}</div>`;
}
function navName(key) {
  return {
    match: L("Match", "赛场"),
    ground:L("Control Ground","控制训练场"),
    network:L("Network Studio","多智能体工作台"),
    tactics: L("Tactics Studio", "战术工作室"),
    control: L("Control Laboratory", "控制实验室"),
    agent: L("Agent Perspective", "球员视角"),
    diagnostics: L("Diagnostics", "诊断与解释"),
    library: L("Tactical Library", "战术资料库"),
    algorithm: L("Algorithm Studio", "算法工作室"),
    research: L("Research Benchmark", "科研基准"),
  }[key];
}
function renderShell() {
  $("#app").innerHTML =
    `<header class="topbar"><div class="brand">${button("", "menu", "icon-only quiet mobile-menu", `aria-label="${L("Open navigation", "打开导航")}"`, "menu")}<div class="brand-mark">∿</div><div><div class="brand-name">OWN <span>/ FLOW</span></div><div class="brand-sub">FOOTBALL INTELLIGENCE LAB</div></div></div><div class="top-meta"><span class="status-text"><i class="status-dot"></i>${L("22 autonomous agents · One shared world", "22 个自主智能体 · 同一个物理世界")}</span></div><div class="top-actions"><span class="version">v${APP_VERSION}</span>${button("EN", "lang", ui.lang === "en" ? "lang-active" : "quiet", 'data-lang="en"')}${button("中文", "lang", ui.lang === "zh" ? "lang-active" : "quiet", 'data-lang="zh"')}${button("", "help", "icon-only quiet", `aria-label="${L("Quick guide", "使用指南")}"`, "help")}</div></header><aside class="sidebar"><div class="nav-section">${L("THE WORKSPACE", "工作台")}</div>${["match", "tactics", "control", "network", "agent", "diagnostics"].map((k) => `<button class="nav-item ${ui.page === k ? "active" : ""}" data-action="nav" data-page="${k}" title="${navName(k)}">${icon(k)}<span>${navName(k)}</span></button>`).join("")}<div class="nav-section">${L("BUILD & EXPERIMENT", "构建与实验")}</div>${["ground", "library", "algorithm", "research"].map((k) => `<button class="nav-item ${ui.page === k ? "active" : ""}" data-action="nav" data-page="${k}" title="${navName(k)}">${icon(k)}<span>${navName(k)}</span></button>`).join("")}<div class="sidebar-foot"><span class="eyebrow">INTELLIGENCE IN MOTION</span><span>${L("Local-first. Yours to experiment.", "本地运行，自由实验。")}</span><span data-live="sidebar-status">${L("Simulation connected", "仿真已连接")}</span>${button(L("Quick guide", "使用指南"), "help", "button-link", "", "arrow")}</div></aside><main class="workspace" id="main"></main>`;
  document.documentElement.lang = ui.lang === "zh" ? "zh-CN" : "en";
  renderPage();
}
function renderPage() {
  if(ui.page==="ground"){
    if(!ground.active){
      resumeAfterGround=running;
      if(worker)send("run",{value:false});
    }
    ground.enter();
  }else if(ground.active){
    ground.leave();
    if(resumeAfterGround&&worker&&!document.hidden)send("run",{value:true});
    resumeAfterGround=false;
  }
  const status=$(".status-text");
  if(status)status.innerHTML='<i class="status-dot"></i>'+(ground.active?L("11 players · Control experiment","11 名球员 · 控制实验"):L("22 autonomous agents · One shared world","22 个自主智能体 · 同一个物理世界"));
  if (ui.page !== "research") ui.replayActive = false;
  const pageFns = {
    match: matchPage,
    ground:()=>ground.webpage(),
    network:()=>network.webpage(),
    tactics: tacticsPage,
    control: controlPage,
    agent: agentPage,
    diagnostics: diagnosticsPage,
    library: libraryPage,
    algorithm: algorithmPage,
    research: researchPage,
  };
  $("#main").dataset.page = ui.page;
  $("#main").innerHTML =
    pageFns[ui.page]() +
    `<div class="footer-note"><span>OWN / FLOW · ${L("Football is the environment. Autonomy is the engine.", "以足球为环境，以自主控制为引擎。")}</span><span>${L("Simulation evidence · No full-match stability claim", "仿真证据 · 不声称完整比赛的稳定性保证")}</span></div>`;
  $$(".nav-item").forEach((el) =>
    el.classList.toggle("active", el.dataset.page === ui.page),
  );
  const host = $("#pitch-host");
  if (host) {
    try {
      if (renderer) renderer.mount(host);
      else {
        const probe = document.createElement("canvas");
        const context = probe.getContext("webgl2");
        if (context) {
          context.getExtension("WEBGL_lose_context")?.loseContext();
          try {
            renderer = new PitchRenderer(host, selectPlayer);
            renderer.backend = "WebGL";
          } catch {
            host.replaceChildren();
            renderer = null;
          }
        }
        if (!renderer) {
          renderer = new CanvasPitchRenderer(host, selectPlayer);
          renderer.backend = "Canvas 3D";
        }
      }
      host
        .querySelector("canvas")
        ?.setAttribute(
          "aria-label",
          L("Interactive football pitch", "可交互足球场"),
        );
      configureRenderer();
      if(ground.active && ground.sim)renderer.setState(ground.sim.snapshot(ground.running));
      else if(state)renderer.setState(viewState());
    } catch (e) {
      host.innerHTML = `<div class="error-banner">${L("The pitch renderer could not start. Reload the page to retry.", "球场渲染未能启动，请刷新页面重试。")}</div>`;
      console.error(e);
    }
  }
  if(ground.active)ground.mount();
  if(ui.page==="network")network.mount();
  if(document.getElementById('mission-studio'))missions.mount();
  typesetMath($("#main"));
  paintLive(true);
}
function configureRenderer() {
  if(ground.active){
    renderer?.configure({cameraMode:ground.camera==="tactical"?"tactical":"broadcast",
      zoom:ground.camera==="player"?2:1,focus:ground.camera==="player"?"player":"overview",
      quality:ui.quality,flags:{},scope:"selected",selected:ground.selected,agentView:false});
    return;
  }
  const local = ui.page === "agent" && ui.tabs.agent === "local";
  renderer?.configure({
    cameraMode: ui.camera,
    zoom: ui.zoom,
    focus: ui.focus,
    quality: ui.quality,
    flags: local
      ? { ...ui.flags, centroids: false, tactical: false, communication: false }
      : { ...ui.flags },
    scope: local ? "selected" : ui.scope,
    selected: ui.selected,
    agentView: local,
  });
}
function viewState() {
  if (ui.replayActive && ui.replay?.frames?.length) {
    const f = ui.replay.frames[ui.replayIndex];
    return {
      ...state,
      ...f,
      players: f.players,
      seed: ui.replay.seed,
      events: ui.replay.events.filter((e) => e.time <= f.time),
      tactics: f.tactics || ui.replay.tactics,
      measurements: ui.replay.frames
        .slice(0, ui.replayIndex + 1)
        .map((f) => ({ time: f.time, teams: f.metrics })),
      running: false,
    };
  }
  return state;
}
function selectPlayer(id) {
  if(ground.active){ground.select(id);return;}
  ui.selected = id;
  ui.team = Math.floor(id / 11);
  configureRenderer();
  renderPage();
}
function selectedControl() {
  return `<select class="select-player" data-source="ui" data-key="selected" aria-label="${L("Select player", "选择球员")}">${cfg()
    .players.map((p, i) =>
      option(
        ui.team * 11 + i,
        `${String(i + 1).padStart(2, "0")} · ${p.name} / ${ROLES[cfg().formation][i]}`,
        ui.selected,
      ),
    )
    .join("")}</select>`;
}
function roster() {
  return `<div class="roster">${cfg()
    .players.map((p, i) =>
      button(
        `<strong>${String(i + 1).padStart(2, "0")}</strong><small>${ROLES[cfg().formation][i]}</small>`,
        "player",
        selectedIndex() === i ? "active" : "",
        `data-id="${ui.team * 11 + i}" title="${escape(p.name)}" aria-label="${escape(p.name)}"`,
      ),
    )
    .join("")}</div>`;
}
function pitchCard() {
  return `<section class="panel" id="match-panel"><div class="score-strip"><div class="match-time"><strong data-live="clock">00:00</strong><span data-live="phase">${L("LIVE MATCH", "比赛直播")}</span></div><div class="team-name right blue"><span data-live="team0">${escape(tactics[0].teamName)}</span><span class="crest">B</span></div><div class="score"><span data-live="score0">0</span><span class="muted" style="font-size:18px;margin:0 4px">:</span><span data-live="score1">0</span></div><div class="team-name coral"><span class="crest">C</span><span data-live="team1">${escape(tactics[1].teamName)}</span></div><div class="match-half"><div data-live="half">${L("FIRST HALF", "上半场")}</div><div class="mono">SEED <span data-live="seed">361</span></div></div></div><div class="match-frame"><div class="pitch-host" id="pitch-host"></div><div class="pitch-toolbar">${button(L("Broadcast", "转播镜头"), "camera", ui.camera === "broadcast" ? "active" : "", 'data-camera="broadcast"')}${button(L("Tactical", "战术镜头"), "camera", ui.camera === "tactical" ? "active" : "", 'data-camera="tactical"')}${button("", "fullscreen", "", `aria-label="${L("Expand match", "放大比赛")}"`, "expand")}</div><div class="pitch-watermark">OWN / FLOW ARENA<span data-live="render-status"></span></div><div class="pitch-bottom"><div class="mini-map" id="mini-map"></div><div class="pitch-zoom"><span>${L("Zoom", "缩放")}</span><input aria-label="${L("Camera zoom", "镜头缩放")}" type="range" min="0.85" max="2.8" step="0.05" value="${ui.zoom}" data-source="ui" data-key="zoom"></div></div></div><div class="match-controls">${button(running ? L("Pause", "暂停") : L("Play", "继续"), "toggle-run", "primary", 'id="play-button"', running ? "pause" : "play")}${button("", "step", "icon-only", `title="${L("Advance 0.1 seconds", "前进 0.1 秒")}" aria-label="${L("Advance one control step", "前进一个控制步")}"`, "step")}<select style="width:70px" data-source="ui" data-key="speed" aria-label="${L("Simulation speed", "仿真速度")}">${[0.5, 1, 2, 4, 8].map((s) => option(s, `${s}×`, speed)).join("")}</select><span class="transport-state" data-live="transport"></span><span class="spacer"></span>${button("", "save-checkpoint", "icon-only", `aria-label="${L("Save match checkpoint", "保存比赛进度")}" title="${L("Save match checkpoint", "保存比赛进度")}"`, "save")}${button(L("New match", "新比赛"), "new-match", "quiet small", "", "reset")}</div></section>`;
}
function playerCard() {
  let p = player(),
    c = cfg(),
    i = selectedIndex();
  return `<section class="panel"><div class="panel-head"><h2>${L("Selected agent", "当前球员")}</h2><span class="chip">${ROLES[c.formation][i]}</span></div><div class="player-card"><div class="shirt" style="--jersey:${c.color}">${String(i + 1).padStart(2, "0")}</div><div><div class="eyebrow">${escape(c.teamName)}</div><h3>${escape(c.players[i].name)}</h3><p>${L("Independent state · Local control", "独立状态 · 局部控制")}</p></div></div><div class="panel-body">${selectedControl()}${dataRow(L("Current action", "当前动作"), actionLabel(p?.action), "action")}${dataRow(L("Speed", "速度"), `${num(p ? Math.hypot(p.vx, p.vy) : 0)} m/s`, "speed")}${dataRow(L("Stamina", "体能"), `${num((p?.stamina || 1) * 100, 0)}%`, "stamina")}${dataRow(L("Visible players", "可见球员"), p?.visible?.length || 0, "visible")}${dataRow(L("Control saturation", "控制饱和"), p?.saturated ? L("Active", "触发") : L("Clear", "未触发"), "saturated")}<div class="actions">${button(L("Why did he move?", "为什么这样跑？"), "nav", "small full", 'data-page="diagnostics"', "arrow")}</div></div></section>`;
}
function actionLabel(v) {
  return (
    {
      idle: L("Holding position", "保持位置"),
      run: L("Running", "跑动"),
      sprint: L("Sprinting", "冲刺"),
      pass: L("Passing", "传球"),
      shoot: L("Shooting", "射门"),
      save: L("Goalkeeper save", "门将扑救"),
      tackle: L("Challenging", "争抢"),
    }[v] || "—"
  );
}
const layerNames = () => ({
  prediction: L("Predicted path · 2 s", "预测路径 · 2 秒"),
  command: L("Current control command", "当前控制指令"),
  history: L("Historical trail", "已发生轨迹"),
  targets: L("Role target", "角色目标位置"),
  centroids: L("Centroid & local estimates", "球队中心与局部估计"),
  tactical: L("Tactical edges", "战术边"),
  communication: L("Communication edges", "通信边"),
  observation: L("Observation region", "观测区域"),
});
function layersPanel() {
  return panel(
    L("On-pitch intelligence", "球场信息图层"),
    `<div class="row" style="margin-bottom:12px">${button(L("Clean", "纯净"), "layers-clean", "small quiet")}${button(L("Analyze", "分析"), "layers-analysis", "small quiet")}</div><div class="layers">${Object.entries(
      layerNames(),
    )
      .map(
        ([k, v]) =>
          `<label class="switch-row"><span>${v}</span><input type="checkbox" data-layer="${k}" ${ui.flags[k] ? "checked" : ""}></label>`,
      )
      .join("")}</div><div class="sep"></div>${selectField(
      L("Layer scope", "图层范围"),
      "scope",
      [
        ["selected", L("Selected agent", "选中球员")],
        ["unit", L("Selected subsystems", "所属子系统")],
        ["team", L("Selected team", "选中球队")],
        ["all", L("All 22 agents", "全部 22 人")],
      ],
      ui.scope,
      "ui",
    )}<p class="hint">${L("Mint: forecast · Gold: command · Faint blue: recorded trail. Click a player on the pitch to inspect.", "薄荷绿：预测；金色：指令；浅蓝：历史轨迹。点击球场上的球员进行检查。")}</p>`,
  );
}
function matchPage() {
 return heading(navName("match"),L("Twenty-two autonomous players. One continuous game.","22 名自主球员，在同一场比赛中协作与对抗。"),`${ui.restoreAvailable?button(L("Resume saved","恢复存档"),"resume","quiet small","","save"):""}${button(L("Save tactic","保存战术"),"save-tactic","quiet small","","save")}`)
 + `<div class="match-stage">${pitchCard()}<div class="view-settings"><div class="row"><span class="eyebrow">${L("CAMERA FOCUS","镜头焦点")}</span>${[["overview","Whole pitch","全场"],["ball","Ball","足球"],["player","Selected player","当前球员"]].map(([v,en,zh])=>button(L(en,zh),"focus",ui.focus===v?"active small":"small quiet",`data-focus="${v}"`)).join("")}</div><div class="row"><label for="visual-quality">${L("Visual quality","渲染质量")}</label><select id="visual-quality" data-source="ui" data-key="quality">${[["balanced",L("Balanced","均衡")],["detail",L("Detail","细节")],["performance",L("Performance","流畅")]].map(([v,n])=>option(v,n,ui.quality)).join("")}</select></div></div></div>
 <div class="metric-row match-metrics">${metric(L("BALL SPEED","球速"),"—","m/s","ball-speed")}${metric(L("BLUE POSSESSION","蓝队控球率"),"—","%","possession")}${metric(L("COMPLETED PASSES","成功传球"),"—","","passes",L("Blue / Coral","蓝队／红队"))}${metric(L("ESTIMATION RMSE","中心估计误差"),"—","m","estimation","","estimation")}</div>
 <div class="match-inspection"><div class="stack">${playerCard()}${panel(L("Team sheet","球队阵容"),roster(),teamPicker())}</div><div class="stack">${layersPanel()}</div><div class="stack">${panel(L("Match balance","比赛统计"),'<div data-live="match-balance"></div>',empirical())}${panel(L("Match events","比赛事件"),'<div class="event-list" data-live="events"></div>',`<span class="chip live">${L("LIVE","实时")}</span>`)}</div></div>`;
}
function fieldSVG({
  team = ui.team,
  positions = null,
  edges = null,
  interactive = false,
  ghost = false,
  small = false,
  custom = null,
} = {}) {
  const c = custom || tactics[team],
    bases = FORMATIONS[c.formation],
    selected = selectedIndex();
  const pos =
    positions ||
    bases.map((r, i) => ({
      x: r[0] * c.depth + (i ? c.centerX : 0),
      y: r[1] * c.width + c.centerY,
    }));
  const xy = (p) => [p.x + 55, 38 - p.y];
  const lines = `<rect x="2.5" y="4" width="105" height="68" rx=".2"/><path d="M55 4v68 M2.5 17.84H19v40.32H2.5 M107.5 17.84H91v40.32h16.5 M2.5 28.84H8v18.32H2.5 M107.5 28.84H102v18.32h5.5"/><circle cx="55" cy="38" r="9.15"/><circle cx="55" cy="38" r=".2"/>`;
  return `<svg class="field-svg" viewBox="0 0 110 76" role="${interactive ? "group" : "img"}" aria-label="${L("Football formation and network diagram", "足球阵型与网络图")}"><g fill="none" stroke="#8cbaa64d" stroke-width=".27">${lines}</g>${
    edges
      ? `<g stroke="${ui.graph === "commEdges" ? "#7bd6e7" : "#e8c885"}" stroke-width=".35" opacity=".6">${edges
          .map(([a, b]) => {
            const A = xy(pos[a]),
              B = xy(pos[b]);
            return `<path d="M${A.join(" ")} L${B.join(" ")}"/>`;
          })
          .join("")}</g>`
      : ""
  }${pos
    .map((p, i) => {
      const [x, y] = xy(p);
      return `<g class="${interactive ? "node" : ""}" ${interactive ? `data-action="field-player" data-index="${i}" tabindex="0" role="button" aria-label="${escape(c.players[i].name)}"` : ""} transform="translate(${x} ${y})"><circle r="${small ? 2 : 2.5}" fill="${i === 0 ? "#c8d27d" : c.color}" stroke="${(interactive && i === selected) || ui.edgeStart === i ? "#d8f9e8" : "#fff4"}" stroke-width="${(interactive && i === selected) || ui.edgeStart === i ? ".7" : ".3"}"/><text y=".9" fill="#fff" text-anchor="middle" font-size="${small ? 2 : 2.5}" font-weight="600">${i + 1}</text>${!small ? `<text y="6" fill="#cbded6" text-anchor="middle" font-size="1.8">${ROLES[c.formation][i]}</text>` : ""}</g>`;
    })
    .join("")}</svg>`;
}
function tacticsPage() {
  let c = cfg(),
    tab = ui.tabs.tactics;
  const top =
    heading(
      navName("tactics"),
      L(
        "Define the intent. Let the team find its shape.",
        "定义战术意图，让球队自主形成队形。",
      ),
      teamPicker() +
        button(
          L("Save tactic", "保存战术"),
          "save-tactic",
          "primary small",
          "",
          "save",
        ),
    ) +
    tabBar("tactics", [
      ["playbooks","Classic playbooks","经典战术"],
      ["formation", "Formation & flow", "阵型与流动"],
      ["missions","Mission rules & structures","任务规则与结构"],
      ["architecture", "Team architecture", "球队系统框图"],
      ["groups", "Subsystems", "子系统"],
      ["graphs", "Networks", "关系网络"],
      ["players", "Player abilities", "球员能力"],
    ]);
  if(tab==="playbooks")return top+coachBoard({id:ui.coachPreset,team:ui.team,lang:ui.lang,homogeneous:ui.coachHomogeneous,currentTactic:c});
  if(tab==='missions')return top+missions.editor();
  if (tab === "architecture") return top + panel(L("From coach intent to local feedback","从教练意图到局部反馈"),networkArchitecture({lang:ui.lang,tactic:c,selected:ui.selected})) + `<div class="actions">${button(L("Open the executable local loop","查看实际执行的局部闭环"),"open-local-loop","primary small")}${button(L("Analyze the multi-agent network","分析多智能体网络"),"open-mas","small")}</div>`;
  if (tab === "formation")
    return (
      top +
      `<div class="grid-main"><div class="stack">${panel(L("Tactical reference", "战术参考"), `<div class="tactic-field" id="formation-field">${fieldSVG({ interactive: true, edges: c.tacticalEdges })}</div><div class="legend"><span><i style="background:${c.color}"></i>${L("Role reference positions", "角色参考位置")}</span><span><i style="background:#e8c885"></i>Gᶠ · ${L("Tactical relationships", "战术关系")}</span></div><div class="sep"></div>${roster()}<div class="note" style="margin-top:16px">${L("These are moving references, not fixed waypoints. Local estimates, ball support, overlapping units and physical limits shape the actual movement.", "这是可变的参考队形。实际运动同时由局部估计、足球支援、重叠子系统和运动约束决定。")}</div>`, `<span class="chip">${c.formation}</span>`)}${panel(L("Team identity & tempo", "球队身份与节奏"), `<div class="field-pair">${field(L("Team name", "球队名称"), `<input type="text" data-source="config" data-key="teamName" maxlength="32" value="${escape(c.teamName)}">`)}${field(L("Tactic name", "战术名称"), `<input type="text" data-source="config" data-key="name" maxlength="80" value="${escape(c.name)}">`)}</div><div class="field-pair">${slider(L("Pressing intensity", "压迫强度"), "press", 0, 1, 0.05, c.press)}${slider(L("Passing tempo", "传球节奏"), "tempo", 0, 1, 0.05, c.tempo)}</div><div class="actions">${button(L("Watch this team", "观看球队表现"), "nav", "primary small", 'data-page="match"', "play")}${button(L("Design the controller", "设计控制器"), "nav", "small quiet", 'data-page="control"', "arrow")}</div>`)}</div><aside class="stack">${panel(
        L("Formation & reference", "阵型与参考"),
        selectField(
          L("Base formation", "基础阵型"),
          "formation",
          Object.keys(FORMATIONS).map((x) => [x, x]),
          c.formation,
        ) +
          slider(L("Width", "宽度"), "width", 0.65, 1.3, 0.05, c.width) +
          slider(L("Depth", "纵深"), "depth", 0.65, 1.3, 0.05, c.depth) +
          slider(
            L("Formation fluidity", "阵型流动性"),
            "flow",
            0,
            1.5,
            0.05,
            c.flow,
          ) +
          slider(
            L("Center · longitudinal", "中心 · 纵向"),
            "centerX",
            -15,
            15,
            1,
            c.centerX,
            " m",
          ) +
          slider(
            L("Center · lateral", "中心 · 横向"),
            "centerY",
            -10,
            10,
            1,
            c.centerY,
            " m",
          ) +
          slider(
            L("Orientation", "整体朝向"),
            "angle",
            -30,
            30,
            1,
            c.angle,
            "°",
          ),
      )}${panel(L("Live changes", "实时调整"), `<p class="hint">${L("Changes apply immediately to the selected team. Save a tactic to retain a reusable configuration. A new match resets physical and observer states.", "修改立即作用于当前球队。保存战术可保留完整配置；开始新比赛会重新初始化物理与观测器状态。")}</p>`)}</aside></div>`
    );
  if (tab === "groups")
    return (
      top +
      `<div class="grid-main"><div class="stack">${panel(L("Overlapping autonomous subsystems", "可重叠的自主子系统"), `<div class="tactic-field">${fieldSVG({ interactive: true, edges: c.tacticalEdges })}</div><div class="sep"></div><div class="group-list">${c.groups.map((g, i) => `<div class="group-card"><div class="row"><h3>${escape(g.name)}</h3><span class="chip">w = ${num(g.weight)}</span></div><p>${L("Local motion correction", "局部运动修正")} (${g.dx}, ${g.dy}) m/s</p><div class="group-members">${g.members.map((n) => `<span class="member">#${n + 1} ${ROLES[c.formation][n]}</span>`).join("")}</div><div class="actions">${button(L("Edit unit", "编辑子系统"), "edit-group", "small quiet", `data-index="${i}"`)}${button(L("Remove", "移除"), "remove-group", "small quiet danger", `data-index="${i}"`)}</div></div>`).join("")}</div>`, button(L("Add subsystem", "新增子系统"), "add-group", "small primary", "", "plus"))}</div><aside class="stack">${panel(L("One player, several units", "一名球员，多个子系统"), `<p class="hint">${L("A full-back can belong to the back line and a flank unit. Each unit adds a weighted motion correction. We normalize overlapping weights and then enforce speed and acceleration limits.", "边后卫可同时属于后防线与边路子系统。每组产生加权运动修正，重叠权重归一化后再执行速度与加速度约束。")}</p><div class="sep"></div><div class="formula">uᵢ = uᵢ,base + Σ wᵢ,g Δuᵢ,g<br>wᵢ,g = w_g / max(1, Σ w_g)</div><div class="sep"></div><p class="note warn">${L("Unit offsets are soft preferences. Opposing preferences are reported as conflicts; this model does not claim a hard-constraint optimizer.", "子系统偏移是软偏好。相反偏好会作为冲突报告；本模型不声称实现硬约束优化器。")}</p>`)}</aside></div>`
    );
  if (tab === "graphs") {
    let health = graphHealth(c.commEdges, c.gamma);
    return (
      top +
      `<div class="grid-main"><div class="stack">${panel(
        L("Network editor", "网络编辑器"),
        `<div class="row" style="margin-bottom:16px"><div class="team-picker">${button(L("Communication Gᶜ", "通信 Gᶜ"), "graph-kind", ui.graph === "commEdges" ? "active" : "", 'data-kind="commEdges"')}${button(L("Tactical Gᶠ", "战术 Gᶠ"), "graph-kind", ui.graph === "tacticalEdges" ? "active" : "", 'data-kind="tacticalEdges"')}</div><span class="chip">${c[ui.graph].length} ${L("edges", "条边")}</span></div><div class="tactic-field">${fieldSVG({ edges: c[ui.graph], interactive: true })}</div><div class="note" style="margin-top:15px">${ui.edgeStart === null ? L("Click two players to add or remove their edge. Communication and tactical edges are edited independently.", "依次点击两名球员，添加或删除连接。通信边与战术边独立编辑。") : L(`Player #${ui.edgeStart + 1} selected. Choose the other endpoint.`, `已选球员 #${ui.edgeStart + 1}，请选择另一端。`)}</div><div class="actions">${[
          ["ring", L("Ring", "环形")],
          ["mesh", L("Relational mesh", "关系网络")],
          ["star", L("Star", "星形")],
          ["full", L("Complete", "全连接")],
        ]
          .map(([id, l]) =>
            button(l, "topology", "small quiet", `data-kind="${id}"`),
          )
          .join(
            "",
          )}${button(L("Clear edges", "清空连接"), "topology", "small quiet danger", 'data-kind="empty"')}</div>`,
      )}${panel(L("Information contract", "信息约定"), `<div class="formula">source → origin_time → arrival_time → receiver → payload → ttl</div><p class="hint" style="margin-top:12px">${L("State messages contain the sender’s position and centroid estimate. Ball observations retain the original source and timestamp when forwarded. Expired evidence is discarded.", "状态消息包含发送者的位置与中心估计。转发的足球观测保留原始来源和时间戳；过期证据自动丢弃。")}</p>`)}</div><aside class="stack">${panel(
        L("Communication model", "通信模型"),
        slider(
          L("Packet delay", "消息延迟"),
          "delay",
          0,
          1500,
          50,
          c.delay,
          " ms",
        ) +
          slider(L("Packet loss", "丢包概率"), "loss", 0, 0.8, 0.05, c.loss) +
          selectField(
            L("Interpret / use / forward", "解释／采用／转发"),
            "information",
            [
              ["all", L("State + fresh ball evidence", "状态＋新鲜足球证据")],
              ["fresh", L("State + first-hand evidence", "状态＋直接观测证据")],
              ["ball", L("Ball evidence only", "仅足球证据")],
            ],
            c.information,
          ) +
          dataRow(
            L("Graph connected", "图是否连通"),
            health.connected ? L("Yes", "是") : L("No", "否"),
          ) +
          dataRow(L("Components", "连通分量"), health.components) +
          dataRow(L("Maximum degree", "最大度数"), health.maxDegree),
      )}${panel(L("Observation geometry", "观测几何"), slider(L("Sensing radius", "感知半径"), "vision", 12, 70, 1, c.vision, " m") + slider(L("Field of view", "视野角度"), "fov", 60, 360, 10, c.fov, "°") + `<p class="hint">${L("Vision is limited by distance, facing angle and player occlusion. Physical collisions do not grant privileged observations.", "视野受距离、朝向与球员遮挡限制。物理碰撞不会自动提供全局信息。")}</p>`)}</aside></div>`
    );
  }
  const i = selectedIndex(),
    a = c.players[i],
    p = player();
  return (
    top +
    `<div class="grid-main"><div class="stack">${panel(
      L("Player capabilities", "球员能力"),
      `<div class="row" style="margin-bottom:16px">${selectedControl()}<span class="chip">${L("Attributes drive the physics", "能力实际影响运动")}</span></div>${roster()}<div class="sep"></div><div class="table-scroll"><table class="data-table"><thead><tr><th>#</th><th>${L("Player", "球员")}</th><th>${L("Role", "角色")}</th><th>${L("Speed", "速度")} m/s</th><th>${L("Accel.", "加速")} m/s²</th><th>${L("Technique", "技术")}</th><th>${L("Vision", "视野")} m</th></tr></thead><tbody>${c.players
        .map((v, j) => {
          let q = state?.players[ui.team * 11 + j];
          return `<tr><td>${j + 1}</td><td>${button(escape(v.name), "player", "quiet", `data-id="${ui.team * 11 + j}"`)}</td><td>${ROLES[c.formation][j]}</td><td>${num(q?.speed || v.speed, 1)}</td><td>${num(q?.acc || v.acceleration, 1)}</td><td>${num((q?.skill || v.skill) * 100, 0)}%</td><td>${num(q?.vision || c.vision, 0)}</td></tr>`;
        })
        .join("")}</tbody></table></div>`,
    )}${panel(
      L("Capability generation", "能力生成"),
      `<div class="field-pair">${selectField(
        L("Ability mode", "能力模式"),
        "abilityMode",
        [
          ["balanced", L("Identical abilities", "同质能力")],
          ["seeded", L("Seeded heterogeneity", "固定种子异质能力")],
          ["custom", L("Custom per player", "逐人自定义")],
        ],
        c.abilityMode,
      )}${field(L("Ability seed", "能力种子"), `<input type="number" min="1" max="4294967295" data-source="config" data-key="abilitySeed" value="${c.abilitySeed}">`)}</div><p class="hint">${L("Speed and acceleration constrain motion. Technique controls passing/shot dispersion and first-touch success. Ability generation is reapplied when a new match begins.", "速度与加速度限制运动；技术影响传射误差和接球表现。能力生成模式在新比赛开始时重新应用。")}</p><div class="actions">${button(L("Start with these abilities", "按此能力开始新比赛"), "new-match", "small primary", "", "play")}</div>`,
    )}</div><aside class="stack">${panel(L("Individual configuration", "个人配置"), field(L("Player name", "球员名称"), `<input type="text" maxlength="32" data-source="player" data-key="name" value="${escape(a.name)}">`) + slider(L("Maximum speed", "最高速度"), "speed", 3, 10, 0.1, a.speed, " m/s", "player") + slider(L("Maximum acceleration", "最大加速度"), "acceleration", 1, 7, 0.1, a.acceleration, " m/s²", "player") + slider(L("Technique", "技术"), "skill", 0.25, 1, 0.05, a.skill, "", "player") + slider(L("Starting stamina", "初始体能"), "stamina", 0.5, 1, 0.05, a.stamina, "", "player") + slider(L("Sensing radius", "感知半径"), "vision", 12, 70, 1, a.vision, " m", "player") + `<p class="note">${L("Editing a physical ability switches the team to Custom mode. Starting stamina applies at the next new match.", "修改物理能力会切换为自定义模式。初始体能从下一场新比赛生效。")}</p>`)}</aside></div>`
  );
}
function blockInfo() {
  return {
    reference: {
      name: L("Reference generator", "参考生成器"),
      sub: L("Intent → local target", "意图 → 局部目标"),
      formula: cfg().mission?.enabled ? "q<sub>i</sub><sup>+</sup> = δ(q<sub>i</sub>, E<sub>i</sub>, π<sub>i</sub>)<br>r<sub>i</sub><sup>q</sup> = R(q<sub>i</sub>, E<sub>i</sub>, r<sub>i</sub><sup>formation</sup>)" : "qᵢʳ = clip(aᵢ + R(ψ) S(l) q̄ᵢ)<br>cᵢʳ = aᵢ + meanⱼ[R(ψ) S(l) q̄ⱼ]",
      description: L(
        cfg().mission?.enabled ? "Local evidence E and ordered rules π select mission state q. The state maps the nominal role reference into the actual controller target. Inspect transitions under Network Studio → Tasks & events. The keeper retains specialized control." : "Each agent builds a role reference from coach configuration and local ball evidence. a is its local anchor, q̄ the role template, R rotation and S scaling; meanⱼ averages the 11 transformed role offsets. Goalkeepers use a separate ball-aware target.",
        cfg().mission?.enabled ? "局部证据 E 与有序规则 π 决定任务状态 q，再把名义阵型参考映射为控制器实际目标。可在多智能体工作台的任务与事件页检查切换依据。门将保留专门控制。" : "每名球员由教练配置与自身足球证据生成参考。a 是局部锚点，q̄ 是角色模板，R 为旋转、S 为缩放；meanⱼ 是 11 个变换后角色偏移的均值。门将采用单独的足球响应目标。",
      ),
      inputs: ["role_reference : m", "known_ball : m"],
      outputs: ["target : m", "reference : m"],
    },
    observation: {
      name: L("Local sensing", "局部感知"),
      sub: L("Visible evidence only", "仅可见证据"),
      formula: "yᵢ = hᵢ(x | range, FOV, occlusion)",
      description: L(
        "Distance, body orientation and occlusion determine what enters the controller. Ground truth appears only in analyst diagnostics.",
        "距离、身体朝向与遮挡共同决定控制器可获得的观测。真值仅用于分析诊断。",
      ),
      inputs: ["own_state : m, m/s", "visible_objects : observation"],
      outputs: ["local_observations", "timestamp : s"],
    },
    observer: {
      name: L("Distributed observer", "分布式观测器"),
      sub: L("Local centroid estimate", "局部球队中心估计"),
      formula: "ĉᵢ⁺ = ĉᵢ + Δpᵢ + γ Σⱼ (ĉ<sub>j,received</sub> − ĉᵢ)",
      description: L(
        "Dynamic average consensus with independently stored memory and delayed neighbor packets. Delay, erasure and stale samples can introduce bias. Agreement and accuracy are measured separately.",
        "动态平均共识具有独立记忆，使用延迟的邻居消息。延迟、丢包与旧样本可能产生偏差；一致性和准确性分开测量。",
      ),
      inputs: ["own_displacement : m", "neighbor_estimates : m"],
      outputs: ["centroid_estimate : m", "message_age : s"],
    },
    controller: {
      name: L("Relational controller", "关系控制器"),
      sub: L("Formation + task + units", "阵型＋任务＋子系统"),
      formula: "uᵢ⁰ = uᶠ + uᶜ + uᵇ + uᵍ + uᵃ + u<sup>mission</sup>",
      description: L(
        "The actual command is decomposed into relationship, centroid, ball-support, unit, avoidance and mission-tracking terms. An uploaded algorithm can blend in a new locally computed command.",
        "实际指令分为关系、中心、足球支援、子系统、避碰与任务跟踪项。上传算法可融合新的局部运动指令。",
      ),
      inputs: ["target : m", "neighbors : m", "local_ball : observation"],
      outputs: ["desired_velocity : m/s", "per_term_trace : m/s"],
    },
    compensator: {
      name: L("Compensator", "补偿器"),
      sub: L("Stateful shaping", "带记忆的调节"),
      formula:
        cfg().compensator === "none" ? "uᵢ<sup>K</sup> = uᵢ⁰" : cfg().compensator === "pi"
          ? "zᵢ⁺ = clip(zᵢ + eᵢ Δt); Δuᵢ = kᵢ zᵢ"
          : cfg().compensator === "lowpass"
            ? "fᵢ⁺ = fᵢ + α(uᵢ⁰ − fᵢ); uᵢ<sup>K</sup> = fᵢ⁺"
            : "Δuᵢ = −k<sub>d</sub> vᵢ",
      description: L(
        "Damping, a bounded integral term, or a first-order low-pass filter acts on each player’s own state. Integral memory is clipped to prevent unbounded wind-up.",
        "阻尼、有界积分或一阶低通滤波作用于每名球员自身状态。积分记忆限幅以避免无限累积。",
      ),
      inputs: [
        "desired_velocity : m/s",
        "own_velocity : m/s",
        "tracking_error : m",
      ],
      outputs: ["compensated_velocity : m/s", "private_memory"],
    },
    algorithm: {
      name: L("Custom algorithm blend", "自定义算法融合"),
      sub: L("Local interface only", "仅局部信息接口"),
      formula: "u<sub>des</sub> = (1 − β) uᵢ<sup>K</sup> + β · sat(Fᵢ(Iᵢ), u<sub>max</sub>)",
      description: L("The compiled custom formula reads the compensated base command and admissible local evidence. Every agent retains its own algorithm memory. With no custom controller this block is an identity.", "编译后的自定义公式读取补偿后的基础指令与允许的局部证据。每名球员保有独立算法记忆；未安装自定义算法时此模块为直通。"),
      inputs:["compensated_base : m/s", "local_evidence", "private_memory"],outputs:["desired_velocity : m/s"]
    },
    actuator: {
      name:L("Actuator limits","执行器约束"),sub:L("Speed-limited command","速度限幅指令"),
      formula:"uᵢ = sat(u<sub>des</sub>, v<sub>max</sub> · (0.65 + 0.35 sᵢ))",
      description:L("Velocity demand is capped by the individual speed ability and current stamina. The plant then applies acceleration limits, boundaries and collisions.","期望速度由个人速度能力与当前体能限幅，随后被控对象施加加速度、边界与碰撞约束。"),
      inputs:["desired_velocity : m/s", "stamina : fraction"],outputs:["limited_command : m/s"]
    },
    motion: {
      name: L("Motion & contact", "运动与接触"),
      sub: L("Feasible physical action", "物理可执行动作"),
      formula: "vᵢ* = sat(uᵢ, v<sub>max</sub>); Δvᵢ = sat(vᵢ* − vᵢ, a<sub>max</sub> Δt)",
      description: L(
        "The motor applies velocity and acceleration limits. Symmetric contact separation and field boundaries form the physical environment. These constraints can change the nominal controller’s behavior.",
        "执行器施加速度与加速度限制。对称接触分离与场地边界构成物理环境，这些约束会改变名义控制器行为。",
      ),
      inputs: ["velocity_command : m/s"],
      outputs: ["position : m", "velocity : m/s", "contact_events"],
    },
  };
}
function controlMap() {return closedLoop({lang:ui.lang,selected:ui.selected,active:ui.block,compensator:cfg().compensator,algorithm:cfg().algorithm,mission:cfg().mission});}
function controlGains() {
  const c = cfg(),
    a = c.players[selectedIndex()],
    value = (k) =>
      ui.controlScope === "agent" ? (a.override?.[k] ?? c[k]) : c[k];
  return (
    selectField(
      L("Apply gains to", "增益作用范围"),
      "controlScope",
      [
        ["team", L("Team template", "全队模板")],
        ["agent", L("Selected agent override", "当前球员覆盖")],
      ],
      ui.controlScope,
      "ui",
    ) +
    slider(
      L("Formation gain kᶠ", "阵型增益 kᶠ"),
      "kFormation",
      0,
      2,
      0.05,
      value("kFormation"),
      "",
      "gain",
    ) +
    slider(
      L("Centroid gain kᶜ", "中心增益 kᶜ"),
      "kCentroid",
      0,
      1,
      0.01,
      value("kCentroid"),
      "",
      "gain",
    ) +
    slider(
      L("Ball support kᵇ", "足球支援 kᵇ"),
      "kSupport",
      0,
      2,
      0.05,
      value("kSupport"),
      "",
      "gain",
    ) +
    (ui.controlScope === "agent"
      ? button(
          L("Restore team inheritance", "恢复继承全队设置"),
          "clear-override",
          "small quiet full",
        )
      : "") +
    `<div class="sep"></div><p class="hint">${L("Each player owns its observer, filter and integral memory. Sharing parameters never shares internal state.", "每名球员独立保存观测器、滤波器与积分记忆。共享参数不共享内部状态。")}</p>`
  );
}
function controlPage() {
  let tab = ui.tabs.control,
    c = cfg(),
    info = blockInfo()[ui.block];
  const h =
    heading(
      navName("control"),
      L(
        "Open the loop. See every signal. Change what matters.",
        "打开闭环，观察信号，让每次调整都有据可查。",
      ),
      teamPicker() + selectedControl(),
    ) +
    `<div class="launch-ground"><span>${L("Follow real match motion as nodes, inspect local feedback and validate inferred interactions.","将实时比赛抽象为节点，检查局部反馈并验证交互拟合。")}</span>${button(L("Open Network Studio","打开多智能体工作台"),"nav","small",'data-page="network"',"network")}</div>` +
    `<div class="launch-ground"><span>${c.tracker?escape(c.teamName)+" · "+c.tracker.type.toUpperCase()+" · "+L("active role tracker","角色跟踪已启用"):L("Build a feedback loop and test it with eleven players.","搭建反馈回路，在球场上验证 11 名球员的响应。")}</span>${button(L("Open Control Ground","进入控制训练场"),"nav","small",'data-page="ground"',"ground")}</div>` +
    tabBar("control", [
      ["architecture", "System architecture", "系统结构"],
      ["multiagent", "Multi-agent analysis", "多智能体分析"],
      ["controller", "Individual controller", "个人控制器"],
      ["consensus", "Consensus & network", "共识与通信"],
      ["compensator", "Compensator", "补偿器"],
    ]);
  if (tab === "multiagent") return h + `<div class="analysis-intro"><span class="eyebrow">${L("NETWORKED CONTROL","网络化控制")}</span><p>${L("Topology, estimation and execution — measured separately, linked to the same team.","分别测量拓扑、估计和执行，追踪同一球队的协作质量。")}</p></div><div class="stack" data-live="mas-analysis"></div>`;
  if (tab === "consensus") {
    let g = graphHealth(c.commEdges, c.gamma);
    return (
      h +
      `<div class="grid-main"><div class="stack">${panel(L("Consensus network", "共识网络"), `<div class="tactic-field">${fieldSVG({ edges: c.commEdges, interactive: true })}</div><div class="sep"></div><div class="formula">ĉᵢ(k+1) = ĉᵢ(k) + [pᵢ(k) − pᵢ(k−1)]<br>　　　　 + γ Σⱼ∈Nᶜᵢ [ĉ<sub>j,received</sub> − ĉᵢ(k)]</div>`, empirical())}<div class="two-cols">${panel(L("Accuracy against true centroid", "相对于真实中心的准确性"), chartMarkup("estimation", "m"))}${panel(L("Agreement between agents", "球员估计之间的一致性"), chartMarkup("disagreement", "m"))}</div>${panel(L("Nominal precheck", "名义条件预检查"), dataRow(L("Graph connected", "图是否连通"), g.connected ? L("Yes", "是") : L("No", "否")) + dataRow(L("Conservative γ upper bound", "γ 的保守上界"), num(g.bound, 3)) + dataRow(L("0 < γ < 1 / dₘₐₓ", "0 < γ < 1 / dₘₐₓ"), g.sufficient ? L("Satisfied", "满足") : L("Not established", "未建立")) + `<div class="note warn" style="margin-top:12px">${L("This check applies only to a fixed, undirected, nonnegative, synchronous consensus submodule. The running match includes delays, changing inputs and physical constraints. Passing this check is not a proof of full-match stability; failing it is not a proof of instability.", "该检查仅针对固定、无向、非负、同步的共识子模块。比赛还包含延迟、变化输入和物理约束。通过检查不代表完整比赛稳定；未通过也不代表不稳定。")}</div>`)}</div><aside class="stack">${panel(L("Consensus parameters", "共识参数"), slider(L("Consensus step γ", "共识步长 γ"), "gamma", 0, 0.5, 0.01, c.gamma) + slider(L("Packet delay", "通信延迟"), "delay", 0, 1500, 50, c.delay, " ms") + slider(L("Packet loss", "丢包概率"), "loss", 0, 0.8, 0.05, c.loss) + `<div class="actions">${button(L("Edit communication graph", "编辑通信网络"), "goto-graphs", "small full", "", "graph")}</div>`)}${panel(L("Current information quality", "当前信息质量"), dataRow(L("Estimation RMSE", "估计 RMSE"), "—", "estimation") + dataRow(L("Disagreement RMS", "分歧 RMS"), "—", "disagreement") + dataRow(L("In-flight packets", "在途消息"), "—", "queued"))}</aside></div>`
    );
  }
  if (tab === "compensator")
    return (
      h + panel(L("Closed-loop feedback control","闭环反馈控制"),controlMap()) +
      `<div class="grid-main control-inspector"><div class="stack">${panel(L("Compensator in the loop", "闭环中的补偿器"), `<div class="formula">${blockInfo().compensator.formula}</div><p class="hint" style="margin-top:14px">${blockInfo().compensator.description}</p>`)}<div class="two-cols">${panel(L("Command effort", "指令均方幅值"), chartMarkup("effort", "m²/s²"))}${panel(L("Velocity saturation", "速度指令饱和"), chartMarkup("saturation", "fraction"))}</div>${panel(L("Private controller memory", "个人控制器记忆"), `<div data-live="controller-memory"></div>`, selectedControl())}</div><aside class="stack">${panel(
        L("Design the compensator", "配置补偿器"),
        selectField(
          L("Structure", "结构"),
          "compensator",
          [
            ["none", L("No compensator", "无补偿")],
            ["damping", L("Velocity damping", "速度阻尼")],
            ["lowpass", L("First-order low-pass", "一阶低通")],
            ["pi", L("Bounded integral correction", "有界积分修正")],
          ],
          c.compensator,
        ) +
          slider(
            L("Compensator gain", "补偿增益"),
            "compGain",
            0,
            1,
            0.01,
            c.compGain,
          ) +
          `<div class="note">${L("Integral memory is limited to ±4. The low-pass coefficient is α = max(0.05, 1 − gain). All blocks run at 10 Hz.", "积分记忆限制为 ±4。低通系数为 α = max(0.05, 1 − gain)。所有控制模块以 10 Hz 运行。")}</div><div class="actions">${button(L("A/B: remove compensation", "A/B：移除补偿"), "ab-compensator", "small primary full", "", "research")}</div>`,
      )}</aside></div>`
    );
  return (
    h + panel(tab === "architecture" ? L("Networked team architecture","网络化球队结构") : L("Closed-loop feedback control","闭环反馈控制"), tab === "architecture" ? networkArchitecture({lang:ui.lang,tactic:c,selected:ui.selected}) : controlMap()) + (tab === "architecture" ? `<div class="actions">${button(L("Inspect selected agent loop","检查当前球员闭环"),"open-local-loop","primary small")}${button(L("Multi-agent analysis","多智能体分析"),"open-mas","small")}</div>` : "") +
    `<div class="grid-main control-inspector"><div class="stack">${panel(tab === "controller" ? L("Inside agent", "球员内部系统") + " #" + String(selectedIndex() + 1).padStart(2, "0") : L("Team → subsystem → autonomous agent", "全队 → 子系统 → 自主球员"), `<div class="signal-ribbon">${L("Mission & reference → error → controller → compensator → algorithm → limits → plant → feedback", "任务与参考 → 误差 → 控制器 → 补偿器 → 算法 → 限幅 → 被控对象 → 反馈")}</div>`, `<span class="chip live">10 Hz · 30 Hz ${L("physics", "物理")}</span>`)}${panel(info.name, `<p class="hint">${info.description}</p><div class="formula" style="margin:16px 0">${info.formula}</div><div class="signal-contract"><div><h3>${L("Inputs", "输入")}</h3>${info.inputs.map((v) => `<div class="signal-item">${v}</div>`).join("")}</div><div><h3>${L("Outputs", "输出")}</h3>${info.outputs.map((v) => `<div class="signal-item">${v}</div>`).join("")}</div></div><div class="sep"></div><div data-live="signal-values"></div>`, `<span class="chip">${L("Signal tracing", "信号追踪")}</span>`)}<div class="metric-row">${metric(L("TARGET RESIDUAL", "目标残差"), "—", "m", "shape", "", "shape")}${metric(L("ESTIMATION RMSE", "估计 RMSE"), "—", "m", "estimation", "", "estimation")}${metric(L("MEAN SQUARED COMMAND", "指令均方幅值"), "—", "m²/s²", "effort", "", "effort")}${metric(L("SATURATION", "饱和比例"), "—", "%", "saturation", "", "saturation")}</div>${tab === "controller" ? panel(L("Per-term command · m/s", "分项运动指令 · m/s"), `<div data-live="command-graphic"></div><details class="exact-values"><summary>${L("Signed components and exact values","有符号分量与精确数值")}</summary><div data-live="vector-table"></div></details>`) : ""}</div><aside class="stack">${panel(L("Controller configuration", "控制器配置"), controlGains())}${panel(
      L("Team & subsystem context", "球队与子系统"),
      `<div class="tactic-field" style="min-height:150px">${fieldSVG({ edges: c.commEdges, small: true })}</div><div class="sep"></div>${dataRow(
        L("Active units", "当前子系统"),
        c.groups
          .filter((g) => g.members.includes(selectedIndex()))
          .map((g) => escape(g.name))
          .join(", ") || "—",
      )}${dataRow(L("Custom algorithm", "自定义算法"), c.algorithm ? escape(c.algorithm.name) : L("None", "无"))}<div class="actions">${button(L("Algorithm Studio", "算法工作室"), "nav", "small quiet full", 'data-page="algorithm"', "algorithm")}</div>`,
    )}</aside></div>`
  );
}
const chartNames = () => ({shape:L("Target residual","目标残差"),estimation:L("Centroid estimation RMSE","中心估计误差"),disagreement:L("Estimate disagreement","估计分歧"),effort:L("Mean squared command","指令均方幅值"),saturation:L("Saturated agents","触发限幅的球员")});
function chartMarkup(key,unit="m") {return `<div class="chart-wrap"><div class="chart-title"><strong>${chartNames()[key]||key}</strong><span><i class="legend-dot blue-bg"></i>${L("Blue","蓝队")} <i class="legend-dot coral-bg"></i>${L("Coral","红队")}</span></div><canvas class="chart" data-chart="${key}"></canvas><div class="chart-caption">${L("Hover to inspect samples · latest 60 physical seconds","悬停查看采样值 · 最近 60 秒物理时间")}</div></div>`;}
function agentPage() {
  let c = cfg(),
    p = player(),
    tab = ui.tabs.agent;
  return (
    heading(
      navName("agent"),
      L(
        "What does this player actually know?",
        "此时此刻，这名球员真正知道什么？",
      ),
      teamPicker() + selectedControl(),
    ) +
    tabBar("agent", [
      ["local", "Agent local view", "球员局部视角"],
      ["evidence", "Evidence & messages", "证据与消息"],
      ["belief", "Hidden-state hypotheses", "隐藏状态假设"],
    ]) +
    (tab === "local"
      ? `<div class="grid-main"><div class="stack">${pitchCard()}${panel(L("The boundary of local knowledge", "局部知识的边界"), `<p class="note">${L("Only currently visible players and a directly observed ball are rendered. Received ball evidence remains in memory and is listed separately. The cyan boundary shows the sensing cone, not an all-seeing radar.", "只渲染当前可见球员和直接观测到的足球。通信中的足球证据保存在记忆里，并单独列出。青色边界表示感知扇区，不是全知雷达。")}</p><div class="sep"></div><div data-live="local-knowledge"></div>`)}</div><aside class="stack">${playerCard()}${panel(L("Perception parameters", "感知参数"), slider(L("Sensing radius", "感知半径"), "vision", 12, 70, 1, c.vision, " m") + slider(L("Field of view", "视野角度"), "fov", 60, 360, 10, c.fov, "°") + `<div class="actions">${button(L("Inspect received evidence", "查看收到的证据"), "tab", "small full", 'data-page="agent" data-tab="evidence"', "arrow")}</div>`)}</aside></div>`
      : tab === "evidence"
        ? `<div class="stack"><div class="workflow">${[
            [
              L("Observe", "观测"),
              L("Range, view, occlusion", "距离、视角、遮挡"),
            ],
            [
              L("Interpret", "解释"),
              L("Position & ball packets", "位置与足球消息"),
            ],
            [L("Use", "采用"), L("Freshness-aware selection", "按时效选择")],
            [
              L("Forward", "转发"),
              L("Preserve source & time", "保留来源与时间"),
            ],
          ]
            .map(
              ([a, b], i) =>
                `<div class="workflow-step"><div class="num">0${i + 1}</div><h3>${a}</h3><p>${b}</p></div>`,
            )
            .join(
              "",
            )}</div><div class="two-cols">${panel(L("Direct observations", "直接观测"), '<div data-live="observation-table"></div>', `<span class="chip">${L("Own sensor only", "仅自身感知")}</span>`)}${panel(L("Received message queue", "已收到的消息"), '<div data-live="messages"></div>', `<span class="chip">${L("Latest 10", "最近 10 条")}</span>`)}</div>${panel(L("Information used by the controller", "控制器采用的信息"), '<div data-live="local-knowledge"></div>')}</div>`
        : `<div class="grid-main"><div class="stack">${panel(L("Behavior-only tactical hypothesis", "仅基于行为的战术假设"), `<div data-live="belief"></div><div class="sep"></div><div class="note warn">${L("This is an inspectable heuristic: at least three visible opponents are needed; their observed mean lateral position is compared with ±7 m. It is not a calibrated Bayesian posterior or a validated detector of hidden intent. No opponent tactic configuration is read.", "这是可检查的启发式：至少看见三名对手后，将其平均横向位置与 ±7 米比较。它不是校准后的贝叶斯后验，也不是经过验证的隐藏意图检测器，不读取对手战术配置。")}</div>`, empirical())}${panel(L("Prediction and outcome", "预测与结果"), `<div class="two-cols"><div><div class="formula">p̂ᵢ(t+τ | Iᵢ(t))<br>τ ∈ (0, 2 s]</div><p class="hint" style="margin-top:12px">${L("A constant-command forecast with the agent’s current acceleration and speed limits. Other agents’ future actions are not known.", "使用当前指令和自身加速度、速度限制的预测。无法预知其他球员未来行动。")}</p></div><div>${dataRow(L("Forecast horizon", "预测时域"), "2.00 s")}${dataRow(L("Measured endpoint error", "实测终点误差"), "—", "prediction-error")}${dataRow(L("Evaluated endpoints", "已评价预测终点"), "—", "prediction-n")}</div></div>`)}</div><aside class="stack">${playerCard()}${panel(L("Research connection", "研究联系"), `<p class="hint">${L("OWN asks what behavior can reveal under limited observations. This page exposes the evidence boundary and allows ambiguous cases to remain Unknown. Full reciprocal strategic probing remains a separate research model.", "OWN 关注有限观测下行为能揭示什么。本页公开证据边界，并允许证据不足时保持未知。完整的双向战略探测仍是独立研究模型。")}</p>`)}</aside></div>`)
  );
}
function diagnosticsPage() {
  let tab = ui.tabs.diagnostics;
  return (
    heading(
      navName("diagnostics"),
      L(
        "From motion to mechanism. Inspect the reason, not just the result.",
        "从运动追踪到机制：既看结果，也检查原因。",
      ),
      teamPicker() + selectedControl(),
    ) +
    `<div class="launch-ground"><span>${L("Trace position errors, incoming signals and motion-model validity.","追踪位置误差、入向信号与运动模型有效性。")}</span>${button(L("Network diagnostics","多智能体诊断"),"network-diagnose","small","","network")}</div>` +
    tabBar("diagnostics", [
      ["why", "Why did he move?", "为什么这样跑？"],
      ["health", "Controller health", "控制器健康"],
      ["ratings", "Ratings & performance", "评分与表现"],
    ]) +
    (tab === "why"
      ? `<div class="grid-main"><div class="stack">${panel(L("Command decomposition", "控制指令分解"), `<div class="row" style="margin-bottom:15px"><span class="chip live" data-live="trace-time">t = 0.00 s</span>${button(running ? L("Freeze this moment", "冻结此刻") : L("Continue", "继续"), "toggle-run", "small quiet", "", running ? "pause" : "play")}</div><div data-live="command-graphic"></div><details class="exact-values"><summary>${L("Signed components and exact values","有符号分量与精确数值")}</summary><div data-live="vector-table"></div></details><div class="note" style="margin-top:15px">${L("The terms reconstruct the desired command. Magnitude does not measure causal importance. Use a matched A/B intervention to estimate the effect of a design change.", "这些分项可以重构期望指令，但向量大小不等于因果重要性。需要匹配的 A/B 干预来评价设计变化的作用。")}</div>`, `${L("Agent", "球员")} #${selectedIndex() + 1}`)}${panel(L("Evidence → belief → action", "证据 → 判断 → 行动"), '<div data-live="movement-trace"></div>')}</div><aside class="stack">${playerCard()}${panel(L("Ask a counterfactual", "提出反事实问题"), `<p class="hint">${L("Save this exact world state, then branch two runs with the same initial memories and random state. Change one gain, drop packets, or remove compensation.", "保存此刻的完整世界状态，然后以相同初始记忆和随机状态分叉两次运行。只修改一个增益、丢包概率或移除补偿。")}</p><div class="actions">${button(L("Fork A/B from this moment", "从此刻分叉 A/B"), "fork", "primary small full", "", "research")}</div>`)}</aside></div>`
      : tab === "health"
        ? `<div class="stack"><div class="metric-row">${metric(L("ESTIMATION RMSE", "估计误差"), "—", "m", "estimation")}${metric(L("ESTIMATE DISAGREEMENT", "估计分歧"), "—", "m", "disagreement")}${metric(L("VELOCITY SATURATION", "速度饱和"), "—", "%", "saturation")}${metric(L("PACKETS RECEIVED", "收到消息"), "—", "", "received")}</div><div class="two-cols">${panel(L("Controller health monitor", "控制器健康监测"), '<div class="health-list" data-live="health"></div>', empirical())}${panel(L("Tracking and estimation", "跟踪与估计"), chartMarkup("shape", "m") + '<div class="sep"></div>' + chartMarkup("estimation", "m"))}</div>${panel(L("What the monitor establishes", "监测结论的适用范围"), `<p class="hint">${L("Threshold-based diagnostics flag empirical problems; they do not certify a nonlinear football system. Target residual measures distance to the current role reference, including legitimate departures during pressing and ball control. Agreement may coexist with estimation bias.", "阈值诊断用于提示实测问题，不提供非线性足球系统的稳定性证书。目标残差是到当前角色参考的距离，也包含压迫、控球时的合理偏离。一致性与估计偏差可能同时存在。")}</p>`)}</div>`
        : `<div class="stack">${panel(L("Performance by player", "逐球员表现"), '<div data-live="ratings"></div>', empirical())}<div class="two-cols">${panel(L("Football evidence", "足球表现依据"), `<p class="hint">${L("Passing completion, shots, goals, tackles and saves are observed events. Players with fewer than two pass attempts have no completion rating. Distance is integrated from physical velocity.", "传球完成、射门、进球、抢断和扑救来自实际事件。传球尝试少于两次时不显示成功率评分。跑动距离由物理速度积分。")}</p>`)}${panel(L("Control evidence", "控制执行依据"), `<p class="hint">${L("Accumulated command effort is ∫‖uᵢ‖²dt (m²/s), not mechanical energy. Saturation is the fraction of physical samples where the requested velocity exceeded the ability limit. These metrics are not combined into an arbitrary player score.", "累计指令代价为 ∫‖uᵢ‖²dt（m²/s），不是机械能；饱和比例是期望速度超过能力限制的物理采样占比。这些量不合并为任意球员总评分。")}</p>`)}</div></div>`)
  );
}
function allPresets() {
  return [
    { preset: defaultTactic(0), builtin: true, version: 1 },
    { preset: defaultTactic(1), builtin: true, version: 1 },
    ...presets,
  ];
}
function libraryPage() {
  return (
    heading(
      navName("library"),
      L(
        "Keep a good idea. Give it an opponent.",
        "保存一个好想法，再给它找一个对手。",
      ),
      button(
        L("Import JSON", "导入 JSON"),
        "import-preset",
        "quiet small",
        "",
        "upload",
      ) +
        button(
          L("Save current tactic", "保存当前战术"),
          "save-tactic",
          "primary small",
          "",
          "save",
        ),
    ) +
    `<div class="launch-ground"><span>${L("Five historical playbooks with source notes and original squads.","五套经典战术，附历史资料与原创实验阵容。")}</span>${button(L("Browse playbooks","浏览经典战术"),"coach-open","small","","tactics")}</div>` +
    `<div class="two-cols" style="margin-bottom:22px">${tactics.map((c, t) => panel(`<span class="${t ? "coral" : "blue"}">${t ? L("CORAL · AWAY", "珊瑚红队 · 客队") : L("BLUE · HOME", "蓝队 · 主队")}</span>`, `<div class="row"><div><h2>${escape(c.name)}</h2><p class="hint">${escape(c.teamName)} · ${c.formation} · ${c.commEdges.length} ${L("communication edges", "条通信边")}</p></div><div class="crest ${t ? "coral" : "blue"}">${t ? "C" : "B"}</div></div><div class="actions">${button(L("Edit setup", "编辑配置"), "edit-team", "small quiet", `data-team="${t}"`)}${button(L("Export tactic", "导出战术"), "export-tactic", "small quiet", `data-team="${t}"`, "download")}</div>`)).join("")}</div><div class="row" style="margin-bottom:20px"><p class="hint">${L("Load any saved strategy into either side, then start a fresh match.", "将任意已存策略加载到任一方，然后开始新的比赛。")}</p>${button(L("Start self-play", "开始策略对抗"), "new-match", "primary small", "", "play")}</div><div class="preset-grid">${allPresets()
      .map(
        ({ preset: p, builtin, version }, i) =>
          `<article class="preset-card"><div class="preset-visual">${fieldSVG({ custom: p, small: true, edges: p.commEdges })}<span class="chip">${builtin ? L("BUILT-IN", "内置") : L("SAVED", "已保存")} · v${version || 1}</span></div><div class="preset-content"><h3>${escape(p.name)}</h3><p>${escape(p.teamName)} · ${p.formation}</p><div class="preset-tags"><span class="chip">${{ none: L("None", "无补偿"), damping: L("Damping", "阻尼"), lowpass: L("Low-pass", "低通"), pi: L("Integral", "积分") }[p.compensator]}</span><span class="chip">${p.groups.length} ${L("units", "子系统")}</span>${p.algorithm ? '<span class="chip live">' + L("Custom controller", "自定义控制器") + "</span>" : ""}</div><div class="preset-actions">${button(L("Load Blue", "加载至蓝队"), "load-preset", "quiet", `data-index="${i}" data-team="0"`)}${button(L("Load Coral", "加载至红队"), "load-preset", "quiet", `data-index="${i}" data-team="1"`)}</div>${!builtin ? `<div class="row" style="margin-top:10px">${button(L("Export", "导出"), "export-preset", "button-link", `data-index="${i}"`)}${button(L("Delete", "删除"), "delete-preset", "button-link danger", `data-index="${i - 2}"`)}</div>` : ""}</div></article>`,
      )
      .join(
        "",
      )}</div><div class="section-title"><h2>${L("Match continuity", "保存与续赛")}</h2><span class="chip">${L("Stored on this browser", "存储于此浏览器")}</span></div><div class="two-cols">${panel(L("Tactic ≠ match checkpoint", "战术与比赛进度分别保存"), `<p class="hint">${L("A tactic contains the formation, graphs, units, capabilities, gains and algorithm. A checkpoint also contains the physical world, agent memory, in-flight messages, clock and random generator state.", "战术保存阵型、网络、子系统、能力、增益和算法。比赛进度还保存物理世界、球员记忆、在途消息、时钟与随机生成器状态。")}</p><div class="actions">${button(L("Save checkpoint", "保存比赛进度"), "save-checkpoint", "small quiet", "", "save")}${button(L("Export checkpoint", "导出比赛进度"), "export-checkpoint", "small quiet", "", "download")}${button(L("Import checkpoint", "导入比赛进度"), "import-checkpoint", "small quiet", "", "upload")}</div>`)}${panel(L("Your data stays with you", "数据由你保管"), `<p class="hint">${L("Strategies are saved in this browser. Checkpoints autosave every 30 seconds. An existing checkpoint is protected until you resume it, start a new match or save explicitly. Export JSON for backups or another device. Clearing browser storage removes local records; no cloud account is required.", "策略保存在此浏览器，比赛进度每 30 秒自动保存。已有进度会受到保护，直到你恢复它、开始新比赛或手动保存。请导出 JSON 用作备份或跨设备迁移。清理浏览器数据会删除本地记录；无需云账户。")}</p><div class="actions">${button(L("Export strategy collection", "导出整个战术库"), "export-library", "small quiet", "", "download")}${button(L("Resume last checkpoint", "恢复最近进度"), "resume", "small quiet", "", "play")}</div>`)}</div>`
  );
}
function algorithmPage() {
  let c = cfg();
  return (
    heading(
      navName("algorithm"),
      L(
        "Your idea, translated into twenty-two autonomous decisions.",
        "将你的算法，转化为场上的自主决策。",
      ),
      teamPicker() +
        button(
          L("Import algorithm", "导入算法"),
          "import-algorithm",
          "quiet small",
          "",
          "upload",
        ),
    ) +
    `<div class="workflow">${[
      [L("Define", "定义"), L("A typed local contract", "类型明确的局部接口")],
      [L("Validate", "校验"), L("Signals & output limits", "信号与输出界限")],
      [L("Compile", "编译"), L("Bounded expression tree", "有界表达式树")],
      [L("Deploy", "部署"), L("11 independent agents", "11 个独立智能体")],
    ]
      .map(
        ([a, b], i) =>
          `<div class="workflow-step"><div class="num">0${i + 1} /</div><h3>${a}</h3><p>${b}</p></div>`,
      )
      .join(
        "",
      )}</div><div class="grid-main"><div class="stack">${panel(L("Controller contract", "控制器契约"), `<textarea id="algorithm-editor" class="code-editor" spellcheck="false" aria-label="${L("Algorithm JSON editor", "算法 JSON 编辑器")}">${escape(ui.algorithmText)}</textarea><div class="actions">${button(L("Validate & compile", "校验并编译"), "compile", "primary small", "", "check")}${button(L("Load example", "加载示例"), "algorithm-example", "small quiet")}${button(L("Download template", "下载模板"), "algorithm-template", "small quiet", "", "download")}${button(L("Export code", "导出算法"), "algorithm-export", "small quiet", "", "download")}</div><div id="compile-result">${compileStatus()}</div>`, `<span class="chip">FlowController · JSON</span>`)}${panel(L("From formula to action", "从公式到运动"), `<div class="formula">u<sub>custom</sub> = f(self, base, target, centroid, reference, ball, memory)<br>u<sub>desired</sub> = (1 − blend) u<sub>base</sub> + blend · sat(u<sub>custom</sub>, maxOutput)<br>u<sub>executed</sub> = motion_limits(u<sub>desired</sub>)</div><div class="sep"></div><p class="hint">${L("Upload a FlowController JSON file, or translate your MATLAB/Python control formula into the x and y expressions above. The parser executes arithmetic and approved functions; it does not execute arbitrary JavaScript, Python, papers or natural-language instructions.", "上传 FlowController JSON 文件，或将 MATLAB/Python 控制公式写入 x、y 表达式。解析器执行算术与支持函数，不直接执行任意 JavaScript、Python、论文或自然语言指令。")}</p>`)}</div><aside class="stack">${panel(L("Permitted local signals", "允许的局部信号"), `<div class="signal-item">self.x / self.y <span>m</span></div><div class="signal-item">self.vx / self.vy <span>m/s</span></div><div class="signal-item">base.x / base.y <span>m/s</span></div><div class="signal-item">target.x / target.y <span>m</span></div><div class="signal-item">centroid.x / .y <span>m</span></div><div class="signal-item">reference.x / .y <span>m</span></div><div class="signal-item">ball.x / .y / .vx / .vy</div><div class="signal-item">ball.known <span>0 / 1</span></div><div class="signal-item">memory.x / memory.y <span>m/s</span></div><div class="signal-item">time <span>s</span></div><p class="hint" style="margin-top:13px">${L("Ball input is the agent’s latest admissible evidence. Unknown ball: known=0, position=self, velocity=0. Memory is the previous custom command.", "足球输入来自该球员的最新可用证据。未知时：known=0、位置为自身位置、速度为0。memory 为上次自定义输出。")}</p>`)}${panel(L("Expression language", "表达式语言"), `<div class="formula">+ − * / ( )<br>abs · sqrt · sin · cos · tanh<br>min(a,b) · max(a,b)<br>clamp(x,lo,hi)</div><p class="hint" style="margin-top:12px">${L("10 Hz sampling; at most 16 parameters and 160 tokens per expression. Near-zero division returns zero. Outputs are finite and speed-limited. Check dimensional consistency when writing a formula.", "采样 10 Hz；最多 16 个参数，每个表达式最多 160 个符号。近零除法返回 0；输出保持有限并限速；公式的量纲一致性需要自行核对。")}</p>`)}${panel(L("Installed on this team", "当前球队已安装"), dataRow(L("Controller", "控制器"), c.algorithm ? escape(c.algorithm.name) : L("Built-in relational", "内置关系控制")) + dataRow(L("Blend", "融合权重"), c.algorithm ? num(c.algorithm.blend) : "—") + `<div class="actions">${button(L("Deploy compiled controller", "部署已编译控制器"), "deploy-algorithm", "primary small full", ui.algorithmValidated ? "" : "disabled", "arrow")}${c.algorithm ? button(L("Remove custom controller", "移除自定义控制器"), "remove-algorithm", "small quiet full") : ""}</div>`)}</aside></div>`
  );
}
function compileStatus() {
  if (ui.compileError)
    return `<div class="compile-status error">${L("Compilation stopped", "编译已停止")} · ${errorMessage(ui.compileError)}</div>`;
  if (ui.algorithmValidated)
    return `<div class="compile-status">✓ ${escape(ui.algorithmValidated.config.name)} · ${L("Valid contract. Signal names resolved. Ready to deploy.", "契约有效，信号已解析，可部署。")}</div>`;
  return `<p class="hint" style="margin-top:12px">${L("Edit, validate, then deploy to the selected team. No code is running until you deploy.", "编辑、校验后部署到选中球队。部署前不影响比赛。")}</p>`;
}
function researchPage() {
  let tab = ui.tabs.research;
  const h =
    heading(
      navName("research"),
      L(
        "Repeat the conditions. Change one mechanism. Measure the difference.",
        "复现条件，只改一个机制，测量真实差异。",
      ),
      button(
        L("Export telemetry", "导出遥测"),
        "export-csv",
        "quiet small",
        "",
        "download",
      ),
    ) +
    tabBar("research", [
      ["benchmark", "Paired benchmark", "配对基准实验"],
      ["replay", "Replay & timeline", "回放与时间线"],
      ["protocol", "Protocol & limits", "协议与边界"],
    ]);
  if (tab === "replay")
    return (
      h +
      `<div class="stack">${panel(L("Replay buffer", "回放缓存"), `<div class="row wrap"><p class="hint">${L("Inspect up to the last 180 physical seconds at 2 snapshots/s. Replay exports round to 4 decimal places; checkpoints retain exact state. Loading a replay pauses the live match.", "以每秒 2 帧状态快照检查最近最多 180 秒物理时间。回放导出保留 4 位小数；比赛存档保留精确状态。加载回放会暂停实时比赛。")}</p><div class="inline">${button(L("Capture current replay", "读取当前回放"), "capture-replay", "primary small", "", "eye")}${button(L("Import", "导入"), "import-replay", "small quiet", "", "upload")}</div></div>${ui.replay?.frames?.length ? `<div class="replay-bar"><span class="mono" id="replay-time">${clock(ui.replay.frames[ui.replayIndex]?.clock)}</span><input aria-label="${L("Replay time", "回放时间")}" type="range" min="0" max="${ui.replay.frames.length - 1}" step="1" value="${ui.replayIndex}" data-source="ui" data-key="replayIndex">${button(L("Export replay", "导出回放"), "export-replay", "small quiet", "", "download")}${button(L("Return to live", "返回实时"), "exit-replay", "small quiet")}</div>` : ""}`)}${ui.replay?.frames?.length ? pitchCard() : `<div class="empty-state">${icon("research")}<h2>${L("Every movement has a history", "每次跑动都有历史")}</h2><p>${L("Capture the current replay after the match has run for a few seconds. Scrub through physical states and the forecasts stored at each moment.", "比赛运行几秒后读取当前回放，即可拖动时间线，检查物理状态与当时记录的预测。")}</p></div>`}</div>`
    );
  if (tab === "protocol")
    return (
      h +
      `<div class="two-cols">${panel(L("Reproducible experimental unit", "可复现实验单元"), `<div class="formula">engine_version + checkpoint + seed<br>+ both_tactics + physical_abilities<br>+ one_explicit_intervention</div><div class="sep"></div><p class="hint">${L("A and B begin with identical positions, observer memories, in-flight messages and random-generator state. The intervention is applied to the selected team. Each branch remains deterministic. Divergent actions may consume different random draws, so this is matched initialization rather than event-aligned common randomness.", "A、B 从相同位置、观测器记忆、在途消息与随机生成器状态开始。干预仅应用于所选球队，各分支保持确定性。不同动作可能消耗不同数量的随机数，因此这是初始条件匹配，并非逐事件对齐的公共随机性。")}</p>`)}${panel(L("Research boundary", "研究边界"), `<p class="hint">${L("The ICARCV paper “Task-Conditioned Distributed Relational Formation Control Under a Global Formation Objective” motivates the relational architecture. This implementation extends it with a heuristic football model, dynamic references and physical limits. It is not a line-by-line reproduction of the paper or a theorem-certified football simulator.", "ICARCV 论文“Task-Conditioned Distributed Relational Formation Control Under a Global Formation Objective”为关系架构提供思想基础。此实现加入启发式足球模型、动态参考与物理约束，并非论文代码的逐行复现，也不是具有定理保证的足球模拟器。")}</p>`)}${panel(L("Football model", "足球模型"), `<p class="hint">${L("Implemented: 22 humanoid players, independent ball motion, dribbling impulses, passing, shots, interceptions, challenges, goalkeeper saves, goals, throw-ins, corners, goal kicks, basic offside-at-reception, halftime, side swap and fulltime. Simplified: collision response, ball spin and player animation. Not modeled: fouls/cards, substitutions, injury, added time, full IFAB officiating, calibrated real-athlete performance or multiplayer.", "已实现：22 名人形球员、独立足球运动、触球带球、传射、拦截、争抢、门将扑救、进球、界外球、角球、球门球、接球时的基础越位检查、中场、换边与终场。简化项：接触响应、球旋转与动作动画。未模拟：犯规和红黄牌、换人、伤病、补时、完整 IFAB 裁判逻辑、真实球员标定和多人联机。")}</p>`)}${panel(L("Metrics and sampling", "指标与采样"), `<p class="hint">${L("Physics: 30 Hz. Control: 10 Hz. Communication: 5 Hz. Metrics and replay: 2 Hz. Forecast: constant current command over 2 s; endpoint error is scored against a later actual state. Target residual is not a pure relational shape error. Confidence intervals describe repeated seeded samples, not theoretical stability.", "物理 30 Hz；控制 10 Hz；通信 5 Hz；指标与回放 2 Hz。预测为当前指令下 2 秒运动外推，终点误差由后续真实状态计算。目标残差不是纯粹的关系形状误差；置信区间描述重复种子样本，不代表理论稳定性。")}</p>`)}</div>`
    );
  return (
    h +
    `<div class="grid-main"><div class="stack">${panel(
      L("Choose the environment", "选择实验环境"),
      `<div class="benchmark-cards">${[
        [
          "formation",
          "01",
          L("Formation recovery", "阵型恢复"),
          L(
            "Perturbed initial positions; fixed reference.",
            "扰动初始位置，固定参考。",
          ),
        ],
        [
          "moving",
          "02",
          L("Moving reference", "时变参考"),
          L(
            "Sinusoidal center motion; constrained agents.",
            "中心正弦移动，执行器受限。",
          ),
        ],
        [
          "match",
          "03",
          L("Tactical self-play", "战术自对抗"),
          L(
            "Both saved strategies; live football rules.",
            "双队策略与实时足球规则。",
          ),
        ],
      ]
        .map(
          ([id, n, a, b]) =>
            `<button class="scenario ${ui.scenario === id ? "active" : ""}" data-action="scenario" data-scenario="${id}"><span class="num">B${n}</span><h3>${a}</h3><p>${b}</p></button>`,
        )
        .join(
          "",
        )}</div>${ui.forkCheckpoint ? `<div class="note" style="margin-top:16px">${L("Fork checkpoint selected at physical time", "已选择分叉存档，物理时间")} ${num(ui.forkCheckpoint.time)} s. ${button(L("Use fresh initialization", "改用全新初始化"), "clear-fork", "button-link")}</div>` : ""}`,
    )}${panel(L("Paired results", "配对实验结果"), `<div id="benchmark-results">${benchmarkResults()}</div>`, empirical())}</div><aside class="stack">${panel(
      L("One controlled intervention", "单一受控干预"),
      selectField(L("Intervention team","干预球队"),"benchmarkTeam",[[0,L("Blue","蓝队")],[1,L("Coral","红队")]],ui.benchmarkTeam,"ui") + selectField(
        L("Branch B changes", "B 分支变化"),
        "intervention",
        [
          ["gain", L("Increase formation gain", "提高阵型增益")],
          ["loss", L("35% packet loss", "35% 丢包")],
          ["compensator", L("Remove compensator", "移除补偿器")],
          ["algorithm", L("Remove custom algorithm", "移除自定义算法")],
          ["tracker",L("Remove ground role tracker","移除训练场角色跟踪器")],
          ["mission_off",L("Disable mission policy","关闭任务策略")],
          ["mission_shield",L("Use cover-first policy","采用保护优先策略")],
          ["mission_hunt",L("Use early-pressure policy","采用主动上压策略")],
          ["mission_lanes",L("Use lane-screen policy","采用路线封锁策略")],
        ],
        ui.intervention,
        "ui",
      ) +
        selectField(
          L("Physical duration", "物理时长"),
          "duration",
          [
            [30, "30 s"],
            [45, "45 s"],
            [90, "90 s"],
            [120, "120 s"],
          ],
          ui.duration,
          "ui",
        ) +
        field(
          L("Base seed", "基础随机种子"),
          `<input type="number" min="1" max="4294967295" data-source="ui" data-key="seed" value="${ui.seed}">`,
        ) +
        `<p class="hint">${L("Three paired seeds. Branch A uses the current team setups. B changes only the chosen mechanism on the intervention team. A 95% paired t interval is reported when three runs are available.", "使用三个配对种子。A 使用当前两队配置；B 仅改变干预球队选中的机制。完成三个配对运行后报告差值的 95% t 区间。")}</p><div class="actions">${button(ui.benchmarkProgress !== null ? L("Running…", "运行中…") : L("Run paired benchmark", "运行配对实验"), "run-benchmark", "primary small full", ui.benchmarkProgress !== null ? "disabled" : "", "research")}${ui.benchmarkProgress !== null ? button(L("Cancel experiment", "取消实验"), "cancel-benchmark", "small quiet full") : ""}${button(L("Use current match checkpoint", "使用当前比赛存档"), "fork", "small quiet full")}</div>`,
    )}${panel(L("Interpretation", "结果解释"), `<p class="hint">${L("Smaller residual or estimation error can help explain coordination; neither guarantees a better football result. Compare like-for-like scenarios and report failed runs. Use longer multi-seed studies before drawing research conclusions.", "更小的残差或估计误差有助于解释协作，但不保证足球表现更好。应比较同类场景并记录失败运行；形成研究结论前还需更长时间、多随机种子实验。")}</p>`)}</aside></div>`
  );
}
function benchmarkResults() {
  if (ui.benchmarkProgress !== null)
    return `<p class="hint">${L("Computing independent A/B branches…", "正在计算独立 A/B 分支……")}</p><div class="progress"><span style="width:${ui.benchmarkProgress * 100}%"></span></div><span class="mono">${num(ui.benchmarkProgress * 100, 0)}%</span>`;
  if (!ui.benchmark)
    return `<div class="empty-state"><h3>${L("Measured results appear here", "实测结果将在此显示")}</h3><p>${L("The benchmark executes the same engine as the match. No illustrative numbers or prefilled curves.", "基准实验执行与比赛相同的引擎，不使用示意数值或预填曲线。")}</p></div>`;
  const r = ui.benchmark.results,
    rows = [
      ["shape", L("Target residual", "目标残差"), "m"],
      ["estimation", L("Centroid RMSE", "中心 RMSE"), "m"],
      ["effort", L("Mean squared command", "指令均方幅值"), "m²/s²"],
      ["saturation", L("Saturation fraction", "饱和比例"), ""],
    ];
  return benchmarkInsights(ui.benchmark,ui.lang) + footballOutcomePanel(ui.benchmark,ui.lang) + `<details class="exact-values"><summary>${L("Paired statistics · full precision in JSON","配对统计 · 完整精度见 JSON")}</summary><div class="table-scroll"><table class="data-table"><thead><tr><th>${L("Metric", "指标")}</th><th>A</th><th>B</th><th>Δ(B−A)</th><th>95% CI</th></tr></thead><tbody>${rows
    .map(([key, label, unit]) => {
      let av = r.reduce((s, x) => s + x.a[key], 0) / r.length,
        bv = r.reduce((s, x) => s + x.b[key], 0) / r.length,
        d = r.map((x) => x.b[key] - x.a[key]),
        mean = bv - av,
        sd = Math.sqrt(
          d.reduce((s, x) => s + (x - mean) ** 2, 0) / (r.length - 1),
        ),
        ci = (4.303 * sd) / Math.sqrt(r.length);
      return `<tr><td>${label} ${unit}</td><td>${num(av,4)}</td><td>${num(bv,4)}</td><td><strong>${num(mean,4)}</strong></td><td>[${num(mean - ci,4)}, ${num(mean + ci,4)}]</td></tr>`;
    })
    .join(
      "",
    )}</tbody></table></div></details><div class="sep"></div><div class="benchmark-toolbar"><span class="chart-title">${L("Last 60 s · A mint / B coral","最近 60 秒曲线 · A 绿／B 红")}</span><select data-source="ui" data-key="benchmarkView" aria-label="${L("Curve samples","曲线采样选择")}">${option("mean",L("Mean of 3 pairs","三组配对均值"),ui.benchmarkView)}${ui.benchmark.results.map((r,i)=>option(String(i),L("Pair ","配对 ")+(i+1),ui.benchmarkView)).join("")}</select></div><div class="two-cols"><div class="chart-wrap"><div class="chart-title">${L("Target residual","目标残差")}</div><canvas class="chart" data-chart="benchmark:shape"></canvas></div><div class="chart-wrap"><div class="chart-title">${L("Mean squared command","指令均方幅值")}</div><canvas class="chart" data-chart="benchmark:effort"></canvas></div></div><div class="sep"></div><div class="hint">${ui.benchmark.checkpoint ? L("Paired RNG states", "配对随机状态") : L("Seeds", "种子")}: ${(ui.benchmark.checkpoint ? ui.benchmark.results.map((r) => r.rngState) : ui.benchmark.seeds).join(" / ")} · ${ui.benchmark.duration} s · ${ui.benchmark.checkpoint ? L("matched checkpoint", "匹配存档") : L("matched initialization", "匹配初始化")}</div><div class="actions">${button(L("Export result JSON", "导出结果 JSON"), "export-benchmark", "small quiet", "", "download")}</div>`;
}
function eventName(type) {
  return (
    {
      kickoff: L("Kick-off", "开球"),
      pass: L("Pass", "传球"),
      shot: L("Shot", "射门"),
      tackle: L("Ball recovered", "争回球权"),
      save: L("Goalkeeper save", "门将扑救"),
      goal: L("GOAL", "进球"),
      throwIn: L("Throw-in", "界外球"),
      corner: L("Corner", "角球"),
      goalKick: L("Goal kick", "球门球"),
      offside: L("Offside", "越位"),
      halftime: L("Half-time · sides switched", "中场 · 已换边"),
      fulltime: L("Full-time", "终场"),
    }[type] || type
  );
}
function vectorTable(p) {
  let labels = {
    formation: L("Formation", "阵型"),
    centroid: L("Centroid", "中心"),
    support: L("Ball support", "足球支援"),
    group: L("Subsystems", "子系统"),
    avoidance: L("Avoidance", "避碰"),
    compensator: L("Compensator", "补偿"),
    algorithm: L("Custom algorithm", "自定义算法"),
    mission:L("Mission tracking","任务跟踪"),
  };
  return `<div class="table-scroll"><table class="vector-table"><thead><tr><th>${L("Component", "分量")}</th><th>uₓ</th><th>uᵧ</th><th>‖u‖</th></tr></thead><tbody>${Object.entries(
    p.parts || {},
  )
    .map(
      ([k, v]) =>
        `<tr><td>${escape(labels[k] || k)}</td><td>${num(v.x)}</td><td>${num(v.y)}</td><td>${num(Math.hypot(v.x, v.y))}</td></tr>`,
    )
    .join(
      "",
    )}<tr><td><strong>${L("Desired sum", "期望合计")}</strong></td><td>${num(p.raw?.x)}</td><td>${num(p.raw?.y)}</td><td>${num(Math.hypot(p.raw?.x || 0, p.raw?.y || 0))}</td></tr><tr><td class="accent">${L("After speed limit", "速度限幅后")}</td><td>${num(p.command.x)}</td><td>${num(p.command.y)}</td><td>${num(Math.hypot(p.command.x, p.command.y))}</td></tr><tr><td>${L("Actual velocity", "实际速度")}</td><td>${num(p.vx)}</td><td>${num(p.vy)}</td><td>${num(Math.hypot(p.vx, p.vy))}</td></tr></tbody></table></div>`;
}
function paintLive(force = false) {
  if(ground.active){
    const el=$('[data-live="sidebar-status"]');
    if(el)el.textContent=L("Training ground","控制训练场")+" · "+(ground.running?L("Running","运行中"):L("Ready","就绪"));
    return;
  }
  if (!state) return;
  let now = performance.now();
  if (!force && now - lastPaint < 350) return;
  lastPaint = now;
  if(ui.page==="network")network.paint();
  missions.paint();
  const s = viewState(),
    p = s.players[ui.selected],
    c = cfg(),
    m = s.metrics[ui.team] || {},
    stats = s.stats[ui.team],
    g = graphHealth(c.commEdges, c.gamma);
  if (!p) return;
  const ball = p.knownBall,
    ballAge = ball ? s.time - ball.time : Infinity,
    totalPos = s.stats[0].possession + s.stats[1].possession,
    pos = totalPos ? (100 * s.stats[0].possession) / totalPos : 50;
  const text = {
    transport: ui.replayActive
      ? L(
          "Recorded snapshot · live controls locked",
          "已记录快照 · 实时操作已锁定",
        )
      : L(
          `${s.minutes} match minutes · ${num(s.minutes / s.clockRate, 0)} real minutes at 1×`,
          `${s.minutes} 分钟比赛 · 1× 时实际约 ${num(s.minutes / s.clockRate, 0)} 分钟`,
        ),
    clock: clock(s.clock),
    phase: ui.replayActive
      ? L("REPLAY", "回放")
      : s.phase === "live"
        ? L("LIVE MATCH", "比赛直播")
        : s.phase === "finished"
          ? L("FULL-TIME", "终场")
          : s.phase === "goal"
            ? L("GOAL", "进球")
            : s.phase === "halftime"
              ? L("HALF-TIME", "中场")
              : L("RESTART", "重新开球"),
    half: s.half === 1 ? L("FIRST HALF", "上半场") : L("SECOND HALF", "下半场"),
    seed: s.seed,
    score0: s.score[0],
    score1: s.score[1],
    team0: s.tactics[0].teamName,
    team1: s.tactics[1].teamName,
    action: actionLabel(p.action),
    speed: `${num(Math.hypot(p.vx, p.vy))} m/s`,
    stamina: `${num(p.stamina * 100, 0)}%`,
    visible: p.visible.length,
    saturated: p.saturated ? L("Active", "触发") : L("Clear", "未触发"),
    "ball-speed": num(Math.hypot(s.ball.vx, s.ball.vy), 1),
    possession: totalPos ? num(pos, 0) : "—",
    passes: `${s.stats[0].completed} / ${s.stats[1].completed}`,
    estimation: num(m.estimation),
    disagreement: num(m.disagreement),
    shape: num(m.shape),
    effort: num(m.effort, 1),
    saturation: num(m.saturation * 100, 0),
    queued: s.queued,
    received: stats.received,
    "prediction-error": stats.predictionN
      ? `${num(stats.prediction / stats.predictionN)} m`
      : "—",
    "prediction-n": stats.predictionN,
    "render-status": renderer ? `${renderer.backend === "WebGL" ? L("WebGL · 3D","WebGL · 三维") : L("Canvas · compatibility","Canvas · 兼容渲染")}` : "",
    "trace-time": `t = ${num(s.time)} s · tick ${s.tick}`,
    "sidebar-status": `${running ? L("Running", "运行中") : L("Paused", "已暂停")} · ${clock(state.clock)}${renderer && $("#pitch-host") ? " · " + renderer.fps + " fps · " + renderer.backend : ""}`,
  };
  for (let el of $$("[data-live]"))
    if (Object.hasOwn(text, el.dataset.live))
      el.textContent = text[el.dataset.live];
  const html = (key, value) =>
    $$(`[data-live="${key}"]`).forEach((el) => (el.innerHTML = value));
  if ($('[data-live="events"]'))
    html(
      "events",
      s.events
        .slice(0, 12)
        .map(
          (e) =>
            `<div class="event ${e.type}"><span class="event-time mono">${clock(e.clock)}</span><span class="event-symbol" style="color:${e.team >= 0 ? s.tactics[e.team].color : "var(--muted)"}">${e.type === "goal" ? "⚽" : e.type === "pass" ? "↗" : e.type === "shot" ? "◎" : e.type === "save" ? "◈" : "·"}</span><span class="event-desc">${e.ownGoal ? L("Own goal", "乌龙球") : eventName(e.type)}<small>${e.player >= 0 ? escape(s.players[e.player].name) : e.team >= 0 ? escape(s.tactics[e.team].teamName) : ""}</small></span></div>`,
        )
        .join(""),
    );
  if ($('[data-live="match-balance"]'))
    html(
      "match-balance",
      [
        [
          L("Possession", "控球"),
          totalPos ? num(pos, 0) + "%" : "—",
          totalPos ? num(100 - pos, 0) + "%" : "—",
          pos,
        ],
        [
          L("Shots", "射门"),
          s.stats[0].shots,
          s.stats[1].shots,
          (100 * s.stats[0].shots) / (s.stats[0].shots + s.stats[1].shots || 1),
        ],
        [
          L("Successful passes", "成功传球"),
          s.stats[0].completed,
          s.stats[1].completed,
          (100 * s.stats[0].completed) /
            (s.stats[0].completed + s.stats[1].completed || 1),
        ],
        [
          L("Goalkeeper saves", "门将扑救"),
          s.stats[0].saves,
          s.stats[1].saves,
          (100 * s.stats[0].saves) / (s.stats[0].saves + s.stats[1].saves || 1),
        ],
      ]
        .map(
          ([l, a, b, w]) =>
            `<div class="comparison-label">${l}</div><div class="comparison"><strong class="blue mono">${a}</strong><div class="bar-track"><span style="width:${w}%"></span></div><strong class="coral mono" style="text-align:right">${b}</strong></div>`,
        )
        .join(""),
    );
  if ($('[data-live="vector-table"]')) html("vector-table", vectorTable(p));
  if ($('[data-live="command-graphic"]')) html("command-graphic",commandGraphic(p,ui.lang));
  if ($('[data-live="mas-analysis"]')) html("mas-analysis",effectiveNetworkPanel(s,ui.team,ui.lang)+networkInsights(s,ui.team,ui.selected,ui.lang));
  if ($('[data-live="signal-values"]'))
    html(
      "signal-values",
      dataRow(
        L("Local estimate ĉᵢ", "局部估计 ĉᵢ"),
        `(${num(p.estimate.x)}, ${num(p.estimate.y)}) m`,
      ) +
        dataRow(
          L("Role reference qᵢʳ", "角色参考 qᵢʳ"),
          `(${num(p.target.x)}, ${num(p.target.y)}) m`,
        ) +
        dataRow(
          L("Command uᵢ", "控制指令 uᵢ"),
          `(${num(p.command.x)}, ${num(p.command.y)}) m/s`,
        ),
    );
  if ($('[data-live="controller-memory"]'))
    html(
      "controller-memory",
      dataRow(
        L("Integral zᵢ", "积分记忆 zᵢ"),
        `(${num(p.integral.x)}, ${num(p.integral.y)})`,
      ) +
        dataRow(
          L("Filter fᵢ", "滤波状态 fᵢ"),
          `(${num(p.filter.x)}, ${num(p.filter.y)})`,
        ) +
        dataRow(
          L("Algorithm memory", "算法记忆"),
          `(${num(p.algoMemory.x)}, ${num(p.algoMemory.y)})`,
        ),
    );
  if ($('[data-live="local-knowledge"]'))
    html(
      "local-knowledge",
      dataRow(
        L("Ball evidence", "足球证据"),
        ball
          ? L(
              ball.via === "vision" ? "Direct observation" : "Received message",
              ball.via === "vision" ? "直接观测" : "通信消息",
            )
          : L("Unknown", "未知"),
      ) +
        dataRow(
          L("Evidence age", "证据年龄"),
          ball ? `${num(ballAge)} s` : "—",
        ) +
        dataRow(
          L("Ball position in memory", "记忆中的足球位置"),
          ball ? `(${num(ball.x)}, ${num(ball.y)}) m` : "—",
        ) +
        dataRow(
          L("Local centroid estimate", "局部球队中心估计"),
          `(${num(p.estimate.x)}, ${num(p.estimate.y)}) m`,
        ) +
        dataRow(
          L("Visible teammates / opponents", "可见队友／对手"),
          `${p.visible.filter((v) => v.team === p.team).length} / ${p.visible.filter((v) => v.team !== p.team).length}`,
        ),
    );
  if ($('[data-live="observation-table"]'))
    html(
      "observation-table",
      `<div class="table-scroll"><table class="data-table"><thead><tr><th>${L("Player", "球员")}</th><th>x (m)</th><th>y (m)</th><th>${L("Team", "队伍")}</th></tr></thead><tbody>${p.visible.map((q) => `<tr><td>${escape(s.players[q.id].name)}</td><td>${num(q.x)}</td><td>${num(q.y)}</td><td class="${q.team ? "coral" : "blue"}">${q.team ? "C" : "B"}</td></tr>`).join("")}</tbody></table></div>`,
    );
  if ($('[data-live="messages"]'))
    html(
      "messages",
      p.inbox.length
        ? `<div class="table-scroll"><table class="data-table"><thead><tr><th>${L("From", "来源")}</th><th>${L("Sent", "发送")} (s)</th><th>${L("Arrived", "到达")} (s)</th><th>${L("Ball", "足球")}</th></tr></thead><tbody>${p.inbox
            .slice(-10)
            .reverse()
            .map(
              (q) =>
                `<tr><td>#${(q.from % 11) + 1}</td><td>${num(q.time, 1)}</td><td>${num(q.arrival, 1)}</td><td>${q.ball ? L("Evidence", "证据") : "—"}</td></tr>`,
            )
            .join("")}</tbody></table></div>`
        : `<p class="no-data">${L("No messages received yet.", "尚未收到消息。")}</p>`,
    );
  if ($('[data-live="belief"]')) {
    let labels = {
      unknown: L("Insufficient evidence", "证据不足"),
      left: L("Observed left-side concentration", "观测到左侧集中"),
      right: L("Observed right-side concentration", "观测到右侧集中"),
      central: L("Observed central concentration", "观测到中路集中"),
    };
    html(
      "belief",
      `<div class="eyebrow">${L("CURRENT HYPOTHESIS", "当前假设")}</div><h2 style="font-size:24px;margin:14px 0">${labels[p.belief.mode]}</h2>${dataRow(L("Visible opponent samples", "可见对手样本"), p.belief.evidence)}${dataRow(L("Observed mean lateral position", "观测平均横向位置"), p.belief.mode === "unknown" ? "—" : `${num(p.belief.meanY)} m`)}${dataRow(L("Calibrated probability", "校准概率"), L("Not estimated", "未估计"))}`,
    );
  }
  if ($('[data-live="movement-trace"]')) {
    const steps = [
      [
        L("What it saw", "它看到了什么"),
        L(
          `${p.visible.length} players are visible. Ball evidence: ${ball ? num(ballAge) + " s old" : "unknown"}.`,
          `${p.visible.length} 名球员可见。足球证据：${ball ? num(ballAge) + " 秒前" : "未知"}。`,
        ),
      ],
      [
        L("What it estimated", "它估计了什么"),
        L(
          `Centroid estimate (${num(p.estimate.x)}, ${num(p.estimate.y)}) m; role reference (${num(p.target.x)}, ${num(p.target.y)}) m.`,
          `中心估计 (${num(p.estimate.x)}, ${num(p.estimate.y)}) 米；角色参考 (${num(p.target.x)}, ${num(p.target.y)}) 米。`,
        ),
      ],
      [
        L("What it computed", "它计算了什么"),
        L(
          `Desired speed ${num(Math.hypot(p.raw?.x || 0, p.raw?.y || 0))} m/s from the terms above.`,
          `分项合成的期望速度为 ${num(Math.hypot(p.raw?.x || 0, p.raw?.y || 0))} 米/秒。`,
        ),
      ],
      [
        L("What actually happened", "实际发生了什么"),
        L(
          `Executed speed ${num(Math.hypot(p.vx, p.vy))} m/s. Velocity saturation ${p.saturated ? "active" : "inactive"}; acceleration limit ${num(p.acc)} m/s².`,
          `实际速度 ${num(Math.hypot(p.vx, p.vy))} 米/秒。速度限幅${p.saturated ? "已触发" : "未触发"}；加速度上限 ${num(p.acc)} 米/秒²。`,
        ),
      ],
    ];
    html(
      "movement-trace",
      steps
        .map(
          ([a, b], i) =>
            `<div class="trace-step"><span class="number">${i + 1}</span><div><h3>${a}</h3><p>${b}</p></div></div>`,
        )
        .join(""),
    );
  }
  if ($('[data-live="health"]')) {
    let groups = c.groups.filter((x) => x.members.includes(selectedIndex())),
      conflict = groups.some((a) =>
        groups.some((b) => a.dx * b.dx + a.dy * b.dy < -1),
      );
    let checks = [
      [
        g.connected,
        L("Communication connected", "通信网络连通"),
        L(
          `${g.components} component(s); maximum degree ${g.maxDegree}.`,
          `${g.components} 个连通分量，最大度数 ${g.maxDegree}。`,
        ),
      ],
      [
        m.estimation < 5,
        L("Centroid accuracy", "球队中心准确性"),
        L(
          `Measured RMSE ${num(m.estimation)} m; advisory threshold 5 m.`,
          `实测 RMSE ${num(m.estimation)} 米；提示阈值为 5 米。`,
        ),
      ],
      [
        m.saturation < 0.4,
        L("Actuator headroom", "执行器余量"),
        L(
          `${num(m.saturation * 100, 0)}% of agents request more than their speed limit.`,
          `${num(m.saturation * 100, 0)}% 球员的指令超过速度上限。`,
        ),
      ],
      [
        !conflict,
        L("Subsystem compatibility", "子系统兼容性"),
        conflict
          ? L(
              "Opposing soft offsets overlap on the selected player.",
              "选中球员同时接收相反方向的软偏移。",
            )
          : L(
              "No opposing soft offsets on this player.",
              "该球员未发现相反方向的软偏移。",
            ),
      ],
      [
        c.delay < 500 && c.loss < 0.25,
        L("Communication quality", "通信质量"),
        L(
          `${c.delay} ms configured delay; ${num(c.loss * 100, 0)}% configured loss.`,
          `${c.delay} 毫秒配置延迟；${num(c.loss * 100, 0)}% 配置丢包率。`,
        ),
      ],
    ];
    html(
      "health",
      checks
        .map(
          ([ok, a, b]) =>
            `<div class="health-item"><i class="health-dot ${ok ? "" : "warn"}"></i><div><h3>${a}</h3><p>${b}</p></div></div>`,
        )
        .join(""),
    );
  }
  if ($('[data-live="ratings"]'))
    html(
      "ratings",
      `<div class="table-scroll"><table class="data-table"><thead><tr><th># / ${L("Player", "球员")}</th><th>${L("Passes", "传球")}</th><th>${L("Completion", "完成率")}</th><th>${L("Shots", "射门")}</th><th>${L("Goals", "进球")}</th><th>${L("Saves", "扑救")}</th><th>${L("Distance", "距离")} m</th><th>∫‖u‖²dt</th><th>${L("Saturation", "饱和率")}</th></tr></thead><tbody>${s.players
        .filter((q) => q.team === ui.team)
        .map((q) => {
          let a = q.individual;
          return `<tr><td>${q.index + 1} · ${escape(q.name)}</td><td>${a.completed}/${a.passes}</td><td>${a.passes >= 2 ? num((a.completed / a.passes) * 100, 0) + "%" : "N/A"}</td><td>${a.shots}</td><td>${a.goals}</td><td>${a.saves}</td><td>${num(a.distance, 0)}</td><td>${num(a.effort, 0)}</td><td>${a.samples ? num((a.saturation / a.samples) * 100, 1) + "%" : "N/A"}</td></tr>`;
        })
        .join("")}</tbody></table></div>`,
    );
  if ($("#mini-map")) $("#mini-map").innerHTML = miniMap(s, p);
  if ($("#play-button")) {
    $("#play-button").innerHTML =
      icon(running ? "pause" : "play") +
      (running ? L("Pause", "暂停") : L("Play", "继续"));
    $("#play-button").disabled = ui.replayActive;
  }
  for (let el of $$(
    '#match-panel [data-action="step"],#match-panel [data-action="save-checkpoint"],#match-panel [data-key="speed"]',
  ))
    el.disabled = ui.replayActive;
  drawCharts(s);
  typesetMath($("#main"));
}
function miniMap(s, p) {
  const local = ui.page === "agent" && ui.tabs.agent === "local",
    visible = new Set([p.id, ...p.visible.map((q) => q.id)]);
  return `<svg viewBox="0 0 110 72" class="field-svg" aria-hidden="true"><g fill="none" stroke="#9fb6ac66" stroke-width=".4"><rect x="2.5" y="2" width="105" height="68"/><path d="M55 2v68"/><circle cx="55" cy="36" r="9.15"/></g>${s.players
    .filter((q) => !local || visible.has(q.id))
    .map(
      (q) =>
        `<circle cx="${q.x + 55}" cy="${36 - q.y}" r="${q.id === p.id ? 2.1 : 1.3}" fill="${s.tactics[q.team].color}" ${q.id === p.id ? 'stroke="#b6f4dc" stroke-width=".6"' : ""}/>`,
    )
    .join(
      "",
    )}${!local || (p.knownBall?.via === "vision" && s.time - p.knownBall.time < 0.12) ? `<circle cx="${s.ball.x + 55}" cy="${36 - s.ball.y}" r="1" fill="#f3edc8"/>` : ""}</svg>`;
}
function drawCharts(s) {
 for (const canvas of $$("canvas[data-chart]")) {
  const key=canvas.dataset.chart,metric=key.startsWith("benchmark")?(key.split(":")[1]||"shape"):key,scale=metric==="saturation"?100:1;
  let series;
  if(key.startsWith("benchmark")&&ui.benchmark){
   const results=ui.benchmark.results, chosen=ui.benchmarkView==="mean"?results:[results[Number(ui.benchmarkView)]||results[0]];
   series=["A","B"].map((label,i)=>({name:label,color:i?"#f39882":"#9be5c6",points:chosen[0]["series"+label].map((r,k)=>({x:r.time,y:chosen.reduce((sum,v)=>sum+(v["series"+label][k]?.teams[ui.benchmark.team??0][metric]||0),0)/chosen.length*scale}))}));
  } else series=[0,1].map(t=>({name:t?L("Coral","红队"):L("Blue","蓝队"),color:t?"#f39882":"#69b9fa",points:(s.measurements||[]).map(r=>({x:r.time,y:r.teams[t][metric]*scale}))}));
  plotChart(canvas,series,{lang:ui.lang,unit:metric==="saturation"?"%":metric==="effort"?"m²/s²":"m",title:chartNames()[metric],spark:canvas.classList.contains("spark")});
 }
}
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").classList.add("show");
  clearTimeout(toaster);
  toaster = setTimeout(() => $("#toast").classList.remove("show"), 4200);
}
function errorMessage(key) {
  const e = {
    benchmark_tracker_missing:L("The selected team has no role tracker.","所选球队尚未安装角色跟踪器。"),
    benchmark_finished: L(
      "This match has finished. Start a new match or use fresh initialization.",
      "这场比赛已结束，请开始新比赛或使用全新初始化。",
    ),
    benchmark_empty: L(
      "The run ended before enough samples were recorded.",
      "本次运行在采集足够样本前已结束。",
    ),
    algorithm_schema: L(
      "Use kind FlowController and schema 1.",
      "请使用 kind=FlowController 和 schema=1。",
    ),
    algorithm_name: L(
      "Name must contain 1–64 characters.",
      "名称需要 1–64 个字符。",
    ),
    sample_time: L(
      "sampleTime must be 0.1 seconds.",
      "sampleTime 必须为 0.1 秒。",
    ),
    unknown_signal: L(
      "Unknown signal or function. Check the permitted signal list.",
      "包含未知信号或函数，请检查允许的信号列表。",
    ),
    parameters: L(
      "Invalid parameter name, value or count.",
      "参数名称、数值或数量无效。",
    ),
    output_bounds: L(
      "blend must be 0–1; maxOutput must be >0 and ≤12.",
      "blend 必须在 0–1，maxOutput 必须大于 0 且不超过 12。",
    ),
    invalid_token: L(
      "Only the documented arithmetic expression language is accepted.",
      "仅支持已说明的算术表达式语言。",
    ),
    expression_budget: L(
      "Expression exceeds the execution budget.",
      "表达式超过执行预算。",
    ),
    expression_length: L(
      "Expression must be a string under 1000 characters.",
      "表达式必须是少于 1000 字符的字符串。",
    ),
    function_arity: L(
      "A function has the wrong number of arguments.",
      "函数的参数数量错误。",
    ),
    parenthesis: L("Check parentheses.", "请检查括号配对。"),
    trailing_token: L(
      "Unexpected tokens after the expression.",
      "表达式后出现额外符号。",
    ),
    tactic_schema: L(
      "This is not a supported TacticPreset JSON file.",
      "这不是受支持的 TacticPreset JSON 文件。",
    ),
    parameter_range: L(
      "A parameter is outside its allowed range.",
      "参数超出允许范围。",
    ),
    graph: L(
      "Edges must be unique pairs of distinct player indices 0–10.",
      "边必须是 0–10 之间不同球员编号组成的不重复连接。",
    ),
    checkpoint_schema: L(
      "Checkpoint format or engine version is not supported.",
      "不支持此比赛进度格式或引擎版本。",
    ),
    checkpoint_state: L(
      "The checkpoint contains an invalid state.",
      "比赛进度包含无效状态。",
    ),
    checkpoint_player: L(
      "The checkpoint contains invalid player data.",
      "比赛进度包含无效球员数据。",
    ),
    groups: L(
      "Check unit members, weight and offsets.",
      "请检查子系统成员、权重和偏移。",
    ),
    players: L(
      "A team must contain exactly eleven players.",
      "一队必须恰好包含 11 名球员。",
    ),
    player_ability: L(
      "Player capability is outside the allowed range.",
      "球员能力超出允许范围。",
    ),
    tactic_name: L(
      "Please enter a valid tactic and team name.",
      "请输入有效战术名和球队名。",
    ),
    seed: L(
      "Use an integer seed from 1 to 4294967295.",
      "请使用 1 至 4294967295 的整数种子。",
    ),
  };
  return (
    e[key] ||
    L(
      "The file or configuration could not be accepted. Please check its JSON format and values.",
      "无法接受该文件或配置，请检查 JSON 格式和数值。",
    )
  );
}
function modal(title, body, actions = "") {
  const d = $("#dialog");
  d.innerHTML = `<div class="dialog-head"><h2>${title}</h2>${button("", "close-dialog", "icon-only quiet", `aria-label="${L("Close", "关闭")}"`, "close")}</div><div class="dialog-body">${body}</div>${actions ? `<div class="dialog-actions">${actions}</div>` : ""}`;
  if (!d.open) d.showModal();
}
function closeModal() {
  $("#dialog").close();
}
function newMatchDialog() {
  modal(
    L("Start a new match", "开始一场新比赛"),
    `<div class="two-cols"><div><div class="eyebrow blue">BLUE</div><h3 style="margin-top:8px">${escape(tactics[0].name)}</h3><p class="hint">${tactics[0].formation}</p></div><div><div class="eyebrow coral">CORAL</div><h3 style="margin-top:8px">${escape(tactics[1].name)}</h3><p class="hint">${tactics[1].formation}</p></div></div><div class="sep"></div><div class="field-pair">${field(L("Match length", "比赛长度"), `<select id="new-minutes">${[90, 60, 30].map((n) => option(n, n + L(" minutes", " 分钟"), 90)).join("")}</select>`)}${field(L("Match clock", "比赛时钟"), `<select id="new-clock">${option(6, L("6× · 15 min real time for 90 min", "6× · 90 分钟比赛实际运行 15 分钟"), 6)}${option(3, L("3× · 30 min real time", "3× · 实际运行 30 分钟"), 6)}${option(1, L("1× · full real time", "1× · 完整真实时长"), 6)}</select>`)}</div>${field(L("Random seed", "随机种子"), `<input id="new-seed" type="number" min="1" max="4294967295" value="${ui.seed}">`)}<p class="note">${L("Your team configurations remain. Physical states, score and agent memories restart. Save a checkpoint first if you want to return to the current match.", "球队配置保留，物理状态、比分与球员记忆重新开始。如需返回当前比赛，请先保存比赛进度。")}</p>`,
    button(L("Cancel", "取消"), "close-dialog", "quiet") +
      button(L("Kick off", "开球"), "confirm-new", "primary", "", "play"),
  );
}
function groupDialog(index = null) {
  let g =
    index === null
      ? {
          name: L("New unit", "新子系统"),
          members: [selectedIndex()],
          weight: 0.25,
          dx: 0,
          dy: 0,
        }
      : cfg().groups[index];
  modal(
    L("Design a subsystem", "设计子系统"),
    field(
      L("Unit name", "子系统名称"),
      `<input id="group-name" maxlength="40" value="${escape(g.name)}">`,
    ) +
      `<div class="field-label" style="margin-bottom:8px">${L("Members · overlaps are allowed", "成员 · 允许重叠")}</div><div class="check-grid">${cfg()
        .players.map(
          (p, i) =>
            `<label class="check-option"><input type="checkbox" name="group-member" value="${i}" ${g.members.includes(i) ? "checked" : ""}>${i + 1} ${ROLES[cfg().formation][i]}</label>`,
        )
        .join(
          "",
        )}</div><div class="sep"></div><div class="field-pair">${field(L("Longitudinal correction (m/s)", "纵向修正（米/秒）"), `<input id="group-dx" type="number" min="-15" max="15" step=".5" value="${g.dx}">`)}${field(L("Lateral correction (m/s)", "横向修正（米/秒）"), `<input id="group-dy" type="number" min="-15" max="15" step=".5" value="${g.dy}">`)}</div>${field(L("Weight (0–1)", "权重（0–1）"), `<input id="group-weight" type="number" min="0" max="1" step=".05" value="${g.weight}">`)}<div id="group-error" class="error-inline"></div>`,
    button(L("Cancel", "取消"), "close-dialog", "quiet") +
      button(
        L("Apply subsystem", "应用子系统"),
        "submit-group",
        "primary",
        `data-index="${index === null ? "new" : index}"`,
      ),
  );
}
function help() {
  modal(
    L("Welcome to OWN / FLOW", "欢迎使用 OWN / FLOW"),
    `<div class="help-grid"><div><h3>${L("Watch & investigate", "观看与检查")}</h3><ol><li>${L("Match: play, pause, zoom or switch camera.", "比赛：运行、暂停、缩放与镜头切换。")}</li><li>${L("Click a player or select from the team sheet.", "点击球员或从阵容中选择。")}</li><li>${L("Open layers and inspect the motion trace.", "打开图层，检查运动与控制分量。")}</li></ol></div><div><h3>${L("Build & compare", "设计与比较")}</h3><ol><li>${L("Edit team, unit and agent settings.", "编辑全队、子系统和个人配置。")}</li><li>${L("Save a tactic; load it on either team.", "保存战术，并加载到任意球队。")}</li><li>${L("Start a match or run a paired benchmark.", "开始比赛或运行配对基准实验。")}</li></ol></div><div><h3>${L("Upload your controller", "上传控制算法")}</h3><p>${L("Algorithm Studio provides a working JSON example. Edit its formula, validate, then deploy to the chosen team. Each player executes it using local evidence.", "算法工作室提供可运行 JSON 示例。编辑公式、校验后部署到球队，各球员使用局部证据独立运行。")}</p></div><div><h3>${L("Save your work", "保存成果")}</h3><p>${L("Tactics persist in this browser; checkpoints autosave every 30 seconds. Export JSON to keep a portable backup. Space pauses/resumes; Escape closes dialogs.", "战术保存在浏览器中，比赛每 30 秒自动保存进度。导出 JSON 可跨设备备份。空格暂停／继续，Esc 关闭弹窗。")}</p></div></div><div class="sep"></div><p class="note">${L("This is a playable research simulator with procedural 3D athletes and a simplified football model. Research Benchmark → Protocol & limits explains the model and scientific scope.", "这是具有程序化三维球员与简化足球模型的可运行科研仿真平台。科研基准 → 协议与边界页面说明模型与科学适用范围。")}</p>`,
    button(L("Explore the pitch", "进入球场"), "close-dialog", "primary"),
  );
}
function send(type, data = {}) {
  worker.postMessage({ type, ...data });
}
function ask(type, data = {}) {
  return new Promise((resolve, reject) => {
    const id = ++requestId;
    const timer = setTimeout(() => {
      requests.delete(id);
      reject(Error("timeout"));
    }, 15000);
    requests.set(id, {
      resolve: (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      reject: (e) => {
        clearTimeout(timer);
        reject(e);
      },
    });
    send(type, { ...data, id });
  });
}
function persistDraft() {
  try {
    localStorage.setItem("flow.draft.v1", JSON.stringify(tactics));
  } catch {
    toast(
      L(
        "Could not persist this edit. Export a tactic JSON as backup.",
        "无法保留本次编辑，请导出战术 JSON 备份。",
      ),
    );
  }
}
function updateTactic(team, value) {
  let checked = validateTactic(value);
  tactics[team] = checked;
  send("tactic", { team, value: checked });
  persistDraft();
}
function safeName(name) {
  return (
    String(name)
      .replace(/[^a-zA-Z0-9_\u3400-\u9fff-]+/g, "_")
      .slice(0, 80) || "OWN_FLOW"
  );
}
async function saveCheckpoint(notify = true) {
  if (notify) ui.autosaveReady = true;
  const cp = await ask("checkpoint");
  await storage.put("checkpoint", cp);
  ui.restoreAvailable = true;
  if (notify)
    toast(
      L(
        "Match checkpoint saved. You can resume from the Tactical Library.",
        "比赛进度已保存，可在战术资料库恢复。",
      ),
    );
  return cp;
}
async function resume() {
  let cp = await storage.get("checkpoint");
  if (!cp) {
    toast(L("No saved checkpoint yet.", "还没有保存的比赛进度。"));
    return;
  }
  await ask("restore", { value: cp });
  ui.autosaveReady = true;
  tactics = cp.tactics.map(validateTactic);
  persistDraft();
  ui.page = "match";
  ui.replayActive = false;
  running = false;
  renderPage();
  toast(
    L(
      "Checkpoint restored. Press Play to continue.",
      "比赛进度已恢复，点击继续即可运行。",
    ),
  );
}
function saveTacticDialog() {
  modal(
    L("Save this tactic", "保存当前战术"),
    teamPicker() +
      `<div style="margin-top:17px">${field(L("Tactic name", "战术名称"), `<input id="save-name" maxlength="80" value="${escape(cfg().name)}">`)}</div><p class="hint">${L("Includes formation, graphs, subsystem memberships, capabilities, controller overrides and custom algorithm.", "包括阵型、网络、子系统成员、能力、个人控制器覆盖与自定义算法。")}</p>`,
    button(L("Cancel", "取消"), "close-dialog", "quiet") +
      button(
        L("Save strategy", "保存策略"),
        "confirm-save",
        "primary",
        "",
        "save",
      ),
  );
}
function importFile(type) {
  importType = type;
  const input = $("#file-input");
  input.value = "";
  input.click();
}
async function onImport(file) {
  if (!file) return;
  if (file.size > (importType === "replay" ? 32 : 20) * 1024 * 1024)
    throw Error("checkpoint_state");
  const value = JSON.parse(await file.text());
  if (importType === "algorithm") {
    const v = validateAlgorithm(value);
    ui.algorithmText = JSON.stringify(v.config, null, 2);
    ui.algorithmValidated = v;
    ui.compileError = null;
    ui.page = "algorithm";
    renderPage();
    toast(
      L(
        "Algorithm imported and validated. Choose Deploy to use it.",
        "算法已导入并校验，可点击部署使用。",
      ),
    );
  } else if (importType === "checkpoint") {
    await ask("restore", { value });
    ui.autosaveReady = true;
    tactics = value.tactics.map(validateTactic);
    persistDraft();
    ui.page = "match";
    running = false;
    renderPage();
    toast(
      L(
        "Checkpoint imported. Press Play to resume.",
        "比赛进度已导入，点击继续恢复。",
      ),
    );
  } else if (importType === "replay") {
    ui.replay = validateReplay(value);
    ui.replayIndex = 0;
    ui.replayActive = true;
    running = false;
    send("run", { value: false });
    ui.page = "research";
    ui.tabs.research = "replay";
    renderPage();
  } else {
    const items = value.kind === "FlowLibrary" ? value.presets : [value];
    if (!Array.isArray(items) || items.length > 100)
      throw Error("tactic_schema");
    const validated = items.map(validateTactic);
    const added = validated.map((p) => ({
      preset: { ...p, id: makeId() },
      version: 1,
      savedAt: new Date().toISOString(),
    }));
    const next = [...presets, ...added];
    if (next.length > 100) throw Error("tactic_schema");
    storage.writePresets(next);
    presets = next;
    ui.page = "library";
    renderPage();
    toast(
      L(
        `${added.length} tactic(s) imported.`,
        `${added.length} 套战术已导入。`,
      ),
    );
  }
}
async function runBenchmark() {
  if(ui.intervention.startsWith('mission_') && (ui.forkCheckpoint?.mode??ui.scenario)!=='match'){
    toast(L('Mission policies require the match environment.','任务策略需要选择比赛环境。'));return;
  }
  if (benchWorker) return;
  if (!Number.isInteger(ui.seed) || ui.seed < 1 || ui.seed > 4294967295) {
    toast(errorMessage("seed"));
    return;
  }
  const subject=(ui.forkCheckpoint?.tactics??tactics)[Number(ui.benchmarkTeam)];
  if(ui.intervention==='mission_off'&&!subject.mission?.enabled){toast(L('Enable a mission policy on the intervention team first.','请先为干预球队启用任务策略。'));return;}
  if(ui.intervention==="algorithm"&&!subject.algorithm){
    toast(L("Install a custom algorithm on the intervention team first.","请先为干预球队安装自定义算法。"));return;
  }
  if(ui.intervention==="tracker"&&!subject.tracker){
    toast(L("Apply a role tracker to the intervention team in Control Ground first.","请先在控制训练场为干预球队应用角色跟踪器。"));return;
  }
  ui.benchmarkProgress = 0;
  ui.benchmark = null;
  benchWorker = new Worker("./benchmark-worker.js", { type: "module" });
  benchWorker.onmessage = ({ data: m }) => {
    if (m.type === "progress") {
      ui.benchmarkProgress = m.value;
      if ($("#benchmark-results"))
        $("#benchmark-results").innerHTML = benchmarkResults();
    } else if (m.type === "complete") {
      ui.benchmark = m.result;
      ui.benchmarkProgress = null;
      benchWorker.terminate();
      benchWorker = null;
      renderPage();
      toast(
        L(
          "Three paired runs completed. Results are ready.",
          "三个配对实验已完成，结果可查看。",
        ),
      );
    } else {
      benchWorker.terminate();
      benchWorker = null;
      ui.benchmarkProgress = null;
      toast(errorMessage(m.error));
      renderPage();
    }
  };
  benchWorker.onerror = () => {
    benchWorker?.terminate();
    benchWorker = null;
    ui.benchmarkProgress = null;
    toast(
      L(
        "The experiment worker failed. Try a shorter run.",
        "实验进程失败，请尝试较短运行。",
      ),
    );
    renderPage();
  };
  benchWorker.postMessage({
    tactics: clone(tactics),
    checkpoint: ui.forkCheckpoint || null,
    seeds: [ui.seed, ui.seed + 97, ui.seed + 211].map((x) => x >>> 0),
    duration: ui.duration,
    mode: ui.scenario,
    intervention: ui.intervention,
    team:Number(ui.benchmarkTeam),
  });
  renderPage();
}
document.addEventListener("click", async (e) => {
  const el = e.target.closest("[data-action]");
  if (!el || el.disabled) return;
  let a = el.dataset.action;
  try {
    if(a==="network-diagnose"){ui.page="network";network.tab="diagnose";renderPage();window.scrollTo(0,0);}
    else if(a==="ground-ab"){
      ui.page="research";ui.tabs.research="benchmark";ui.scenario="match";ui.intervention="tracker";ui.benchmarkTeam=ui.team;
      ui.forkCheckpoint=null;ui.benchmark=null;renderPage();window.scrollTo(0,0);
    }
    else if(a==="coach-preset"){ui.coachPreset=el.dataset.id;renderPage();}
    else if(a==="coach-abilities"){ui.coachHomogeneous=el.dataset.homogeneous==="true";renderPage();}
    else if(a==="coach-apply"){
      const tactic=buildPlaybook(ui.coachPreset,ui.team,{homogeneous:ui.coachHomogeneous});
      updateTactic(ui.team,tactic);
      ground.rosterOverride=null;
      renderPage();
      toast(L("Tactic and player abilities loaded","战术与球员能力已加载"));
    }
    else if(a==="coach-open"){ui.page="tactics";ui.tabs.tactics="playbooks";renderPage();window.scrollTo(0,0);}
    else if(a === "open-local-loop"){ui.page="control";ui.tabs.control="controller";renderPage();window.scrollTo(0,0);}
    else if(a === "open-mas"){ui.page="control";ui.tabs.control="multiagent";renderPage();window.scrollTo(0,0);}
    else if(a === "focus"){ui.focus=el.dataset.focus;ui.zoom=ui.focus==="overview"?1:ui.focus==="player"?2.2:1.7;configureRenderer();renderPage();}
    else if (a === "nav") {
      ui.page = el.dataset.page;
      $(".sidebar").classList.remove("open");
      renderPage();
      window.scrollTo(0, 0);
    } else if (a === "lang") {
      ui.lang = el.dataset.lang;
      try {
        localStorage.setItem("flow.lang", ui.lang);
      } catch {}
      renderShell();
    } else if (a === "menu") $(".sidebar").classList.toggle("open");
    else if (a === "help") help();
    else if (a === "close-dialog") closeModal();
    else if (a === "tab") {
      ui.tabs[el.dataset.page] = el.dataset.tab;
      ui.replayActive =
        ui.page === "research" && el.dataset.tab === "replay" && !!ui.replay;
      renderPage();
    } else if (a === "team") {
      ui.team = Number(el.dataset.team);
      ui.selected = ui.team * 11 + selectedIndex();
      if ($("#dialog").open && $("#save-name")) saveTacticDialog();
      else renderPage();
    } else if (a === "player") {
      if (el.classList.contains("agent-loop")) {ui.page="control";ui.tabs.control="controller";ui.block="controller";}
      selectPlayer(Number(el.dataset.id));
    }
    else if (a === "camera") {
      ui.camera = el.dataset.camera;
      configureRenderer();
      $$('[data-action="camera"]').forEach((x) =>
        x.classList.toggle("active", x.dataset.camera === ui.camera),
      );
    } else if (a === "fullscreen")
      $("#match-panel").classList.toggle("fullscreen");
    else if (a === "toggle-run") {
      if (ui.replayActive) return;
      if (state?.phase === "finished") {
        newMatchDialog();
        return;
      }
      running = !running;
      send("run", { value: running });
      if (ui.page === "diagnostics") renderPage();
      else paintLive(true);
    } else if (a === "step") {
      if (ui.replayActive) return;
      running = false;
      send("step");
    } else if (a === "layers-clean") {
      Object.keys(ui.flags).forEach((k) => (ui.flags[k] = false));
      renderPage();
    } else if (a === "layers-analysis") {
      ui.flags.prediction = true;
      ui.flags.command = true;
      ui.flags.centroids = true;
      renderPage();
    } else if (a === "new-match") newMatchDialog();
    else if (a === "confirm-new") {
      let seed = Number($("#new-seed").value);
      if (!Number.isInteger(seed) || seed < 1 || seed > 4294967295) {
        toast(errorMessage("seed"));
        return;
      }
      ui.seed = seed;
      ui.autosaveReady = true;
      send("new", {
        options: {
          tactics: clone(tactics),
          seed,
          minutes: Number($("#new-minutes").value),
          clockRate: Number($("#new-clock").value),
        },
      });
      ui.replayActive = false;
      running = true;
      closeModal();
      ui.page = "match";
      renderPage();
    } else if (a === "save-tactic") saveTacticDialog();
    else if (a === "confirm-save") {
      let name = $("#save-name").value.trim();
      if (!name) {
        toast(errorMessage("tactic_name"));
        return;
      }
      let c = clone(cfg());
      c.name = name;
      let idx = presets.findIndex((p) => p.preset.id === c.id);
      if (idx < 0) c.id = makeId();
      let record = {
          preset: validateTactic(c),
          version: idx < 0 ? 1 : presets[idx].version + 1,
          savedAt: new Date().toISOString(),
        },
        next = clone(presets);
      if (idx < 0) next.push(record);
      else next[idx] = record;
      storage.writePresets(next);
      presets = next;
      updateTactic(ui.team, c);
      closeModal();
      renderPage();
      toast(
        L(
          "Tactic saved. Load it on either team in the Tactical Library.",
          "战术已保存，可在战术资料库加载到任意球队。",
        ),
      );
    } else if (a === "save-checkpoint") await saveCheckpoint();
    else if (a === "export-checkpoint")
      storage.download("OWN_FLOW_Checkpoint.json", await ask("checkpoint"));
    else if (a === "resume") await resume();
    else if (a === "export-tactic")
      storage.download(
        safeName(tactics[Number(el.dataset.team)].name) + ".json",
        tactics[Number(el.dataset.team)],
      );
    else if (a === "export-preset") {
      let p = allPresets()[Number(el.dataset.index)].preset;
      storage.download(safeName(p.name) + ".json", p);
    } else if (a === "export-library")
      storage.download("OWN_FLOW_Tactical_Library.json", {
        kind: "FlowLibrary",
        schema: 1,
        presets: presets.map((p) => p.preset),
      });
    else if (a === "import-preset") importFile("preset");
    else if (a === "import-checkpoint") importFile("checkpoint");
    else if (a === "import-algorithm") importFile("algorithm");
    else if (a === "import-replay") importFile("replay");
    else if (a === "edit-team") {
      ui.team = Number(el.dataset.team);
      ui.selected = ui.team * 11 + selectedIndex();
      ui.page = "tactics";
      renderPage();
    } else if (a === "load-preset") {
      let p = clone(allPresets()[Number(el.dataset.index)].preset),
        team = Number(el.dataset.team);
      p.teamName = tactics[team].teamName;
      p.color = tactics[team].color;
      updateTactic(team, p);
      renderPage();
      toast(
        L(
          "Tactic loaded. Start a new match to reinitialize abilities and memories.",
          "战术已加载，开始新比赛可重新初始化能力与记忆。",
        ),
      );
    } else if (a === "delete-preset")
      modal(
        L("Delete saved tactic?", "删除已保存战术？"),
        `<p>${escape(presets[Number(el.dataset.index)].preset.name)}</p>`,
        button(L("Cancel", "取消"), "close-dialog", "quiet") +
          button(
            L("Delete", "删除"),
            "confirm-delete",
            "danger",
            `data-index="${el.dataset.index}"`,
          ),
      );
    else if (a === "confirm-delete") {
      let next = presets.filter((_, i) => i !== Number(el.dataset.index));
      storage.writePresets(next);
      presets = next;
      closeModal();
      renderPage();
    } else if (a === "add-group") groupDialog();
    else if (a === "edit-group") groupDialog(Number(el.dataset.index));
    else if (a === "remove-group") {
      let c = clone(cfg());
      c.groups.splice(Number(el.dataset.index), 1);
      updateTactic(ui.team, c);
      renderPage();
    } else if (a === "submit-group") {
      let g = {
          name: $("#group-name").value.trim(),
          members: $$('input[name="group-member"]:checked').map((x) =>
            Number(x.value),
          ),
          weight: Number($("#group-weight").value),
          dx: Number($("#group-dx").value),
          dy: Number($("#group-dy").value),
        },
        c = clone(cfg());
      if (el.dataset.index === "new") c.groups.push(g);
      else c.groups[Number(el.dataset.index)] = g;
      try {
        updateTactic(ui.team, c);
        closeModal();
        renderPage();
      } catch (err) {
        $("#group-error").textContent = errorMessage(err.message);
      }
    } else if (a === "graph-kind") {
      ui.graph = el.dataset.kind;
      ui.edgeStart = null;
      renderPage();
    } else if (a === "field-player") {
      let i = Number(el.dataset.index);
      if (ui.page === "tactics" && ui.tabs.tactics === "graphs") {
        if (ui.edgeStart === null) ui.edgeStart = i;
        else if (ui.edgeStart === i) ui.edgeStart = null;
        else {
          let c = clone(cfg()),
            a = ui.edgeStart,
            b = i,
            j = c[ui.graph].findIndex(
              (e) => (e[0] === a && e[1] === b) || (e[0] === b && e[1] === a),
            );
          if (j < 0) c[ui.graph].push([a, b]);
          else c[ui.graph].splice(j, 1);
          updateTactic(ui.team, c);
          ui.edgeStart = null;
        }
        renderPage();
      } else selectPlayer(ui.team * 11 + i);
    } else if (a === "topology") {
      let c = clone(cfg());
      c[ui.graph] =
        el.dataset.kind === "empty" ? [] : graphEdges(el.dataset.kind);
      updateTactic(ui.team, c);
      ui.edgeStart = null;
      renderPage();
    } else if (a === "goto-graphs") {
      ui.page = "tactics";
      ui.tabs.tactics = "graphs";
      renderPage();
    } else if (a === "block") {
      ui.block = el.dataset.block;
      if(ui.page==="tactics"){ui.page="control";ui.tabs.control="controller";}
      renderPage();
    } else if (a === "clear-override") {
      let c = clone(cfg());
      c.players[selectedIndex()].override = null;
      updateTactic(ui.team, c);
      renderPage();
    } else if (a === "algorithm-example") {
      ui.algorithmText = JSON.stringify(ALGORITHM_EXAMPLE, null, 2);
      ui.algorithmValidated = null;
      ui.compileError = null;
      renderPage();
    } else if (a === "algorithm-template")
      storage.download("FlowController_Template.json", ALGORITHM_EXAMPLE);
    else if (a === "algorithm-export")
      storage.download("FlowController.json", ui.algorithmText);
    else if (a === "compile") {
      ui.algorithmText = $("#algorithm-editor").value;
      try {
        ui.algorithmValidated = validateAlgorithm(ui.algorithmText);
        ui.compileError = null;
      } catch (err) {
        ui.algorithmValidated = null;
        ui.compileError = err.message;
      }
      renderPage();
    } else if (a === "deploy-algorithm") {
      if (!ui.algorithmValidated) return;
      let c = clone(cfg());
      c.algorithm = clone(ui.algorithmValidated.config);
      updateTactic(ui.team, c);
      renderPage();
      toast(
        L(
          "Controller deployed to 11 independent agents.",
          "控制器已部署到 11 个独立智能体。",
        ),
      );
    } else if (a === "remove-algorithm") {
      let c = clone(cfg());
      c.algorithm = null;
      updateTactic(ui.team, c);
      renderPage();
    } else if (a === "scenario") {
      ui.scenario = el.dataset.scenario;
      ui.forkCheckpoint = null;
      renderPage();
    } else if (a === "fork") {
      ui.forkCheckpoint = await ask("checkpoint");
      ui.intervention = cfg().mission?.enabled ? "mission_off" : "compensator";
      ui.benchmarkTeam = ui.team;
      ui.scenario = ui.forkCheckpoint.mode;
      ui.page = "research";
      ui.tabs.research = "benchmark";
      renderPage();
      toast(
        L(
          "Matched checkpoint captured for A/B experiments.",
          "已保存 A/B 实验的匹配起点。",
        ),
      );
    } else if (a === "clear-fork") {
      ui.forkCheckpoint = null;
      renderPage();
    } else if (a === "ab-compensator") {
      ui.forkCheckpoint = await ask("checkpoint");
      ui.intervention = "compensator";
      ui.page = "research";
      ui.tabs.research = "benchmark";
      renderPage();
    } else if (a === "run-benchmark") await runBenchmark();
    else if (a === "cancel-benchmark") {
      benchWorker?.terminate();
      benchWorker = null;
      ui.benchmarkProgress = null;
      renderPage();
    } else if (a === "export-benchmark" && ui.benchmark)
      storage.download("OWN_FLOW_Benchmark.json", ui.benchmark);
    else if (a === "capture-replay") {
      running = false;
      send("run", { value: false });
      ui.replay = await ask("history");
      ui.replayIndex = 0;
      ui.replayActive = !!ui.replay.frames.length;
      renderPage();
    } else if (a === "export-replay" && ui.replay)
      storage.download(
        "OWN_FLOW_Replay.json",
        JSON.stringify(ui.replay, (_k, v) =>
          typeof v === "number" ? Math.round(v * 1e4) / 1e4 : v,
        ),
      );
    else if (a === "exit-replay") {
      ui.replayActive = false;
      ui.page = "match";
      renderPage();
    } else if (a === "export-csv") {
      const data = await ask("exportMetrics");
      let csv =
        "time_s,team,target_residual_m,centroid_rmse_m,disagreement_m,control_effort_m2s2,saturation\n" +
        data.measurements
          .flatMap((row) =>
            row.teams.map((v, i) =>
              [
                row.time,
                i,
                v.shape,
                v.estimation,
                v.disagreement,
                v.effort,
                v.saturation,
              ].join(","),
            ),
          )
          .join("\n");
      storage.download("OWN_FLOW_Telemetry.csv", csv, "text/csv;charset=utf-8");
    }
  } catch (err) {
    console.warn(err);
    toast(errorMessage(err.message));
  }
});
document.addEventListener("input", (e) => {
  const el = e.target;
  if (el.id === "algorithm-editor") {
    ui.algorithmText = el.value;
    ui.algorithmValidated = null;
    ui.compileError = null;
    $("#compile-result").innerHTML = compileStatus();
    $('[data-action="deploy-algorithm"]').disabled = true;
    return;
  }
  if (el.type === "range") handleInput(el, false);
});
document.addEventListener("change", async (e) => {
  const el = e.target;
  try {
    if (el.id === "file-input") {
      await onImport(el.files[0]);
      return;
    }
    if (el.dataset.layer) {
      ui.flags[el.dataset.layer] = el.checked;
      configureRenderer();
      return;
    }
    if (el.dataset.source) handleInput(el, true);
  } catch (err) {
    toast(errorMessage(err.message));
  }
});
function handleInput(el, committed) {
  let source = el.dataset.source,
    key = el.dataset.key;
  if (!source) return;
  let numeric =
      el.type === "range" ||
      el.type === "number" ||
      ["selected", "speed", "zoom", "replayIndex", "duration", "seed"].includes(
        key,
      ),
    value = numeric ? Number(el.value) : el.value;
  if (numeric && !Number.isFinite(value)) return;
  if (el.type === "range") {
    let out = $(`#out-${source}-${key}`);
    if (out)
      out.textContent =
        num(value, Number(el.step) >= 1 ? 0 : 2) + (el.dataset.unit || "");
  }
  try {
    if (source === "ui") {
      if (key === "speed") {
        speed = value;
        send("speed", { value });
      } else if (key === "selected") selectPlayer(value);
      else if (key === "zoom") {
        ui.zoom = value;
        configureRenderer();
      } else if (key === "replayIndex") {
        ui.replayIndex = value;
        ui.replayActive = true;
        renderer?.setState(viewState());
        if ($("#replay-time"))
          $("#replay-time").textContent = clock(ui.replay.frames[value].clock);
        paintLive(true);
      } else {
        ui[key] = value;
        if (["scope", "controlScope", "benchmarkView"].includes(key)) renderPage();
        if(key === "quality"){configureRenderer();}
      }
      return;
    }
    let c = clone(cfg());
    if (source === "config") c[key] = value;
    if (source === "player") {
      c.players[selectedIndex()][key] = value;
      if (key !== "name") c.abilityMode = "custom";
    }
    if (source === "gain") {
      if (ui.controlScope === "agent") {
        c.players[selectedIndex()].override ??= {};
        c.players[selectedIndex()].override[key] = value;
      } else c[key] = value;
    }
    updateTactic(ui.team, c);
    if (
      el.type !== "range" ||
      (committed &&
        ["width", "depth", "centerX", "centerY", "angle"].includes(key))
    ) {
      renderPage();
    }
  } catch (err) {
    if (committed) {
      toast(errorMessage(err.message));
      renderPage();
    }
  }
}
document.addEventListener("keydown", (e) => {
  if(ground.active)return;
  if (e.target.closest("input,textarea,select") || $("#dialog").open) return;
  if ((e.key === "Enter" || e.code === "Space") && e.target.matches(".node")) {
    e.preventDefault(); e.target.dispatchEvent(new MouseEvent("click",{bubbles:true})); return;
  }
  if (e.code === "Space") {
    e.preventDefault();
    if (!ui.replayActive) {
      running = !running;
      send("run", { value: running });
      paintLive(true);
    }
  }
  if (e.key === "Enter" && e.target.matches(".node"))
    e.target.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  if (e.key === "Escape") $("#match-panel")?.classList.remove("fullscreen");
});
document.addEventListener("visibilitychange", () => {
  if(ground.active){if(document.hidden){ground.pause();ground.paint();}return;}
  if (document.hidden && running) {
    send("run", { value: false });
    running = false;
    ui.autoPaused = true;
  } else if (!document.hidden && ui.autoPaused) {
    ui.autoPaused = false;
    toast(
      L(
        "Paused while the tab was hidden. Press Play to continue.",
        "标签页隐藏时已暂停，点击继续即可恢复。",
      ),
    );
  }
});
async function boot() {
  try {
    const saved = JSON.parse(localStorage.getItem("flow.draft.v1") || "null");
    if (saved?.length === 2) tactics = saved.map(validateTactic);
  } catch {}
  presets = presets.filter((v) => {
    try {
      v.preset = validateTactic(v.preset);
      return true;
    } catch {
      return false;
    }
  });
  renderShell();
  worker = new Worker("./sim-worker.js", { type: "module" });
  worker.onmessage = ({ data: m }) => {
    if (m.type === "state") {
      state = { ...m.state, running: m.running };
      running = m.running;
      speed = m.speed;
      network.ingest(m.observations,m.epoch);
      if (renderer && !ui.replayActive && !ground.active && $("#pitch-host")) renderer.setState(state);
      paintLive();
      if (
        ui.autosaveReady &&
        state.time > 0 &&
        performance.now() - lastSave > 30000
      ) {
        lastSave = performance.now();
        saveCheckpoint(false).catch(() => {});
      }
    } else if (m.type === "result") {
      requests.get(m.id)?.resolve(m.data);
      requests.delete(m.id);
    } else if (m.type === "error") {
      requests.get(m.id)?.reject(Error(m.error));
      requests.delete(m.id);
      toast(errorMessage(m.error));
    }
  };
  worker.onerror = (e) => {
    console.error(e);
    toast(
      L(
        "The simulation could not start. Serve this package over HTTPS; opening index.html directly is not supported.",
        "仿真无法启动。请通过 HTTPS 部署此包，不支持直接双击 index.html。",
      ),
    );
  };
  send("new", { options: { seed: ui.seed, tactics: clone(tactics) } });
  try {
    const cp = await storage.get("checkpoint");
    ui.restoreAvailable = !!cp;
    ui.autosaveReady = !cp;
    if (cp && ui.page === "match") renderPage();
  } catch {
    ui.autosaveReady = true;
  }
}
boot();

let resizeTimer; window.addEventListener("resize",()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(ground.active){ground.paint();}else if(state)drawCharts(viewState());},120);});
