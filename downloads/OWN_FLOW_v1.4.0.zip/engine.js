import {normalizeControl,newControlMemory,sampleFilter,stepControl,isControlMemory} from "./control-kernel.js";
import {selectPlaybookReceiver} from "./passing-style.js";
import {defaultMission,validateMission,localMission,validMissionMemory} from './mission-core.js';
import {newJournal,journalEvent,monitorTick,validateJournal} from './task-monitor.js';
import {
  ENGINE_VERSION,
  validateAlgorithm,
  executeAlgorithm,
} from "./algorithm.js";
export { ENGINE_VERSION };
export const supportedEngine = value => [ENGINE_VERSION,"1.3.0","1.2.0","1.0.0"].includes(value);
export const DT = 1 / 30;
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const norm = (v) => Math.hypot(v.x, v.y),
  distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const limit = (v, m) => {
  const s = Math.min(1, m / (norm(v) || 1));
  return { x: v.x * s, y: v.y * s };
};
const clone = (x) => structuredClone(x);
export const FORMATIONS = {
  "5-3-2": [[-48,0],[-23,27],[-30,13],[-38,0],[-30,-13],[-23,-27],[-7,15],[-11,0],[-7,-15],[23,10],[23,-10]],
  "4-2-3-1": [
    [-48, 0],
    [-28, 25],
    [-30, 8],
    [-30, -8],
    [-28, -25],
    [-12, 11],
    [-12, -11],
    [7, 24],
    [10, 0],
    [7, -24],
    [26, 0],
  ],
  "4-3-3": [
    [-48, 0],
    [-28, 25],
    [-30, 8],
    [-30, -8],
    [-28, -25],
    [-13, 0],
    [0, 15],
    [0, -15],
    [21, 25],
    [28, 0],
    [21, -25],
  ],
  "3-5-2": [
    [-48, 0],
    [-28, 19],
    [-31, 0],
    [-28, -19],
    [-5, 28],
    [-11, 12],
    [-9, 0],
    [-11, -12],
    [-5, -28],
    [25, 9],
    [25, -9],
  ],
  "4-4-2": [
    [-48, 0],
    [-29, 25],
    [-31, 8],
    [-31, -8],
    [-29, -25],
    [-5, 25],
    [-8, 9],
    [-8, -9],
    [-5, -25],
    [25, 9],
    [25, -9],
  ],
};
export const ROLES = {
  "5-3-2": ["GK","LWB","CB","SW","CB","RWB","CM","DM","CM","ST","ST"],
  "4-2-3-1": ["GK", "LB", "CB", "CB", "RB", "DM", "DM", "LW", "AM", "RW", "ST"],
  "4-3-3": ["GK", "LB", "CB", "CB", "RB", "DM", "CM", "CM", "LW", "ST", "RW"],
  "3-5-2": ["GK", "CB", "CB", "CB", "LWB", "CM", "DM", "CM", "RWB", "ST", "ST"],
  "4-4-2": ["GK", "LB", "CB", "CB", "RB", "LM", "CM", "CM", "RM", "ST", "ST"],
};
export function graphEdges(type = "mesh") {
  if (type === "ring")
    return Array.from({ length: 11 }, (_, i) => [i, (i + 1) % 11]);
  if (type === "star")
    return Array.from({ length: 11 }, (_, i) => [5, i]).filter(
      (e) => e[0] !== e[1],
    );
  if (type === "full")
    return Array.from({ length: 11 }, (_, i) =>
      Array.from({ length: i }, (_, j) => [j, i]),
    ).flat();
  return [
    [0, 2],
    [0, 3],
    [1, 2],
    [2, 3],
    [3, 4],
    [1, 5],
    [2, 5],
    [3, 6],
    [4, 6],
    [5, 6],
    [5, 7],
    [5, 8],
    [6, 8],
    [6, 9],
    [7, 8],
    [8, 9],
    [7, 10],
    [8, 10],
    [9, 10],
  ];
}
export function graphHealth(edges, gamma = 0.1) {
  let seen = new Set([0]),
    change = true;
  while (change) {
    change = false;
    for (const [a, b] of edges) {
      if (seen.has(a) && !seen.has(b)) {
        seen.add(b);
        change = true;
      }
      if (seen.has(b) && !seen.has(a)) {
        seen.add(a);
        change = true;
      }
    }
  }
  const d = Array(11).fill(0);
  edges.forEach(([a, b]) => {
    d[a]++;
    d[b]++;
  });
  const max = Math.max(...d);
  return {
    connected: seen.size === 11,
    components: components(edges),
    maxDegree: max,
    bound: max ? 1 / max : 0,
    sufficient: seen.size === 11 && gamma > 0 && gamma < (max ? 1 / max : 0),
  };
}
function components(edges) {
  let visited = new Set(),
    count = 0;
  for (let i = 0; i < 11; i++) {
    if (visited.has(i)) continue;
    count++;
    let q = [i];
    visited.add(i);
    for (let a of q)
      for (let [b, c] of edges) {
        let v = a === b ? c : a === c ? b : -1;
        if (v >= 0 && !visited.has(v)) {
          visited.add(v);
          q.push(v);
        }
      }
  }
  return count;
}
const names = [
  "Avery",
  "Bennett",
  "Cameron",
  "Drew",
  "Ellis",
  "Finley",
  "Harper",
  "Jamie",
  "Kai",
  "Morgan",
  "Rowan",
];
export function defaultTactic(team = 0) {
  return {
    kind: "TacticPreset",
    schema: 1,
    engine: ENGINE_VERSION,
    id: team ? "coral-counter" : "blue-relational",
    name: team ? "Compact counter" : "Relational flow",
    teamName: team ? "CORAL FC" : "BLUE FC",
    color: team ? "#fc795f" : "#43a5ff",
    formation: team ? "4-4-2" : "4-2-3-1",
    width: 1,
    depth: 1,
    flow: 0.7,
    press: team ? 0.48 : 0.7,
    tempo: 0.55,
    centerX: 0,
    centerY: 0,
    angle: 0,
    kFormation: 0.7,
    kCentroid: 0.28,
    kSupport: 0.65,
    gamma: 0.12,
    compensator: "damping",
    compGain: 0.18,
    vision: 44,
    fov: 240,
    delay: 100,
    loss: 0,
    information: "all",
    tacticalEdges: graphEdges(),
    commEdges: graphEdges(),
    abilityMode: "seeded",
    abilitySeed: team ? 204 : 103,
    algorithm: null,
    passStyle: null,
    tracker: null,
    mission: defaultMission(),
    players: names.map((name, i) => ({
      name: team
        ? [
            "Alex",
            "Blake",
            "Casey",
            "Devon",
            "Emery",
            "Frankie",
            "Gray",
            "Hayden",
            "Jules",
            "Logan",
            "Reese",
          ][i]
        : name,
      speed: 7.4,
      acceleration: 4.2,
      skill: 0.8,
      stamina: 1,
      vision: 44,
      override: null,
    })),
    groups: [
      { name: "Back line", members: [1, 2, 3, 4], weight: 0.25, dx: 0, dy: 0 },
      { name: "Midfield", members: [5, 6, 8], weight: 0.2, dx: 0, dy: 0 },
      { name: "Left channel", members: [1, 5, 7], weight: 0.2, dx: 3, dy: 2 },
      { name: "Right channel", members: [4, 6, 9], weight: 0.2, dx: 3, dy: -2 },
    ],
  };
}
const ranges = {
  width: [0.65, 1.3],
  depth: [0.65, 1.3],
  flow: [0, 1.5],
  press: [0, 1],
  tempo: [0, 1],
  centerX: [-15, 15],
  centerY: [-10, 10],
  angle: [-30, 30],
  kFormation: [0, 2],
  kCentroid: [0, 1],
  kSupport: [0, 2],
  gamma: [0, 0.5],
  compGain: [0, 1],
  vision: [12, 70],
  fov: [60, 360],
  delay: [0, 1500],
  loss: [0, 0.8],
};
export function validateTactic(value) {
  if (!value || value.kind !== "TacticPreset" || value.schema !== 1)
    throw Error("tactic_schema");
  const x = clone(value),
    base = defaultTactic();
  if (
    typeof x.name !== "string" ||
    !x.name.trim() ||
    x.name.length > 80 ||
    typeof x.teamName !== "string" ||
    x.teamName.length > 32
  )
    throw Error("tactic_name");
  if (!FORMATIONS[x.formation] || !/^#[\da-f]{6}$/i.test(x.color || ""))
    throw Error("tactic_shape");
  for (let [k, [lo, hi]] of Object.entries(ranges))
    if (
      typeof x[k] !== "number" ||
      !Number.isFinite(x[k]) ||
      x[k] < lo ||
      x[k] > hi
    )
      throw Error("parameter_range");
  for (let key of ["tacticalEdges", "commEdges"]) {
    if (!Array.isArray(x[key]) || x[key].length > 55) throw Error("graph");
    let seen = new Set();
    for (let e of x[key]) {
      if (
        !Array.isArray(e) ||
        e.length !== 2 ||
        !e.every((n) => Number.isInteger(n) && n >= 0 && n < 11) ||
        e[0] === e[1]
      )
        throw Error("graph");
      let k = [...e].sort((a, b) => a - b).join("-");
      if (seen.has(k)) throw Error("graph");
      seen.add(k);
    }
  }
  if (
    !["none", "damping", "lowpass", "pi"].includes(x.compensator) ||
    !["all", "ball", "fresh"].includes(x.information) ||
    !["balanced", "seeded", "custom"].includes(x.abilityMode)
  )
    throw Error("tactic_mode");
  if (
    !Number.isInteger(x.abilitySeed) ||
    x.abilitySeed < 0 ||
    x.abilitySeed > 4294967295
  )
    throw Error("seed");
  if (!Array.isArray(x.players) || x.players.length !== 11)
    throw Error("players");
  x.players = x.players.map((p) => {
    if (typeof p.name !== "string" || !p.name.trim() || p.name.length > 32)
      throw Error("player_name");
    for (let [k, a, b] of [
      ["speed", 3, 10],
      ["acceleration", 1, 7],
      ["skill", 0.25, 1],
      ["stamina", 0.5, 1],
      ["vision", 12, 70],
    ])
      if (!Number.isFinite(p[k]) || p[k] < a || p[k] > b)
        throw Error("player_ability");
    if (p.override !== null && p.override !== undefined) {
      for (let [k, v] of Object.entries(p.override))
        if (
          !["kFormation", "kCentroid", "kSupport"].includes(k) ||
          !Number.isFinite(v) ||
          v < 0 ||
          v > 2
        )
          throw Error("override");
    }
    if (p.appearance != null) {
      const {heightCm,build,skinTone}=p.appearance;
      if (!Number.isFinite(heightCm) || heightCm<145 || heightCm>215 ||
          !Number.isFinite(build) || build<.85 || build>1.2 ||
          !Number.isInteger(skinTone) || skinTone<0 || skinTone>4) throw Error("player_ability");
      p.appearance={heightCm,build,skinTone};
    }
    return p;
  });
  if (!Array.isArray(x.groups) || x.groups.length > 12) throw Error("groups");
  x.groups.forEach((g) => {
    if (
      typeof g.name !== "string" ||
      !g.name.trim() ||
      g.name.length > 40 ||
      !Array.isArray(g.members) ||
      g.members.length < 1 ||
      g.members.length > 11 ||
      new Set(g.members).size !== g.members.length ||
      !g.members.every((n) => Number.isInteger(n) && n >= 0 && n < 11) ||
      !Number.isFinite(g.weight) ||
      g.weight < 0 ||
      g.weight > 1 ||
      !Number.isFinite(g.dx) ||
      Math.abs(g.dx) > 15 ||
      !Number.isFinite(g.dy) ||
      Math.abs(g.dy) > 15
    )
      throw Error("groups");
  });
  if (x.passStyle != null && !["triangles","transition","press","wingbacks","libero"].includes(x.passStyle)) throw Error("tactic_mode");
  if (x.tracker != null) {
    if(x.tracker.dt!==.1)throw Error("parameter_range");
    x.tracker=normalizeControl(x.tracker);
  }
  x.engine=ENGINE_VERSION;
  x.mission=validateMission(x.mission);
  if (x.algorithm) x.algorithm = validateAlgorithm(x.algorithm).config;
  return Object.fromEntries(Object.keys(base).map((k) => [k, x[k] ?? base[k]]));
}
class Random {
  constructor(seed) {
    this.s = seed >>> 0 || 1;
  }
  next() {
    let x = this.s;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.s = x >>> 0;
    return this.s / 4294967296;
  }
  signed() {
    return this.next() * 2 - 1;
  }
}
// Resolve the abilities used by both the match and the formation experiment.
export function resolveSquad(tactic) {
  const rng=new Random(tactic.abilitySeed);
  return tactic.players.map(player=>{
    const result={...player};
    if(tactic.abilityMode==="seeded"){
      result.speed=clamp(7.2+rng.signed()*.9,3,10);
      result.acceleration=clamp(4.2+rng.signed()*.65,1,7);
      result.skill=clamp(.78+rng.signed()*.13,.25,1);
    } else if(tactic.abilityMode==="balanced"){
      Object.assign(result,{speed:7.4,acceleration:4.2,skill:.8});
    }
    if(tactic.abilityMode!=="custom")result.vision=tactic.vision;
    return result;
  });
}

function roleTrackerOutput(player,axis,target,config) {
  player.trackMemory ??= {};
  const position=player[axis];
  const state=player.trackMemory[axis] ??= {
    reference:target,measurement:position,controller:newControlMemory(position)
  };
  state.reference=sampleFilter(state.reference,target,config.refTau,.1);
  state.measurement=sampleFilter(state.measurement,position,config.sensorTau,.1);
  const error=state.reference+config.sign*state.measurement;
  return stepControl(config,state.controller,{error,measurement:state.measurement,
    virtualReference:state.measurement+error}).u;
}
export class MatchEngine {
  constructor({
    seed = 361,
    tactics,
    minutes = 90,
    mode = "match",
    clockRate = 6,
  } = {}) {
    this.tactics = (tactics || [defaultTactic(0), defaultTactic(1)]).map(
      validateTactic,
    );
    this.compiled = this.tactics.map((t) =>
      t.algorithm ? validateAlgorithm(t.algorithm) : null,
    );
    this.seed = seed >>> 0;
    this.rng = new Random(this.seed);
    this.tick = 0;
    this.time = 0;
    this.minutes = minutes;
    this.clockRate = clockRate;
    this.mode = mode;
    this.half = 1;
    this.score = [0, 0];
    this.phase = "kickoff";
    this.phaseUntil = 1.8;
    this.restartTeam = 0;
    this.lastTouch = -1;
    this.pass = null;
    this.eventId = 0;
    this.events = [];
    this.queue = [];
    this.history = [];
    this.lastHistory = -1;
    this.predictions = [];
    this.lastPrediction = -1;
    this.measurements = [];
    this.stats = [this.newStats(), this.newStats()];
    this.players = [];
    this.journal = newJournal();
    this.ball = {
      x: 0,
      y: 0,
      z: 0.11,
      vx: 0,
      vy: 0,
      vz: 0,
      spin: 0,
      owner: -1,
    };
    this.pendingOffside = [];
    this.resetPositions(0);
    this.addEvent("kickoff", 0);
    if (mode !== "match") {
      this.phase = "live";
      for (let p of this.players) {
        p.x += this.rng.signed() * 8;
        p.y += this.rng.signed() * 7;
      }
      this.ball.x = 0;
      this.ball.y = 0;
    }
  }
  newStats() {
    return {
      possession: 0,
      passes: 0,
      completed: 0,
      shots: 0,
      saves: 0,
      tackles: 0,
      sent: 0,
      received: 0,
      dropped: 0,
      effort: 0,
      saturation: 0,
      samples: 0,
      shape: 0,
      estimation: 0,
      prediction: 0,
      predictionN: 0,
    };
  }
  dir(team) {
    return (team === 0 ? 1 : -1) * (this.half === 1 ? 1 : -1);
  }
  resetPositions(team) {
    this.queue = [];
    this.pass = null;
    this.pendingOffside = [];
    for (let t = 0; t < 2; t++) {
      const cfg = this.tactics[t],
        roster = resolveSquad(cfg),
        d = this.dir(t);
      for (let i = 0; i < 11; i++) {
        const id = t * 11 + i,
          base = FORMATIONS[cfg.formation][i],
          old = this.players[id],
          attr = cfg.players[i];
        const {skill,speed,acceleration:acc}=roster[i];
        const x = (this.mode === "match" ? Math.min(base[0], -2) : base[0]) * d,
          y = base[1] * d;
        this.players[id] = {
          id,
          team: t,
          index: i,
          name: attr.name,
          role: ROLES[cfg.formation][i],
          x,
          y,
          vx: 0,
          vy: 0,
          heading: d > 0 ? 0 : Math.PI,
          stamina: old?.stamina ?? attr.stamina,
          speed,
          acc,
          skill,
          vision: cfg.abilityMode === "custom" ? attr.vision : cfg.vision,
          action: "idle",
          actionUntil: 0,
          cooldown: 0,
          estimate: { x, y },
          prev: { x, y },
          knownBall: null,
          visible: [],
          inbox: [],
          memory: [],
          neighbors: {},
          command: { x: 0, y: 0 },
          raw: { x: 0, y: 0 },
          target: { x, y },
          reference: { x: 0, y: 0 },
          integral: { x: 0, y: 0 },
          filter: { x: 0, y: 0 },
          algoMemory: { x: 0, y: 0 },
          parts: {},
          trail: [],
          prediction: [],
          belief: { mode: "unknown", evidence: 0, meanY: 0 },
          saturated: false,
          individual: old?.individual || {
            passes: 0,
            completed: 0,
            shots: 0,
            goals: 0,
            tackles: 0,
            saves: 0,
            distance: 0,
            effort: 0,
            saturation: 0,
            samples: 0,
          },
        };
      }
    }
    if (this.mode === "match") {
      const p = this.players[team * 11 + 10];
      p.x = -this.dir(team) * 0.8;
      p.y = 0;
    }
    this.ball = {
      x: 0,
      y: 0,
      z: 0.11,
      vx: 0,
      vy: 0,
      vz: 0,
      spin: 0,
      owner: -1,
    };
    this.lastTouch = -1;
  }
  setTactic(team, value) {
    const previous=this.tactics[team].tracker;
    this.tactics[team] = validateTactic(value);
    journalEvent(this,'policy_edit',team,-1,{policy:structuredClone(this.tactics[team].mission)});
    const changed=JSON.stringify(previous)!==JSON.stringify(this.tactics[team].tracker);
    const roster=resolveSquad(this.tactics[team]);
    this.compiled[team] = value.algorithm
      ? validateAlgorithm(value.algorithm)
      : null;
    for (let p of this.players.filter((p) => p.team === team)) {
      const c = this.tactics[team],
        a = c.players[p.index];
      p.name = a.name;
      p.role = ROLES[c.formation][p.index];
      p.vision = c.abilityMode === "custom" ? a.vision : c.vision;
      Object.assign(p,{speed:roster[p.index].speed,acc:roster[p.index].acceleration,skill:roster[p.index].skill});
      if(changed)delete p.trackMemory;
    }
  }
  addEvent(type, team = -1, player = -1, extra = {}) {
    journalEvent(this,'football',team,player,{event:type,detail:extra});
    this.events.unshift({
      id: ++this.eventId,
      type,
      team,
      player,
      time: this.time,
      clock: this.time * this.clockRate,
      ...extra,
    });
    if (this.events.length > 200) this.events.length = 200;
  }
  sense() {
    const now = this.time;
    let arrived = this.queue.filter((m) => m.arrival <= now);
    this.queue = this.queue.filter((m) => m.arrival > now);
    for (let m of arrived) {
      const p = this.players[m.to];
      p.inbox.push(m);
      if (p.inbox.length > 20) p.inbox.shift();
      if (m.type === "state")
        p.neighbors[m.from] = {
          x: m.x,
          y: m.y,
          ex: m.ex,
          ey: m.ey,
          time: m.time,
          mission:m.mission??null,
        };
      this.stats[p.team].received++;
      if (
        m.ball &&
        now - m.ball.time < 2 &&
        (!p.knownBall || m.ball.time > p.knownBall.time)
      ) {
        p.knownBall = {
          ...m.ball,
          source: m.ball.source,
          relay: m.from,
          via: "message",
        };
      }
    }
    for (let p of this.players) {
      const c = this.tactics[p.team];
      p.visible = [];
      const seen = (q) => {
        let dx = q.x - p.x,
          dy = q.y - p.y,
          len = Math.hypot(dx, dy);
        if (len > p.vision) return false;
        const a = Math.atan2(dy, dx) - p.heading;
        return len < 5 || Math.cos(a) >= Math.cos((c.fov * Math.PI) / 360);
      };
      for (let q of this.players) {
        if (p.id === q.id || !seen(q)) continue;
        const len = distance(p, q);
        let blocked = this.players.some(
          (o) =>
            o.id !== p.id &&
            o.id !== q.id &&
            distance(p, o) < len &&
            Math.abs((q.x - p.x) * (o.y - p.y) - (q.y - p.y) * (o.x - p.x)) /
              (len || 1) <
              0.42 &&
            (o.x - p.x) * (q.x - p.x) + (o.y - p.y) * (q.y - p.y) > 0,
        );
        if (!blocked)
          p.visible.push({
            id: q.id,
            team: q.team,
            x: q.x,
            y: q.y,
            vx: q.vx,
            vy: q.vy,
            time: now,
          });
      }
      if (seen(this.ball))
        p.knownBall = {
          x: this.ball.x,
          y: this.ball.y,
          vx: this.ball.vx,
          vy: this.ball.vy,
          owner: this.ball.owner,
          time: now,
          source: p.id,
          via: "vision",
        };
      if (p.knownBall && now - p.knownBall.time > 4) p.knownBall = null;
      const opp = p.visible.filter((v) => v.team !== p.team);
      if (opp.length >= 3) {
        const my = opp.reduce((s, q) => s + q.y, 0) / opp.length;
        p.belief = {
          mode: my > 7 ? "left" : my < -7 ? "right" : "central",
          evidence: opp.length,
          meanY: my,
        };
      } else p.belief = { mode: "unknown", evidence: opp.length, meanY: 0 };
    }
  }
  communicate() {
    for (let t = 0; t < 2; t++) {
      const cfg = this.tactics[t];
      for (let [a, b] of cfg.commEdges)
        for (let [from, to] of [
          [a, b],
          [b, a],
        ]) {
          const p = this.players[t * 11 + from];
          this.stats[t].sent++;
          if (this.rng.next() < cfg.loss) {
            this.stats[t].dropped++;
            continue;
          }
          let ball =
            p.knownBall && this.time - p.knownBall.time < 2
              ? { ...p.knownBall }
              : null;
          if (cfg.information === "fresh" && ball && ball.source !== p.id)
            ball = null;
          this.queue.push({
            id: `${p.id}:${this.tick}:${to}`,
            from: p.id,
            to: t * 11 + to,
            time: this.time,
            arrival: this.time + cfg.delay / 1000,
            ...(cfg.information === "ball"
              ? {}
              : { ex: p.estimate.x, ey: p.estimate.y, x: p.x, y: p.y }),
            ball,
            ttl: ball ? Math.max(0, 2 - (this.time - ball.time)) : 0,
            type: cfg.information === "ball" ? "ball" : "state",
            ...(cfg.information==='ball'?{}:{mission:p.mission?{state:p.mission.state,target:{...p.target},since:p.mission.enteredAt}:null}),
          });
        }
    }
    if (this.queue.length > 10000)
      this.queue.splice(0, this.queue.length - 10000);
  }
  control() {
    this.sense();
    const oldEst = this.players.map((p) => ({ ...p.estimate }));
    for (let p of this.players) {
      let c = this.tactics[p.team],
        d = this.dir(p.team),
        b = p.knownBall,
        known = b && this.time - b.time < 3,
        neighbors = Object.entries(p.neighbors)
          .filter(
            ([id, n]) =>
              this.time - n.time < 2.5 &&
              c.commEdges.some(
                ([i, j]) =>
                  (i === p.index && j === Number(id) % 11) ||
                  (j === p.index && i === Number(id) % 11),
              ),
          )
          .map(([id, n]) => ({ ...n, id: Number(id) }));
      const cfg = { ...c, ...(c.players[p.index].override || {}) };
      // Diagnostic evidence captured at the controller's own sample time.
      // It is never read by the dynamics or controller.
      const trace = {
        time:this.time, position:{x:p.x,y:p.y}, velocity:{x:p.vx,y:p.vy},
        estimateBefore:{...oldEst[p.id]}, displacement:{x:p.x-p.prev.x,y:p.y-p.prev.y},
        observerInputs:c.information==='ball'?[]:neighbors.map(n=>({
          from:n.id, age:this.time-n.time, estimate:{x:n.ex,y:n.ey},
          correction:{x:c.gamma*(n.ex-oldEst[p.id].x),y:c.gamma*(n.ey-oldEst[p.id].y)}
        })), relations:[]
      };
      let ex = 0,
        ey = 0;
      if (c.information !== "ball")
        for (let n of neighbors) {
          ex += n.ex - oldEst[p.id].x;
          ey += n.ey - oldEst[p.id].y;
        }
      p.estimate.x = clamp(
        oldEst[p.id].x + p.x - p.prev.x + c.gamma * ex,
        -100,
        100,
      );
      p.estimate.y = clamp(
        oldEst[p.id].y + p.y - p.prev.y + c.gamma * ey,
        -80,
        80,
      );
      trace.estimateAfter={...p.estimate};
      p.prev = { x: p.x, y: p.y };
      const attacking =
          known && b.owner >= 0 && Math.floor(b.owner / 11) === p.team,
        defending = known && b.owner >= 0 && !attacking;
      let cx = c.centerX * d,
        cy = c.centerY;
      if (this.mode === "match" && known) {
        cx +=
          clamp(b.x * 0.28, -13, 13) * c.flow +
          (attacking ? 8 : -4) * d * c.flow;
        cy += clamp(b.y * 0.28, -8, 8) * c.flow;
      }
      if (this.mode === "moving") {
        cx += Math.sin(this.time * 0.08) * 13;
        cy += Math.sin(this.time * 0.06) * 8;
      }
      p.reference = { x: cx, y: cy };
      const base = FORMATIONS[c.formation][p.index],
        ang = (c.angle * Math.PI) / 180,
        rot = (r) => ({
          x:
            (r[0] * c.depth * Math.cos(ang) - r[1] * c.width * Math.sin(ang)) *
            d,
          y:
            (r[0] * c.depth * Math.sin(ang) + r[1] * c.width * Math.cos(ang)) *
            d,
        });
      let r = rot(base);
      const meanR = FORMATIONS[c.formation]
        .map(rot)
        .reduce((a, v) => ({ x: a.x + v.x / 11, y: a.y + v.y / 11 }), {
          x: 0,
          y: 0,
        });
      p.reference = { x: cx + meanR.x, y: cy + meanR.y };
      p.target = { x: clamp(cx + r.x, -49, 49), y: clamp(cy + r.y, -31, 31) };
      p.formationTarget={...p.target};
      const missionActive=this.mode==='match'&&p.index!==0&&c.mission.enabled;
      if(missionActive){
        const localPlayer={...p,neighbors:c.information==='ball'?{}:Object.fromEntries(neighbors.map(n=>[n.id,n]))};
        const result=localMission(localPlayer,c.mission,p.target,this.time,d,this.phase);
        p.mission=result.mission;p.target={...result.mission.target};
        if(result.transition)journalEvent(this,'mission',p.team,p.id,result.transition);
      } else if(p.mission)delete p.mission;
      const formation = { x: 0, y: 0 };
      let degree = 0;
      for (let [a, j] of c.tacticalEdges) {
        let other = a === p.index ? j : j === p.index ? a : -1;
        if (other < 0) continue;
        let v =
          p.visible.find((v) => v.id === p.team * 11 + other) ||
          neighbors.find((v) => v.id === p.team * 11 + other);
        if (!v) continue;
        let nr = rot(FORMATIONS[c.formation][other]);
        trace.relations.push({from:v.id, source:p.visible.some(q=>q.id===v.id)?'vision':'message',
          age:p.visible.some(q=>q.id===v.id)?0:this.time-v.time,
          observed:{x:v.x,y:v.y},offset:{x:nr.x-r.x,y:nr.y-r.y},
          error:{x:v.x-p.x-(nr.x-r.x),y:v.y-p.y-(nr.y-r.y)}});
        formation.x += v.x - p.x - (nr.x - r.x);
        formation.y += v.y - p.y - (nr.y - r.y);
        degree++;
      }
      if (c.tracker) {
        const correctionX=roleTrackerOutput(p,"x",p.target.x,c.tracker);
        const correctionY=roleTrackerOutput(p,"y",p.target.y,c.tracker);
        formation.x=.7*cfg.kFormation*formation.x/Math.max(1,degree)+.3*correctionX;
        formation.y=.7*cfg.kFormation*formation.y/Math.max(1,degree)+.3*correctionY;
      } else {
        formation.x=cfg.kFormation*((formation.x/Math.max(1,degree))*.7+(p.target.x-p.x)*.3);
        formation.y=cfg.kFormation*((formation.y/Math.max(1,degree))*.7+(p.target.y-p.y)*.3);
      }
      const centroid = {
          x: cfg.kCentroid * (p.reference.x - p.estimate.x),
          y: cfg.kCentroid * (p.reference.y - p.estimate.y),
        },
        support = { x: 0, y: 0 },
        group = { x: 0, y: 0 };
      if(missionActive){
        formation.x*=c.mission.shapeWeight;formation.y*=c.mission.shapeWeight;
        centroid.x*=c.mission.shapeWeight;centroid.y*=c.mission.shapeWeight;
      }
      if (this.mode === "match" && known) {
        const mate = p.visible.filter(
          (q) => q.team === p.team && q.id % 11 !== 0,
        );
        let myDist = distance(p, b),
          better = mate.filter((q) => distance(q, b) < myDist - 1.5).length;
        let chaser =
          p.index !== 0 && better <= (defending && c.press > 0.75 ? 1 : 0);
        if(missionActive){
          // Mission reference replaces the legacy chase branch. Formation coupling
          // still uses nominal role offsets, never hidden neighbour mission targets.
        } else if (b.owner === p.id) {
          support.x = d * p.speed * 0.8;
          support.y = clamp(-p.y * 0.2, -2, 2);
          formation.x *= 0.2;
          formation.y *= 0.2;
          centroid.x *= 0.2;
          centroid.y *= 0.2;
        } else if (chaser) {
          let pursuit = {
            x: (b.x + b.vx * 0.3 - p.x) * 1.7,
            y: (b.y + b.vy * 0.3 - p.y) * 1.7,
          };
          Object.assign(
            support,
            limit(pursuit, p.speed * (defending ? 0.75 + c.press * 0.25 : 1)),
          );
          formation.x *= 0.15;
          formation.y *= 0.15;
          centroid.x *= 0.2;
          centroid.y *= 0.2;
        } else if (attacking) {
          support.x = d * (1.6 + c.flow) * (0.6 + p.index / 15);
          support.y = clamp((b.y * 0.4 - p.y) * 0.08, -1.5, 1.5);
        } else if (defending) {
          support.x = -d * c.press * 0.5;
          support.y = clamp((b.y - p.y) * 0.07, -1.5, 1.5);
        }
        if (p.index === 0) {
          p.target = {
            x: -d * (48.8 - (attacking ? 2 : 0)),
            y: clamp(
              b.vx * d < -4
                ? b.y + b.vy * clamp((-d * 48.8 - b.x) / b.vx, 0, 2)
                : b.y * 0.45,
              -3.2,
              3.2,
            ),
          };
          formation.x = (p.target.x - p.x) * 2;
          formation.y = (p.target.y - p.y) * 2;
          centroid.x = centroid.y = support.x = support.y = 0;
        }
      }
      support.x *= cfg.kSupport * 1.4;
      support.y *= cfg.kSupport * 1.4;
      const groups = c.groups.filter((g) => g.members.includes(p.index));
      const weight = Math.max(
        1,
        groups.reduce((s, g) => s + g.weight, 0),
      );
      for (let g of groups) {
        group.x += (g.weight * g.dx * d) / weight;
        group.y += (g.weight * g.dy) / weight;
      }
      const avoidance = { x: 0, y: 0 };
      for (let q of p.visible) {
        let dx = p.x - q.x,
          dy = p.y - q.y,
          len = Math.hypot(dx, dy);
        if (len < 1.5 && len > 0.01) {
          let m = (1.5 - len) * 2;
          avoidance.x += (dx / len) * m;
          avoidance.y += (dy / len) * m;
        }
      }
      const comp = { x: 0, y: 0 };
      const mission={x:0,y:0};
      if(missionActive){
        mission.x=c.mission.taskGain*(p.target.x-p.x);
        mission.y=c.mission.taskGain*(p.target.y-p.y);
      }
      if (c.compensator === "damping") {
        comp.x = -c.compGain * p.vx;
        comp.y = -c.compGain * p.vy;
      }
      if (c.compensator === "pi") {
        p.integral.x = clamp(p.integral.x + (p.target.x - p.x) * 0.1, -4, 4);
        p.integral.y = clamp(p.integral.y + (p.target.y - p.y) * 0.1, -4, 4);
        comp.x = p.integral.x * c.compGain;
        comp.y = p.integral.y * c.compGain;
      }
      let sum = {
        x:
          formation.x + centroid.x + support.x + group.x + avoidance.x + comp.x + mission.x,
        y:
          formation.y + centroid.y + support.y + group.y + avoidance.y + comp.y + mission.y,
      };
      if (c.compensator === "lowpass") {
        const alpha = clamp(1 - c.compGain, 0.05, 1);
        p.filter.x += alpha * (sum.x - p.filter.x);
        p.filter.y += alpha * (sum.y - p.filter.y);
        comp.x = p.filter.x - sum.x;
        comp.y = p.filter.y - sum.y;
        sum = { ...p.filter };
      }
      let algorithm = { x: 0, y: 0 };
      if (this.compiled[p.team]) {
        const a = executeAlgorithm(this.compiled[p.team], {
          self: p,
          base: sum,
          target: p.target,
          centroid: p.estimate,
          reference: p.reference,
          ball: known
            ? { ...b, known: 1 }
            : { x: p.x, y: p.y, vx: 0, vy: 0, known: 0 },
          time: this.time,
          memory: p.algoMemory,
        });
        const blend = c.algorithm.blend;
        algorithm.x = blend * (a.x - sum.x);
        algorithm.y = blend * (a.y - sum.y);
        sum.x += algorithm.x;
        sum.y += algorithm.y;
        p.algoMemory = a;
      }
      p.parts = {
        formation,
        centroid,
        support,
        group,
        avoidance,
        compensator: comp,
        algorithm,
        mission,
      };
      trace.target={...p.target};
      trace.reference={...p.reference};
      trace.parts=clone(p.parts);
      trace.raw={...sum};
      p.controlTrace=trace;
      p.raw = sum;
      p.command = limit(sum, p.speed * (0.65 + 0.35 * p.stamina));
      p.saturated = norm(sum) > norm(p.command) + 0.01;
      trace.command={...p.command};
      trace.saturated=p.saturated;
      if (
        this.mode === "match" &&
        p.index === 0 &&
        known &&
        Math.abs(b.x) > 39 &&
        b.vx * d < -4 &&
        Math.abs(b.y) < 6
      ) {
        p.action = "save";
        p.actionUntil = this.time + 0.55;
      }
      p.prediction = [];
      let px = p.x,
        py = p.y,
        vx = p.vx,
        vy = p.vy;
      for (let j = 1; j <= 20; j++) {
        let delta = limit(
          { x: p.command.x - vx, y: p.command.y - vy },
          p.acc * 0.1,
        );
        vx += delta.x;
        vy += delta.y;
        px = clamp(px + vx * 0.1, -52, 52);
        py = clamp(py + vy * 0.1, -33.5, 33.5);
        p.prediction.push({ x: px, y: py, t: j * 0.1 });
      }
    }
    if (this.tick % 6 === 0) this.communicate();
  }
  movePlayers() {
    for (let p of this.players) {
      const dv = limit(
        { x: p.command.x - p.vx, y: p.command.y - p.vy },
        p.acc * DT,
      );
      p.vx += dv.x;
      p.vy += dv.y;
      p.x = clamp(p.x + p.vx * DT, -52, 52);
      p.y = clamp(p.y + p.vy * DT, -33.6, 33.6);
      const sp = Math.hypot(p.vx, p.vy);
      if (sp > 0.25) {
        let da = Math.atan2(p.vy, p.vx) - p.heading;
        da = Math.atan2(Math.sin(da), Math.cos(da));
        p.heading += clamp(da, -4.2 * DT, 4.2 * DT);
      }
      if (p.actionUntil < this.time)
        p.action = sp > 5 ? "sprint" : sp > 0.4 ? "run" : "idle";
      p.stamina = clamp(p.stamina + DT * (sp > 5 ? -0.0003 : 0.00012), 0.4, 1);
      p.cooldown = Math.max(0, p.cooldown - DT);
      p.individual.distance += sp * DT;
      p.individual.effort += norm(p.command) ** 2 * DT;
      p.individual.samples++;
      p.individual.saturation += p.saturated ? 1 : 0;
    }
    // Contact separation is symmetric. This is physical contact, not a sensing channel.
    for (let i = 0; i < 22; i++)
      for (let j = i + 1; j < 22; j++) {
        let a = this.players[i],
          b = this.players[j],
          dx = a.x - b.x,
          dy = a.y - b.y,
          len = Math.hypot(dx, dy);
        if (len < 0.68) {
          let ux = len > 0.001 ? dx / len : 1,
            uy = len > 0.001 ? dy / len : 0,
            shift = (0.68 - len) * 0.5;
          a.x = clamp(a.x + ux * shift, -52, 52);
          a.y = clamp(a.y + uy * shift, -33.6, 33.6);
          b.x = clamp(b.x - ux * shift, -52, 52);
          b.y = clamp(b.y - uy * shift, -33.6, 33.6);
        }
      }
  }
  kick(p, target, speed, type = "pass", loft = 0) {
    let dx = target.x - this.ball.x,
      dy = target.y - this.ball.y,
      len = Math.hypot(dx, dy) || 1,
      err = (1 - p.skill) * this.rng.signed() * (type === "shot" ? 0.18 : 0.1),
      angle = Math.atan2(dy, dx) + err;
    this.ball.vx = Math.cos(angle) * speed;
    this.ball.vy = Math.sin(angle) * speed;
    this.ball.vz = loft;
    this.ball.owner = -1;
    p.cooldown = 0.6;
    p.action = type === "shot" ? "shoot" : "pass";
    p.actionUntil = this.time + 0.55;
    this.lastTouch = p.id;
    if (type === "pass") {
      this.stats[p.team].passes++;
      p.individual.passes++;
      this.pass = { from: p.id, time: this.time };
      const d = this.dir(p.team),
        def = this.players
          .filter((q) => q.team !== p.team)
          .map((q) => q.x * d)
          .sort((a, b) => b - a),
        line = Math.max(def[1], this.ball.x * d, 0);
      this.pendingOffside = this.players
        .filter(
          (q) => q.team === p.team && q.id !== p.id && q.x * d > line + 0.15,
        )
        .map((q) => q.id);
      this.addEvent("pass", p.team, p.id);
    } else {
      this.stats[p.team].shots++;
      p.individual.shots++;
      this.pass = null;
      this.pendingOffside = [];
      this.addEvent("shot", p.team, p.id);
    }
  }
  football() {
    const b = this.ball;
    let owner = b.owner >= 0 ? this.players[b.owner] : null;
    if (owner && distance(owner, b) > 2.1) {
      b.owner = -1;
      owner = null;
    }
    if (owner) {
      const p = owner,
        d = this.dir(p.team),
        c = this.tactics[p.team];
      this.stats[p.team].possession += DT;
      // A dribble is a repeated impulse toward a point in front of the foot.
      const tx = p.x + Math.cos(p.heading) * 0.65,
        ty = p.y + Math.sin(p.heading) * 0.65;
      b.vx += (tx - b.x) * 18 * DT + (p.vx - b.vx) * 5 * DT;
      b.vy += (ty - b.y) * 18 * DT + (p.vy - b.vy) * 5 * DT;
      if (p.cooldown <= 0) {
        let goalDist = 52.5 - p.x * d,
          near = p.visible
            .filter((q) => q.team !== p.team)
            .sort((a, b) => distance(p, a) - distance(p, b))[0],
          pressure = near ? distance(p, near) : 99;
        if (goalDist < 24 && Math.abs(p.y) < 20 && p.index !== 0) {
          const target = {
            x: d * 54,
            y: this.rng.signed() * (3.7 + goalDist * 0.09 + (1 - p.skill) * 4),
          };
          this.kick(p, target, 23 + p.skill * 8, "shot", this.rng.next() * 3.5);
        } else {
          let candidates = p.visible
            .filter(
              (q) =>
                q.team === p.team &&
                q.id !== p.id &&
                distance(p, q) > 5 &&
                distance(p, q) < 36 &&
                q.id % 11 !== 0,
            )
            .map((q) => {
              let clearance = 15;
              for (let o of p.visible.filter((o) => o.team !== p.team)) {
                clearance = Math.min(clearance, distance(q, o));
              }
              return {
                ...q,
                value:
                  (q.x - p.x) * d * 0.45 +
                  Math.min(clearance, 12) * 1.5 -
                  distance(p, q) * 0.12,
              };
            })
            .sort((a, b) => b.value - a.value);
          const receiver = c.passStyle ? selectPlaybookReceiver(c.passStyle,p,d) : candidates[0],
            wait = 1.3 + (1 - c.tempo) * 3;
          if (
            receiver &&
            (pressure < 3.5 ||
              p.index === 0 ||
              this.time - (p.lastCarry || 0) > wait)
          ) {
            let len = distance(p, receiver),
              speed = clamp(11 + len * 0.3, 13, 23),
              flight = len / speed;
            this.kick(
              p,
              {
                x: receiver.x + receiver.vx * flight * 0.55,
                y: receiver.y + receiver.vy * flight * 0.55,
              },
              speed,
              "pass",
              len > 25 ? 2.2 : 0.5,
            );
          }
        }
      }
    }
    b.x += b.vx * DT;
    b.y += b.vy * DT;
    b.z += b.vz * DT;
    b.vz -= 9.81 * DT;
    if (b.z < 0.11) {
      b.z = 0.11;
      if (b.vz < -0.7) b.vz = -b.vz * 0.36;
      else b.vz = 0;
    }
    const drag = b.z > 0.15 ? 0.996 : 0.986;
    b.vx *= drag;
    b.vy *= drag;
    b.spin += (Math.hypot(b.vx, b.vy) * DT) / 0.11;
    // Posts and crossbar can deflect shots before the goal-line decision.
    for (let gx of [-52.5, 52.5])
      for (let gy of [-3.66, 3.66]) {
        const dd = Math.hypot(b.x - gx, b.y - gy);
        if (dd < 0.18 && b.z < 2.5) {
          let nx = (b.x - gx) / (dd || 1),
            ny = (b.y - gy) / (dd || 1),
            v = b.vx * nx + b.vy * ny;
          b.vx -= 1.7 * v * nx;
          b.vy -= 1.7 * v * ny;
          b.x = gx + nx * 0.19;
          b.y = gy + ny * 0.19;
        }
      }
    if (
      Math.abs(Math.abs(b.x) - 52.5) < 0.2 &&
      Math.abs(b.y) < 3.7 &&
      Math.abs(b.z - 2.44) < 0.17
    ) {
      b.vx *= -0.65;
      b.vz *= -0.6;
    }
    for (let p of this.players) {
      if (p.cooldown > 0) continue;
      const len = distance(p, b),
        keeper = p.index === 0 && Math.abs(p.x) > 36,
        catchRange = keeper ? (p.action === "save" ? 2.0 : 1.35) : 0.95;
      if (len > catchRange || b.z > (keeper ? 2.45 : 1.15)) continue;
      if (b.owner === p.id) continue;
      if (b.owner >= 0) {
        let q = this.players[b.owner];
        if (
          q.team === p.team ||
          len > 0.85 ||
          this.rng.next() > 0.04 + p.skill * 0.04
        )
          continue;
        this.stats[p.team].tackles++;
        p.individual.tackles++;
        p.action = "tackle";
        p.actionUntil = this.time + 0.45;
        this.addEvent("tackle", p.team, p.id);
      }
      if (
        this.pendingOffside.includes(p.id) &&
        this.pass &&
        this.players[this.pass.from].team === p.team
      ) {
        this.restart("offside", 1 - p.team, { x: p.x, y: p.y });
        return;
      }
      const speed = Math.hypot(b.vx, b.vy);
      if (!keeper && speed > 19 && this.rng.next() > p.skill * 0.45) {
        b.vx *= 0.65;
        b.vy *= 0.65;
        this.lastTouch = p.id;
        continue;
      }
      if (keeper && speed > 12) {
        this.stats[p.team].saves++;
        p.individual.saves++;
        p.action = "save";
        p.actionUntil = this.time + 0.65;
        this.addEvent("save", p.team, p.id);
      }
      if (this.pass) {
        let from = this.players[this.pass.from];
        if (from.team === p.team && from.id !== p.id) {
          this.stats[p.team].completed++;
          from.individual.completed++;
        }
        this.pass = null;
      }
      this.pendingOffside = [];
      b.owner = p.id;
      b.vx = p.vx * 0.7;
      b.vy = p.vy * 0.7;
      b.vz = 0;
      b.z = 0.11;
      p.lastCarry = this.time;
      p.cooldown = keeper ? 0.9 : 0.4;
      this.lastTouch = p.id;
      break;
    }
    if (Math.abs(b.x) > 52.65) {
      let end = Math.sign(b.x),
        defTeam = this.dir(0) === end ? 1 : 0;
      if (Math.abs(b.y) < 3.66 && b.z < 2.44) {
        let scoring = 1 - defTeam;
        this.score[scoring]++;
        if (
          this.lastTouch >= 0 &&
          this.players[this.lastTouch].team === scoring
        )
          this.players[this.lastTouch].individual.goals++;
        this.addEvent("goal", scoring, this.lastTouch, {
          ownGoal:
            this.lastTouch >= 0 &&
            this.players[this.lastTouch].team !== scoring,
        });
        this.phase = "goal";
        this.phaseUntil = this.time + 3;
        this.restartTeam = defTeam;
        b.owner = -1;
        b.vx *= 0.1;
        b.vy *= 0.1;
        b.x = end * 53.4;
      } else if (
        this.lastTouch >= 0 &&
        this.players[this.lastTouch].team === defTeam
      )
        this.restart("corner", 1 - defTeam, {
          x: end * 51.8,
          y: Math.sign(b.y || 1) * 33.4,
        });
      else this.restart("goalKick", defTeam, { x: end * 46, y: 0 });
    } else if (Math.abs(b.y) > 34.15)
      this.restart(
        "throwIn",
        this.lastTouch >= 0 ? 1 - this.players[this.lastTouch].team : 0,
        { x: clamp(b.x, -49, 49), y: Math.sign(b.y) * 33.2 },
      );
  }
  restart(type, team, point) {
    this.addEvent(type, team);
    this.phase = "restart";
    this.phaseUntil = this.time + 1.5;
    this.restartTeam = team;
    this.ball = {
      ...this.ball,
      x: point.x,
      y: point.y,
      z: 0.11,
      vx: 0,
      vy: 0,
      vz: 0,
      owner: -1,
    };
    let p = this.players
      .filter((p) => p.team === team)
      .sort((a, b) => distance(a, point) - distance(b, point))[0];
    p.x = point.x - this.dir(team) * 0.4;
    p.y = point.y;
    p.vx = p.vy = 0;
    p.cooldown = 0.2;
    this.lastTouch = p.id;
    this.restartPlayer = p.id;
    this.pass = null;
    this.pendingOffside = [];
  }
  suspendMissions(){
    for(const p of this.players){const m=p.mission;if(!m||m.rule==='public_stop')continue;
      const from=m.state,evidence={...m.evidence,localPhase:'stopped',handoffPending:false};
      p.mission={...m,state:'hold',rule:'public_stop',pending:'hold',pendingRule:'public_stop',pendingSince:this.time,enteredAt:this.time,sampleTime:this.time,evidence,transitions:m.transitions+(from==='hold'?0:1)};
      if(from!=='hold')journalEvent(this,'mission',p.team,p.id,{from,to:'hold',rule:'public_stop',evidence,revision:m.revision,duration:this.time-m.enteredAt,target:{...p.target}});
    }
  }
  step() {
    if (this.phase === "finished") return;
    this.tick++;
    this.time = this.tick * DT;
    if (this.mode === "match") {
      let clock = this.time * this.clockRate;
      if (clock >= this.minutes * 60) {
        this.phase = "finished";
        this.addEvent("fulltime");
        this.suspendMissions();
        monitorTick(this);
        return;
      }
      if (this.half === 1 && clock >= this.minutes * 30) {
        this.half = 2;
        this.phase = "halftime";
        this.phaseUntil = this.time + 3;
        this.resetPositions(1);
        this.restartTeam = 1;
        this.addEvent("halftime");
      }
      if (this.phase !== "live") {
        this.suspendMissions();
        if (this.time >= this.phaseUntil) {
          if (this.phase === "goal") this.resetPositions(this.restartTeam);
          let id =
            this.phase === "restart"
              ? this.restartPlayer
              : this.restartTeam * 11 + 10;
          this.ball.owner = id;
          this.lastTouch = id;
          this.players[id].lastCarry = this.time;
          this.phase = "live";
        }
        this.sample();
        monitorTick(this);
        return;
      }
    }
    if (this.tick % 3 === 0) this.control();
    this.movePlayers();
    if (this.mode === "match") this.football();
    if(this.phase!=='live')this.suspendMissions();
    monitorTick(this);
    this.sample();
  }
  sample() {
    if (this.tick % 15 !== 0) return;
    let metrics = [];
    for (let t = 0; t < 2; t++) {
      const ps = this.players.filter((p) => p.team === t),
        cp = {
          x: ps.reduce((s, p) => s + p.x, 0) / 11,
          y: ps.reduce((s, p) => s + p.y, 0) / 11,
        };
      let shape = 0,
        est = 0,
        effort = 0,
        sat = 0,
        disagree = 0;
      const meanEst = {
        x: ps.reduce((s, p) => s + p.estimate.x, 0) / 11,
        y: ps.reduce((s, p) => s + p.estimate.y, 0) / 11,
      };
      for (let p of ps) {
        shape += distance(p, p.target) ** 2;
        est += distance(p.estimate, cp) ** 2;
        effort += norm(p.command) ** 2;
        sat += p.saturated ? 1 : 0;
        disagree += distance(p.estimate, meanEst) ** 2;
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > 30) p.trail.shift();
      }
      const row = {
        shape: Math.sqrt(shape / 11),
        estimation: Math.sqrt(est / 11),
        disagreement: Math.sqrt(disagree / 11),
        effort: effort / 11,
        saturation: sat / 11,
        centroid: cp,
        reference: ps[5].reference,
      };
      metrics.push(row);
      let s = this.stats[t];
      s.shape += row.shape;
      s.estimation += row.estimation;
      s.effort += row.effort;
      s.saturation += row.saturation;
      s.samples++;
    }
    this.metrics = metrics;
    this.measurements.push({ time: this.time, teams: clone(metrics) });
    if (this.measurements.length > 600) this.measurements.shift();
    // Forecasts are frozen before outcomes exist, then scored two physical seconds later.
    for (let pred of this.predictions.filter((q) => this.time - q.time >= 2)) {
      for (let i = 0; i < 22; i++) {
        let p = this.players[i];
        this.stats[p.team].prediction += distance(p, pred.positions[i]);
        this.stats[p.team].predictionN++;
      }
    }
    this.predictions = this.predictions.filter((q) => this.time - q.time < 2);
    if (this.tick % 60 === 0)
      this.predictions.push({
        time: this.time,
        positions: this.players.map(
          (p) => p.prediction.at(-1) || { x: p.x, y: p.y },
        ),
      });
    this.history.push({
      minutes: this.minutes,
      clockRate: this.clockRate,
      queued: this.queue.length,
      tactics: clone(this.tactics),
      time: this.time,
      tick: this.tick,
      clock: this.time * this.clockRate,
      half: this.half,
      phase: this.phase,
      score: [...this.score],
      metrics: clone(this.metrics),
      stats: clone(this.stats),
      ball: clone(this.ball),
      players: this.players.map((p) => ({
        id: p.id,
        team: p.team,
        index: p.index,
        name: p.name,
        role: p.role,
        x: p.x,
        y: p.y,
        vx: p.vx,
        vy: p.vy,
        heading: p.heading,
        action: p.action,
        estimate: clone(p.estimate),
        target: clone(p.target),
        formationTarget:clone(p.formationTarget??p.target),
        mission:clone(p.mission??null),
        reference: clone(p.reference),
        command: clone(p.command),
        raw: clone(p.raw),
        parts: clone(p.parts),
        visible: p.visible.map((q) => ({ id: q.id, team: q.team })),
        knownBall: clone(p.knownBall),
        prediction: clone(p.prediction),
        stamina: p.stamina,
        vision: p.vision,
        speed: p.speed,
        acc: p.acc,
        skill: p.skill,
        belief: clone(p.belief),
        saturated: p.saturated,
        trail: clone(p.trail),
      })),
    });
    if (this.history.length > 360) this.history.shift();
  }
  snapshot() {
    return {
      engine: ENGINE_VERSION,
      seed: this.seed,
      mode: this.mode,
      time: this.time,
      tick: this.tick,
      clock: this.time * this.clockRate,
      minutes: this.minutes,
      clockRate: this.clockRate,
      half: this.half,
      phase: this.phase,
      score: this.score,
      ball: this.ball,
      players: this.players,
      metrics: this.metrics || [],
      stats: this.stats,
      events: this.events.slice(0, 30),
      tactics: this.tactics,
      queued: this.queue.length,
      measurements: this.measurements.slice(-120),
      missionAnalysis:{phase:this.journal.phase,episode:this.journal.episode,latest:this.journal.latest,
        teams:this.journal.teams,events:this.journal.events.slice(-60),totalEvents:this.journal.totalEvents,droppedEvents:this.journal.droppedEvents},
    };
  }
  checkpoint() {
    return {
      kind: "MatchCheckpoint",
      schema: 1,
      engine: ENGINE_VERSION,
      seed: this.seed,
      rng: this.rng.s,
      ...Object.fromEntries(
        [
          "tactics",
          "tick",
          "time",
          "minutes",
          "clockRate",
          "mode",
          "half",
          "score",
          "phase",
          "phaseUntil",
          "restartTeam",
          "restartPlayer",
          "lastTouch",
          "pass",
          "eventId",
          "events",
          "queue",
          "predictions",
          "stats",
          "players",
          "ball",
          "pendingOffside",
          "metrics",
          "measurements",
          "journal",
        ].map((k) => [k, clone(this[k] ?? null)]),
      ),
    };
  }
  static restore(c) {
    if (
      !c ||
      c.kind !== "MatchCheckpoint" ||
      c.schema !== 1 ||
      !supportedEngine(c.engine) ||
      !Array.isArray(c.players) ||
      c.players.length !== 22 ||
      !Array.isArray(c.tactics) ||
      c.tactics.length !== 2
    )
      throw Error("checkpoint_schema");
    if (
      !Number.isInteger(c.tick) ||
      c.tick < 0 ||
      c.tick > 500000 ||
      !Number.isFinite(c.time) ||
      Math.abs(c.time - c.tick * DT) > 0.001 ||
      !["match", "formation", "moving"].includes(c.mode) ||
      ![1, 2].includes(c.half) ||
      !["kickoff", "live", "goal", "restart", "halftime", "finished"].includes(
        c.phase,
      ) ||
      !Number.isFinite(c.minutes) ||
      c.minutes < 1 ||
      c.minutes > 180 ||
      !Number.isFinite(c.clockRate) ||
      c.clockRate < 1 ||
      c.clockRate > 30
    )
      throw Error("checkpoint_state");
    function finiteTree(x, depth = 0) {
      if (depth > 20) throw Error("checkpoint_state");
      if (typeof x === "number" && !Number.isFinite(x))
        throw Error("checkpoint_state");
      if (x && typeof x === "object") {
        if (Array.isArray(x) && x.length > 10000)
          throw Error("checkpoint_state");
        for (let v of Object.values(x)) finiteTree(v, depth + 1);
      }
    }
    finiteTree(c);
    if(c.journal!=null)validateJournal(c.journal,c.time,c.tick);
    for (let [i, p] of c.players.entries())
      if (
        p.id !== i ||
        p.team !== Math.floor(i / 11) ||
        p.index !== i % 11 ||
        !Number.isFinite(p.x) ||
        !Number.isFinite(p.y) ||
        Math.abs(p.x) > 60 ||
        Math.abs(p.y) > 40 ||
        !p.command ||
        !p.parts ||
        !p.neighbors ||
        !p.estimate ||
        !p.prev ||
        !Array.isArray(p.prediction) ||
        !Array.isArray(p.inbox) ||
        !p.individual
      )
        throw Error("checkpoint_player");
    if (
      !c.ball ||
      !Number.isFinite(c.ball.x) ||
      !Number.isFinite(c.ball.y) ||
      Math.abs(c.ball.x) > 100 ||
      Math.abs(c.ball.y) > 100 ||
      !Number.isInteger(c.ball.owner) ||
      c.ball.owner < -1 ||
      c.ball.owner > 21 ||
      !Array.isArray(c.queue) ||
      !Array.isArray(c.stats) ||
      c.stats.length !== 2
    )
      throw Error("checkpoint_state");
    const numeric = (x, keys) =>
      keys.every((k) => typeof x?.[k] === "number" && Number.isFinite(x[k]));
    const vec = (x) => numeric(x, ["x", "y"]);
    if (
      !Number.isInteger(c.rng) ||
      !Number.isInteger(c.seed) ||
      !Array.isArray(c.score) ||
      c.score.length !== 2 ||
      !c.score.every((v) => Number.isInteger(v) && v >= 0 && v < 10000) ||
      !Number.isFinite(c.phaseUntil) ||
      !Number.isInteger(c.eventId) ||
      !Array.isArray(c.events) ||
      !Array.isArray(c.measurements) ||
      !Array.isArray(c.predictions) ||
      !Array.isArray(c.pendingOffside)
    )
      throw Error("checkpoint_state");
    for (let p of c.players) {
      if(p.mission&&!validMissionMemory(p.mission,c.time))throw Error('checkpoint_player');
      if (
        !numeric(p, [
          "vx",
          "vy",
          "heading",
          "stamina",
          "speed",
          "acc",
          "skill",
          "vision",
          "cooldown",
          "actionUntil",
        ]) ||
        ![
          "estimate",
          "prev",
          "command",
          "raw",
          "target",
          "reference",
          "integral",
          "filter",
          "algoMemory",
        ].every((k) => vec(p[k])) ||
        !Array.isArray(p.visible) ||
        !Array.isArray(p.trail) ||
        typeof p.name !== "string" ||
        !["idle", "run", "sprint", "pass", "shoot", "save", "tackle"].includes(
          p.action,
        ) ||
        typeof p.parts !== "object" ||
        !Object.values(p.parts).every(vec) ||
        !p.belief ||
        !["unknown", "left", "right", "central"].includes(p.belief.mode) ||
        !numeric(p.individual, [
          "passes",
          "completed",
          "shots",
          "goals",
          "tackles",
          "saves",
          "distance",
          "effort",
          "saturation",
          "samples",
        ])
      )
        throw Error("checkpoint_player");
      if (
        p.knownBall &&
        !numeric(p.knownBall, ["x", "y", "vx", "vy", "owner", "time", "source"])
      )
        throw Error("checkpoint_player");
      for (let n of Object.values(p.neighbors))
        if (!numeric(n, ["x", "y", "ex", "ey", "time"]))
          throw Error("checkpoint_player");
      for (let v of p.visible)
        if (
          !numeric(v, ["x", "y", "vx", "vy", "time", "team", "id"]) ||
          v.id < 0 ||
          v.id > 21
        )
          throw Error("checkpoint_player");
      for (let v of p.prediction)
        if (!numeric(v, ["x", "y", "t"])) throw Error("checkpoint_player");
    }
    const validPacket = (m) =>
      numeric(m, ["from", "to", "time", "arrival"]) &&
      ["ball", "state"].includes(m.type) &&
      (m.type === "ball" || numeric(m, ["ex", "ey", "x", "y"])) &&
      Number.isInteger(m.to) &&
      m.to >= 0 &&
      m.to < 22 &&
      Number.isInteger(m.from) &&
      m.from >= 0 &&
      m.from < 22 &&
      (!m.ball ||
        numeric(m.ball, ["x", "y", "vx", "vy", "owner", "time", "source"]));
    if (
      !c.queue.every(validPacket) ||
      !c.players.every((p) => p.inbox.every(validPacket)) ||
      !numeric(c.ball, ["x", "y", "z", "vx", "vy", "vz", "spin", "owner"]) ||
      !c.stats.every((st) =>
        numeric(st, [
          "possession",
          "passes",
          "completed",
          "shots",
          "saves",
          "tackles",
          "sent",
          "received",
          "dropped",
          "effort",
          "saturation",
          "samples",
          "shape",
          "estimation",
          "prediction",
          "predictionN",
        ]),
      )
    )
      throw Error("checkpoint_state");
    const validMetrics = (rows) =>
      Array.isArray(rows) &&
      rows.length === 2 &&
      rows.every(
        (m) =>
          numeric(m, [
            "shape",
            "estimation",
            "disagreement",
            "effort",
            "saturation",
          ]) &&
          vec(m.centroid) &&
          vec(m.reference),
      );
    if (c.metrics !== null && !validMetrics(c.metrics))
      throw Error("checkpoint_state");
    if (
      !c.measurements.every(
        (m) => Number.isFinite(m.time) && validMetrics(m.teams),
      ) ||
      !c.predictions.every(
        (p) =>
          Number.isFinite(p.time) &&
          Array.isArray(p.positions) &&
          p.positions.length === 22 &&
          p.positions.every(vec),
      ) ||
      !c.pendingOffside.every((i) => Number.isInteger(i) && i >= 0 && i < 22) ||
      !c.events.every(
        (e) =>
          numeric(e, ["time", "clock", "id", "team", "player"]) &&
          [-1, 0, 1].includes(e.team) &&
          Number.isInteger(e.player) &&
          e.player >= -1 &&
          e.player < 22 &&
          [
            "kickoff",
            "pass",
            "shot",
            "tackle",
            "save",
            "goal",
            "throwIn",
            "corner",
            "goalKick",
            "offside",
            "halftime",
            "fulltime",
          ].includes(e.type),
      ) ||
      (c.pass && !numeric(c.pass, ["from", "time"]))
    )
      throw Error("checkpoint_state");
    if (
      c.players.some(
        (p) =>
          p.speed < 0 ||
          p.speed > 10 ||
          p.acc < 0 ||
          p.acc > 7 ||
          !p.trail.every(vec),
      )
    )
      throw Error("checkpoint_player");
    for(const player of c.players){
      if(player.trackMemory != null){
        for(const axis of ["x","y"]){
          const trace=player.trackMemory[axis];
          if(!trace || !numeric(trace,["reference","measurement"]) ||
             !isControlMemory(trace.controller))throw Error("checkpoint_player");
        }
      }
    }
    const e = new MatchEngine({
      seed: c.seed,
      tactics: c.tactics,
      minutes: c.minutes,
      mode: c.mode,
      clockRate: c.clockRate,
    });
    for (let k of Object.keys(e.checkpoint()))
      if (
        !["kind", "schema", "engine", "rng", "tactics"].includes(k) &&
        Object.hasOwn(c, k)
      )
        e[k] = clone(c[k]);
    e.rng.s = c.rng >>> 0;
    if(c.journal==null){e.journal=newJournal();e.journal.lastTime=e.time;e.journal.lastTick=e.tick;}
    e.compiled = e.tactics.map((t) =>
      t.algorithm ? validateAlgorithm(t.algorithm) : null,
    );
    e.history = [];
    return e;
  }
}
