# Mission policies, stage-conditioned identification and task evidence

OWN / FLOW 1.4.0 · 2026-11-11

## Scope and research connection

This is an executable, heuristic football control laboratory. It is not a formal proof engine or a calibrated football outcome predictor. Two views are intentionally separated:

- Each agent executes its policy using its own state, current vision and fresh state messages on configured links. The coach broadcasts settings, not privileged instantaneous world state.
- The analyst observes the physical world to measure execution, mark possession stages and record events. These measurements never enter the player controller.

The architecture follows the Information → Mission → Control separation discussed in the supplied *mission planning fusion control(1).pdf*. It is instantiated per agent: local evidence selects a mission state, the state constructs a reference, and the existing controller executes it. This is an implementation inspired by that architecture, not a verbatim reproduction or a formal verification of its guarantees.

The supplied *Football_Task_Study_v4.pdf* changes how a structural diagnosis should be interpreted. All ten fixed-target candidates admitted joint trajectories after broader search. The external screening of 6,653 starts produced 3,114 joint paths, 2,989 cases excluding at least one individual duty, 525 invalid cases and 25 undetermined/other cases; there were no certified individually feasible but jointly infeasible cases. The app therefore reports observed gaps, fixed-window misses and uncertainty. It never upgrades a failed optimizer or a geometric gap to an unavoidable structural conflict. Moving-target, reaction and acceleration assumptions matter; a frozen-target optimistic travel time is only a scoped reference quantity.

The earlier theory audit also motivated explicit distance/own-motion baselines and restraint when interpreting structural features. Fitted associations are not observed communication or proof of a tactical advantage.

## Executed mission states

| State | Local reference / purpose | Preconditions |
|---|---|---|
| Hold | Nominal formation reference | Fallback or explicit rule |
| Collect | Short prediction of locally known free ball | Known free ball and eligible local seeker by default |
| Press | Short prediction of locally known opposing possession | Opponent possession; default candidate within activation distance |
| Screen | 42–54% point on a locally visible ball-to-outlet segment | Opponent possession and a visible outlet |
| Cover | Goal-side region behind locally known ball | Opponent possession |
| Recover | Nominal role reference | Missing evidence or excess displacement by default |
| Support | Nominal role target shifted forward and toward ball | Own-team possession |
| Carry | Ten metres forward from self, softened lateral target | Self possession |

Default rules are evaluated in priority order. Players can reorder, add, disable or remove rules and edit the output state. Rules use a fixed, explicit guard vocabulary; arbitrary temporal-logic specifications are not executed. An execution precondition prevents a user rule from assigning carry without possession, screen without a visible lane or a defensive task during attack.

Local elections rank observed outfield peers. Role preferences bias the ranking; they are not a global exclusive assignment solver. Inconsistent or stale observations may produce duplicate assignments. The duty graph displays what was assigned, while geometric metrics independently assess readiness.

A candidate guard must persist for `guardDwell`, and the current state must remain for `minDwell`. Loss of critical evidence or possession can bypass residence. Recovery has an exit threshold at 75% of its entry threshold. Dead-ball signals suspend active tasks and record `public_stop` once. Goalkeepers retain specialized control.

## Handoffs and information admissibility

An incumbent cover player retains the duty until a fresh state packet reports a different teammate in cover state within the configured cover radius, or the defensive task ends. Vision alone is not an ACK. Ball-only mode and removed communication edges cannot provide cached state ACKs. Future-dated packets, opponents and keepers do not qualify.

This is a local observed-readiness protocol. The packet records the sender's earlier position; it cannot guarantee the replacement is still there at the instant of release. The live analyst coverage, message age, candidate ID, ACK sender and recorded guard values make that limitation inspectable. Packet delays can cause overlap or delayed handoffs. No global deadlock-free or exclusive-allocation guarantee is claimed.

## Coupling to the controller and consensus

The mission reference becomes the real `p.target`. Its proportional tracking term is added to the command. `shapeWeight` scales the existing formation and centroid terms; nominal relative offsets remain the basis of formation coupling. The conventional ball-chase branch is bypassed for active mission-controlled outfield players. Unit offsets, avoidance, compensation, an installed role tracker, custom algorithm blending, speed and acceleration limits still execute.

Consequently, assigned mission, issued velocity, limited command and actual movement can differ. Signed command components reconstruct the raw command. Agreement of formation errors is measured separately from tracking accuracy: every player can share the same offset while the team remains away from its references.

Control Ground remains the place for exact nominal transfer functions, internal poles and homogeneous network-mode tests for P, PID, first-order LADRC and constrained finite-horizon MPC. The switched, constrained football mission system does not have one universally valid transfer function, and no match-wide stability certificate is inferred from a Ground result.

## Physical stages and identification

The analyst marks gained possession and lost possession for three physical seconds after a change of owning team, then settled attack or defense. Ownerless ball is `loose`; non-live play is `stopped`. A teammate-to-teammate ownership change does not restart the team transition clock. These are reproducible possession heuristics, not a learned football phase classifier.

Motion is sampled at 5 Hz. Identification rejects intervals spanning a stage segment, restart, half, configuration epoch, time gap or large position jump. A stage filter can select gain, loss, attack, defense or loose-ball intervals. Different fragments are never joined by an invented finite difference. At least 40 valid intervals are required.

Training uses the first 70% of valid intervals, skips one interval, and validates on later intervals. This is chronological interval holdout, not leave-one-match or leave-one-episode-out validation. Targets are supplied by the simulator. Unmeasured shared causes, switching, saturation, correlation and low excitation can still invalidate causal interpretations. All prior rank, conditioning and held-out-gain gates remain active.

## Measurement definitions

Control and task aggregates use physical 30 Hz samples, not scoreboard seconds. Control RMS uses the ten outfield agents, with separate active-reference error, nominal formation error and mean-offset disagreement. Speed saturation is a fraction of outfield samples. Width and depth describe observed team extent; compactness is a design preference, not an independent optimality score.

Defensive tasks are declared geometric proxies:

- Pressure: at least one outfield player within the declared ball radius.
- Cover: at least one outfield player within the declared goal-side cover region.
- Joint: two distinct agents can simultaneously be assigned pressure and cover, including when both are eligible for both duties.
- Lane readiness: proximity to up to two declared ball-to-outlet line segments. This omits arrival direction, reaction dynamics and ball interception timing; it is not an interception certificate.
- Attack support: at least two teammates between 5 and 22 m of the ball.

Pressure, cover and joint ratios use defensive physical time. Lane readiness uses the number of eligible lanes times physical time. Support uses own-possession time. A missing denominator displays `—`, never zero success. Conditional ratios in two A/B branches can have different denominators. Active-reference RMS also changes meaning when a policy changes the reference; compare nominal formation, tasks and football outcomes together.

An ownership window begins at observed possession, ends at release, ownership change or stoppage, and freezes its pressure deadline and pressure radius. A successful pressure confirmation requires 0.2 s of consecutive sampled proximity. An edit cannot reset an existing window or erase a missed deadline. Subsequent success leaves an earlier miss recorded. These are tick-sampled observations, not a proof of continuous-time contact between samples.

## Events, reports and reproducibility

The ledger records sequence, physical time, tick, scoreboard clock, team/player, ownership-window ID, policy revision, trigger evidence and a physical scene snapshot. Policy edits include exact settings. A live page displays the latest 60 events; exports retain the latest 2,400 and explicitly report omitted counts. Aggregates retain the full monitored history even after old event entries are omitted. A full checkpoint also stores local mission memories, in-flight state packets, deadlines, RNG state and the journal.

HTML reports contain phase tables, six recent significant scene snapshots, chronological event rows and policy settings. JSON preserves full guard records and retained snapshots. `node maintenance/reproduce-mission.mjs path/to/OWN_FLOW_Mission_Evidence.json` checks timestamps, event continuity, scene completeness and reproduces summary tables. That verifies internal report consistency, not the truth of a third-party imported data set. `node maintenance/reproduce-network.mjs evidence.json` reproduces phase-filtered motion fits.

A/B forks start with identical positions, local memories, queued messages, deadlines and RNG states. Only the chosen team's mechanism is changed. Different future actions may consume different random draws. The three-pair t intervals are descriptive small-sample evidence, not a general ranking. Mission-off, cover-first, early-pressure and lane-screen interventions are available in match mode. A copied mission preset is treated as one whole-policy intervention, not as a one-scalar causal ablation.

## Deliberate remaining limits

No continuous-time temporal-logic solver, global assignment guarantee, formal multi-duty infeasibility certificate, learned phase recognition or real-player calibration is implemented. Attack protection and pass-lane metrics are simplified proxies. Long runs require periodic report exports if a complete event archive is needed. Native phone touch and hardware WebGL performance require device testing; the delivered browser checks use a narrow iframe and software Canvas rendering.
