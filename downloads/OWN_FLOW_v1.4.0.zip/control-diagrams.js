const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const defs=`<defs><marker id="signal-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#a6dccb"/></marker><marker id="info-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#6db9ea"/></marker></defs>`;
function block(x,y,w,key,title,sub,symbol,active){return `<g class="schematic-node node ${active===key?'selected':''}" role="button" tabindex="0" data-action="block" data-block="${key}" aria-label="${esc(title)}"><rect x="${x}" y="${y}" width="${w}" height="68" rx="10"/><text class="diagram-symbol" x="${x+14}" y="${y+23}">${symbol}</text><text class="diagram-label" x="${x+14}" y="${y+44}">${esc(title)}</text><text class="diagram-sub" x="${x+14}" y="${y+59}">${esc(sub)}</text></g>`;}
const wire=(d,info=false)=>`<path class="${info?'info-wire':'signal-wire'}" d="${d}" marker-end="url(#${info?'info':'signal'}-arrow)"/>`;
const label=(x,y,text)=>`<text class="wire-label" x="${x}" y="${y}">${text}</text>`;
export function closedLoop({lang='en',selected=7,active='controller',compensator='damping',algorithm=null,mission=null}={}) {
  const L=(a,b)=>lang==='zh'?b:a,i=selected%11+1;
  const mode={none:L('Identity','直通'),damping:L('Velocity damping','速度阻尼'),pi:L('Bounded integral','有界积分'),lowpass:L('Low-pass memory','低通记忆')}[compensator];
  return `<div class="diagram-caption"><span class="eyebrow">${L('EXECUTABLE LOCAL LOOP','实际执行的局部闭环')}</span><span>${L('Agent','球员')} #${String(i).padStart(2,'0')} · ${L('click a block to trace its signals','点击模块追踪信号')}</span></div><div class="schematic-scroll"><svg class="loop-diagram" viewBox="0 0 1080 470" role="group" aria-label="${L('Closed-loop feedback control diagram','闭环反馈控制框图')}">${defs}
  <rect class="agent-boundary" x="244" y="35" width="798" height="416" rx="18"/>
  ${label(260,23,L('AUTONOMOUS AGENT  ·  private observer and controller memory','自主智能体 · 独立观测器与控制器记忆'))}
  ${block(18,70,152,'reference',mission?.enabled?L('Mission reference','任务参考'):L('Reference','参考生成器'),mission?.enabled?L('local rules → state','局部规则 → 任务状态'):L('coach + local evidence','教练配置＋局部证据'),'qʳ',active)}
  <circle class="sum-junction" cx="211" cy="104" r="19"/><text class="sum-symbol" x="204" y="110">Σ</text>${label(181,94,'+')}${label(218,137,'−')}
  ${block(266,70,172,'controller',L('Controller','控制器'),L('relations + task + units','关系＋任务＋子系统'),'Cᵢ',active)}
  ${block(486,70,172,'compensator',L('Compensator','补偿器'),mode,'Kᵢ',active)}
  ${block(706,70,302,'algorithm',L('Custom controller blend','自定义控制器融合'),algorithm?esc(algorithm.name.slice(0,32)):L('Identity · no custom algorithm','直通 · 未安装自定义算法'),'Fᵢ',active)}
  ${wire('M170 104H190')}${wire('M230 104H266')}${label(234,91,'eᵢ')}${wire('M438 104H486')}${label(444,91,'u₀')}${wire('M658 104H706')}${label(662,91,'u<tspan baseline-shift="sub" font-size="75%">K</tspan>')}
  ${block(820,233,188,'actuator',L('Actuator limits','执行器约束'),L('speed saturation','速度限幅'),'sat(·)',active)}
  ${block(520,233,214,'motion',L('Plant · player dynamics','被控对象 · 球员动力学'),L('acceleration + contact','加速度＋接触约束'),'Pᵢ',active)}
  ${block(266,233,172,'observation',L('Feedback / sensing','反馈与感知'),L('self + visible evidence','自身状态＋可见证据'),'Hᵢ',active)}
  ${wire('M914 138V233')}${label(927,187,'u<tspan baseline-shift="sub" font-size="75%">des</tspan>')}${wire('M820 267H734')}${label(754,254,'uᵢ')}${wire('M520 267H438')}${label(452,254,'pᵢ, vᵢ')}
  ${wire('M266 267H211V123')}${label(80,258,L('position feedback','位置反馈'))}${label(88,277,'pᵢ')}
  ${block(266,366,216,'observer',L('Distributed observer','分布式观测器'),L('local centroid estimate','局部球队中心估计'),'ĉᵢ',active)}
  ${wire('M352 301V366',true)}${label(360,338,'Δpᵢ')}${wire('M482 400H494V170H352V138',true)}${label(470,192,'ĉᵢ')}
  ${compensator==='pi'?wire('M248 104V156H634V138',true)+label(594,151,'eᵢ'):''}
  ${compensator==='damping'?wire('M400 233V208H580V138',true)+label(551,222,'vᵢ'):''}
  <rect class="packet-block" x="20" y="365" width="180" height="68" rx="10"/><text class="diagram-label" x="34" y="392">${L('Neighbor messages','邻居消息')}</text><text class="diagram-sub" x="34" y="413">${L('delay · loss · timestamp','延迟 · 丢包 · 时间戳')}</text>${wire('M200 400H266',true)}
  <path class="disturbance-wire" d="M628 366V301" marker-end="url(#signal-arrow)"/>${label(538,389,L('Ball · opponents · contact','足球 · 对手 · 接触'))}
  ${label(540,415,L('Shared physical world couples all 22 plants.','共享物理世界耦合全部 22 个被控对象。'))}
  </svg></div><div class="diagram-legend"><span><i class="legend-line"></i>${L('physical / control signal','物理／控制信号')}</span><span><i class="legend-line info"></i>${L('local information','局部信息')}</span><span>${L('Negative feedback: e = reference − position. This is one controller input.','负反馈：误差＝参考−位置，是控制器的一个输入。')}</span></div>`;
}
export function networkArchitecture({lang='en',tactic,selected=7}={}) {
  const L=(a,b)=>lang==='zh'?b:a,coords=Array.from({length:11},(_,i)=>[70+(i%4)*270,270+Math.floor(i/4)*118]);
  const links=tactic.commEdges.map(([a,b])=>{const p=coords[a],q=coords[b];return `<path class="network-coupling ${[a,b].includes(selected%11)?'highlight':''}" d="M${p[0]+72} ${p[1]+38}L${q[0]+72} ${q[1]+38}"/>`;}).join('');
  return `<div class="diagram-caption"><span class="eyebrow">${L('TEAM SYSTEM OF SYSTEMS','球队：由独立子系统组成的系统')}</span><span>${tactic.commEdges.length} ${L('communication edges','条通信边')} · 11 ${L('local loops','个局部闭环')}</span></div><div class="schematic-scroll"><svg class="network-architecture" viewBox="0 0 1080 690" role="group" aria-label="${L('Multi-agent network and coordinator','多智能体网络与协调器')}">
  <rect class="coordinator" x="260" y="14" width="560" height="82" rx="12"/><text class="diagram-symbol" x="284" y="40">${L('COACH / COORDINATOR','教练／协调器')}</text><text class="diagram-label" x="284" y="64">${L('Formation · reference policy · role and subsystem templates','阵型 · 参考策略 · 角色与子系统模板')}</text><text class="diagram-sub" x="284" y="83">${L('Configuration broadcast; each agent computes its own command.','下发配置；每名球员独立计算运动指令。')}</text>
  <path class="config-bus" d="M540 96V125H145V205M540 125H955V205M415 125V205M685 125V205"/>
  ${tactic.groups.slice(0,4).map((g,k)=>`<rect class="subsystem-box" x="${30+k*270}" y="150" width="210" height="58" rx="9"/><text class="diagram-label" x="${44+k*270}" y="173">${esc(g.name.slice(0,24))}</text><text class="diagram-sub" x="${44+k*270}" y="194">${g.members.slice(0,4).map(i=>'#'+(i+1)).join(' · ')+(g.members.length>4?' +'+(g.members.length-4):'')} · w=${g.weight.toFixed(2)}</text>`).join('')}
  <text class="diagram-sub" x="32" y="237">${L('Overlapping units contribute weighted local corrections. All configured units execute; four shown above.','子系统可重叠，以权重叠加局部修正。所有已配置子系统均执行，上方展示前四个。')}</text>
  <path class="config-bus" d="M145 208V245H955V208M415 208V245M685 208V245M145 245V270M415 245V270M685 245V270M955 245V270"/>
  <rect class="agent-boundary" x="22" y="250" width="1036" height="355" rx="16"/>${links}
  ${coords.map(([x,y],i)=>`<g class="agent-loop node ${i===selected%11?'selected':''}" tabindex="0" role="button" aria-label="${L('Inspect agent','检查球员')} ${i+1}" data-action="player" data-id="${Math.floor(selected/11)*11+i}"><rect x="${x-30}" y="${y}" width="206" height="78" rx="9"/><text class="diagram-label" x="${x-16}" y="${y+23}">#${String(i+1).padStart(2,'0')} ${esc(tactic.players[i].name)}</text><text class="diagram-symbol" x="${x-16}" y="${y+47}">${tactic.mission?.enabled?'M → C → K → P':'C → K → P'}</text><text class="diagram-sub" x="${x-16}" y="${y+66}">← H · ${L('private state','独立状态')} ↲</text></g>`).join('')}
  <rect class="world-block" x="22" y="632" width="1036" height="44" rx="10"/><text class="diagram-label" x="48" y="660">${L('SHARED WORLD  ·  22 dynamic players + one ball + contact constraints','共享环境 · 22 个动态球员＋独立足球＋接触约束')}</text><path class="config-bus" d="M540 605V632"/>
  </svg></div><div class="diagram-legend"><span><i class="legend-line info"></i>${L('actual configured communication edges','实际配置的通信边')}</span><span>${L('Click an agent to inspect its loop. The opponent team has another 11 local loops.','点击球员检查其闭环；对方球队另有 11 个局部闭环。')}</span></div>`;
}
