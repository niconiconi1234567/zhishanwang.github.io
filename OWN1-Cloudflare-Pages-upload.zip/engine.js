// OWN1 numerical core, ported from the original 11-agent nominal configuration.
// All coordinates are world coordinates (x right, y up). No global centroid
// is read by step(); global quantities exist only in metrics().
export const N = 11;
export const ALPHA = 0.020, GAMMA = 0.20, KAPPA = 1;
export const REFERENCE = {c:[45,34],angle:0,length:10,width:8};
export const NOMINAL = [[22,39],[24,50],[37,37],[23,31],[40,18],[38,37],[54,31],[52,50],[69,40],[52,18],[73,28]];
export const FORMATION_EDGES = [[0,2,1.3],[0,3,1.3],[1,2,1.2],[2,3,1.4],[3,4,1.2],[2,5,1.4],[3,6,1.4],[1,5,1],[4,6,1],[5,6,1.3],[5,7,1],[5,8,1.2],[6,8,1.2],[6,9,1],[7,8,1.1],[8,9,1.1],[7,10,1],[8,10,1.4],[9,10,1]];
export const COMMUNICATION_EDGES = [[0,2],[0,3],[0,5],[0,6],[1,2],[1,5],[1,7],[2,3],[2,5],[2,6],[3,4],[3,5],[3,6],[4,6],[4,9],[5,6],[5,7],[5,8],[6,8],[6,9],[7,8],[7,10],[8,9],[8,10],[9,10]];
export const HALF_WIDTHS = [[.8,.8],[.9,.7],[.8,.7],[.8,.7],[.9,.7],[.9,.7],[.9,.7],[1,.7],[1,.8],[1,.7],[1,.8]];
export const TEMPLATES = {
  '4231':{label:'4–2–3–1',description:'双后腰连接前后场，保持中路支撑。',roles:['GK','LB','LCB','RCB','RB','LDM','RDM','LW','AM','RW','ST'],q:[[-3,0],[-1.3,2.625],[-1.5,1],[-1.5,-1],[-1.3,-2.625],[.1,1],[.1,-1],[1.6,2.625],[1.5,0],[1.6,-2.625],[3.7,0]]},
  '433':{label:'4–3–3',description:'三中场连接，双边锋提供横向空间。',roles:['GK','LB','LCB','RCB','RB','LCM','DM','LW','RCM','RW','ST'],q:[[-3,0],[-1.5,2.5],[-1.7,.85],[-1.7,-.85],[-1.5,-2.5],[.6,1.3],[-.2,0],[2.6,2.55],[.6,-1.3],[2.6,-2.55],[3.7,0]]},
  '442':{label:'4–4–2',description:'两条四人防线，双前锋保留前场接应。',roles:['GK','LB','LCB','RCB','RB','LCM','RCM','LM','LST','RM','RST'],q:[[-3,0],[-1.5,2.5],[-1.7,.85],[-1.7,-.85],[-1.5,-2.5],[.6,.85],[.6,-.85],[.8,2.6],[3.1,.8],[.8,-2.6],[3.1,-.8]]}
};
export const clone = p => p.map(v=>[...v]);
export const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
export const mean = p => p.reduce((s,v)=>[s[0]+v[0]/p.length,s[1]+v[1]/p.length],[0,0]);
const d2=(a,b)=>(a[0]-b[0])**2+(a[1]-b[1])**2;
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
export function convexHull(points){
  const p=points.map(a=>[...a]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  const unique=p.filter((a,i)=>!i||d2(a,p[i-1])>1e-20);
  if(unique.length<=2)return unique;
  const lower=[],upper=[];
  for(const a of unique){while(lower.length>=2&&cross(lower.at(-2),lower.at(-1),a)<=1e-12)lower.pop();lower.push(a);}
  for(const a of [...unique].reverse()){while(upper.length>=2&&cross(upper.at(-2),upper.at(-1),a)<=1e-12)upper.pop();upper.push(a);}
  return lower.slice(0,-1).concat(upper.slice(0,-1));
}
export function clipField(poly){
  let out=poly;
  for(const [axis,bound,sign] of [[0,0,1],[0,105,-1],[1,0,1],[1,68,-1]]){
    const input=out;out=[];
    for(let i=0;i<input.length;i++){
      const a=input[i],b=input[(i+1)%input.length],ia=(a[axis]-bound)*sign>=-1e-10,ib=(b[axis]-bound)*sign>=-1e-10;
      if(ia)out.push(a);
      if(ia!==ib){const t=(bound-a[axis])/(b[axis]-a[axis]);out.push([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])]);}
    }
  }
  return convexHull(out);
}
export function inside(p,poly,tolerance=1e-8){return poly.length>=3&&poly.every((a,i)=>cross(a,poly[(i+1)%poly.length],p)>=-tolerance);}
export function project(p,poly){
  if(inside(p,poly))return [...p];
  if(!poly.length)throw Error('Empty feasible polygon');
  let best=poly[0],distance=Infinity;
  for(let i=0;i<poly.length;i++){
    const a=poly[i],b=poly[(i+1)%poly.length],dx=b[0]-a[0],dy=b[1]-a[1];
    const t=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1),0,1);
    const v=[a[0]+t*dx,a[1]+t*dy],dd=d2(p,v);if(dd<distance){distance=dd;best=v;}
  }
  return [...best];
}
export function makePlan(formation,reference){
  const template=TEMPLATES[formation];
  const center=mean(template.q),qbar=template.q.map(p=>[p[0]-center[0],p[1]-center[1]]);
  let {length,width,angle}=reference;const theta=angle*Math.PI/180,cs=Math.cos(theta),sn=Math.sin(theta);
  const transform=p=>[cs*length*p[0]-sn*width*p[1],sn*length*p[0]+cs*width*p[1]];
  let offset=qbar.map(transform);
  let minX=Math.min(...offset.map(p=>p[0])),maxX=Math.max(...offset.map(p=>p[0])),minY=Math.min(...offset.map(p=>p[1])),maxY=Math.max(...offset.map(p=>p[1]));
  const fit=Math.min(1,101/(maxX-minX),64/(maxY-minY));
  length*=fit;width*=fit;offset=qbar.map(transform);
  minX=Math.min(...offset.map(p=>p[0]));maxX=Math.max(...offset.map(p=>p[0]));minY=Math.min(...offset.map(p=>p[1]));maxY=Math.max(...offset.map(p=>p[1]));
  const c=[clamp(reference.c[0],2-minX,103-maxX),clamp(reference.c[1],2-minY,66-maxY)];
  const q=offset.map(p=>[p[0]+c[0],p[1]+c[1]]);
  const regions=qbar.map((p,i)=>clipField([[-1,-1],[1,-1],[1,1],[-1,1]].map(([a,b])=>{
    const t=transform([p[0]+a*HALF_WIDTHS[i][0],p[1]+b*HALF_WIDTHS[i][1]]);return [c[0]+t[0],c[1]+t[1]];
  })));
  return {formation,roles:template.roles,q,regions,reference:{c,angle,length,width},span:[(Math.max(...qbar.map(p=>p[0]))-Math.min(...qbar.map(p=>p[0])))*length,(Math.max(...qbar.map(p=>p[1]))-Math.min(...qbar.map(p=>p[1])))*width],adjusted:fit<1||d2(c,reference.c)>1e-10};
}
export function createSimulation(plan,positions,{transition=false}={}){
  const p=clone(positions);
  const regions=plan.regions.map((poly,i)=>transition?convexHull([...poly,p[i]]):clone(poly));
  // In nominal mode the supplied positions must already be feasible.
  if(!p.every((v,i)=>inside(v,regions[i])))throw Error('Initial state is not feasible');
  return {p,chat:clone(p),q:clone(plan.q),c:[...plan.reference.c],regions,k:0};
}
export function step(s){
  const g=s.chat.map(c=>[KAPPA*(c[0]-s.c[0]),KAPPA*(c[1]-s.c[1])]);
  for(const [i,j,w] of FORMATION_EDGES){
    const ex=s.p[j][0]-s.p[i][0]-(s.q[j][0]-s.q[i][0]);
    const ey=s.p[j][1]-s.p[i][1]-(s.q[j][1]-s.q[i][1]);
    g[i][0]-=w*ex;g[i][1]-=w*ey;g[j][0]+=w*ex;g[j][1]+=w*ey;
  }
  const next=s.p.map((p,i)=>project([p[0]-ALPHA*g[i][0],p[1]-ALPHA*g[i][1]],s.regions[i]));
  const consensus=Array.from({length:N},()=>[0,0]);
  for(const [i,j] of COMMUNICATION_EDGES){for(let a=0;a<2;a++){const delta=s.chat[i][a]-s.chat[j][a];consensus[i][a]+=delta;consensus[j][a]-=delta;}}
  const chat=s.chat.map((c,i)=>c.map((v,a)=>v-GAMMA*consensus[i][a]+next[i][a]-s.p[i][a]));
  s.p=next;s.chat=chat;s.k++;return s;
}
export function metrics(positions,plan,chat=null){
  const cp=mean(positions),distances=positions.map((p,i)=>Math.sqrt(d2(p,plan.q[i])));
  const centroid=Math.sqrt(d2(cp,plan.reference.c));
  const error=Math.sqrt(distances.reduce((s,d)=>s+d*d,0));
  const estimator=chat?Math.sqrt(chat.reduce((s,c)=>s+d2(c,cp),0)):null;
  return {cp,distances,error,rmse:error/Math.sqrt(N),centroid,estimator,recovered:distances.filter(d=>d<=.5).length,maxError:Math.max(...distances)};
}
export function perturb(plan,strength=0.65,random=Math.random){
  return plan.q.map((p,i)=>{
    const poly=plan.regions[i],vertex=poly[Math.floor(random()*poly.length)],v2=poly[Math.floor(random()*poly.length)],r=random();
    const edgePoint=[vertex[0]*r+v2[0]*(1-r),vertex[1]*r+v2[1]*(1-r)];
    return [p[0]+strength*(edgePoint[0]-p[0]),p[1]+strength*(edgePoint[1]-p[1])];
  });
}
