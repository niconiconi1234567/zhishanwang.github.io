import {makePlan,mean,clamp,TEMPLATES,REFERENCE} from './engine.js';
export const PHASES={
  defend:{name:'防守',formation:'4231',intent:'收缩防线，保护中路'},
  attack:{name:'进攻',formation:'433',intent:'拉开宽度，创造前场接应'},
  counter:{name:'防守转进攻',formation:'433',intent:'向前展开，保留中场连接'},
  retreat:{name:'进攻转防守',formation:'442',intent:'快速回收，建立两道防线'}
};
export function opponentPreset(name){
  const config={balanced:['433',65,34,8.3,7.5],press:['433',49,34,8.1,7],block:['442',78,34,6.3,6.6],flank:['4231',61,46,7.5,5.1]}[name]??['433',65,34,8.3,7.5];
  const [formation,x,y,length,width]=config;
  const plan=makePlan(formation,{c:[105-x,y],angle:0,length,width});
  return plan.q.map(([px,py])=>[105-px,py]);
}
export function analyzeOpponents(opponents){
  const p=opponents.slice(1),c=mean(p);
  const sd=p.reduce((s,v)=>[s[0]+(v[0]-c[0])**2/p.length,s[1]+(v[1]-c[1])**2/p.length],[0,0]).map(Math.sqrt);
  return {c,sd,pressure:p.filter(v=>v[0]<48).length};
}
export function recommend(opponents,phase='defend',chosen='auto'){
  const info=analyzeOpponents(opponents),{c:[ox,oy],sd:[sx,sy],pressure}=info;
  let c,length,width,angle,reasons;
  const side=oy>36?'我方左路':oy<32?'我方右路':'中路';
  if(phase==='defend'){
    c=[clamp(ox-22,31,45),clamp(34+.45*(oy-34),25,43)];length=clamp(7.4+.035*(ox-55),6.5,8.2);width=clamp(5.6+.10*sy,5.8,8);
    angle=clamp(Math.atan2(oy-c[1],ox-c[0])*180/Math.PI,-12,12);
    reasons=[['保护纵深',`对手场上球员中心 x = ${ox.toFixed(1)} m；防线中心保持在其后方，压近时整体回收。`],['回应威胁侧',`对手重心位于${side}，我方横向跟随其偏移的 45%，并适度朝向威胁侧。`],['保持覆盖',`对手横向分布标准差 ${sy.toFixed(1)} m；据此调整宽度，双后腰提供中路支撑。`]];
  }else if(phase==='attack'){
    c=[clamp(ox-9,45,57),clamp(34-.30*(oy-34),27,41)];length=clamp(8.2+.035*sx,8.3,9.3);width=clamp(9.4-.06*sy,8.0,9.1);
    angle=clamp(Math.atan2(c[1]-34,45)*180/Math.PI,-10,10);
    reasons=[['向前建立支点',`根据对手中心 x = ${ox.toFixed(1)} m，前推我方中心，形成多层接应。`],['利用较空侧',`对手重心偏向${side}；我方以其横向偏移的 30% 向相反侧移动。`],['展开边路',`对手越集中，我方越拉开横向间距；三前锋提供纵深和边路接应。`]];
  }else if(phase==='counter'){
    c=[clamp(ox-13,40,53),clamp(34-.22*(oy-34),28,40)];length=clamp(8.6+.02*sx,8.6,9.5);width=7.5;
    angle=clamp(Math.atan2(c[1]-34,45)*180/Math.PI,-10,10);
    reasons=[['先纵向展开',`由防守站位向前推进，中心随对手位置取 ${c[0].toFixed(1)} m，增加前后接应层次。`],['避开密集侧',`对手重心位于${side}；我方向较空的一侧适度偏移。`],['保留连接',`宽度尺度固定为 7.5，避免转换开始时横向过度分散。`]];
  }else{
    c=[clamp(ox-25,29,41),clamp(34+.55*(oy-34),24,44)];length=6.8;width=clamp(5.6+.07*sy,6,7.3);
    angle=clamp(Math.atan2(oy-c[1],ox-c[0])*180/Math.PI,-12,12);
    reasons=[['回收保护',`对手有 ${pressure} 名场上球员进入 x < 48 m 区域；我方中心退至其后方。`],['封住威胁侧',`以对手横向偏移的 55% 调整重心，优先保护${side}。`],['压缩层间距',`采用更短的纵深尺度 6.8，形成紧凑的防守接应结构。`]];
  }
  const formation=chosen==='auto'?PHASES[phase].formation:chosen;
  if(formation!==PHASES[phase].formation)reasons[2][1]+=` 当前采用你指定的 ${TEMPLATES[formation].label} 模板。`;
  const plan=makePlan(formation,{c,angle,length,width});
  return {...plan,phase,info,reasons,manual:false,intent:PHASES[phase].intent};
}
export function baseline(formation='4231'){
  return {...makePlan(formation,REFERENCE),phase:'defend',manual:false,intent:'固定目标，观察分布式恢复',reasons:[['固定目标',`中心 (45, 34) m，朝向 0°，纵横尺度 (10, 8)。`],['局部交互',`19 条阵型关系约束形状，25 条通信连接用于估计质心。`],['角色约束',`我方拖动和扰动均保持在角色可行区域内；每一步由控制器重新计算。`]]};
}
export function roleDescription(role,phase){
  const defensive=phase==='defend'||phase==='retreat';
  if(role==='GK')return '门将角色位于后场中轴，通过两名中卫保持后场结构。这里是阵型控制抽象，未建模守门行为。';
  if(['LCB','RCB'].includes(role))return defensive?'保持后线紧凑，保护中路纵深，与门将、边后卫和中场维持连接。':'提供后场支点，随整体阵型前推，同时维持与中场的接应距离。';
  if(['LB','RB'].includes(role))return defensive?'保护侧翼与肋部，随威胁侧移动，与邻近中卫、中场协同。':'拓展侧翼接应空间，与中场保持层次，同时保留后场连接。';
  if(['DM','LDM','RDM'].includes(role))return defensive?'保护防线前方，连接中卫与前场球员，保持中路覆盖。':'提供中场回传支点，在进攻展开时保留前后场连接。';
  if(['LCM','RCM','AM'].includes(role))return defensive?'压缩中场空隙，连接防线与前场，随整体重心移动。':'在前后场之间提供接应，通过局部相对位置关系维持传递层次。';
  if(['LW','RW','LM','RM'].includes(role))return defensive?'回收保护边路，保持与中场和前锋的横向、纵向关系。':'拉开边路宽度，向较空侧提供接应点，与中央队友保持联系。';
  return defensive?'保留前场出口，与中场及另一侧队友保持联系，避免阵型断开。':'提供纵深支点，牵引前场队形，与边路和中场形成接应关系。';
}
export const RULE_TEXT='规则（夹取后还需满足场地边界）：防守 cx = clip(对手中心x − 22, 31, 45)，cy = 34 + 0.45·横向偏移；进攻 cx = clip(对手中心x − 9, 45, 57)，cy = 34 − 0.30·横向偏移；防转攻 cx = clip(对手中心x − 13, 40, 53)，cy = 34 − 0.22·横向偏移；攻转防 cx = clip(对手中心x − 25, 29, 41)，cy = 34 + 0.55·横向偏移。原始模板经去均值、缩放、旋转和平移生成目标；边界适配作用于整体参考，不逐人裁切目标。';
