export const copy=p=>p.map(v=>[...v]);
export const clone=o=>JSON.parse(JSON.stringify(o));
export const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
export const mean=p=>p.reduce((s,v)=>[s[0]+v[0]/p.length,s[1]+v[1]/p.length],[0,0]);
export const lineDistance=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1),0,1);return distance(p,[a[0]+t*dx,a[1]+t*dy]);};
