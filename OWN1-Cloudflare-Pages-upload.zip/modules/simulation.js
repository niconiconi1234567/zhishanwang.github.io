import {controlStep} from './controller.js';
import {passCandidates,ballAt,ballHeight} from './passing.js';
import {copy,clone,clamp,distance,mean} from './math.js';
import {ROLES,BASE_OWN,BASE_OPP,dt,baseConfig} from './config.js';
export function components(edges){const seen=new Set();let n=0;for(let i=0;i<11;i++){if(seen.has(i))continue;n++;const q=[i];seen.add(i);while(q.length){const a=q.pop();for(const[e,f]of edges){const b=e===a?f:f===a?e:-1;if(b>=0&&!seen.has(b)){seen.add(b);q.push(b);}}}}return n;}
export function newRun(snapshot,cfg){const s={own:copy(snapshot.own),opp:copy(snapshot.opp),chat:copy(snapshot.own),cfg:clone(cfg),template:copy(snapshot.template||BASE_OWN),oppBase:copy(snapshot.opp),oppChat:copy(snapshot.opp),oppCfg:baseConfig(),passMode:snapshot.passMode||'short',longCap:snapshot.longCap||42,holder:snapshot.holder,ball:[...snapshot.opp[snapshot.holder]],flight:null,t:0,hold:1.4,cap:snapshot.passCap,pattern:snapshot.pattern,passes:0,backpasses:0,forwardpasses:0,intercepts:0,heldClose:0,done:false,outcome:'未开始',decision:'准备判断出球选项',logs:[],distance:Array(11).fill(0),trails:snapshot.own.map(p=>[[...p]]),passHistory:[],pressers:[],support:[],target:copy(BASE_OWN),disturbances:clone(snapshot.disturbances||[]),perturbIndex:0,frozen:false,recoveryStart:null,settled:0,recovery:null,seed:73821,coverageSum:0,rmseSum:0,samples:0};s.target=targets(s);while(s.perturbIndex<s.disturbances.length&&s.disturbances[s.perturbIndex].t<=0){inject(s,s.disturbances[s.perturbIndex++].strength);}return s;}
export function log(s,text){s.logs.unshift({t:s.t,text});if(s.logs.length>20)s.logs.pop();s.decision=text;}
export function targetError(s){return Math.sqrt(s.own.reduce((sum,p,i)=>sum+distance(p,s.target[i])**2,0)/11);}
export function keyCoverage(s){let yes=0,n=0;for(let x=2.5;x<35;x+=5)for(let y=24;y<46;y+=4){n++;if(s.own.some(p=>distance(p,[x,y])<=8))yes++;}return yes/n*100;}
export function lineDistance(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],t=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1),0,1);return distance(p,[a[0]+t*dx,a[1]+t*dy]);}
export function targets(s){
  const g=s.cfg.aggression/100,b=s.ball,shiftX=clamp((b[0]-61)*.24,-8,7)+g*5-2.5,shiftY=clamp((b[1]-34)*.32,-8,8);
  const q=s.template.map((p,i)=>{if(i===0)return[8,clamp(34+shiftY*.5,28,40)];const d=s.cfg.duties[i],count=+d.D + +d.M + +d.A;const roleShift=count?((-4*+d.D)+(0*+d.M)+(4*+d.A))/count:0;return[clamp(p[0]+shiftX+roleShift,5,92),clamp(p[1]+shiftY,5,63)];});
  const eligible=s.own.map((p,i)=>({i,d:distance(p,b)})).filter(v=>v.i!==0&&(s.cfg.duties[v.i].D||s.cfg.duties[v.i].M)&&v.d<12+22*g).sort((a,b)=>a.d-b.d);
  s.pressers=eligible.slice(0,g>=.8?3:g>=.4?2:1).map(v=>v.i);
  s.pressers.forEach((i,k)=>{q[i]=[clamp(b[0]-1.3-k*.8,2,103),clamp(b[1]+(k===1?2.2:k===2?-2.2:0),2,66)];});
  const support=new Set();
  for(const i of s.pressers)for(const[a,c]of s.cfg.formation){const j=a===i?c:c===i?a:-1;if(j>0&&!s.pressers.includes(j)&&(s.cfg.duties[j].D||s.cfg.duties[j].M)){support.add(j);q[j][0]=clamp(q[j][0]+.15*(s.template[i][0]-q[j][0]),3,98);q[j][1]=clamp(q[j][1]+.12*(s.template[i][1]-q[j][1]),3,65);}}
  s.support=[...support];return q;
}
export function candidates(s){return passCandidates(s);}
export function choosePass(s){
 if(s.flight||s.done||s.frozen)return false;
 const chosen=candidates(s).find(v=>v.allowed);
 if(!chosen){s.hold=.7;log(s,'暂无安全出口，持球等待队友接应。');return false;}
 const from=[...s.opp[s.holder]],to=[...chosen.to];
 s.flight={...chosen.spec,from,to,fromId:s.holder,toId:chosen.i,elapsed:0,back:chosen.back,pressed:chosen.pressed,length:chosen.d,type:chosen.type,cap:chosen.cap};s.ball=from;s.heldClose=0;
 log(s,`${ROLES[s.holder]} → ${ROLES[chosen.i]} · ${chosen.spec.label} ${chosen.d.toFixed(1)} m · 初速 ${chosen.spec.v0} m/s · ${chosen.reason}`);return true;
}
export function moveDefenders(s){
 const next=controlStep(s.own,s.chat,s.target,s.cfg.formation,s.cfg.communication,{dt,maxSpeed:4.8});
 next.travel.forEach((d,i)=>s.distance[i]+=d);s.own=next.p;s.chat=next.chat;
}
export function moveAttackers(s){
 const base=s.oppBase,b=s.ball,q=base.map((p,i)=>i===0?[...p]:[clamp(p[0]+clamp((b[0]-61)*.18,-10,4),3,102),clamp(p[1]+(b[1]-34)*.09,3,65)]);
 // Receiver follows the kick-time target; support players offer short outlets.
 if(s.flight)q[s.flight.toId]=[...s.flight.to];else q[s.holder]=[...s.opp[s.holder]];
 for(let i=1;i<11;i++)if(i!==s.holder&&(!s.flight||i!==s.flight.toId)){
  const nearest=s.own.reduce((a,p)=>distance(p,s.opp[i])<distance(a,s.opp[i])?p:a,s.own[0]);
  if(distance(nearest,s.opp[i])<6)q[i][1]=clamp(q[i][1]+(s.opp[i][1]>=nearest[1]?2:-2),3,65);
 }
 const next=controlStep(s.opp,s.oppChat,q,s.oppCfg.formation,s.oppCfg.communication,{dt,maxSpeed:3.8});
 if(!s.flight){next.chat[s.holder][0]+=s.opp[s.holder][0]-next.p[s.holder][0];next.chat[s.holder][1]+=s.opp[s.holder][1]-next.p[s.holder][1];next.p[s.holder]=[...s.opp[s.holder]];}
 // Receive interception must remain physically reachable; direct final approach only near the target.
 if(s.flight){const i=s.flight.toId,p=s.opp[i],goal=s.flight.to,d=distance(p,goal),step=Math.min(d,3.8*dt),n=d>0?[p[0]+(goal[0]-p[0])*step/d,p[1]+(goal[1]-p[1])*step/d]:[...p];next.chat[i][0]+=n[0]-next.p[i][0];next.chat[i][1]+=n[1]-next.p[i][1];next.p[i]=n;}
 s.opp=next.p;s.oppChat=next.chat;
}
export function endRun(s,result){s.done=true;s.outcome=result;log(s,result);}
export function tick(s){
  if(s.done)return;
  while(s.perturbIndex<s.disturbances.length&&s.disturbances[s.perturbIndex].t<=s.t+1e-8){inject(s,s.disturbances[s.perturbIndex++].strength);}
  s.t+=dt;if(!s.frozen){moveAttackers(s);s.target=targets(s);}moveDefenders(s);
  if(s.frozen){if(targetError(s)<=.5)s.settled+=dt;else s.settled=0;if(s.recoveryStart!==null&&s.settled>=1&&s.recovery===null){s.recovery=s.t-s.recoveryStart;log(s,`固定任务恢复达到阈值，${s.recovery.toFixed(1)} s（本规则模型）`);}}
  else if(s.flight){
    const f=s.flight;f.elapsed=Math.min(f.duration,f.elapsed+dt);const old=[...s.ball];s.ball=ballAt(f,f.elapsed);s.ballZ=ballHeight(f,f.elapsed);
    const intercepted=s.ballZ<=1.7?s.own.findIndex(p=>lineDistance(p,old,s.ball)<1.0):-1;
    if(intercepted>=0){s.intercepts++;s.ball=[...s.own[intercepted]];s.flight=null;s.ballZ=0;endRun(s,`我方 ${intercepted+1}号线路拦截`);}
    else if(f.elapsed>=f.duration){
     const gap=distance(s.opp[f.toId],f.to);s.flight=null;s.ballZ=0;
     if(gap>2){endRun(s,'接球者未能到达落点');}
     else{s.holder=f.toId;s.ball=[...s.opp[s.holder]];s.passes++;if(f.back&&f.pressed)s.backpasses++;if(f.to[0]<f.from[0]-2)s.forwardpasses++;
      s.passHistory.push({length:f.length,cap:f.cap,back:f.back,from:f.fromId,to:f.toId,type:f.type,t:s.t});
      s.hold=.7+f.settle+f.length*.008;s.heldClose=0;log(s,`对手 ${s.holder+1}号 ${ROLES[s.holder]} 接球 · 停球调整 ${f.settle.toFixed(2)} s`);
      if(s.holder===10&&s.ball[0]<38)endRun(s,'对手完成前场接应');
     }
    }
  }else{
    s.ball=[...s.opp[s.holder]];const close=Math.min(...s.own.map(p=>distance(p,s.ball)));s.heldClose=close<1.35?s.heldClose+dt:0;
    if(s.heldClose>=.45)endRun(s,'我方逼抢夺回球权');else{s.hold-=dt;if(s.hold<=0)choosePass(s);}
  }
  const k=Math.round(s.t/dt);if(k%5===0)s.own.forEach((p,i)=>{if(s.trails[i].length<320)s.trails[i].push([...p]);});
  if(k%10===0){s.coverageSum+=keyCoverage(s);s.rmseSum+=targetError(s);s.samples++;}
  if(s.t>=60&&!s.done)endRun(s,s.frozen?'冻结恢复观察结束':'60 s 传导观察结束');
}
export function inject(s,strength){s.own=s.own.map((p,i)=>{s.seed=(s.seed*1664525+1013904223)>>>0;const a=s.seed/4294967296*Math.PI*2;s.seed=(s.seed*1664525+1013904223)>>>0;const r=strength*(.55+.45*s.seed/4294967296);const next=[clamp(p[0]+r*Math.cos(a),0,105),clamp(p[1]+r*Math.sin(a),0,68)];s.chat[i][0]+=next[0]-p[0];s.chat[i][1]+=next[1]-p[1];return next;});s.trails=s.own.map(p=>[[...p]]);s.recovery=null;s.settled=0;s.recoveryStart=s.frozen?s.t:null;log(s,`我方失位扰动：位移不超过 ${strength} m，不计作自主跑动`);}
