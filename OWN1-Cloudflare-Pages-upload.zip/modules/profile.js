import {clone} from './math.js';
export const STORAGE_KEY='own1.tactical-profile.v1';
export const MOTIVES={intent:'战术意图',shape:'阵型稳定',communication:'通信结构稳定',speed:'恢复速度',pressure:'压迫强度'};
const validFormation=new Set(['4231','433','442']);
const empty=()=>({schema:1,experiments:[],preferences:[],edits:{formation:0,communication:0,duty:0,aggression:0}});
let storageWarning='';
function finite(v,min=0,max=1e7){return typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;}
export function validRecord(r){return r&&typeof r==='object'&&['formation','defense'].includes(r.stage)&&validFormation.has(r.formation)&&typeof r.at==='string'&&r.at.length<40&&finite(r.aggression,0,100)&&finite(r.formationEdges,0,55)&&finite(r.communicationEdges,0,55)&&finite(r.commComponents,1,11)&&finite(r.crossRatio,0,1)&&finite(r.running)&&finite(r.rmse)&&finite(r.coverage,0,100)&&typeof r.outcome==='string'&&r.outcome.length<150;}
export function parseProfile(text){
 const raw=JSON.parse(text);if(raw?.schema!==1)throw Error('Unsupported profile version');
 const p=empty();p.experiments=(Array.isArray(raw.experiments)?raw.experiments:[]).filter(validRecord).slice(-100);
 p.preferences=(Array.isArray(raw.preferences)?raw.preferences:[]).filter(r=>validRecord(r)&&Object.hasOwn(MOTIVES,r.motive)).slice(-100);
 for(const k of Object.keys(p.edits))if(finite(raw.edits?.[k],0,1e7))p.edits[k]=raw.edits[k];return p;
}
let data=empty();
try{const text=globalThis.localStorage?.getItem(STORAGE_KEY);if(text)data=parseProfile(text);}catch{storageWarning='本设备存储不可用或旧记录无法读取；当前会话仍可使用，建议导出。';}
function changed(){try{globalThis.localStorage?.setItem(STORAGE_KEY,JSON.stringify(data));}catch{storageWarning='浏览器未允许保存；记录仅保留在本次会话，请导出。';}globalThis.document?.dispatchEvent(new CustomEvent('own1:profile-change'));}
export function getProfile(){return clone(data);}
export function getStorageWarning(){return storageWarning;}
export function noteEdit(kind){if(Object.hasOwn(data.edits,kind)){data.edits[kind]++;changed();}}
function normalize(record){return {stage:record.stage??'defense',formation:validFormation.has(record.formation)?record.formation:'4231',at:new Date().toISOString(),aggression:record.aggression??50,formationEdges:record.formationEdges??19,communicationEdges:record.communicationEdges??25,commComponents:record.commComponents??1,crossRatio:record.crossRatio??0,running:record.running??0,rmse:record.rmse??0,coverage:record.coverage??0,outcome:record.outcome??'完成',phase:record.phase??'defend'};}
export function recordExperiment(record){const r=normalize(record);if(!validRecord(r))return false;data.experiments.push(r);data.experiments=data.experiments.slice(-100);changed();return true;}
export function recordPreference(record,motive){if(!Object.hasOwn(MOTIVES,motive))return false;const r=normalize(record);if(!validRecord(r))return false;data.preferences.push({...r,motive});data.preferences=data.preferences.slice(-100);changed();return true;}
export function clearProfile(){data=empty();storageWarning='';try{globalThis.localStorage?.removeItem(STORAGE_KEY);}catch{}changed();}
export function summarizeProfile(p=getProfile()){
 const reasons=Object.fromEntries(Object.keys(MOTIVES).map(k=>[k,0]));for(const r of p.preferences)reasons[r.motive]++;
 const source=p.preferences.length?p.preferences:p.experiments,forms={'4231':0,'433':0,'442':0};for(const r of source)forms[r.formation]++;
 const n=source.length,avg=k=>n?source.reduce((s,r)=>s+r[k],0)/n:null;
 return {count:p.experiments.length,choices:p.preferences.length,reasons,forms,n,aggression:avg('aggression'),fEdges:avg('formationEdges'),cEdges:avg('communicationEdges'),cross:avg('crossRatio'),connected:source.filter(r=>r.commComponents===1).length,sufficient:p.preferences.length>=3,fromPreferences:p.preferences.length>0};
}
export function recordFromSimulation(s,scenario){
 const primary=i=>s.cfg.duties[i].D?'D':s.cfg.duties[i].M?'M':'A';
 return {stage:'defense',formation:scenario.formation||'4231',aggression:s.cfg.aggression,formationEdges:s.cfg.formation.length,communicationEdges:s.cfg.communication.length,commComponents:graphComponents(s.cfg.communication),crossRatio:s.cfg.formation.filter(([i,j])=>primary(i)!==primary(j)).length/Math.max(1,s.cfg.formation.length),running:s.distance.reduce((a,b)=>a+b,0),rmse:s.samples?s.rmseSum/s.samples:0,coverage:s.samples?s.coverageSum/s.samples:0,outcome:s.outcome};
}
function graphComponents(edges){const seen=new Set();let n=0;for(let i=0;i<11;i++){if(seen.has(i))continue;n++;const q=[i];seen.add(i);while(q.length){const a=q.pop();for(const[i,j]of edges){const b=i===a?j:j===a?i:-1;if(b>=0&&!seen.has(b)){seen.add(b);q.push(b);}}}}return n;}
