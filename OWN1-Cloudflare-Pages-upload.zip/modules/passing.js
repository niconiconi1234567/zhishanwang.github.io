import {clamp,distance,lineDistance} from './math.js';
import {PASS_EDGES} from './config.js';

// Transparent application parameters, not proprietary game values or fitted match data.
export const PASS_TYPES={
 ground:{label:'地面短传',v0:12,decel:.8,loft:0,settle:.30},
 driven:{label:'快速地面传球',v0:18,decel:1.1,loft:0,settle:.50},
 through:{label:'向空间直塞',v0:15,decel:.9,loft:0,settle:.40},
 lob:{label:'有限长传',v0:21,decel:.65,loft:3.8,settle:.75},
 cross:{label:'传中',v0:17,decel:.65,loft:2.8,settle:.65}
};
export function flightPlan(type,length){
 const p=PASS_TYPES[type],disc=p.v0*p.v0-2*p.decel*length;
 if(disc<=0)return null;
 const duration=(p.v0-Math.sqrt(disc))/p.decel;
 return {...p,duration,endSpeed:p.v0-p.decel*duration};
}
export const ballHeight=(f,t)=>4*f.loft*clamp(t/f.duration,0,1)*(1-clamp(t/f.duration,0,1));
export function ballAt(f,time){const travel=Math.min(f.length,f.v0*time-.5*f.decel*time*time),u=clamp(travel/(f.length||1),0,1);return[f.from[0]+u*(f.to[0]-f.from[0]),f.from[1]+u*(f.to[1]-f.from[1])];}
function offside(s,j){
 const line=[...s.own.map(p=>p[0])].sort((a,b)=>a-b)[1];
 return s.opp[j][0]<52.5&&s.opp[j][0]<Math.min(s.ball[0],line)-.2;
}
function interceptMargin(s,f){
 let margin=Infinity;
 for(let k=1;k<=14;k++){
  const t=f.duration*k/14;if(ballHeight(f,t)>1.7)continue;
  const p=ballAt(f,t);
  for(const d of s.own){const arrive=.28+Math.max(0,distance(d,p)-1)/4.8;margin=Math.min(margin,arrive-t);}
 }
 return margin;
}
export function passCandidates(s){
 const from=s.opp[s.holder],pressure=Math.min(...s.own.map(p=>distance(p,from))),pressed=pressure<8.5;
 const conventional=PASS_EDGES.filter(([a,b])=>a===s.holder||b===s.holder).map(([a,b])=>a===s.holder?b:a);
 const out=[];
 for(let j=0;j<11;j++){
  if(j===s.holder)continue;
  const common=conventional.includes(j),raw=s.opp[j],dist=distance(from,raw);
  if(!common&&s.passMode!=='mixed')continue;
  const types=common?['ground','driven']:[];
  if(common&&j>=7&&from[0]>raw[0]+2)types.push('through');
  if(s.passMode==='mixed'&&dist>24)types.push('lob');
  if((s.holder===7||s.holder===9)&&j===10)types.push('cross');
  for(const type of types){
   const isLong=type==='lob',to=[...raw];
   if(type==='through')to[0]=clamp(to[0]-3.5,2,103);
   const d=distance(from,to),limit=isLong?(s.longCap??42):s.cap;
   const spec=flightPlan(type,d);if(!spec)continue;
   const f={...spec,from,to,length:d},space=Math.min(...s.own.map(p=>distance(p,to))),margin=interceptMargin(s,f),lane=Math.min(...s.own.map(p=>lineDistance(p,from,to)));
   const back=to[0]>from[0]+2,long=d>limit+1e-8,off=offside(s,j),covered=space<2.1;
   const blocked=margin<-.08||(spec.loft===0&&lane<1.15);
   const receiverTime=Math.max(0,distance(raw,to)-1)/3.8;
   const unavailable=receiverTime>spec.duration+.3;
   const allowed=!long&&!off&&!covered&&!blocked&&!unavailable&&d>=3;
   const progress=from[0]-to[0];
   const pref=s.pattern==='middle'?[[2,5],[3,6],[5,8],[6,8],[8,7],[8,9],[7,10],[9,10]]:[[2,1],[3,4],[1,7],[4,9],[5,7],[6,9],[7,10],[9,10]];
   const route=pref.some(([a,b])=>a===s.holder&&b===j)?3:0;
   let score=progress*.14+Math.min(space,13)*.24+clamp(margin,-2,2)*2.0+route-d*.045;
   if(pressed)score+=back?4.8:Math.abs(progress)<3?2:0;
   if(type==='lob')score-=3.7; // No unconditional long-ball escape under pressure.
   if(type==='driven')score-=.6+spec.settle;
   if(type==='through')score+=.5;
   if(type==='cross'&&from[0]<45)score+=1.6;
   const last=s.passHistory.at(-1);if(last?.from===j&&s.t-last.t<8)score-=2;
   const reason=long?`超过 ${limit} m 上限`:off?'接球者处于越位位置':covered?'接球空间不足':blocked?'防守者可能先到线路':unavailable?'接球者赶不到落点':d<3?'距离过近':pressed&&back?'受压，安全回传':back?'回传重新组织':`${spec.label}，线路可用`;
   out.push({i:j,d,space,lane,margin,back,pressed,allowed,score,reason,type,to,spec,cap:limit});
  }
 }
 return out.sort((a,b)=>Number(b.allowed)-Number(a.allowed)||b.score-a.score);
}
