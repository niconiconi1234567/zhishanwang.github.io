import {controlStep} from './controller.js';
import {FORMATION,COMM} from './config.js';
import {convexHull,makePlan} from '../engine.js';
import {recordExperiment} from './profile.js';

  (()=>{
    const root=document.getElementById('own1-prototype');
    const el=id=>root.querySelector('#'+id),ns='http://www.w3.org/2000/svg';
    const node=(tag,attrs={})=>{const n=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,v);return n;};
    const copy=p=>p.map(v=>[...v]),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
    const avg=p=>p.reduce((s,v)=>[s[0]+v[0]/p.length,s[1]+v[1]/p.length],[0,0]);
    const edges=[[0,2],[0,3],[1,2],[2,3],[3,4],[2,5],[3,6],[1,5],[4,6],[5,6],[5,7],[5,8],[6,8],[6,9],[7,8],[8,9],[7,10],[8,10],[9,10]];
    const templates={
      '4231':{q:[[-3,0],[-1.3,2.625],[-1.5,1],[-1.5,-1],[-1.3,-2.625],[.1,1],[.1,-1],[1.6,2.625],[1.5,0],[1.6,-2.625],[3.7,0]],roles:['GK','LB','LCB','RCB','RB','LDM','RDM','LW','AM','RW','ST'],name:'4–2–3–1'},
      '433':{q:[[-3,0],[-1.5,2.5],[-1.7,.85],[-1.7,-.85],[-1.5,-2.5],[.6,1.3],[-.2,0],[2.6,2.55],[.6,-1.3],[2.6,-2.55],[3.7,0]],roles:['GK','LB','LCB','RCB','RB','LCM','DM','LW','RCM','RW','ST'],name:'4–3–3'},
      '442':{q:[[-3,0],[-1.5,2.5],[-1.7,.85],[-1.7,-.85],[-1.5,-2.5],[.6,.85],[.6,-.85],[.8,2.6],[3.1,.8],[.8,-2.6],[3.1,-.8]],roles:['GK','LB','LCB','RCB','RB','LCM','RCM','LM','LST','RM','RST'],name:'4–4–2'}
    };
    const phases={defend:{name:'防守 · 保护中路',formation:'4231'},attack:{name:'进攻 · 拉开空间',formation:'433'},counter:{name:'防守 → 进攻',formation:'433'},retreat:{name:'进攻 → 防守',formation:'442'}};
    function pose(formation,c=[45,34],angle=0,length=10,width=8){
      const t=templates[formation],mean=avg(t.q),a=angle*Math.PI/180;
      let o=t.q.map(v=>{const x=(v[0]-mean[0])*length,y=(v[1]-mean[1])*width;return [x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)];});
      const xs=o.map(v=>v[0]),ys=o.map(v=>v[1]);const scale=Math.min(1,101/(Math.max(...xs)-Math.min(...xs)),64/(Math.max(...ys)-Math.min(...ys)));
      o=o.map(v=>v.map(x=>x*scale));length*=scale;width*=scale;
      const cx=clamp(c[0],2-Math.min(...o.map(v=>v[0])),103-Math.max(...o.map(v=>v[0]))),cy=clamp(c[1],2-Math.min(...o.map(v=>v[1])),66-Math.max(...o.map(v=>v[1])));
      return {q:o.map(v=>[v[0]+cx,v[1]+cy]),formation,roles:t.roles,c:[cx,cy],angle,length,width,span:[(Math.max(...t.q.map(v=>v[0]))-Math.min(...t.q.map(v=>v[0])))*length,(Math.max(...t.q.map(v=>v[1]))-Math.min(...t.q.map(v=>v[1])))*width]};
    }
    function preset(name){const [f,x,y,l,w]={balanced:['433',65,34,8,7],press:['433',50,34,8,7],block:['442',77,34,6.2,6.5],flank:['4231',61,46,7.5,5.1]}[name];return pose(f,[105-x,y],0,l,w).q.map(v=>[105-v[0],v[1]]);}
    let own=copy(pose('4231').q),opponents=preset('balanced'),actions=Array(11).fill('hold'),plan=null,selected=null,drag=null,animation=null,frame=null,paths=own.map(p=>[[...p]]),totalDistance=0,eachDistance=Array(11).fill(0),perturbed=false,completed=false,baselineMetrics=null;
    let playerButtons={own:[],opponent:[]};
    const xy=p=>`${p[0]},${68-p[1]}`,line=p=>p.map((v,i)=>`${i?'L':'M'}${xy(v)}`).join(' ');
    const radius=()=>+el('tl-radius').value;
    function endpoint(i){const p=opponents[i],a=actions[i];return [clamp(p[0]+(a==='forward'?-12:0),0,105),clamp(p[1]+(a==='left'?12:a==='right'?-12:0),0,68)];}
    function measure(){
      const r=radius(),covered=p=>own.some(v=>dist(p,v)<=r),phase=el('tl-phase').value;
      const zones=Array.from({length:9},()=>({count:0,total:0}));let count=0,total=0,keyCount=0,keyTotal=0;
      for(let ix=0;ix<42;ix++)for(let iy=0;iy<28;iy++){
        const p=[(ix+.5)*105/42,(iy+.5)*68/28],yes=covered(p),zi=(2-Math.min(2,Math.floor(p[1]/(68/3))))*3+Math.min(2,Math.floor(p[0]/35));
        zones[zi].total++;if(yes)zones[zi].count++;total++;if(yes)count++;
        const key=(phase==='attack'||phase==='counter'?p[0]>=70:p[0]<35)&&Math.abs(p[1]-34)<68/6;
        if(key){keyTotal++;if(yes)keyCount++;}
      }
      const marking=opponents.slice(1).filter(covered).length;
      const routes=opponents.slice(1).filter((p,j)=>{const end=endpoint(j+1);return [0,.25,.5,.75,1].every(t=>covered([p[0]+t*(end[0]-p[0]),p[1]+t*(end[1]-p[1])]));}).length;
      const rmse=plan?Math.sqrt(own.reduce((s,p,i)=>s+dist(p,plan.q[i])**2,0)/11):null;
      return {coverage:count/total*100,keyCoverage:keyCount/(keyTotal||1)*100,marking,routes,rmse,zones};
    }
    function stop(){if(frame)cancelAnimationFrame(frame);frame=null;animation=null;el('tl-play').textContent='运行控制恢复';}
    function invalidate(){stop();completed=false;baselineMetrics=null;totalDistance=0;eachDistance.fill(0);paths=own.map(p=>[[...p]]);}
    function advise(){
      invalidate();perturbed=false;el('tl-recovery').textContent='未测试';el('tl-recovery-note').textContent='以控制迭代步数报告恢复';const phase=el('tl-phase').value,op=avg(opponents.slice(1)),f=el('tl-formation').value==='auto'?phases[phase].formation:el('tl-formation').value;
      const sy=Math.sqrt(opponents.slice(1).reduce((s,p)=>s+(p[1]-op[1])**2/10,0));
      let cx,cy,psi,length,width;
      if(phase==='defend'){cx=clamp(op[0]-22,31,45);cy=34+.45*(op[1]-34);length=7.5;width=clamp(5.6+.1*sy,5.8,8);psi=clamp((op[1]-34)*.6,-12,12);}
      else if(phase==='attack'){cx=clamp(op[0]-9,45,57);cy=34-.3*(op[1]-34);length=8.8;width=clamp(9.4-.06*sy,8,9.1);psi=clamp((cy-34)*.6,-10,10);}
      else if(phase==='counter'){cx=clamp(op[0]-13,40,53);cy=34-.22*(op[1]-34);length=9.2;width=7.5;psi=clamp((cy-34)*.6,-10,10);}
      else{cx=clamp(op[0]-25,29,41);cy=34+.55*(op[1]-34);length=6.8;width=clamp(5.6+.07*sy,6,7.3);psi=clamp((op[1]-34)*.6,-12,12);}
      plan=pose(f,[cx,cy],psi,length,width);el('tl-status').textContent='02 · 建议目标待执行';el('tl-play').disabled=false;
      el('tl-reference-title').textContent='建议参数 · '+templates[f].name;
      el('tl-intent').textContent=phases[phase].name;
      const side=op[1]>37?'偏左':op[1]<31?'偏右':'居中';
      el('tl-why').textContent=`对手重心 ${side} · 中心 (${op[0].toFixed(1)}, ${op[1].toFixed(1)}) m`;
      el('tl-role-text').textContent=phase==='defend'||phase==='retreat'?'任务规则示意：向威胁侧偏移，缩短纵深，优先保护后场中路。':'任务规则示意：向前展开，向相对空的一侧偏移，保留前后场接应。';
      render();
    }
    function renderPitch(){
      const heat=el('tl-heat');heat.replaceChildren();
      if(el('tl-layer-cover').checked)for(let ix=0;ix<21;ix++)for(let iy=0;iy<14;iy++){
        const p=[(ix+.5)*5,(iy+.5)*68/14];if(own.some(v=>dist(v,p)<=radius()))heat.append(node('rect',{x:ix*5,y:68-(iy+1)*68/14,width:5,height:68/14,fill:'#c9e79d',opacity:.19}));
      }
      const goal=el('tl-targets');goal.replaceChildren();if(plan&&el('tl-layer-target').checked){for(const p of plan.q)goal.append(node('circle',{cx:p[0],cy:68-p[1],r:1.9,fill:'none',stroke:'#e0ed9f','stroke-width':.25,'stroke-dasharray':'.7 .45'}));goal.append(node('path',{d:`M${plan.c[0]-.8} ${68-plan.c[1]}h1.6M${plan.c[0]} ${68-plan.c[1]-.8}v1.6`,stroke:'#e0ed9f','stroke-width':.3}));}
      const regions=el('tl-responsibilities');regions.replaceChildren();
      if(plan&&(el('tl-layer-role').checked||selected?.team==='own'))for(let i=0;i<11;i++){
        if(el('tl-layer-role').checked||selected.i===i){const p=plan.q[i],a=plan.angle*Math.PI/180,hw=.85*plan.length,hh=.7*plan.width;
          const poly=[[-hw,-hh],[hw,-hh],[hw,hh],[-hw,hh]].map(([x,y])=>[clamp(p[0]+Math.cos(a)*x-Math.sin(a)*y,0,105),clamp(p[1]+Math.sin(a)*x+Math.cos(a)*y,0,68)]);
          regions.append(node('polygon',{points:poly.map(xy).join(' '),fill:'#d4e6a6','fill-opacity':selected?.team==='own'&&selected.i===i?.15:.04,stroke:'#d4e6a6','stroke-width':.14,'stroke-opacity':.6}));}
      }
      const links=el('tl-relations');links.replaceChildren();if(el('tl-layer-links').checked)for(const [i,j]of edges)links.append(node('path',{d:line([own[i],own[j]]),stroke:'#a2e9df','stroke-width':selected?.team==='own'&&(selected.i===i||selected.i===j)?.3:.15,opacity:.5,fill:'none'}));
      const traces=el('tl-traces');traces.replaceChildren();for(const p of paths)if(p.length>1)traces.append(node('path',{d:line(p),stroke:'#a2e9df','stroke-width':.19,fill:'none',opacity:.65}));
      const acts=el('tl-opponent-actions');acts.replaceChildren();if(el('tl-layer-actions').checked)for(let i=1;i<11;i++)if(actions[i]!=='hold')acts.append(node('path',{d:line([opponents[i],endpoint(i)]),fill:'none',stroke:'#f4a28b','stroke-width':.28,'stroke-dasharray':'1 .7','marker-end':'url(#tl-arrow)'}));
      for(const team of ['own','opponent']){
        const pts=team==='own'?own:opponents;
        pts.forEach((p,i)=>{const b=playerButtons[team][i];b.style.left=`${(p[0]+4)/113*100}%`;b.style.top=`${(72-p[1])/76*100}%`;b.classList.toggle('tl-selected',selected?.team===team&&selected.i===i);b.setAttribute('aria-label',`${team==='own'?'我方':'对手'}${i+1}号${team==='own'?' '+(plan?.roles[i]??templates['4231'].roles[i]):''}，${p[0].toFixed(1)}, ${p[1].toFixed(1)} 米`);});
      }
    }
    function renderMetrics(){
      const m=measure();el('tl-cover').textContent=m.coverage.toFixed(1);el('tl-key-cover').textContent=m.keyCoverage.toFixed(1);el('tl-marking').textContent=m.marking;el('tl-actions-covered').textContent=m.routes;el('tl-rmse').textContent=m.rmse===null?'—':m.rmse.toFixed(2);el('tl-distance').textContent=totalDistance.toFixed(1);
      el('tl-key-name').textContent=['attack','counter'].includes(el('tl-phase').value)?'前场中路覆盖':'后场中路覆盖';
      el('tl-distance-note').textContent=`控制路径累计 · 单人最大 ${Math.max(...eachDistance).toFixed(1)} m`;
      el('tl-comparison').textContent=completed&&baselineMetrics?`调整前覆盖 ${baselineMetrics.coverage.toFixed(1)}% → 当前 ${m.coverage.toFixed(1)}%`:'当前站位 · 无综合评分';
      const zoneNames=['后场左路','中场左路','前场左路','后场中路','中场中路','前场中路','后场右路','中场右路','前场右路'];
      el('tl-zones').replaceChildren(...m.zones.map((v,i)=>{const d=document.createElement('div');d.className='tl-zone';const a=document.createElement('span'),b=document.createElement('strong');a.textContent=zoneNames[i];b.textContent=(v.count/v.total*100).toFixed(0)+'%';d.append(a,b);return d;}));
      el('tl-assignment').replaceChildren(...opponents.slice(1).map((p,i)=>{const ds=own.map(q=>dist(p,q)),d=Math.min(...ds),j=ds.indexOf(d),box=document.createElement('div');box.className='tl-match'+(d<=radius()?' covered':'');const a=document.createElement('span'),b=document.createElement('strong'),c=document.createElement('small');a.textContent='对手 '+(i+2);b.textContent='我方 '+(j+1);c.textContent=d.toFixed(1)+' m';box.append(a,b,c);return box;}));
    }
    function renderSelection(){
      el('tl-selected-player').value=selected?selected.team+':'+selected.i:'';
      el('tl-action-label').hidden=selected?.team!=='opponent'||selected.i===0;
      if(!selected){el('tl-selected-info').textContent='点击球员查看角色、责任区域与战术邻居';return;}
      const {team,i}=selected;
      if(team==='opponent'){el('tl-action').value=actions[i];el('tl-selected-info').textContent=`对手 ${i+1}号${i===0?' · 门将（不计入对手覆盖指标）':' · 在右侧设置下一步动作'}`;}
      else{const roles=plan?.roles??templates['4231'].roles,neighbors=edges.filter(([a,b])=>a===i||b===i).map(([a,b])=>roles[a===i?b:a]);el('tl-selected-info').textContent=`我方 ${i+1}号 ${roles[i]} · 协同 ${neighbors.join(' / ')}${plan?' · 浅色区域为责任区':''}`;}
    }
    function render(){
      renderPitch();renderMetrics();renderSelection();
      if(plan){el('tl-center').textContent=`${plan.c[0].toFixed(1)}, ${plan.c[1].toFixed(1)} m`;el('tl-angle').textContent=plan.angle.toFixed(1)+'°';el('tl-size').textContent=`${plan.span[0].toFixed(1)} × ${plan.span[1].toFixed(1)} m`;
        for(const [id,v]of [['tl-cx',plan.c[0]],['tl-cy',plan.c[1]],['tl-psi',plan.angle],['tl-length',plan.length],['tl-width',plan.width]])el(id).value=v;
      }else{el('tl-center').textContent='待生成';el('tl-angle').textContent='—';el('tl-size').textContent='—';}
    }
    function pointer(event){const rect=el('tl-field').getBoundingClientRect();return [clamp((event.clientX-rect.left)/rect.width*113-4,0,105),clamp(72-(event.clientY-rect.top)/rect.height*76,0,68)];}
    function edited(team){invalidate();if(team==='opponent'){plan=null;el('tl-play').disabled=true;el('tl-status').textContent='01 · 对手局面已改变';el('tl-why').textContent='重新生成建议';}else{el('tl-status').textContent='我方位置已调整';if(plan)el('tl-play').disabled=false;}render();}
    for(const team of ['own','opponent'])for(let i=0;i<11;i++){
      const b=document.createElement('button');b.type='button';b.className='tl-player';b.dataset.team=team;b.textContent=i+1;
      b.addEventListener('pointerdown',event=>{if(event.button!==0||drag)return;event.preventDefault();stop();selected={team,i};b.focus({preventScroll:true});const p=pointer(event),v=(team==='own'?own:opponents)[i];drag={team,i,id:event.pointerId,b,offset:[v[0]-p[0],v[1]-p[1]],moved:false};b.setPointerCapture(event.pointerId);render();});
      b.addEventListener('focus',()=>{selected={team,i};renderSelection();renderPitch();});
      b.addEventListener('keydown',event=>{if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();const p=(team==='own'?own:opponents)[i],d=event.shiftKey?3:1;if(event.key==='ArrowLeft')p[0]-=d;if(event.key==='ArrowRight')p[0]+=d;if(event.key==='ArrowUp')p[1]+=d;if(event.key==='ArrowDown')p[1]-=d;p[0]=clamp(p[0],0,105);p[1]=clamp(p[1],0,68);selected={team,i};edited(team);});
      el('tl-players').append(b);playerButtons[team].push(b);
      const option=document.createElement('option');option.value=team+':'+i;option.textContent=(team==='own'?'我方':'对手')+' '+(i+1)+'号';el('tl-selected-player').append(option);
    }
    root.addEventListener('pointermove',event=>{if(!drag||event.pointerId!==drag.id)return;event.preventDefault();const p=pointer(event);(drag.team==='own'?own:opponents)[drag.i]=[clamp(p[0]+drag.offset[0],0,105),clamp(p[1]+drag.offset[1],0,68)];drag.moved=true;renderPitch();renderMetrics();},{passive:false});
    const finish=event=>{if(!drag||event.pointerId!==drag.id)return;const d=drag;drag=null;if(d.b.hasPointerCapture(event.pointerId))d.b.releasePointerCapture(event.pointerId);if(d.moved)edited(d.team);};root.addEventListener('pointerup',finish);root.addEventListener('pointercancel',finish);
    for(const id of ['tl-phase','tl-formation'])el(id).addEventListener('change',()=>{invalidate();plan=null;el('tl-play').disabled=true;el('tl-status').textContent='01 · 战术任务已改变';el('tl-intent').textContent=phases[el('tl-phase').value].name;el('tl-why').textContent='点击生成建议阵型';render();});
    el('tl-preset').addEventListener('change',()=>{opponents=preset(el('tl-preset').value);actions.fill('hold');edited('opponent');});
    el('tl-action').addEventListener('change',()=>{if(selected?.team==='opponent'){actions[selected.i]=el('tl-action').value;render();}});
    el('tl-selected-player').addEventListener('change',()=>{const value=el('tl-selected-player').value;if(value){const [team,i]=value.split(':');selected={team,i:+i};}else selected=null;renderSelection();renderPitch();});
    for(const id of ['tl-layer-target','tl-layer-cover','tl-layer-role','tl-layer-links','tl-layer-actions'])el(id).addEventListener('change',renderPitch);
    el('tl-radius').addEventListener('change',()=>{baselineMetrics=null;render();});
    for(const id of ['tl-cx','tl-cy','tl-psi','tl-length','tl-width'])el(id).addEventListener('input',()=>{invalidate();const f=plan?.formation??(el('tl-formation').value==='auto'?phases[el('tl-phase').value].formation:el('tl-formation').value);plan=pose(f,[+el('tl-cx').value,+el('tl-cy').value],+el('tl-psi').value,+el('tl-length').value,+el('tl-width').value);el('tl-play').disabled=false;el('tl-status').textContent='02 · 手动目标待执行';el('tl-why').textContent='用户指定参考参数';el('tl-role-text').textContent='中心、朝向与尺度由用户调整；目标整体适配场地边界。';render();});
    el('tl-generate').addEventListener('click',advise);
    el('tl-play').addEventListener('click',()=>{
      if(animation){stop();el('tl-status').textContent='控制恢复已暂停';return;}
      if(!plan)return;baselineMetrics=measure();completed=false;
      const reference=makePlan(plan.formation,{c:plan.c,angle:plan.angle,length:plan.length,width:plan.width});
      const regions=reference.regions.map((poly,i)=>convexHull([...poly,own[i]]));
      let chat=copy(own),iteration=0;animation={active:true};el('tl-play').textContent='暂停恢复';
      const advance=()=>{
        if(!animation)return;
        for(let k=0;k<4;k++){const next=controlStep(own,chat,plan.q,FORMATION,COMM,{gamma:.20,regions});own=next.p;chat=next.chat;iteration++;
          next.travel.forEach((d,i)=>{totalDistance+=d;eachDistance[i]+=d;});
        }
        if(iteration%8===0)own.forEach((p,i)=>paths[i].push([...p]));
        renderPitch();renderMetrics();const error=Math.sqrt(own.reduce((v,p,i)=>v+dist(p,plan.q[i])**2,0)/11);
        el('tl-status').textContent=`OWN1 控制恢复 · k = ${iteration}`;
        if(error>.03&&iteration<1200){frame=requestAnimationFrame(advance);return;}
        animation=null;frame=null;completed=true;el('tl-play').textContent='运行控制恢复';el('tl-play').disabled=true;
        el('tl-status').textContent=error<=.03?'控制恢复完成':'达到迭代上限';el('tl-recovery').textContent=iteration+' 步';el('tl-recovery-note').textContent='固定目标控制迭代，不换算为真实球员恢复时间';
        recordExperiment({stage:'formation',formation:plan.formation,phase:el('tl-phase').value,running:totalDistance,rmse:error,coverage:measure().coverage,outcome:error<=.03?'固定目标恢复完成':'达到迭代上限'});render();
      };frame=requestAnimationFrame(advance);
    });
    document.getElementById('s-import-stage1').addEventListener('click',()=>{stop();document.dispatchEvent(new CustomEvent('own1:scenario',{detail:{own:copy(own),opp:copy(opponents),template:copy(plan?.q??own),formation:plan?.formation??'4231',roles:plan?.roles??templates['4231'].roles}}));});
    document.addEventListener('own1:stage',e=>{if(e.detail!==1)stop();});
    el('tl-perturb').addEventListener('click',()=>{invalidate();if(!plan)plan=pose('4231');own=own.map(p=>[clamp(p[0]+(Math.random()-.5)*18,0,105),clamp(p[1]+(Math.random()-.5)*14,0,68)]);paths=own.map(p=>[[...p]]);perturbed=true;el('tl-recovery').textContent='已扰动';el('tl-recovery-note').textContent='等待固定目标控制恢复';el('tl-status').textContent='扰动已施加 · 可运行控制恢复';el('tl-play').disabled=false;render();});
    el('tl-reset').addEventListener('click',()=>{invalidate();own=copy(pose('4231').q);opponents=preset('balanced');actions.fill('hold');plan=null;selected=null;perturbed=false;completed=false;paths=own.map(p=>[[...p]]);el('tl-phase').value='defend';el('tl-formation').value='auto';el('tl-preset').value='balanced';el('tl-play').disabled=true;el('tl-status').textContent='01 · 布置局面';el('tl-recovery').textContent='未测试';el('tl-recovery-note').textContent='以控制迭代步数报告恢复';el('tl-reference-title').textContent='建议参数';el('tl-intent').textContent='防守 · 保护中路';el('tl-why').textContent='等待根据对手局面生成';el('tl-role-text').textContent='关系层：角色区域 + 战术邻居；执行层：OWN1 局部关系与质心估计';render();});
    render();

})();
