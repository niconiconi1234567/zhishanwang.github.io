import {MOTIVES,getProfile,getStorageWarning,summarizeProfile,clearProfile} from './profile.js';
const $=id=>document.getElementById(id);
function text(tag,value){const n=document.createElement(tag);n.textContent=value;return n;}
export function renderProfile(){
 const p=getProfile(),s=summarizeProfile(p);$('p-count').textContent=`${s.count} 次完成实验 · ${s.choices} 次主动选择`;
 $('p-evidence').textContent=s.sufficient?'已有多次主动取舍记录；以下描述仅适用于本网站内的战术偏好。':'偏好证据不足：完成实验后，选择你更看重的维度并保留战术；至少 3 次主动选择后形成初步画像。';
 $('p-storage').textContent=getStorageWarning()||'记录保存在此浏览器，可导出和清除；换设备不会自动同步。';
 $('p-reasons').replaceChildren(...Object.entries(MOTIVES).map(([k,label])=>{
  const row=document.createElement('div');row.className='p-reason';const h=text('div',`${label} · ${s.reasons[k]} 次`),track=document.createElement('div'),bar=document.createElement('span');track.className='p-track';bar.style.width=`${s.choices?s.reasons[k]/s.choices*100:0}%`;track.append(bar);row.append(h,track);return row;
 }));
 const ranked=Object.entries(s.forms).sort((a,b)=>b[1]-a[1]);const names={'4231':'4–2–3–1','433':'4–3–3','442':'4–4–2'};
 $('p-formation').textContent=s.n?`${names[ranked[0][0]]} · ${ranked[0][1]} / ${s.n} 次`:'尚无记录';
 $('p-formation-note').textContent=s.fromPreferences?'来自你主动保留的战术':'目前显示使用频次，不代表喜爱程度';
 $('p-style').textContent=s.aggression===null?'尚无记录':`${s.aggression.toFixed(0)} / 100 · ${s.aggression<35?'较保守':s.aggression<75?'中等压迫':'较强压迫'}`;
 $('p-links').textContent=s.n?`战术边 ${s.fEdges.toFixed(1)} · 通信边 ${s.cEdges.toFixed(1)}`:'尚无记录';
 $('p-cross').textContent=s.n?`跨职责战术边 ${(s.cross*100).toFixed(0)}% · 通信连通 ${s.connected}/${s.n} 次`:'完成实验后显示协作结构';
 $('p-edit-count').textContent=`战术连接编辑 ${p.edits.formation} 次 · 通信编辑 ${p.edits.communication} 次 · 职责编辑 ${p.edits.duty} 次`;
 const max=Math.max(...Object.values(s.reasons));const leaders=Object.entries(s.reasons).filter(([,n])=>n===max).map(([k])=>MOTIVES[k]);
 $('p-summary').textContent=s.sufficient?`在 ${s.choices} 次主动取舍中，你最常选择的关注点是${leaders.join('、')}。${s.connected===s.n?'保留的通信图均连通。':''} 这反映实验内的选择，不是人格或能力评分。`:'先试几种阵型与连接方式，再比较它们的运行结果。';
 $('p-history').replaceChildren(...p.experiments.slice(-8).reverse().map(r=>{const tr=document.createElement('tr');for(const value of [new Date(r.at).toLocaleDateString('zh-CN'),r.stage==='formation'?'阵型恢复':'带球防守',names[r.formation],r.outcome])tr.append(text('td',value));return tr;}));
 $('p-empty').hidden=p.experiments.length>0;$('p-history-table').hidden=!p.experiments.length;
}
document.addEventListener('own1:profile-change',renderProfile);
document.addEventListener('DOMContentLoaded',renderProfile);
export function initProfile(){
 $('p-export').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(getProfile(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='own1-tactical-profile.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
 $('p-clear').addEventListener('click',()=>{if(confirm('清除本浏览器内的战术画像与实验记录？'))clearProfile();});renderProfile();
}
