import {mean,distance,clamp} from './math.js';
import {project} from '../engine.js';

/** OWN1 local relational gradient + dynamic average estimator.
 * q and its centroid are the shared reference; actual team mean is never fed back.
 * All position and estimator updates are synchronous. Dynamic targets and speed
 * limits are application extensions, not covered by the nominal theorem.
 */
export function controlStep(p,chat,q,formation,communication,options={}){
 const {alpha=.020,kappa=1,dt=.04,maxSpeed=Infinity,regions=null}=options;
 const c=mean(q),g=chat.map(v=>[kappa*(v[0]-c[0]),kappa*(v[1]-c[1])]);
 for(const[i,j,w=1]of formation)for(let a=0;a<2;a++){
  const e=(p[i][a]-p[j][a])-(q[i][a]-q[j][a]);g[i][a]+=w*e;g[j][a]-=w*e;
 }
 const next=p.map((v,i)=>{
  let delta=g[i].map(x=>-alpha*x);const length=Math.hypot(...delta),cap=(i===0&&Number.isFinite(maxSpeed)?Math.min(maxSpeed,3):maxSpeed)*dt;
  if(length>cap)delta=delta.map(x=>x*cap/length);
  const point=[v[0]+delta[0],v[1]+delta[1]];
  return regions?project(point,regions[i]):[clamp(point[0],0,105),clamp(point[1],0,68)];
 });
 const consensus=p.map(()=>[0,0]),degree=p.map(()=>0);
 for(const[i,j]of communication){degree[i]++;degree[j]++;for(let a=0;a<2;a++){const d=chat[i][a]-chat[j][a];consensus[i][a]+=d;consensus[j][a]-=d;}}
 const gamma=options.gamma??.85/Math.max(1,...degree);
 return {p:next,chat:chat.map((v,i)=>v.map((x,a)=>x-gamma*consensus[i][a]+next[i][a]-p[i][a])),travel:next.map((v,i)=>distance(v,p[i]))};
}
