try {
 await import('./modules/stage-one.js');
 await import('./modules/lab.js');
} catch (error) {
 const message=document.createElement('p');message.className='fatal-notice';message.setAttribute('role','alert');
 message.textContent='实验室未能完整加载。请刷新页面；若问题持续，请保留本设备记录并反馈出现问题的步骤。';
 document.body.prepend(message);console.error('OWN1 initialization failed',error);
}
